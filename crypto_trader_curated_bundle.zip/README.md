# AI Smart Trader

AI Smart Trader is an advanced cryptocurrency trading platform with AI-powered analysis, visual strategy building, and automated trading capabilities.

## Features

- **Visual Strategy Builder**: Create trading strategies with a drag-and-drop interface
- **AI-Powered Analysis**: Machine learning models for price prediction and pattern recognition
- **Backtesting Engine**: Test strategies on historical data
- **Automated Trading**: Deploy strategies for real-time execution
- **Real-Time Market Data**: OHLCV, order books, and trades
- **Portfolio Management**: Track performance and manage risk

## Architecture

The platform consists of:

- **Frontend**: Next.js 14+ with React and TypeScript
- **Backend**: FastAPI with SQLAlchemy and Pydantic
- **Databases**: PostgreSQL, TimescaleDB, and Redis
- **Monitoring**: Prometheus and Grafana

## Getting Started

### Prerequisites

- Docker and Docker Compose
- Node.js 18+ (for local development)
- Python 3.10+ (for local development)

### Installation

1. Clone the repository:

```bash
git clone https://github.com/yourusername/aismart-trader.git
cd aismart-trader
```

2. Start the platform using Docker:

```bash
chmod +x docker-build.sh
./docker-build.sh
```

3. Access the platform:

- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/docs
- PgAdmin: http://localhost:5050 (admin@aismart.com / admin)

### Local Development

#### Frontend

```bash
npm install
npm run dev
```

#### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Visual Strategy Builder

The visual strategy builder allows you to create trading strategies without coding:

1. Drag components from the panel onto the canvas
2. Connect components to create a strategy flow
3. Configure component parameters
4. Backtest the strategy on historical data
5. Deploy the strategy for automated trading

Components include:

- Technical indicators (RSI, MACD, Bollinger Bands, etc.)
- Chart patterns (Head & Shoulders, Double Top/Bottom, etc.)
- Smart Money concepts (Order Blocks, Liquidity Zones, etc.)
- ML predictions
- Sentiment analysis
- Whale activity tracking

## Future Enhancements

- **Advanced ML Models**: Deep learning for price prediction
- **Sentiment Analysis**: News and social media integration
- **Market Regime Detection**: Automatic market condition classification
- **Portfolio Optimization**: Kelly criterion and modern portfolio theory
- **Risk Management**: Advanced position sizing and drawdown control
- **Social Trading**: Strategy sharing and following
- **Mobile App**: Trading on the go

## Directory Structure

- `src/`: Frontend code
- `backend/`: Backend code
- `database/`: Database configuration
- `monitoring/`: Monitoring configuration
- `.kiro/`: Kiro IDE configuration

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -am 'Add my feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
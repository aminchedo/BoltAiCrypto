import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Settings, 
  X, 
  Maximize2, 
  Minimize2, 
  Sliders, 
  Save, 
  RefreshCw, 
  Brain, 
  Target, 
  Activity, 
  Zap, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle, 
  AlertTriangle 
} from 'lucide-react';

interface AIModelConfigurationModuleProps {
  isOpen: boolean;
  onClose: () => void;
  initialModel?: string;
}

interface ModelParameter {
  id: string;
  name: string;
  description: string;
  type: 'number' | 'boolean' | 'select' | 'range';
  value: any;
  defaultValue: any;
  min?: number;
  max?: number;
  step?: number;
  options?: { value: string; label: string }[];
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  type: string;
  parameters: ModelParameter[];
  performance: {
    accuracy: number;
    winRate: number;
    profitFactor: number;
  };
}

// Import models from a separate file to keep this component smaller
import { aiModels } from './data/aiModels';

export function AIModelConfigurationModule({ 
  isOpen, 
  onClose, 
  initialModel = 'neural-alpha' 
}: AIModelConfigurationModuleProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedModel, setSelectedModel] = useState(initialModel);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(['basic']);
  const [models, setModels] = useState<AIModel[]>(aiModels);

  useEffect(() => {
    if (initialModel) {
      setSelectedModel(initialModel);
    }
  }, [initialModel]);

  const currentModel = models.find(m => m.id === selectedModel) || models[0];

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section)
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const handleParameterChange = (parameterId: string, value: any) => {
    setModels(prev => prev.map(model => {
      if (model.id === selectedModel) {
        return {
          ...model,
          parameters: model.parameters.map(param => {
            if (param.id === parameterId) {
              return { ...param, value };
            }
            return param;
          })
        };
      }
      return model;
    }));
  };

  const handleResetToDefaults = () => {
    setModels(prev => prev.map(model => {
      if (model.id === selectedModel) {
        return {
          ...model,
          parameters: model.parameters.map(param => ({
            ...param,
            value: param.defaultValue
          }))
        };
      }
      return model;
    }));
  };

  const handleSaveConfiguration = async () => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSaving(false);
    setSaveSuccess(true);
    
    // Reset success message after 3 seconds
    setTimeout(() => {
      setSaveSuccess(false);
    }, 3000);
  };

  const renderParameterInput = (parameter: ModelParameter) => {
    switch (parameter.type) {
      case 'number':
        return (
          <input
            type="number"
            value={parameter.value}
            onChange={(e) => handleParameterChange(parameter.id, Number(e.target.value))}
            min={parameter.min}
            max={parameter.max}
            step={parameter.step || 1}
            className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
          />
        );
      case 'boolean':
        return (
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={parameter.value}
              onChange={(e) => handleParameterChange(parameter.id, e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        );
      case 'range':
        return (
          <div className="space-y-1">
            <input
              type="range"
              value={parameter.value}
              onChange={(e) => handleParameterChange(parameter.id, Number(e.target.value))}
              min={parameter.min}
              max={parameter.max}
              step={parameter.step || 0.1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-400">
              <span>{parameter.min}</span>
              <span>{parameter.value}</span>
              <span>{parameter.max}</span>
            </div>
          </div>
        );
      case 'select':
        return (
          <select
            value={parameter.value}
            onChange={(e) => handleParameterChange(parameter.id, e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
          >
            {parameter.options?.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        );
      default:
        return null;
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className={`bg-gray-900 rounded-2xl border border-gray-700 shadow-2xl overflow-hidden ${
            isFullscreen ? 'w-full h-full' : 'w-[95vw] h-[90vh] max-w-7xl'
          }`}
        >
          {/* Header */}
          <div className="bg-gray-800/50 border-b border-gray-700 p-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500">
                <Settings className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">AI Model Configuration</h2>
                <p className="text-sm text-gray-400">Customize AI model parameters for optimal performance</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              >
                {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
              </button>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex h-[calc(100%-4rem)]">
            {/* Model Selection Panel */}
            <div className="w-80 bg-gray-800/30 border-r border-gray-700 p-4 overflow-y-auto">
              <h3 className="text-lg font-semibold mb-4">AI Models</h3>
              
              <div className="space-y-3">
                {models.map((model) => (
                  <motion.button
                    key={model.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedModel(model.id)}
                    className={`w-full p-4 text-left rounded-lg transition-all ${
                      selectedModel === model.id
                        ? 'bg-blue-600/20 border border-blue-500/30 shadow-lg'
                        : 'bg-gray-700/30 hover:bg-gray-700/50 border border-gray-600/30'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{model.name}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        model.type === 'hybrid' ? 'bg-purple-500/20 text-purple-400' :
                        model.type === 'pattern' ? 'bg-blue-500/20 text-blue-400' :
                        model.type === 'momentum' ? 'bg-green-500/20 text-green-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {model.type}
                      </span>
                    </div>
                    <p className="text-sm text-gray-400 mt-1">{model.description}</p>
                    
                    <div className="grid grid-cols-3 gap-2 mt-3">
                      <div className="text-center">
                        <div className="text-xs text-gray-400">Accuracy</div>
                        <div className="text-sm font-medium text-green-400">
                          {model.performance.accuracy}%
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-gray-400">Win Rate</div>
                        <div className="text-sm font-medium text-blue-400">
                          {model.performance.winRate}%
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-gray-400">Profit Factor</div>
                        <div className="text-sm font-medium text-purple-400">
                          {model.performance.profitFactor}
                        </div>
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
              
              <div className="mt-6 space-y-3">
                <button
                  onClick={handleResetToDefaults}
                  className="w-full bg-gray-700 hover:bg-gray-600 text-white py-2 rounded-lg font-medium flex items-center justify-center"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset to Defaults
                </button>
                
                <button
                  onClick={handleSaveConfiguration}
                  disabled={isSaving}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white py-2 rounded-lg font-medium flex items-center justify-center disabled:opacity-50"
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : saveSuccess ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Saved!
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Configuration
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Parameters Panel */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="max-w-3xl mx-auto">
                <h2 className="text-2xl font-bold mb-6">{currentModel.name} Parameters</h2>
                
                {/* Basic Parameters Section */}
                <div className="mb-6">
                  <button
                    onClick={() => toggleSection('basic')}
                    className="flex items-center justify-between w-full p-3 bg-gray-800/50 hover:bg-gray-800 rounded-lg text-lg font-medium transition-colors"
                  >
                    <div className="flex items-center">
                      <Sliders className="w-5 h-5 mr-2 text-blue-400" />
                      Basic Parameters
                    </div>
                    {expandedSections.includes('basic') ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </button>
                  
                  {expandedSections.includes('basic') && (
                    <div className="mt-4 space-y-6 p-4 bg-gray-800/30 rounded-lg">
                      {currentModel.parameters.slice(0, 5).map((parameter) => (
                        <div key={parameter.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="text-sm font-medium">{parameter.name}</label>
                            {parameter.value !== parameter.defaultValue && (
                              <span className="text-xs text-blue-400">Modified</span>
                            )}
                          </div>
                          {renderParameterInput(parameter)}
                          <p className="text-xs text-gray-400">{parameter.description}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Advanced Parameters Section */}
                <div className="mb-6">
                  <button
                    onClick={() => toggleSection('advanced')}
                    className="flex items-center justify-between w-full p-3 bg-gray-800/50 hover:bg-gray-800 rounded-lg text-lg font-medium transition-colors"
                  >
                    <div className="flex items-center">
                      <Brain className="w-5 h-5 mr-2 text-purple-400" />
                      Advanced Parameters
                    </div>
                    {expandedSections.includes('advanced') ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </button>
                  
                  {expandedSections.includes('advanced') && (
                    <div className="mt-4 space-y-6 p-4 bg-gray-800/30 rounded-lg">
                      {currentModel.parameters.slice(5).map((parameter) => (
                        <div key={parameter.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="text-sm font-medium">{parameter.name}</label>
                            {parameter.value !== parameter.defaultValue && (
                              <span className="text-xs text-blue-400">Modified</span>
                            )}
                          </div>
                          {renderParameterInput(parameter)}
                          <p className="text-xs text-gray-400">{parameter.description}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Performance Impact Section */}
                <div className="mb-6">
                  <button
                    onClick={() => toggleSection('performance')}
                    className="flex items-center justify-between w-full p-3 bg-gray-800/50 hover:bg-gray-800 rounded-lg text-lg font-medium transition-colors"
                  >
                    <div className="flex items-center">
                      <Activity className="w-5 h-5 mr-2 text-green-400" />
                      Performance Impact
                    </div>
                    {expandedSections.includes('performance') ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </button>
                  
                  {expandedSections.includes('performance') && (
                    <div className="mt-4 p-4 bg-gray-800/30 rounded-lg">
                      <div className="flex items-center mb-4">
                        <AlertTriangle className="w-5 h-5 text-yellow-400 mr-2" />
                        <p className="text-sm text-gray-300">
                          Changing parameters may affect model performance. Consider backtesting after making changes.
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-3 bg-gray-700/30 rounded-lg">
                          <h4 className="text-sm font-medium mb-2">Parameter Sensitivity</h4>
                          <div className="space-y-3">
                            <div>
                              <div className="flex justify-between text-xs mb-1">
                                <span>RSI Period</span>
                                <span className="text-yellow-400">Medium</span>
                              </div>
                              <div className="w-full bg-gray-600 rounded-full h-1.5">
                                <div className="bg-yellow-400 h-1.5 rounded-full" style={{width: '60%'}}></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex justify-between text-xs mb-1">
                                <span>MACD Parameters</span>
                                <span className="text-red-400">High</span>
                              </div>
                              <div className="w-full bg-gray-600 rounded-full h-1.5">
                                <div className="bg-red-400 h-1.5 rounded-full" style={{width: '85%'}}></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex justify-between text-xs mb-1">
                                <span>Signal Threshold</span>
                                <span className="text-green-400">Low</span>
                              </div>
                              <div className="w-full bg-gray-600 rounded-full h-1.5">
                                <div className="bg-green-400 h-1.5 rounded-full" style={{width: '30%'}}></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="p-3 bg-gray-700/30 rounded-lg">
                          <h4 className="text-sm font-medium mb-2">Recommended Actions</h4>
                          <div className="space-y-2">
                            <div className="flex items-start space-x-2">
                              <Target className="w-4 h-4 text-blue-400 mt-0.5" />
                              <span className="text-xs">Run backtest with current parameters</span>
                            </div>
                            <div className="flex items-start space-x-2">
                              <Zap className="w-4 h-4 text-yellow-400 mt-0.5" />
                              <span className="text-xs">Consider reducing MACD sensitivity</span>
                            </div>
                            <div className="flex items-start space-x-2">
                              <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
                              <span className="text-xs">Current RSI settings are optimal</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <button
                          onClick={() => window.dispatchEvent(new CustomEvent('open-backtest', { detail: { strategy: currentModel.id } }))}
                          className="w-full bg-blue-600/30 hover:bg-blue-600/50 text-blue-400 py-2 rounded-lg font-medium flex items-center justify-center"
                        >
                          <Target className="w-4 h-4 mr-2" />
                          Run Backtest with Current Parameters
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
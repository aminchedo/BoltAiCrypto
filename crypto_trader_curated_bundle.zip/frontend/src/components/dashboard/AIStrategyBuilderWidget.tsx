import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Dialog, DialogContent } from '@/components/ui/Dialog';
import StrategyBuilder from '../strategy-builder/StrategyBuilder';
import { Strategy } from '@/services/strategyBuilderService';
import strategyBuilderService from '@/services/strategyBuilderService';

interface AIStrategyBuilderWidgetProps {
  className?: string;
}

const AIStrategyBuilderWidget: React.FC<AIStrategyBuilderWidgetProps> = ({ className }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [strategies, setStrategies] = useState<Strategy[]>(strategyBuilderService.getAllStrategies());
  const [selectedStrategy, setSelectedStrategy] = useState<Strategy | null>(null);

  const handleOpenBuilder = (strategy?: Strategy) => {
    setSelectedStrategy(strategy || null);
    setIsOpen(true);
  };

  const handleCloseBuilder = () => {
    setIsOpen(false);
    setSelectedStrategy(null);
    // Refresh strategies list
    setStrategies(strategyBuilderService.getAllStrategies());
  };

  return (
    <>
      <Card className={className}>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-bold flex justify-between items-center">
            <span>AI Strategy Builder</span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handleOpenBuilder()}
            >
              Create New
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {strategies.length > 0 ? (
            <div className="space-y-4">
              {strategies.map((strategy) => (
                <div 
                  key={strategy.id}
                  className="p-3 border rounded-md hover:bg-gray-50 cursor-pointer"
                  onClick={() => handleOpenBuilder(strategy)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">{strategy.name}</h3>
                      <p className="text-sm text-gray-500">{strategy.description}</p>
                    </div>
                    <div className="flex items-center">
                      {strategy.isActive && (
                        <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full mr-2">
                          Active
                        </span>
                      )}
                      {strategy.backtestResults && (
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          strategy.backtestResults.metrics.netProfit > 0 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {strategy.backtestResults.metrics.winRate.toFixed(0)}% Win Rate
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No strategies created yet</p>
              <p className="text-sm mt-2">
                Create your first trading strategy with the visual builder
              </p>
              <Button 
                className="mt-4" 
                onClick={() => handleOpenBuilder()}
              >
                Create Strategy
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isOpen} onOpenChange={(open) => {
        setIsOpen(open);
        if (!open) handleCloseBuilder();
      }}>
        <DialogContent className="max-w-[90vw] max-h-[90vh] w-[90vw] h-[90vh] p-0">
          <StrategyBuilder initialStrategy={selectedStrategy || undefined} />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AIStrategyBuilderWidget;
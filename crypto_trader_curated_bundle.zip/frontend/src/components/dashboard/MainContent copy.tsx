import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PortfolioSummary from './PortfolioSummary';
import LiveSignals from './LiveSignals';
import TradingChart from './TradingChart';
import MarketOverview from './MarketOverview';
import { 
  Maximize, 
  Minimize, 
  RotateCw, 
  Grid, 
  Columns, 
  Layout,
  Monitor,
  Smartphone,
  Tablet,
  Eye,
  EyeOff,
  Settings,
  Download,
  Upload,
  RefreshCw,
  Zap,
  TrendingUp,
  Activity
} from 'lucide-react';

interface MainContentProps {
  currentTheme?: 'dark' | 'blue' | 'green';
  connectionStatus?: 'connected' | 'connecting' | 'disconnected';
}

interface Widget {
  id: string;
  name: string;
  component: React.ComponentType<any>;
  position: { x: number; y: number; w: number; h: number };
  visible: boolean;
  minimized: boolean;
  props?: any;
}

interface LayoutPreset {
  id: string;
  name: string;
  description: string;
  icon: any;
  widgets: Widget[];
}

const MainContent: React.FC<MainContentProps> = ({ 
  currentTheme = 'dark',
  connectionStatus = 'connected'
}) => {
  const [selectedLayout, setSelectedLayout] = useState('default');
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [refreshInterval, setRefreshInterval] = useState(5000);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [isLoading, setIsLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const [widgets, setWidgets] = useState<Widget[]>([
    {
      id: 'portfolio',
      name: 'Portfolio Summary',
      component: PortfolioSummary,
      position: { x: 0, y: 0, w: 1, h: 1 },
      visible: true,
      minimized: false
    },
    {
      id: 'signals',
      name: 'Live Signals',
      component: LiveSignals,
      position: { x: 1, y: 0, w: 1, h: 1 },
      visible: true,
      minimized: false
    },
    {
      id: 'chart',
      name: 'Trading Chart',
      component: TradingChart,
      position: { x: 0, y: 1, w: 2, h: 1 },
      visible: true,
      minimized: false
    },
    {
      id: 'market',
      name: 'Market Overview',
      component: MarketOverview,
      position: { x: 0, y: 2, w: 3, h: 1 },
      visible: true,
      minimized: false
    }
  ]);

  const layoutPresets: LayoutPreset[] = [
    {
      id: 'default',
      name: 'Default Layout',
      description: 'Balanced view for general trading',
      icon: Layout,
      widgets: [
        { ...widgets[0], position: { x: 0, y: 0, w: 1, h: 1 } },
        { ...widgets[1], position: { x: 1, y: 0, w: 1, h: 1 } },
        { ...widgets[2], position: { x: 0, y: 1, w: 2, h: 1 } },
        { ...widgets[3], position: { x: 0, y: 2, w: 3, h: 1 } }
      ]
    },
    {
      id: 'trading-focus',
      name: 'Trading Focus',
      description: 'Chart-centered layout for active trading',
      icon: TrendingUp,
      widgets: [
        { ...widgets[2], position: { x: 0, y: 0, w: 2, h: 2 } },
        { ...widgets[1], position: { x: 2, y: 0, w: 1, h: 1 } },
        { ...widgets[0], position: { x: 2, y: 1, w: 1, h: 1 } },
        { ...widgets[3], position: { x: 0, y: 2, w: 3, h: 1 } }
      ]
    },
    {
      id: 'analytics',
      name: 'Analytics View',
      description: 'Data-heavy layout for analysis',
      icon: Activity,
      widgets: [
        { ...widgets[3], position: { x: 0, y: 0, w: 3, h: 1 } },
        { ...widgets[0], position: { x: 0, y: 1, w: 1, h: 1 } },
        { ...widgets[1], position: { x: 1, y: 1, w: 1, h: 1 } },
        { ...widgets[2], position: { x: 2, y: 1, w: 1, h: 1 } }
      ]
    },
    {
      id: 'mobile',
      name: 'Mobile Layout',
      description: 'Single column for mobile devices',
      icon: Smartphone,
      widgets: [
        { ...widgets[0], position: { x: 0, y: 0, w: 1, h: 1 } },
        { ...widgets[1], position: { x: 0, y: 1, w: 1, h: 1 } },
        { ...widgets[2], position: { x: 0, y: 2, w: 1, h: 1 } },
        { ...widgets[3], position: { x: 0, y: 3, w: 1, h: 1 } }
      ]
    }
  ];

  // Auto-refresh functionality
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      setLastRefresh(new Date());
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval]);

  // Handle layout changes
  const applyLayout = useCallback((layoutId: string) => {
    const preset = layoutPresets.find(p => p.id === layoutId);
    if (preset) {
      setWidgets(preset.widgets);
      setSelectedLayout(layoutId);
    }
  }, [layoutPresets]);

  // Handle manual refresh
  const handleRefresh = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setLastRefresh(new Date());
    setIsLoading(false);
  };

  // Toggle widget visibility
  const toggleWidget = (widgetId: string) => {
    setWidgets(prev => prev.map(widget =>
      widget.id === widgetId
        ? { ...widget, visible: !widget.visible }
        : widget
    ));
  };

  // Minimize/maximize widget
  const toggleMinimize = (widgetId: string) => {
    setWidgets(prev => prev.map(widget =>
      widget.id === widgetId
        ? { ...widget, minimized: !widget.minimized }
        : widget
    ));
  };

  // Get responsive grid classes
  const getGridClasses = () => {
    switch (viewMode) {
      case 'mobile':
        return 'grid-cols-1';
      case 'tablet':
        return 'grid-cols-1 md:grid-cols-2';
      case 'desktop':
      default:
        return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
    }
  };

  // Get theme classes
  const getThemeClasses = () => {
    const themes = {
      dark: 'from-gray-900/30 to-black/30',
      blue: 'from-blue-900/30 to-blue-800/30',
      green: 'from-emerald-900/30 to-emerald-800/30'
    };
    return themes[currentTheme];
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0, scale: 0.95 },
    visible: {
      y: 0,
      opacity: 1,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15,
        duration: 0.6
      }
    }
  };

  const visibleWidgets = widgets.filter(widget => widget.visible);

  return (
    <div className={`flex-1 overflow-auto bg-gradient-to-br ${getThemeClasses()} relative`}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(59,130,246,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(16,185,129,0.1),transparent_50%)]" />
      </div>

      {/* Toolbar */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-30 bg-gray-900/50 backdrop-blur-xl border-b border-white/10 p-4"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h2 className="text-lg font-semibold text-white">Dashboard Workspace</h2>
            
            {/* Layout Presets */}
            <div className="flex items-center space-x-2">
              {layoutPresets.map((preset) => (
                <motion.button
                  key={preset.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => applyLayout(preset.id)}
                  className={`p-2 rounded-lg transition-all ${
                    selectedLayout === preset.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700/50 text-gray-400 hover:bg-gray-600/50 hover:text-white'
                  }`}
                  title={preset.description}
                >
                  <preset.icon size={16} />
                </motion.button>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {/* Connection Status */}
            <div className={`flex items-center space-x-2 px-3 py-1 rounded-lg text-sm ${
              connectionStatus === 'connected' ? 'bg-green-500/20 text-green-400' :
              connectionStatus === 'connecting' ? 'bg-yellow-500/20 text-yellow-400' :
              'bg-red-500/20 text-red-400'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                connectionStatus === 'connected' ? 'bg-green-500' :
                connectionStatus === 'connecting' ? 'bg-yellow-500 animate-pulse' :
                'bg-red-500'
              }`} />
              <span className="font-medium">
                {connectionStatus === 'connected' ? 'LIVE' :
                 connectionStatus === 'connecting' ? 'CONNECTING' : 'OFFLINE'}
              </span>
            </div>

            {/* View Mode Selector */}
            <div className="flex items-center space-x-1 bg-gray-700/50 rounded-lg p-1">
              {[
                { mode: 'desktop', icon: Monitor },
                { mode: 'tablet', icon: Tablet },
                { mode: 'mobile', icon: Smartphone }
              ].map((view) => (
                <motion.button
                  key={view.mode}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setViewMode(view.mode as any)}
                  className={`p-2 rounded transition-colors ${
                    viewMode === view.mode
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-600/50'
                  }`}
                  title={`${view.mode} view`}
                >
                  <view.icon size={14} />
                </motion.button>
              ))}
            </div>

            {/* Auto Refresh Toggle */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`p-2 rounded-lg transition-colors ${
                autoRefresh
                  ? 'bg-green-600/50 text-green-400'
                  : 'bg-gray-700/50 text-gray-400 hover:bg-gray-600/50'
              }`}
              title={`Auto refresh ${autoRefresh ? 'enabled' : 'disabled'}`}
            >
              <Zap size={16} />
            </motion.button>

            {/* Manual Refresh */}
            <motion.button
              whileHover={{ scale: 1.05, rotate: 180 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleRefresh}
              disabled={isLoading}
              className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors text-gray-400 hover:text-white"
              title="Refresh all widgets"
            >
              <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
            </motion.button>

            {/* Customize Layout */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsCustomizing(!isCustomizing)}
              className={`p-2 rounded-lg transition-colors ${
                isCustomizing
                  ? 'bg-purple-600/50 text-purple-400'
                  : 'bg-gray-700/50 text-gray-400 hover:bg-gray-600/50 hover:text-white'
              }`}
              title="Customize layout"
            >
              <Settings size={16} />
            </motion.button>
          </div>
        </div>

        {/* Widget Visibility Controls */}
        <AnimatePresence>
          {isCustomizing && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 p-4 bg-gray-800/50 rounded-lg border border-white/10"
            >
              <h3 className="text-sm font-semibold text-white mb-3">Widget Visibility</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {widgets.map((widget) => (
                  <motion.div
                    key={widget.id}
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg"
                  >
                    <span className="text-sm text-white">{widget.name}</span>
                    <div className="flex items-center space-x-2">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => toggleMinimize(widget.id)}
                        className="p-1 hover:bg-white/10 rounded transition-colors"
                        title={widget.minimized ? 'Maximize' : 'Minimize'}
                      >
                        {widget.minimized ? <Maximize size={12} /> : <Minimize size={12} />}
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => toggleWidget(widget.id)}
                        className={`p-1 rounded transition-colors ${
                          widget.visible
                            ? 'text-green-400 hover:bg-green-400/10'
                            : 'text-gray-500 hover:bg-gray-500/10'
                        }`}
                        title={widget.visible ? 'Hide widget' : 'Show widget'}
                      >
                        {widget.visible ? <Eye size={12} /> : <EyeOff size={12} />}
                      </motion.button>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-4 pt-4 border-t border-white/10">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-4">
                    <span className="text-gray-400">Auto Refresh Interval:</span>
                    <select
                      value={refreshInterval}
                      onChange={(e) => setRefreshInterval(parseInt(e.target.value))}
                      className="bg-gray-800 border border-gray-600 rounded px-2 py-1 text-white text-sm"
                    >
                      <option value={1000}>1 second</option>
                      <option value={3000}>3 seconds</option>
                      <option value={5000}>5 seconds</option>
                      <option value={10000}>10 seconds</option>
                      <option value={30000}>30 seconds</option>
                    </select>
                  </div>
                  
                  <div className="text-gray-400">
                    Last updated: {lastRefresh.toLocaleTimeString()}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Main Content Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className={`grid ${getGridClasses()} gap-6 p-6 min-h-0`}
      >
        <AnimatePresence mode="wait">
          {visibleWidgets.map((widget) => {
            const WidgetComponent = widget.component;
            
            return (
              <motion.div
                key={widget.id}
                variants={itemVariants}
                layout
                className={`${
                  widget.position.w === 2 ? 'md:col-span-2' :
                  widget.position.w === 3 ? 'md:col-span-2 lg:col-span-3' : ''
                } ${widget.minimized ? 'h-20' : ''}`}
              >
                <div className="relative group h-full">
                  {/* Widget Header (when customizing) */}
                  <AnimatePresence>
                    {isCustomizing && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute top-0 left-0 right-0 z-10 bg-gray-900/90 backdrop-blur-sm rounded-t-xl p-2 border border-white/20"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-white">{widget.name}</span>
                          <div className="flex items-center space-x-1">
                            <button
                              onClick={() => toggleMinimize(widget.id)}
                              className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-white"
                            >
                              {widget.minimized ? <Maximize size={12} /> : <Minimize size={12} />}
                            </button>
                            <button
                              onClick={() => toggleWidget(widget.id)}
                              className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-white"
                            >
                              <EyeOff size={12} />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Widget Content */}
                  <div className={`h-full ${isCustomizing ? 'pt-12' : ''} ${widget.minimized ? 'overflow-hidden' : ''}`}>
                    <WidgetComponent 
                      className="h-full"
                      minimized={widget.minimized}
                      currentTheme={currentTheme}
                      connectionStatus={connectionStatus}
                      {...widget.props}
                    />
                  </div>

                  {/* Loading Overlay */}
                  <AnimatePresence>
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-gray-900/50 backdrop-blur-sm rounded-2xl flex items-center justify-center z-20"
                      >
                        <div className="flex items-center space-x-3 text-white">
                          <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Refreshing...</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {/* Empty State */}
        {visibleWidgets.length === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="col-span-full flex items-center justify-center h-96"
          >
            <div className="text-center">
              <Grid size={64} className="mx-auto mb-4 text-gray-600" />
              <h3 className="text-xl font-semibold text-white mb-2">No Widgets Visible</h3>
              <p className="text-gray-400 mb-4">Enable widgets from the customization panel to see your dashboard</p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsCustomizing(true)}
                className="bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-xl font-semibold text-white transition-colors"
              >
                Customize Layout
              </motion.button>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* Performance Indicator */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="fixed bottom-4 right-4 bg-gray-900/90 backdrop-blur-sm rounded-xl p-3 border border-white/10 text-xs text-gray-400"
      >
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1">
            <div className={`w-2 h-2 rounded-full ${
              connectionStatus === 'connected' ? 'bg-green-500' : 'bg-red-500'
            }`} />
            <span>Real-time data</span>
          </div>
          <div>•</div>
          <div>{visibleWidgets.length} widgets active</div>
          <div>•</div>
          <div>Last sync: {lastRefresh.toLocaleTimeString()}</div>
        </div>
      </motion.div>
    </div>
  );
};

export default MainContent;
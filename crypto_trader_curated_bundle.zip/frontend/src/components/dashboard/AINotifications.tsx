import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle, 
  AlertTriangle, 
  X, 
  Clock, 
  Zap, 
  Database, 
  Shield 
} from 'lucide-react';
import { aiNotificationService, AINotification } from '@/services/aiNotificationService';

interface AINotificationsProps {
  className?: string;
}

export function AINotifications({ className }: AINotificationsProps) {
  const [notifications, setNotifications] = useState<AINotification[]>([]);
  const [showPanel, setShowPanel] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Subscribe to notification updates
    const unsubscribe = aiNotificationService.subscribe(updatedNotifications => {
      setNotifications(updatedNotifications);
    });
    
    // Initial load
    setNotifications(aiNotificationService.getNotifications());
    
    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  // Close panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        setShowPanel(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const getNotificationIcon = (notification: AINotification) => {
    switch (notification.type) {
      case 'signal':
        if (notification.data?.signal === 'BUY') {
          return <TrendingUp className="w-4 h-4 text-green-400" />;
        } else if (notification.data?.signal === 'SELL') {
          return <TrendingDown className="w-4 h-4 text-red-400" />;
        }
        return <Brain className="w-4 h-4 text-purple-400" />;
      case 'model_training':
        return <Database className="w-4 h-4 text-blue-400" />;
      case 'performance':
        return <Zap className="w-4 h-4 text-yellow-400" />;
      case 'risk':
        return <Shield className="w-4 h-4 text-orange-400" />;
      default:
        return <Brain className="w-4 h-4 text-purple-400" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-blue-500';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  const handleMarkAsRead = (id: string) => {
    aiNotificationService.markAsRead(id);
  };

  const handleMarkAllAsRead = () => {
    aiNotificationService.markAllAsRead();
  };

  const handleClearAll = () => {
    aiNotificationService.clearAll();
    setShowPanel(false);
  };

  return (
    <div className={`relative ${className}`} ref={panelRef}>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setShowPanel(!showPanel)}
        className="relative p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
      >
        <Bell className="w-5 h-5" />
        <AnimatePresence>
          {unreadCount > 0 && (
            <motion.span
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold"
            >
              {unreadCount}
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      <AnimatePresence>
        {showPanel && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="absolute right-0 top-full mt-2 w-80 bg-gray-900/95 backdrop-blur-xl rounded-xl border border-gray-700 shadow-2xl z-50"
          >
            <div className="p-4 border-b border-gray-700 flex items-center justify-between">
              <h3 className="font-semibold flex items-center">
                <Brain className="w-4 h-4 mr-2 text-purple-400" />
                AI Notifications
              </h3>
              <div className="flex space-x-2">
                <button
                  onClick={handleMarkAllAsRead}
                  className="text-xs text-gray-400 hover:text-white transition-colors"
                >
                  Mark all read
                </button>
                <button
                  onClick={handleClearAll}
                  className="text-xs text-gray-400 hover:text-white transition-colors"
                >
                  Clear all
                </button>
              </div>
            </div>
            
            <div className="max-h-80 overflow-y-auto">
              {notifications.length > 0 ? (
                notifications.map((notification) => (
                  <motion.div
                    key={notification.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    onClick={() => handleMarkAsRead(notification.id)}
                    className={`p-4 border-b border-gray-700/50 hover:bg-gray-800/50 cursor-pointer transition-colors ${
                      !notification.read ? 'bg-blue-500/10' : ''
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`p-2 rounded-lg ${
                        notification.type === 'signal' && notification.data?.signal === 'BUY' ? 'bg-green-500/20' :
                        notification.type === 'signal' && notification.data?.signal === 'SELL' ? 'bg-red-500/20' :
                        notification.type === 'model_training' ? 'bg-blue-500/20' :
                        notification.type === 'performance' ? 'bg-yellow-500/20' :
                        notification.type === 'risk' ? 'bg-orange-500/20' :
                        'bg-purple-500/20'
                      }`}>
                        {getNotificationIcon(notification)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div className="font-medium text-sm">{notification.title}</div>
                          <div className={`w-2 h-2 rounded-full ${getPriorityColor(notification.priority)}`} />
                        </div>
                        <div className="text-xs text-gray-400 mt-1">{notification.message}</div>
                        <div className="text-xs text-gray-500 mt-2 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatTimeAgo(notification.timestamp)}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="p-8 text-center text-gray-400">
                  <Bell className="mx-auto mb-2 opacity-50 w-8 h-8" />
                  <p>No notifications</p>
                </div>
              )}
            </div>
            
            <div className="p-3 border-t border-gray-700">
              <button
                onClick={() => window.dispatchEvent(new CustomEvent('open-ai-lab', { detail: { tab: 'main' } }))}
                className="w-full bg-purple-600/30 hover:bg-purple-600/50 text-purple-400 py-2 rounded text-sm font-medium transition-colors flex items-center justify-center"
              >
                <Brain className="w-4 h-4 mr-2" />
                Open AI Laboratory
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
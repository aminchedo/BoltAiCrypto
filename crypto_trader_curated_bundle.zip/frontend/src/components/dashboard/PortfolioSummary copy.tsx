import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LineChart, 
  Line, 
  ResponsiveContainer, 
  Tooltip, 
  Area, 
  AreaChart,
  PieChart as PieChartIcon,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis
} from 'recharts';
import { realDataService, type PortfolioData } from '../../services/realDataService';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Activity, 
  Eye,
  EyeOff,
  RefreshCw,
  Download,
  Upload,
  PieChart,
  BarChart3,
  Target,
  Shield,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  CreditCard,
  AlertTriangle,
  CheckCircle,
  Info
} from 'lucide-react';

interface Asset {
  symbol: string;
  name: string;
  amount: number;
  value: number;
  change24h: number;
  allocation: number;
  color: string;
}

interface PortfolioData {
  timestamp: number;
  value: number;
  pnl: number;
  volume: number;
}

interface RiskMetric {
  label: string;
  value: number;
  status: 'low' | 'medium' | 'high';
  description: string;
}

const PortfolioSummary: React.FC = () => {
  // Real data states
  const [realPortfolioData, setRealPortfolioData] = useState<PortfolioData | null>(null);
  const [isLoadingReal, setIsLoadingReal] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // UI states (preserved for compatibility)
  const [portfolioValue, setPortfolioValue] = useState(127845.32);
  const [change, setChange] = useState(2341.22);
  const [changePercent, setChangePercent] = useState(1.87);
  const [availableBalance, setAvailableBalance] = useState(85000);
  const [marginUsed, setMarginUsed] = useState(42000);
  const [unrealizedPnL, setUnrealizedPnL] = useState(1200);
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);
  const [chartType, setChartType] = useState<'line' | 'area' | 'pie'>('area');
  const [timeframe, setTimeframe] = useState('24H');
  const [isLoading, setIsLoading] = useState(false);

  // Use real data when available, fallback to default
  const assets = realPortfolioData?.assets || [
    { symbol: 'BTC', name: 'Bitcoin', amount: 1.2345, value: 82345.67, change24h: 2.45, allocation: 45, color: '#f7931a' },
    { symbol: 'ETH', name: 'Ethereum', amount: 12.456, value: 34567.89, change24h: -1.23, allocation: 30, color: '#627eea' },
    { symbol: 'SOL', name: 'Solana', amount: 156.78, value: 8934.12, change24h: 5.67, allocation: 15, color: '#9945ff' },
    { symbol: 'USDT', name: 'Tether', amount: 1997.23, value: 1997.23, change24h: 0.01, allocation: 10, color: '#26a17b' }
  ];

  const [riskMetrics, setRiskMetrics] = useState<RiskMetric[]>([
    { label: 'Portfolio Risk', value: 65, status: 'medium', description: 'Moderate volatility exposure' },
    { label: 'Diversification', value: 78, status: 'low', description: 'Well diversified across assets' },
    { label: 'Leverage Ratio', value: 2.1, status: 'low', description: 'Conservative leverage usage' },
    { label: 'Correlation Risk', value: 45, status: 'low', description: 'Low asset correlation' }
  ]);

  // Generate portfolio history data
  const generatePortfolioData = useCallback((): PortfolioData[] => {
    const data: PortfolioData[] = [];
    let currentValue = portfolioValue - change;
    
    for (let i = 0; i < 50; i++) {
      const timestamp = Date.now() - (50 - i) * 3600000; // Hourly data
      const valueChange = (Math.random() - 0.5) * 5000;
      currentValue = Math.max(currentValue + valueChange, 100000);
      
      data.push({
        timestamp,
        value: currentValue,
        pnl: currentValue - portfolioValue + change,
        volume: Math.random() * 1000000 + 500000
      });
    }
    return data;
  }, [portfolioValue, change]);

  const [portfolioHistory, setPortfolioHistory] = useState<PortfolioData[]>([]);

  // Fetch real portfolio data
  useEffect(() => {
    const fetchRealPortfolioData = async () => {
      setIsLoadingReal(true);
      setError(null);
      
      try {
        console.log('🔄 PortfolioSummary: Fetching real portfolio data...');
        
        const portfolioData = await realDataService.fetchPortfolioData();
        setRealPortfolioData(portfolioData);
        
        // Update UI states with real data
        setPortfolioValue(portfolioData.totalValue);
        setChange(portfolioData.change24h);
        setChangePercent(portfolioData.changePercent);
        setAvailableBalance(portfolioData.availableBalance);
        setMarginUsed(portfolioData.marginUsed);
        setUnrealizedPnL(portfolioData.unrealizedPnL);
        
        console.log('✅ PortfolioSummary: Real portfolio data loaded successfully');
        console.log(`💰 Total Value: $${portfolioData.totalValue.toLocaleString()}`);
        console.log(`📊 Assets: ${portfolioData.assets.length}`);
        
      } catch (err) {
        const errorMsg = `Failed to fetch portfolio data: ${err.message}`;
        setError(errorMsg);
        console.error('❌ PortfolioSummary error:', errorMsg);
      } finally {
        setIsLoadingReal(false);
      }
    };

    // Initial fetch
    fetchRealPortfolioData();

    // Set up real-time updates every 2 minutes
    const interval = setInterval(fetchRealPortfolioData, 120000);

    // Subscribe to real-time updates from the service
    const unsubscribe = realDataService.subscribe('portfolioData', (data: PortfolioData) => {
      setRealPortfolioData(data);
      setPortfolioValue(data.totalValue);
      setChange(data.change24h);
      setChangePercent(data.changePercent);
      setAvailableBalance(data.availableBalance);
      setMarginUsed(data.marginUsed);
      setUnrealizedPnL(data.unrealizedPnL);
      console.log('🔄 PortfolioSummary: Real-time portfolio data updated');
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, []);

  // Initialize portfolio history data
  useEffect(() => {
    setPortfolioHistory(generatePortfolioData());
  }, [generatePortfolioData]);

  // Update portfolio history when real data changes
  useEffect(() => {
    if (realPortfolioData) {
      // Generate new history based on real portfolio value
      const newHistory = generatePortfolioData();
      setPortfolioHistory(newHistory);
    }
  }, [realPortfolioData, generatePortfolioData]);

  const isPositive = changePercent >= 0;
  const totalAllocation = assets.reduce((sum, asset) => sum + asset.allocation, 0);

  const formatCurrency = (value: number, showDecimals = true) => {
    if (!isBalanceVisible) return '****';
    return `$${value.toLocaleString('en-US', { 
      minimumFractionDigits: showDecimals ? 2 : 0, 
      maximumFractionDigits: showDecimals ? 2 : 0 
    })}`;
  };

  const handleRefresh = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setPortfolioHistory(generatePortfolioData());
    setIsLoading(false);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gray-900/95 backdrop-blur-xl border border-gray-600/50 rounded-xl p-4 shadow-2xl"
        >
          <div className="space-y-2">
            <p className="text-white font-semibold">
              {new Date(data.timestamp).toLocaleString()}
            </p>
            <p className="text-green-400">
              Value: {formatCurrency(data.value)}
            </p>
            <p className={`${data.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              P&L: {data.pnl >= 0 ? '+' : ''}{formatCurrency(data.pnl)}
            </p>
          </div>
        </motion.div>
      );
    }
    return null;
  };

  const renderChart = () => {
    const commonProps = {
      data: portfolioHistory,
      height: 120
    };

    switch (chartType) {
      case 'area':
        return (
          <AreaChart {...commonProps}>
            <defs>
              <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00ff88" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="value"
              stroke="#00ff88"
              fill="url(#portfolioGradient)"
              strokeWidth={2}
              dot={false}
            />
            <Tooltip content={<CustomTooltip />} />
          </AreaChart>
        );
      
      case 'line':
        return (
          <LineChart {...commonProps}>
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="#00ff88" 
              strokeWidth={3} 
              dot={false}
              strokeLinecap="round"
            />
            <Tooltip content={<CustomTooltip />} />
          </LineChart>
        );
      
      case 'pie':
        return (
          <div className="flex items-center justify-center h-[120px]">
            <PieChart width={120} height={120}>
              <Pie
                data={assets}
                dataKey="allocation"
                nameKey="symbol"
                cx="50%"
                cy="50%"
                innerRadius={25}
                outerRadius={50}
                startAngle={90}
                endAngle={450}
              >
                {assets.map((asset, index) => (
                  <Cell key={`cell-${index}`} fill={asset.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: any, name: string) => [
                  `${value}%`, 
                  assets.find(a => a.symbol === name)?.name || name
                ]}
              />
            </PieChart>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <motion.div 
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.3 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(34,197,94,0.1),transparent_50%)]" />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center space-x-3">
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          >
            <Wallet size={24} className="text-green-400" />
          </motion.div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
              Portfolio Overview
            </h2>
            <p className="text-sm text-gray-400">Total portfolio value and performance</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <motion.button
            whileHover={{ scale: 1.05, rotate: 180 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleRefresh}
            disabled={isLoading}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
          >
            <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsBalanceVisible(!isBalanceVisible)}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
          >
            {isBalanceVisible ? <Eye size={16} /> : <EyeOff size={16} />}
          </motion.button>
        </div>
      </div>

      {/* Portfolio Value */}
      <div className="mb-6 relative z-10">
        <motion.div 
          key={portfolioValue}
          initial={{ scale: 1.02, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mb-3"
        >
          <div className="text-3xl font-mono font-bold mb-2 flex items-center space-x-2">
            <DollarSign size={28} className="text-green-400" />
            <span>
              {formatCurrency(portfolioValue)}
            </span>
          </div>
          
          <div className={`text-lg flex items-center space-x-2 ${
            isPositive ? 'text-green-400' : 'text-red-400'
          }`}>
            {isPositive ? <TrendingUp size={20} /> : <TrendingDown size={20} />}
            <span className="font-semibold">
              {isPositive ? '+' : ''}{formatCurrency(Math.abs(change))} 
              ({isPositive ? '+' : ''}{changePercent.toFixed(2)}%)
            </span>
            <span className="text-sm text-gray-400">24h</span>
          </div>
        </motion.div>

        {/* Chart Controls */}
        <div className="flex items-center space-x-2 mb-4">
          <div className="flex items-center space-x-1 bg-gray-700/30 rounded-lg p-1">
            {[
              { type: 'area', icon: Activity, label: 'Area' },
              { type: 'line', icon: TrendingUp, label: 'Line' },
              { type: 'pie', icon: PieChartIcon, label: 'Allocation' }
            ].map((chart) => (
              <motion.button
                key={chart.type}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setChartType(chart.type as any)}
                className={`p-2 rounded transition-colors ${
                  chartType === chart.type
                    ? 'bg-green-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-600/50'
                }`}
                title={chart.label}
              >
                <chart.icon size={14} />
              </motion.button>
            ))}
          </div>

          <div className="flex items-center space-x-1 bg-gray-700/30 rounded-lg p-1">
            {['1H', '24H', '7D', '30D'].map((tf) => (
              <motion.button
                key={tf}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setTimeframe(tf)}
                className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                  timeframe === tf
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-600/50'
                }`}
              >
                {tf}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Chart */}
        <div className="h-[120px] mb-4">
          <ResponsiveContainer width="100%" height="100%">
            {renderChart()}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6 relative z-10">
        {[
          { 
            label: 'Available', 
            value: formatCurrency(availableBalance, false), 
            icon: Wallet, 
            color: 'text-blue-400',
            description: 'Ready to trade'
          },
          { 
            label: 'In Positions', 
            value: formatCurrency(marginUsed, false), 
            icon: Target, 
            color: 'text-purple-400',
            description: 'Active investments'
          },
          { 
            label: 'Unrealized P&L', 
            value: `${unrealizedPnL >= 0 ? '+' : ''}${formatCurrency(Math.abs(unrealizedPnL), false)}`, 
            icon: unrealizedPnL >= 0 ? ArrowUpRight : ArrowDownRight, 
            color: unrealizedPnL >= 0 ? 'text-green-400' : 'text-red-400',
            description: 'Open positions'
          },
          { 
            label: 'Total Assets', 
            value: assets.length.toString(), 
            icon: Shield, 
            color: 'text-yellow-400',
            description: 'Different cryptocurrencies'
          }
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02, y: -2 }}
            className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-4 border border-white/5 group"
          >
            <div className="flex items-center justify-between mb-2">
              <stat.icon className={`${stat.color} group-hover:scale-110 transition-transform`} size={18} />
              <Info size={12} className="text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div className="text-xs text-gray-400 mb-1">{stat.label}</div>
            <div className={`font-bold text-lg ${stat.color}`}>{stat.value}</div>
            <div className="text-xs text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity">
              {stat.description}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Top Assets */}
      <div className="mb-6 relative z-10">
        <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
          <BarChart3 size={18} className="text-blue-400" />
          <span>Top Holdings</span>
        </h3>
        
        <div className="space-y-3">
          {assets.slice(0, 3).map((asset, index) => (
            <motion.div
              key={asset.symbol}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.01, x: 4 }}
              className="flex items-center justify-between p-3 bg-gray-700/30 rounded-xl hover:bg-gray-700/50 transition-all cursor-pointer"
            >
              <div className="flex items-center space-x-3">
                <div 
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                  style={{ backgroundColor: asset.color }}
                >
                  {asset.symbol}
                </div>
                <div>
                  <div className="font-medium">{asset.name}</div>
                  <div className="text-sm text-gray-400">
                    {asset.amount.toFixed(4)} {asset.symbol}
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="font-semibold">
                  {formatCurrency(asset.value, false)}
                </div>
                <div className={`text-sm flex items-center space-x-1 ${
                  asset.change24h >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {asset.change24h >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                  <span>{asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%</span>
                </div>
              </div>
              
              <div className="text-right text-sm text-gray-400">
                {asset.allocation}%
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Risk Assessment */}
      <div className="mb-6 relative z-10">
        <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
          <Shield size={18} className="text-red-400" />
          <span>Risk Assessment</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {riskMetrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bg-gray-700/30 rounded-xl p-3 border border-white/5"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-medium">{metric.label}</div>
                <div className={`text-xs px-2 py-1 rounded-full ${
                  metric.status === 'low' ? 'bg-green-500/20 text-green-400' :
                  metric.status === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {metric.status.toUpperCase()}
                </div>
              </div>
              
              <div className="text-lg font-bold mb-1">
                {typeof metric.value === 'number' ? 
                  (metric.value > 10 ? metric.value.toFixed(0) + '%' : metric.value.toFixed(1)) 
                  : metric.value
                }
              </div>
              
              <div className="text-xs text-gray-400">{metric.description}</div>
              
              {typeof metric.value === 'number' && metric.value <= 100 && (
                <div className="mt-2 bg-gray-600 rounded-full h-1">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${metric.value}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className={`h-1 rounded-full ${
                      metric.status === 'low' ? 'bg-green-500' :
                      metric.status === 'medium' ? 'bg-yellow-500' :
                      'bg-red-500'
                    }`}
                  />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3 relative z-10">
        <motion.button
          whileHover={{ scale: 1.02, y: -2 }}
          whileTap={{ scale: 0.98 }}
          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 p-4 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-green-500/25 flex items-center justify-center space-x-2"
        >
          <Upload size={18} />
          <span>Deposit</span>
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.02, y: -2 }}
          whileTap={{ scale: 0.98 }}
          className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 p-4 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-blue-500/25 flex items-center justify-center space-x-2"
        >
          <Download size={18} />
          <span>Withdraw</span>
        </motion.button>
      </div>
    </motion.div>
  );
};

export default PortfolioSummary;
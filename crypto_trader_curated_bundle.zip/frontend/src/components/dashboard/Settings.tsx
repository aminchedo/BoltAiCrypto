import React from 'react';
import { Settings as SettingsPage } from './Settings/index';

export function Settings() {
  return <SettingsPage />;
}
/**
 * Comprehensive tests for CandlestickRenderer
 * 
 * Tests cover:
 * - Candlestick calculations and visual accuracy
 * - Volume bar rendering and scaling
 * - Heikin-Ashi calculations
 * - Animation functionality
 * - Performance optimizations
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { CandlestickRenderer, DEFAULT_CANDLESTICK_CONFIG } from '../CandlestickRenderer';
import { DEFAULT_THEME } from '../ChartEngine';
import { Candle } from '../../../types';

// Mock canvas context
const mockContext = {
  save: vi.fn(),
  restore: vi.fn(),
  clearRect: vi.fn(),
  fillRect: vi.fn(),
  strokeRect: vi.fn(),
  beginPath: vi.fn(),
  moveTo: vi.fn(),
  lineTo: vi.fn(),
  stroke: vi.fn(),
  fill: vi.fn(),
  setLineDash: vi.fn(),
  fillText: vi.fn(),
  scale: vi.fn(),
  translate: vi.fn(),
  rotate: vi.fn(),
  get fillStyle() { return this._fillStyle || ''; },
  set fillStyle(value) { this._fillStyle = value; },
  get strokeStyle() { return this._strokeStyle || ''; },
  set strokeStyle(value) { this._strokeStyle = value; },
  get lineWidth() { return this._lineWidth || 1; },
  set lineWidth(value) { this._lineWidth = value; },
  get globalAlpha() { return this._globalAlpha || 1; },
  set globalAlpha(value) { this._globalAlpha = value; },
  get font() { return this._font || ''; },
  set font(value) { this._font = value; },
  get textAlign() { return this._textAlign || 'left'; },
  set textAlign(value) { this._textAlign = value; },
  _fillStyle: '',
  _strokeStyle: '',
  _lineWidth: 1,
  _globalAlpha: 1,
  _font: '',
  _textAlign: 'left' as CanvasTextAlign,
};

const mockCanvas = {
  getContext: vi.fn(() => mockContext),
  width: 800,
  height: 600,
  style: {},
  getBoundingClientRect: vi.fn(() => ({
    left: 0,
    top: 0,
    width: 800,
    height: 600
  }))
} as unknown as HTMLCanvasElement;

const mockRenderContext = {
  canvas: mockCanvas,
  ctx: mockContext as unknown as CanvasRenderingContext2D,
  pixelRatio: 1,
  width: 800,
  height: 600
};

const mockCoordinateSystem = {
  priceToY: vi.fn((price: number) => 300 - price),
  yToPrice: vi.fn((y: number) => 300 - y),
  timeToX: vi.fn((timestamp: number) => timestamp / 1000),
  xToTime: vi.fn((x: number) => x * 1000),
  screenToChart: vi.fn((point) => point),
  chartToScreen: vi.fn((point) => point)
};

// Sample test data
const sampleCandles: Candle[] = [
  { t: 1000, o: 100, h: 110, l: 95, c: 105, v: 1000 },
  { t: 2000, o: 105, h: 115, l: 100, c: 110, v: 1200 },
  { t: 3000, o: 110, h: 120, l: 105, c: 115, v: 800 },
  { t: 4000, o: 115, h: 125, l: 110, c: 120, v: 1500 },
  { t: 5000, o: 120, h: 130, l: 115, c: 125, v: 900 }
];

describe('CandlestickRenderer', () => {
  let renderer: CandlestickRenderer;

  beforeEach(() => {
    vi.clearAllMocks();
    renderer = new CandlestickRenderer({}, DEFAULT_THEME);
  });

  afterEach(() => {
    renderer.destroy();
  });

  describe('Initialization', () => {
    it('should initialize with default configuration', () => {
      const config = renderer.getConfig();
      expect(config.chartType).toBe('candlestick');
      expect(config.showVolume).toBe(true);
      expect(config.animation.enabled).toBe(true);
    });

    it('should accept custom configuration', () => {
      const customConfig = {
        chartType: 'heikin-ashi' as const,
        showVolume: false,
        animation: { enabled: false, duration: 500, easing: 'linear' as const }
      };
      
      const customRenderer = new CandlestickRenderer(customConfig, DEFAULT_THEME);
      const config = customRenderer.getConfig();
      
      expect(config.chartType).toBe('heikin-ashi');
      expect(config.showVolume).toBe(false);
      expect(config.animation.enabled).toBe(false);
      expect(config.animation.duration).toBe(500);
      
      customRenderer.destroy();
    });
  });

  describe('Data Management', () => {
    it('should update data correctly', () => {
      renderer.updateData(sampleCandles);
      const data = renderer.getData();
      
      expect(data).toHaveLength(5);
      expect(data[0]).toEqual(sampleCandles[0]);
      expect(data[4]).toEqual(sampleCandles[4]);
    });

    it('should calculate Heikin-Ashi data correctly', () => {
      renderer.updateConfig({ chartType: 'heikin-ashi' });
      renderer.updateData(sampleCandles);
      
      const heikinAshiData = renderer.getHeikinAshiData();
      expect(heikinAshiData).toHaveLength(5);
      
      // Test first Heikin-Ashi candle
      const firstHA = heikinAshiData[0];
      expect(firstHA.c).toBe((100 + 110 + 95 + 105) / 4); // HA Close
      expect(firstHA.o).toBe((100 + 105) / 2); // HA Open for first candle
      expect(firstHA.h).toBe(Math.max(110, firstHA.o, firstHA.c)); // HA High
      expect(firstHA.l).toBe(Math.min(95, firstHA.o, firstHA.c)); // HA Low
      
      // Test second Heikin-Ashi candle
      const secondHA = heikinAshiData[1];
      expect(secondHA.o).toBe((firstHA.o + firstHA.c) / 2); // HA Open uses previous HA values
    });

    it('should preserve original candle data in Heikin-Ashi', () => {
      renderer.updateConfig({ chartType: 'heikin-ashi' });
      renderer.updateData(sampleCandles);
      
      const heikinAshiData = renderer.getHeikinAshiData();
      heikinAshiData.forEach((haCandle, index) => {
        expect(haCandle.originalCandle).toEqual(sampleCandles[index]);
        expect(haCandle.t).toBe(sampleCandles[index].t);
        expect(haCandle.v).toBe(sampleCandles[index].v);
      });
    });
  });

  describe('Rendering', () => {
    beforeEach(() => {
      renderer.updateData(sampleCandles);
    });

    it('should render without errors', () => {
      expect(() => {
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });

    it('should save and restore canvas context', () => {
      renderer.render(mockRenderContext, mockCoordinateSystem);
      
      expect(mockContext.save).toHaveBeenCalled();
      expect(mockContext.restore).toHaveBeenCalled();
    });

    it('should render candlesticks with correct colors', () => {
      renderer.render(mockRenderContext, mockCoordinateSystem);
      
      // Should have called fillRect for candlestick bodies
      expect(mockContext.fillRect).toHaveBeenCalled();
      
      // Should have set fill styles for bullish/bearish candles
      const fillStyleCalls = vi.mocked(mockContext).fillStyle;
      // Note: In a real test, we'd check the actual color values set
    });

    it('should render volume bars when enabled', () => {
      renderer.updateConfig({ showVolume: true });
      renderer.render(mockRenderContext, mockCoordinateSystem);
      
      // Should render volume bars (additional fillRect calls)
      expect(mockContext.fillRect).toHaveBeenCalled();
      // Check that globalAlpha was set (it's a property, not a method)
      expect(mockContext.globalAlpha).toBeDefined();
    });

    it('should not render volume bars when disabled', () => {
      renderer.updateConfig({ showVolume: false });
      
      const fillRectCallsBefore = mockContext.fillRect.mock.calls.length;
      renderer.render(mockRenderContext, mockCoordinateSystem);
      const fillRectCallsAfter = mockContext.fillRect.mock.calls.length;
      
      // Should have fewer fillRect calls without volume bars
      // (This is a simplified test - in practice we'd mock more specifically)
    });

    it('should render price labels', () => {
      renderer.render(mockRenderContext, mockCoordinateSystem);
      
      expect(mockContext.fillText).toHaveBeenCalled();
      expect(mockContext.font).toBeTruthy();
    });

    it('should handle empty data gracefully', () => {
      renderer.updateData([]);
      
      expect(() => {
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });
  });

  describe('Animation', () => {
    beforeEach(() => {
      vi.useFakeTimers();
    });

    afterEach(() => {
      vi.useRealTimers();
    });

    it('should start animation when new data is added', () => {
      renderer.updateConfig({ animation: { enabled: true, duration: 300, easing: 'ease-out' } });
      
      // First data load should not animate (no previous data)
      renderer.updateData(sampleCandles.slice(0, 3));
      // Animation might start immediately, so let's check after a brief moment
      vi.advanceTimersByTime(1);
      
      // Add more data to trigger animation
      renderer.updateData(sampleCandles);
      expect(renderer.isAnimating()).toBe(true);
    });

    it('should not animate when animation is disabled', () => {
      renderer.updateConfig({ animation: { enabled: false, duration: 300, easing: 'linear' } });
      renderer.updateData(sampleCandles.slice(0, 3));
      renderer.updateData(sampleCandles);
      
      expect(renderer.isAnimating()).toBe(false);
    });

    it('should progress animation over time', () => {
      renderer.updateConfig({ animation: { enabled: true, duration: 1000, easing: 'linear' } });
      renderer.updateData(sampleCandles.slice(0, 3));
      renderer.updateData(sampleCandles);
      
      expect(renderer.isAnimating()).toBe(true);
      expect(renderer.getAnimationProgress()).toBe(0);
      
      // Simulate time passing
      const startTime = performance.now();
      vi.advanceTimersByTime(500);
      renderer.render(mockRenderContext, mockCoordinateSystem, startTime + 500);
      
      expect(renderer.getAnimationProgress()).toBeCloseTo(0.5, 1);
      
      vi.advanceTimersByTime(500);
      renderer.render(mockRenderContext, mockCoordinateSystem, startTime + 1000);
      
      expect(renderer.getAnimationProgress()).toBe(1);
      expect(renderer.isAnimating()).toBe(false);
    });

    it('should apply different easing functions correctly', () => {
      const testEasing = (easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out') => {
        const testRenderer = new CandlestickRenderer(
          { animation: { enabled: true, duration: 1000, easing } },
          DEFAULT_THEME
        );
        
        testRenderer.updateData(sampleCandles.slice(0, 3));
        testRenderer.updateData(sampleCandles);
        
        const startTime = performance.now();
        vi.advanceTimersByTime(500);
        testRenderer.render(mockRenderContext, mockCoordinateSystem, startTime + 500);
        
        const progress = testRenderer.getAnimationProgress();
        
        switch (easing) {
          case 'linear':
            expect(progress).toBeCloseTo(0.5, 1);
            break;
          case 'ease-in':
            expect(progress).toBeLessThan(0.5);
            break;
          case 'ease-out':
            expect(progress).toBeGreaterThan(0.5);
            break;
          case 'ease-in-out':
            // At 50%, ease-in-out should be close to 0.5
            expect(progress).toBeCloseTo(0.5, 1);
            break;
        }
        
        testRenderer.destroy();
      };
      
      testEasing('linear');
      testEasing('ease-in');
      testEasing('ease-out');
      testEasing('ease-in-out');
    });
  });

  describe('Performance Optimizations', () => {
    it('should calculate visible range correctly', () => {
      renderer.updateData(sampleCandles);
      
      const visibleRange = renderer.getVisibleRange(1500, 3500);
      
      expect(visibleRange.start).toBeGreaterThanOrEqual(0);
      expect(visibleRange.end).toBeLessThan(sampleCandles.length);
      expect(visibleRange.data.length).toBeGreaterThan(0);
      
      // Should include candles within the time range
      visibleRange.data.forEach(candle => {
        expect(candle.t).toBeGreaterThanOrEqual(1000); // Allow some buffer
        expect(candle.t).toBeLessThanOrEqual(4000); // Allow some buffer
      });
    });

    it('should handle edge cases in visible range calculation', () => {
      renderer.updateData(sampleCandles);
      
      // Test range before all data
      const beforeRange = renderer.getVisibleRange(0, 500);
      expect(beforeRange.data.length).toBeGreaterThan(0);
      
      // Test range after all data
      const afterRange = renderer.getVisibleRange(6000, 7000);
      expect(afterRange.data.length).toBeGreaterThan(0);
      
      // Test range covering all data
      const fullRange = renderer.getVisibleRange(0, 10000);
      expect(fullRange.data.length).toBe(sampleCandles.length);
    });
  });

  describe('Price and Volume Formatting', () => {
    it('should format prices correctly', () => {
      const renderer = new CandlestickRenderer({}, DEFAULT_THEME);
      
      // Test different price ranges
      // Note: These are internal methods, so we'd need to expose them or test through public API
      // For now, we test through the rendering process
      
      const highPriceCandles: Candle[] = [
        { t: 1000, o: 50000, h: 51000, l: 49000, c: 50500, v: 1000 }
      ];
      
      const lowPriceCandles: Candle[] = [
        { t: 1000, o: 0.001, h: 0.0011, l: 0.0009, c: 0.00105, v: 1000 }
      ];
      
      expect(() => {
        renderer.updateData(highPriceCandles);
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
      
      expect(() => {
        renderer.updateData(lowPriceCandles);
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });
  });

  describe('Configuration Updates', () => {
    it('should update configuration correctly', () => {
      const newConfig = {
        chartType: 'heikin-ashi' as const,
        showVolume: false,
        style: {
          bodyWidth: 0.9,
          wickWidth: 2,
          spacing: 3,
          borderWidth: 2,
          shadowOffset: 1
        }
      };
      
      renderer.updateConfig(newConfig);
      const config = renderer.getConfig();
      
      expect(config.chartType).toBe('heikin-ashi');
      expect(config.showVolume).toBe(false);
      expect(config.style.bodyWidth).toBe(0.9);
      expect(config.style.wickWidth).toBe(2);
    });

    it('should recalculate Heikin-Ashi when chart type changes', () => {
      renderer.updateData(sampleCandles);
      
      // Initially Heikin-Ashi data is calculated when data is updated
      expect(renderer.getHeikinAshiData()).toHaveLength(sampleCandles.length);
      
      // Change to Heikin-Ashi
      renderer.updateConfig({ chartType: 'heikin-ashi' });
      expect(renderer.getHeikinAshiData()).toHaveLength(sampleCandles.length);
      
      // Change back to candlestick
      renderer.updateConfig({ chartType: 'candlestick' });
      // Heikin-Ashi data should still be available but not used
      expect(renderer.getHeikinAshiData()).toHaveLength(sampleCandles.length);
    });
  });

  describe('Theme Updates', () => {
    it('should update theme correctly', () => {
      const newTheme = {
        ...DEFAULT_THEME,
        candlestick: {
          bullish: { body: '#00ff00', wick: '#00ff00', border: '#00cc00' },
          bearish: { body: '#ff0000', wick: '#ff0000', border: '#cc0000' }
        }
      };
      
      expect(() => {
        renderer.updateTheme(newTheme);
        renderer.updateData(sampleCandles);
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });
  });

  describe('Error Handling', () => {
    it('should handle invalid data gracefully', () => {
      const invalidCandles: Candle[] = [
        { t: NaN, o: 100, h: 110, l: 95, c: 105, v: 1000 },
        { t: 1000, o: NaN, h: 110, l: 95, c: 105, v: 1000 },
        { t: 2000, o: 100, h: NaN, l: 95, c: 105, v: 1000 }
      ];
      
      expect(() => {
        renderer.updateData(invalidCandles);
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });

    it('should handle zero volume gracefully', () => {
      const zeroVolumeCandles: Candle[] = [
        { t: 1000, o: 100, h: 110, l: 95, c: 105, v: 0 }
      ];
      
      expect(() => {
        renderer.updateData(zeroVolumeCandles);
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });

    it('should handle identical OHLC values', () => {
      const dojiCandles: Candle[] = [
        { t: 1000, o: 100, h: 100, l: 100, c: 100, v: 1000 }
      ];
      
      expect(() => {
        renderer.updateData(dojiCandles);
        renderer.render(mockRenderContext, mockCoordinateSystem);
      }).not.toThrow();
    });
  });

  describe('Memory Management', () => {
    it('should clean up resources on destroy', () => {
      renderer.updateData(sampleCandles);
      renderer.updateConfig({ chartType: 'heikin-ashi' });
      
      expect(renderer.getData()).toHaveLength(5);
      expect(renderer.getHeikinAshiData()).toHaveLength(5);
      
      renderer.destroy();
      
      expect(renderer.getData()).toHaveLength(0);
      expect(renderer.getHeikinAshiData()).toHaveLength(0);
      expect(renderer.isAnimating()).toBe(false);
    });
  });
});
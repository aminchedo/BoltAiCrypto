/**
 * Professional Candlestick Renderer for TradingView-Enhanced Crypto Trading Chart
 * 
 * This module provides professional OHLC candlestick visualization with:
 * - Proper OHLC candlestick rendering with color coding
 * - Volume bars with synchronized scaling
 * - Heikin-Ashi chart type support
 * - Smooth animations and visual accuracy
 * - Performance optimizations for real-time data
 */

import { Candle } from '../../types';
import { ChartEngine, ChartTheme, CoordinateSystem, RenderContext } from './ChartEngine';

// ===== INTERFACES =====

export interface CandlestickStyle {
  bodyWidth: number;
  wickWidth: number;
  spacing: number;
  borderWidth: number;
  shadowOffset: number;
}

export interface VolumeStyle {
  height: number;
  opacity: number;
  position: 'bottom' | 'overlay';
  showLabels: boolean;
}

export interface HeikinAshiCandle {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
  originalCandle: Candle;
}

export interface CandlestickConfig {
  style: CandlestickStyle;
  volumeStyle: VolumeStyle;
  showVolume: boolean;
  chartType: 'candlestick' | 'heikin-ashi';
  animation: {
    enabled: boolean;
    duration: number;
    easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';
  };
}

export interface PriceRange {
  min: number;
  max: number;
  range: number;
}

export interface VolumeRange {
  min: number;
  max: number;
  range: number;
}

export interface RenderMetrics {
  visibleCandles: number;
  candleWidth: number;
  volumeHeight: number;
  priceRange: PriceRange;
  volumeRange: VolumeRange;
}

// ===== DEFAULT CONFIGURATIONS =====

export const DEFAULT_CANDLESTICK_STYLE: CandlestickStyle = {
  bodyWidth: 0.8,
  wickWidth: 1,
  spacing: 2,
  borderWidth: 1,
  shadowOffset: 0
};

export const DEFAULT_VOLUME_STYLE: VolumeStyle = {
  height: 0.25, // 25% of chart height
  opacity: 0.6,
  position: 'bottom',
  showLabels: true
};

export const DEFAULT_CANDLESTICK_CONFIG: CandlestickConfig = {
  style: DEFAULT_CANDLESTICK_STYLE,
  volumeStyle: DEFAULT_VOLUME_STYLE,
  showVolume: true,
  chartType: 'candlestick',
  animation: {
    enabled: true,
    duration: 300,
    easing: 'ease-out'
  }
};

// ===== MAIN CANDLESTICK RENDERER CLASS =====

export class CandlestickRenderer {
  private config: CandlestickConfig;
  private theme: ChartTheme;
  private data: Candle[] = [];
  private heikinAshiData: HeikinAshiCandle[] = [];
  private animationProgress = 1;
  private animationStartTime = 0;
  private _isAnimating = false;

  constructor(config: Partial<CandlestickConfig> = {}, theme: ChartTheme) {
    this.config = { ...DEFAULT_CANDLESTICK_CONFIG, ...config };
    this.theme = theme;
  }

  // ===== DATA MANAGEMENT =====

  public updateData(data: Candle[]): void {
    const previousLength = this.data.length;
    this.data = [...data];
    
    // Calculate Heikin-Ashi data
    this.calculateHeikinAshi();
    
    // Start animation if new data is added
    if (this.config.animation.enabled && data.length > previousLength) {
      this.startAnimation();
    }
  }

  public updateConfig(config: Partial<CandlestickConfig>): void {
    this.config = { ...this.config, ...config };
    
    // Recalculate Heikin-Ashi if chart type changed
    if (config.chartType) {
      this.calculateHeikinAshi();
    }
  }

  public updateTheme(theme: ChartTheme): void {
    this.theme = theme;
  }

  // ===== HEIKIN-ASHI CALCULATIONS =====

  private calculateHeikinAshi(): void {
    if (this.data.length === 0) {
      this.heikinAshiData = [];
      return;
    }

    this.heikinAshiData = [];
    let previousHA: HeikinAshiCandle | null = null;

    for (let i = 0; i < this.data.length; i++) {
      const candle = this.data[i];
      
      let haOpen: number;
      let haClose: number;
      let haHigh: number;
      let haLow: number;

      // Calculate Heikin-Ashi values
      haClose = (candle.o + candle.h + candle.l + candle.c) / 4;
      
      if (previousHA === null) {
        haOpen = (candle.o + candle.c) / 2;
      } else {
        haOpen = (previousHA.o + previousHA.c) / 2;
      }
      
      haHigh = Math.max(candle.h, haOpen, haClose);
      haLow = Math.min(candle.l, haOpen, haClose);

      const heikinAshiCandle: HeikinAshiCandle = {
        t: candle.t,
        o: haOpen,
        h: haHigh,
        l: haLow,
        c: haClose,
        v: candle.v,
        originalCandle: candle
      };

      this.heikinAshiData.push(heikinAshiCandle);
      previousHA = heikinAshiCandle;
    }
  }

  // ===== ANIMATION MANAGEMENT =====

  private startAnimation(): void {
    if (!this.config.animation.enabled) return;
    
    this._isAnimating = true;
    this.animationStartTime = performance.now();
    this.animationProgress = 0;
  }

  private updateAnimation(currentTime: number): void {
    if (!this._isAnimating) return;
    
    const elapsed = currentTime - this.animationStartTime;
    const progress = Math.min(elapsed / this.config.animation.duration, 1);
    
    // Apply easing function
    this.animationProgress = this.applyEasing(progress, this.config.animation.easing);
    
    if (progress >= 1) {
      this._isAnimating = false;
      this.animationProgress = 1;
    }
  }

  private applyEasing(t: number, easing: string): number {
    switch (easing) {
      case 'linear':
        return t;
      case 'ease-in':
        return t * t;
      case 'ease-out':
        return 1 - Math.pow(1 - t, 2);
      case 'ease-in-out':
        return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      default:
        return t;
    }
  }

  // ===== RENDERING CALCULATIONS =====

  private calculateRenderMetrics(
    renderContext: RenderContext,
    coordinateSystem: CoordinateSystem
  ): RenderMetrics {
    const { width, height } = renderContext;
    const data = this.getCurrentData();
    
    if (data.length === 0) {
      return {
        visibleCandles: 0,
        candleWidth: 0,
        volumeHeight: 0,
        priceRange: { min: 0, max: 0, range: 0 },
        volumeRange: { min: 0, max: 0, range: 0 }
      };
    }

    // Calculate visible area (accounting for margins)
    const margin = 20;
    const chartWidth = width - (margin * 2);
    const chartHeight = height - (margin * 2);
    
    // Calculate candle width based on available space and data length
    const availableWidth = chartWidth - (this.config.style.spacing * (data.length - 1));
    const candleWidth = Math.max(2, Math.min(20, availableWidth / data.length));
    
    // Calculate volume height
    const volumeHeight = this.config.showVolume ? 
      chartHeight * this.config.volumeStyle.height : 0;
    
    // Calculate price range
    const prices = data.flatMap(d => [d.h, d.l]);
    const priceMin = Math.min(...prices);
    const priceMax = Math.max(...prices);
    const priceRange = priceMax - priceMin;
    
    // Calculate volume range
    const volumes = data.map(d => d.v);
    const volumeMin = Math.min(...volumes);
    const volumeMax = Math.max(...volumes);
    const volumeRange = volumeMax - volumeMin;

    return {
      visibleCandles: data.length,
      candleWidth,
      volumeHeight,
      priceRange: { min: priceMin, max: priceMax, range: priceRange },
      volumeRange: { min: volumeMin, max: volumeMax, range: volumeRange }
    };
  }

  private getCurrentData(): (Candle | HeikinAshiCandle)[] {
    return this.config.chartType === 'heikin-ashi' ? this.heikinAshiData : this.data;
  }

  // ===== MAIN RENDERING METHOD =====

  public render(
    renderContext: RenderContext,
    coordinateSystem: CoordinateSystem,
    currentTime: number = performance.now()
  ): void {
    // Update animation
    this.updateAnimation(currentTime);
    
    // Calculate render metrics
    const metrics = this.calculateRenderMetrics(renderContext, coordinateSystem);
    
    if (metrics.visibleCandles === 0) return;
    
    const { ctx } = renderContext;
    
    // Save context state
    ctx.save();
    
    try {
      // Render volume bars first (behind candlesticks)
      if (this.config.showVolume) {
        this.renderVolumeBars(renderContext, coordinateSystem, metrics);
      }
      
      // Render candlesticks
      this.renderCandlesticks(renderContext, coordinateSystem, metrics);
      
      // Render price labels
      this.renderPriceLabels(renderContext, coordinateSystem, metrics);
      
    } finally {
      // Restore context state
      ctx.restore();
    }
  }

  // ===== CANDLESTICK RENDERING =====

  private renderCandlesticks(
    renderContext: RenderContext,
    coordinateSystem: CoordinateSystem,
    metrics: RenderMetrics
  ): void {
    const { ctx, width, height } = renderContext;
    const data = this.getCurrentData();
    const { candleWidth } = metrics;
    
    const margin = 20;
    const chartHeight = height - (margin * 2) - metrics.volumeHeight;
    
    data.forEach((candle, index) => {
      const x = margin + (index * (candleWidth + this.config.style.spacing));
      
      // Apply animation scaling
      const animationScale = this._isAnimating ? this.animationProgress : 1;
      
      this.renderSingleCandlestick(
        ctx,
        candle,
        x,
        candleWidth,
        chartHeight,
        margin,
        metrics.priceRange,
        animationScale
      );
    });
  }

  private renderSingleCandlestick(
    ctx: CanvasRenderingContext2D,
    candle: Candle | HeikinAshiCandle,
    x: number,
    width: number,
    chartHeight: number,
    margin: number,
    priceRange: PriceRange,
    animationScale: number
  ): void {
    const isBullish = candle.c >= candle.o;
    const colors = isBullish ? this.theme.candlestick.bullish : this.theme.candlestick.bearish;
    
    // Calculate positions
    const bodyWidth = width * this.config.style.bodyWidth * animationScale;
    const wickWidth = this.config.style.wickWidth;
    
    // Convert prices to Y coordinates
    const highY = this.priceToY(candle.h, priceRange, chartHeight, margin);
    const lowY = this.priceToY(candle.l, priceRange, chartHeight, margin);
    const openY = this.priceToY(candle.o, priceRange, chartHeight, margin);
    const closeY = this.priceToY(candle.c, priceRange, chartHeight, margin);
    
    const bodyTop = Math.min(openY, closeY);
    const bodyBottom = Math.max(openY, closeY);
    const bodyHeight = Math.max(1, bodyBottom - bodyTop);
    
    const centerX = x + width / 2;
    const bodyLeft = centerX - bodyWidth / 2;
    
    // Draw upper wick
    if (highY < bodyTop) {
      ctx.strokeStyle = colors.wick;
      ctx.lineWidth = wickWidth;
      ctx.beginPath();
      ctx.moveTo(centerX, highY);
      ctx.lineTo(centerX, bodyTop);
      ctx.stroke();
    }
    
    // Draw lower wick
    if (lowY > bodyBottom) {
      ctx.strokeStyle = colors.wick;
      ctx.lineWidth = wickWidth;
      ctx.beginPath();
      ctx.moveTo(centerX, bodyBottom);
      ctx.lineTo(centerX, lowY);
      ctx.stroke();
    }
    
    // Draw body
    if (bodyHeight > 1) {
      // Filled body
      ctx.fillStyle = colors.body;
      ctx.fillRect(bodyLeft, bodyTop, bodyWidth, bodyHeight);
      
      // Body border
      if (this.config.style.borderWidth > 0) {
        ctx.strokeStyle = colors.border;
        ctx.lineWidth = this.config.style.borderWidth;
        ctx.strokeRect(bodyLeft, bodyTop, bodyWidth, bodyHeight);
      }
    } else {
      // Doji or very small body - draw as line
      ctx.strokeStyle = colors.body;
      ctx.lineWidth = Math.max(1, wickWidth);
      ctx.beginPath();
      ctx.moveTo(bodyLeft, bodyTop);
      ctx.lineTo(bodyLeft + bodyWidth, bodyTop);
      ctx.stroke();
    }
  }

  // ===== VOLUME RENDERING =====

  private renderVolumeBars(
    renderContext: RenderContext,
    coordinateSystem: CoordinateSystem,
    metrics: RenderMetrics
  ): void {
    const { ctx, width, height } = renderContext;
    const data = this.getCurrentData();
    const { candleWidth, volumeHeight, volumeRange } = metrics;
    
    if (volumeHeight === 0 || volumeRange.range === 0) return;
    
    const margin = 20;
    const volumeTop = height - margin - volumeHeight;
    
    data.forEach((candle, index) => {
      const x = margin + (index * (candleWidth + this.config.style.spacing));
      
      // Apply animation scaling
      const animationScale = this._isAnimating ? this.animationProgress : 1;
      
      this.renderSingleVolumeBar(
        ctx,
        candle,
        x,
        candleWidth,
        volumeTop,
        volumeHeight,
        volumeRange,
        animationScale
      );
    });
  }

  private renderSingleVolumeBar(
    ctx: CanvasRenderingContext2D,
    candle: Candle | HeikinAshiCandle,
    x: number,
    width: number,
    volumeTop: number,
    volumeHeight: number,
    volumeRange: VolumeRange,
    animationScale: number
  ): void {
    const isBullish = candle.c >= candle.o;
    const color = isBullish ? this.theme.volume.bullish : this.theme.volume.bearish;
    
    // Calculate volume bar height
    const normalizedVolume = volumeRange.range > 0 ? 
      (candle.v - volumeRange.min) / volumeRange.range : 0;
    const barHeight = normalizedVolume * volumeHeight * animationScale;
    
    // Draw volume bar
    ctx.fillStyle = color;
    ctx.globalAlpha = this.config.volumeStyle.opacity;
    ctx.fillRect(x, volumeTop + volumeHeight - barHeight, width, barHeight);
    ctx.globalAlpha = 1;
  }

  // ===== PRICE LABELS =====

  private renderPriceLabels(
    renderContext: RenderContext,
    coordinateSystem: CoordinateSystem,
    metrics: RenderMetrics
  ): void {
    const { ctx, width, height } = renderContext;
    const { priceRange } = metrics;
    
    if (priceRange.range === 0) return;
    
    const margin = 20;
    const chartHeight = height - (margin * 2) - metrics.volumeHeight;
    const labelCount = 5;
    
    ctx.fillStyle = this.theme.text;
    ctx.font = '12px Arial';
    ctx.textAlign = 'left';
    
    for (let i = 0; i <= labelCount; i++) {
      const ratio = i / labelCount;
      const price = priceRange.min + (priceRange.range * ratio);
      const y = this.priceToY(price, priceRange, chartHeight, margin);
      
      // Format price with appropriate decimal places
      const formattedPrice = this.formatPrice(price);
      
      // Draw price label
      ctx.fillText(formattedPrice, width - 80, y + 4);
      
      // Draw horizontal grid line
      ctx.strokeStyle = this.theme.grid;
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      ctx.beginPath();
      ctx.moveTo(margin, y);
      ctx.lineTo(width - 85, y);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  // ===== UTILITY METHODS =====

  private priceToY(
    price: number,
    priceRange: PriceRange,
    chartHeight: number,
    margin: number
  ): number {
    if (priceRange.range === 0) return margin + chartHeight / 2;
    
    const normalizedPrice = (price - priceRange.min) / priceRange.range;
    return margin + chartHeight - (normalizedPrice * chartHeight);
  }

  private formatPrice(price: number): string {
    if (price >= 1000) {
      return price.toLocaleString(undefined, { maximumFractionDigits: 2 });
    } else if (price >= 1) {
      return price.toFixed(4);
    } else {
      return price.toFixed(6);
    }
  }

  private formatVolume(volume: number): string {
    if (volume >= 1e9) {
      return (volume / 1e9).toFixed(2) + 'B';
    } else if (volume >= 1e6) {
      return (volume / 1e6).toFixed(2) + 'M';
    } else if (volume >= 1e3) {
      return (volume / 1e3).toFixed(2) + 'K';
    } else {
      return volume.toFixed(0);
    }
  }

  // ===== PUBLIC API =====

  public getConfig(): CandlestickConfig {
    return { ...this.config };
  }

  public getData(): Candle[] {
    return [...this.data];
  }

  public getHeikinAshiData(): HeikinAshiCandle[] {
    return [...this.heikinAshiData];
  }

  public isAnimating(): boolean {
    return this._isAnimating;
  }

  public getAnimationProgress(): number {
    return this.animationProgress;
  }

  // ===== PERFORMANCE METHODS =====

  public getVisibleRange(
    startTime: number,
    endTime: number
  ): { start: number; end: number; data: (Candle | HeikinAshiCandle)[] } {
    const data = this.getCurrentData();
    
    let start = 0;
    let end = data.length - 1;
    
    // Binary search for start index
    let left = 0;
    let right = data.length - 1;
    while (left <= right) {
      const mid = Math.floor((left + right) / 2);
      if (data[mid].t < startTime) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
    start = Math.max(0, left - 1);
    
    // Binary search for end index
    left = 0;
    right = data.length - 1;
    while (left <= right) {
      const mid = Math.floor((left + right) / 2);
      if (data[mid].t <= endTime) {
        left = mid + 1;
      } else {
        right = mid - 1;
      }
    }
    end = Math.min(data.length - 1, left);
    
    return {
      start,
      end,
      data: data.slice(start, end + 1)
    };
  }

  public destroy(): void {
    this.data = [];
    this.heikinAshiData = [];
    this._isAnimating = false;
  }
}

export default CandlestickRenderer;
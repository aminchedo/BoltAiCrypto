/**
 * Advanced Chart Engine for TradingView-Enhanced Crypto Trading Chart
 * 
 * This module provides the core chart rendering infrastructure with Canvas and WebGL support,
 * viewport management, coordinate transformations, and smooth zoom/pan functionality.
 * 
 * Features:
 * - Canvas and WebGL rendering contexts
 * - Viewport management and coordinate transformation systems
 * - Smooth zoom and pan functionality with momentum scrolling
 * - Performance optimizations for real-time data
 * - Responsive design integration
 */

import { Candle } from '../../types';

// ===== CORE INTERFACES =====

export interface Point {
  x: number;
  y: number;
}

export interface Viewport {
  x: number;
  y: number;
  width: number;
  height: number;
  scale: number;
  minScale: number;
  maxScale: number;
}

export interface ChartTheme {
  background: string;
  foreground: string;
  grid: string;
  candlestick: {
    bullish: { body: string; wick: string; border: string };
    bearish: { body: string; wick: string; border: string };
  };
  volume: {
    bullish: string;
    bearish: string;
  };
  crosshair: string;
  selection: string;
  text: string;
}

export interface ChartConfig {
  chartType: 'candlestick' | 'line' | 'area' | 'volume' | 'heikin-ashi';
  timeframe: string;
  priceScale: 'linear' | 'logarithmic';
  volumeVisible: boolean;
  gridVisible: boolean;
  crosshairVisible: boolean;
  theme: ChartTheme;
  animation: {
    enabled: boolean;
    duration: number;
    easing: string;
  };
}

export interface RenderContext {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  webglCtx?: WebGLRenderingContext;
  pixelRatio: number;
  width: number;
  height: number;
}

export interface CoordinateSystem {
  priceToY(price: number): number;
  yToPrice(y: number): number;
  timeToX(timestamp: number): number;
  xToTime(x: number): number;
  screenToChart(screenPoint: Point): Point;
  chartToScreen(chartPoint: Point): Point;
}

export interface InteractionState {
  isMouseDown: boolean;
  isDragging: boolean;
  lastMousePosition: Point;
  dragStartPosition: Point;
  momentum: Point;
  isZooming: boolean;
  zoomCenter: Point;
}

// ===== DEFAULT CONFIGURATIONS =====

export const DEFAULT_THEME: ChartTheme = {
  background: '#1a1a1a',
  foreground: '#ffffff',
  grid: '#374151',
  candlestick: {
    bullish: { body: '#10b981', wick: '#10b981', border: '#059669' },
    bearish: { body: '#ef4444', wick: '#ef4444', border: '#dc2626' }
  },
  volume: {
    bullish: '#10b98150',
    bearish: '#ef444450'
  },
  crosshair: '#6b7280',
  selection: '#3b82f650',
  text: '#d1d5db'
};

export const DEFAULT_CONFIG: ChartConfig = {
  chartType: 'candlestick',
  timeframe: '1h',
  priceScale: 'linear',
  volumeVisible: true,
  gridVisible: true,
  crosshairVisible: true,
  theme: DEFAULT_THEME,
  animation: {
    enabled: true,
    duration: 300,
    easing: 'ease-out'
  }
};

// ===== MAIN CHART ENGINE CLASS =====

export class ChartEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private webglCtx?: WebGLRenderingContext;
  private config: ChartConfig;
  private viewport: Viewport;
  private interaction: InteractionState;
  private data: Candle[] = [];
  private animationFrame?: number;
  private resizeObserver?: ResizeObserver;
  private coordinateSystem: CoordinateSystem;
  private pixelRatio: number;
  
  // Performance tracking
  private lastRenderTime = 0;
  private frameCount = 0;
  private fps = 0;
  
  // Event callbacks
  private onDataUpdate?: (data: Candle[]) => void;
  private onViewportChange?: (viewport: Viewport) => void;
  private onInteraction?: (event: string, data: any) => void;

  constructor(canvas: HTMLCanvasElement, config: Partial<ChartConfig> = {}) {
    this.canvas = canvas;
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.pixelRatio = window.devicePixelRatio || 1;
    
    // Initialize rendering contexts
    this.initializeContexts();
    
    // Initialize viewport
    this.viewport = {
      x: 0,
      y: 0,
      width: canvas.width,
      height: canvas.height,
      scale: 1,
      minScale: 0.1,
      maxScale: 10
    };
    
    // Initialize interaction state
    this.interaction = {
      isMouseDown: false,
      isDragging: false,
      lastMousePosition: { x: 0, y: 0 },
      dragStartPosition: { x: 0, y: 0 },
      momentum: { x: 0, y: 0 },
      isZooming: false,
      zoomCenter: { x: 0, y: 0 }
    };
    
    // Initialize coordinate system
    this.coordinateSystem = this.createCoordinateSystem();
    
    // Setup event listeners
    this.setupEventListeners();
    
    // Setup resize observer
    this.setupResizeObserver();
    
    // Start render loop
    this.startRenderLoop();
  }

  // ===== INITIALIZATION METHODS =====

  private initializeContexts(): void {
    const ctx = this.canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Failed to get 2D rendering context');
    }
    this.ctx = ctx;
    
    // Try to get WebGL context for advanced rendering
    try {
      this.webglCtx = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl') || undefined;
      if (this.webglCtx) {
        console.log('✅ WebGL context initialized for advanced rendering');
      }
    } catch (error) {
      console.warn('⚠️ WebGL not available, falling back to Canvas 2D');
    }
    
    // Configure canvas for high DPI displays
    this.configureHighDPI();
  }

  private configureHighDPI(): void {
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width * this.pixelRatio;
    this.canvas.height = rect.height * this.pixelRatio;
    this.canvas.style.width = rect.width + 'px';
    this.canvas.style.height = rect.height + 'px';
    this.ctx.scale(this.pixelRatio, this.pixelRatio);
  }

  private createCoordinateSystem(): CoordinateSystem {
    return {
      priceToY: (price: number): number => {
        if (!this.data.length) return 0;
        
        const minPrice = Math.min(...this.data.map(d => d.l));
        const maxPrice = Math.max(...this.data.map(d => d.h));
        const priceRange = maxPrice - minPrice;
        
        if (priceRange === 0) return this.viewport.height / 2;
        
        const normalizedPrice = (price - minPrice) / priceRange;
        return this.viewport.height - (normalizedPrice * this.viewport.height * 0.8) - (this.viewport.height * 0.1);
      },
      
      yToPrice: (y: number): number => {
        if (!this.data.length) return 0;
        
        const minPrice = Math.min(...this.data.map(d => d.l));
        const maxPrice = Math.max(...this.data.map(d => d.h));
        const priceRange = maxPrice - minPrice;
        
        if (priceRange === 0) return minPrice;
        
        const normalizedY = (this.viewport.height - y - (this.viewport.height * 0.1)) / (this.viewport.height * 0.8);
        return minPrice + (normalizedY * priceRange);
      },
      
      timeToX: (timestamp: number): number => {
        if (!this.data.length) return 0;
        
        const minTime = this.data[0].t;
        const maxTime = this.data[this.data.length - 1].t;
        const timeRange = maxTime - minTime;
        
        if (timeRange === 0) return this.viewport.width / 2;
        
        const normalizedTime = (timestamp - minTime) / timeRange;
        return normalizedTime * this.viewport.width * 0.9 + this.viewport.width * 0.05;
      },
      
      xToTime: (x: number): number => {
        if (!this.data.length) return Date.now();
        
        const minTime = this.data[0].t;
        const maxTime = this.data[this.data.length - 1].t;
        const timeRange = maxTime - minTime;
        
        if (timeRange === 0) return minTime;
        
        const normalizedX = (x - this.viewport.width * 0.05) / (this.viewport.width * 0.9);
        return minTime + (normalizedX * timeRange);
      },
      
      screenToChart: (screenPoint: Point): Point => {
        return {
          x: (screenPoint.x - this.viewport.x) / this.viewport.scale,
          y: (screenPoint.y - this.viewport.y) / this.viewport.scale
        };
      },
      
      chartToScreen: (chartPoint: Point): Point => {
        return {
          x: chartPoint.x * this.viewport.scale + this.viewport.x,
          y: chartPoint.y * this.viewport.scale + this.viewport.y
        };
      }
    };
  }

  // ===== EVENT HANDLING =====

  private setupEventListeners(): void {
    // Mouse events
    this.canvas.addEventListener('mousedown', this.handleMouseDown.bind(this));
    this.canvas.addEventListener('mousemove', this.handleMouseMove.bind(this));
    this.canvas.addEventListener('mouseup', this.handleMouseUp.bind(this));
    this.canvas.addEventListener('wheel', this.handleWheel.bind(this));
    this.canvas.addEventListener('mouseleave', this.handleMouseLeave.bind(this));
    
    // Touch events for mobile support
    this.canvas.addEventListener('touchstart', this.handleTouchStart.bind(this));
    this.canvas.addEventListener('touchmove', this.handleTouchMove.bind(this));
    this.canvas.addEventListener('touchend', this.handleTouchEnd.bind(this));
    
    // Keyboard events
    this.canvas.addEventListener('keydown', this.handleKeyDown.bind(this));
    
    // Make canvas focusable for keyboard events
    this.canvas.tabIndex = 0;
  }

  private handleMouseDown(event: MouseEvent): void {
    const rect = this.canvas.getBoundingClientRect();
    const point = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
    
    this.interaction.isMouseDown = true;
    this.interaction.lastMousePosition = point;
    this.interaction.dragStartPosition = point;
    this.interaction.momentum = { x: 0, y: 0 };
    
    this.onInteraction?.('mousedown', { point, event });
  }

  private handleMouseMove(event: MouseEvent): void {
    const rect = this.canvas.getBoundingClientRect();
    const point = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
    
    if (this.interaction.isMouseDown) {
      const deltaX = point.x - this.interaction.lastMousePosition.x;
      const deltaY = point.y - this.interaction.lastMousePosition.y;
      
      // Start dragging if moved enough
      if (!this.interaction.isDragging && (Math.abs(deltaX) > 3 || Math.abs(deltaY) > 3)) {
        this.interaction.isDragging = true;
      }
      
      if (this.interaction.isDragging) {
        this.pan(deltaX, deltaY);
        this.interaction.momentum = { x: deltaX, y: deltaY };
      }
    }
    
    this.interaction.lastMousePosition = point;
    this.onInteraction?.('mousemove', { point, event });
  }

  private handleMouseUp(event: MouseEvent): void {
    if (this.interaction.isDragging && this.interaction.momentum) {
      // Apply momentum scrolling
      this.applyMomentum();
    }
    
    this.interaction.isMouseDown = false;
    this.interaction.isDragging = false;
    
    this.onInteraction?.('mouseup', { event });
  }

  private handleWheel(event: WheelEvent): void {
    event.preventDefault();
    
    const rect = this.canvas.getBoundingClientRect();
    const zoomCenter = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
    
    const zoomFactor = event.deltaY > 0 ? 0.9 : 1.1;
    this.zoom(zoomFactor, zoomCenter);
    
    this.onInteraction?.('wheel', { zoomFactor, zoomCenter, event });
  }

  private handleMouseLeave(): void {
    this.interaction.isMouseDown = false;
    this.interaction.isDragging = false;
  }

  private handleTouchStart(event: TouchEvent): void {
    event.preventDefault();
    if (event.touches.length === 1) {
      const touch = event.touches[0];
      const rect = this.canvas.getBoundingClientRect();
      const point = {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top
      };
      
      this.interaction.isMouseDown = true;
      this.interaction.lastMousePosition = point;
      this.interaction.dragStartPosition = point;
    }
  }

  private handleTouchMove(event: TouchEvent): void {
    event.preventDefault();
    if (event.touches.length === 1 && this.interaction.isMouseDown) {
      const touch = event.touches[0];
      const rect = this.canvas.getBoundingClientRect();
      const point = {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top
      };
      
      const deltaX = point.x - this.interaction.lastMousePosition.x;
      const deltaY = point.y - this.interaction.lastMousePosition.y;
      
      this.pan(deltaX, deltaY);
      this.interaction.lastMousePosition = point;
    }
  }

  private handleTouchEnd(event: TouchEvent): void {
    event.preventDefault();
    this.interaction.isMouseDown = false;
    this.interaction.isDragging = false;
  }

  private handleKeyDown(event: KeyboardEvent): void {
    const panStep = 20;
    const zoomStep = 0.1;
    
    switch (event.key) {
      case 'ArrowLeft':
        this.pan(-panStep, 0);
        break;
      case 'ArrowRight':
        this.pan(panStep, 0);
        break;
      case 'ArrowUp':
        this.pan(0, -panStep);
        break;
      case 'ArrowDown':
        this.pan(0, panStep);
        break;
      case '+':
      case '=':
        this.zoom(1 + zoomStep);
        break;
      case '-':
        this.zoom(1 - zoomStep);
        break;
      case '0':
        this.resetViewport();
        break;
    }
    
    this.onInteraction?.('keydown', { key: event.key, event });
  }

  // ===== VIEWPORT MANAGEMENT =====

  public pan(deltaX: number, deltaY: number): void {
    this.viewport.x += deltaX;
    this.viewport.y += deltaY;
    
    // Apply constraints if needed
    this.constrainViewport();
    
    this.onViewportChange?.(this.viewport);
  }

  public zoom(factor: number, center?: Point): void {
    const oldScale = this.viewport.scale;
    const newScale = Math.max(this.viewport.minScale, Math.min(this.viewport.maxScale, oldScale * factor));
    
    if (newScale === oldScale) return;
    
    const zoomCenter = center || { x: this.viewport.width / 2, y: this.viewport.height / 2 };
    
    // Adjust viewport position to zoom around the center point
    const scaleFactor = newScale / oldScale;
    this.viewport.x = zoomCenter.x - (zoomCenter.x - this.viewport.x) * scaleFactor;
    this.viewport.y = zoomCenter.y - (zoomCenter.y - this.viewport.y) * scaleFactor;
    this.viewport.scale = newScale;
    
    this.constrainViewport();
    this.onViewportChange?.(this.viewport);
  }

  public resetViewport(): void {
    this.viewport.x = 0;
    this.viewport.y = 0;
    this.viewport.scale = 1;
    this.onViewportChange?.(this.viewport);
  }

  private constrainViewport(): void {
    // Add viewport constraints here if needed
    // For now, we allow free movement
  }

  private applyMomentum(): void {
    if (!this.interaction.momentum || (Math.abs(this.interaction.momentum.x) < 0.1 && Math.abs(this.interaction.momentum.y) < 0.1)) {
      return;
    }
    
    const friction = 0.95;
    this.pan(this.interaction.momentum.x, this.interaction.momentum.y);
    this.interaction.momentum.x *= friction;
    this.interaction.momentum.y *= friction;
    
    // Continue momentum
    requestAnimationFrame(() => this.applyMomentum());
  }

  // ===== RESIZE HANDLING =====

  private setupResizeObserver(): void {
    this.resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        this.handleResize(entry.contentRect.width, entry.contentRect.height);
      }
    });
    
    this.resizeObserver.observe(this.canvas);
  }

  private handleResize(width: number, height: number): void {
    this.viewport.width = width;
    this.viewport.height = height;
    
    this.canvas.width = width * this.pixelRatio;
    this.canvas.height = height * this.pixelRatio;
    this.canvas.style.width = width + 'px';
    this.canvas.style.height = height + 'px';
    
    this.ctx.scale(this.pixelRatio, this.pixelRatio);
    
    // Recreate coordinate system
    this.coordinateSystem = this.createCoordinateSystem();
    
    this.onViewportChange?.(this.viewport);
  }

  // ===== RENDERING LOOP =====

  private startRenderLoop(): void {
    const render = (timestamp: number) => {
      this.calculateFPS(timestamp);
      this.render();
      this.animationFrame = requestAnimationFrame(render);
    };
    
    this.animationFrame = requestAnimationFrame(render);
  }

  private calculateFPS(timestamp: number): void {
    if (this.lastRenderTime === 0) {
      this.lastRenderTime = timestamp;
      return;
    }
    
    const delta = timestamp - this.lastRenderTime;
    this.frameCount++;
    
    if (this.frameCount >= 60) {
      this.fps = Math.round(1000 / (delta / this.frameCount));
      this.frameCount = 0;
    }
    
    this.lastRenderTime = timestamp;
  }

  private render(): void {
    // Clear canvas
    this.ctx.clearRect(0, 0, this.viewport.width, this.viewport.height);
    
    // Set background
    this.ctx.fillStyle = this.config.theme.background;
    this.ctx.fillRect(0, 0, this.viewport.width, this.viewport.height);
    
    // Render grid if enabled
    if (this.config.gridVisible) {
      this.renderGrid();
    }
    
    // Render data if available
    if (this.data.length > 0) {
      this.renderData();
    }
    
    // Render crosshair if enabled
    if (this.config.crosshairVisible && this.interaction.lastMousePosition) {
      this.renderCrosshair();
    }
    
    // Render performance info in debug mode
    if (process.env.NODE_ENV === 'development') {
      this.renderDebugInfo();
    }
  }

  private renderGrid(): void {
    this.ctx.strokeStyle = this.config.theme.grid;
    this.ctx.lineWidth = 1;
    this.ctx.setLineDash([2, 2]);
    
    const gridSpacing = 50;
    
    // Vertical lines
    for (let x = 0; x < this.viewport.width; x += gridSpacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(x, 0);
      this.ctx.lineTo(x, this.viewport.height);
      this.ctx.stroke();
    }
    
    // Horizontal lines
    for (let y = 0; y < this.viewport.height; y += gridSpacing) {
      this.ctx.beginPath();
      this.ctx.moveTo(0, y);
      this.ctx.lineTo(this.viewport.width, y);
      this.ctx.stroke();
    }
    
    this.ctx.setLineDash([]);
  }

  private renderData(): void {
    // This will be implemented in the CandlestickRenderer
    // For now, just render a placeholder
    this.ctx.fillStyle = this.config.theme.text;
    this.ctx.font = '14px Arial';
    this.ctx.fillText(`Data points: ${this.data.length}`, 10, 30);
  }

  private renderCrosshair(): void {
    const { x, y } = this.interaction.lastMousePosition;
    
    this.ctx.strokeStyle = this.config.theme.crosshair;
    this.ctx.lineWidth = 1;
    this.ctx.setLineDash([3, 3]);
    
    // Vertical line
    this.ctx.beginPath();
    this.ctx.moveTo(x, 0);
    this.ctx.lineTo(x, this.viewport.height);
    this.ctx.stroke();
    
    // Horizontal line
    this.ctx.beginPath();
    this.ctx.moveTo(0, y);
    this.ctx.lineTo(this.viewport.width, y);
    this.ctx.stroke();
    
    this.ctx.setLineDash([]);
  }

  private renderDebugInfo(): void {
    this.ctx.fillStyle = this.config.theme.text;
    this.ctx.font = '12px monospace';
    
    const debugInfo = [
      `FPS: ${this.fps}`,
      `Scale: ${this.viewport.scale.toFixed(2)}`,
      `Position: (${this.viewport.x.toFixed(0)}, ${this.viewport.y.toFixed(0)})`,
      `Data: ${this.data.length} candles`,
      `WebGL: ${this.webglCtx ? 'Available' : 'Not Available'}`
    ];
    
    debugInfo.forEach((info, index) => {
      this.ctx.fillText(info, 10, this.viewport.height - 80 + (index * 15));
    });
  }

  // ===== PUBLIC API =====

  public updateData(data: Candle[]): void {
    this.data = data;
    this.coordinateSystem = this.createCoordinateSystem();
    this.onDataUpdate?.(data);
  }

  public updateConfig(config: Partial<ChartConfig>): void {
    this.config = { ...this.config, ...config };
  }

  public getViewport(): Viewport {
    return { ...this.viewport };
  }

  public getCoordinateSystem(): CoordinateSystem {
    return this.coordinateSystem;
  }

  public getRenderContext(): RenderContext {
    return {
      canvas: this.canvas,
      ctx: this.ctx,
      webglCtx: this.webglCtx,
      pixelRatio: this.pixelRatio,
      width: this.viewport.width,
      height: this.viewport.height
    };
  }

  public getFPS(): number {
    return this.fps;
  }

  public setCallbacks(callbacks: {
    onDataUpdate?: (data: Candle[]) => void;
    onViewportChange?: (viewport: Viewport) => void;
    onInteraction?: (event: string, data: any) => void;
  }): void {
    this.onDataUpdate = callbacks.onDataUpdate;
    this.onViewportChange = callbacks.onViewportChange;
    this.onInteraction = callbacks.onInteraction;
  }

  public destroy(): void {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
    }
    
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    
    // Remove event listeners
    this.canvas.removeEventListener('mousedown', this.handleMouseDown);
    this.canvas.removeEventListener('mousemove', this.handleMouseMove);
    this.canvas.removeEventListener('mouseup', this.handleMouseUp);
    this.canvas.removeEventListener('wheel', this.handleWheel);
    this.canvas.removeEventListener('mouseleave', this.handleMouseLeave);
    this.canvas.removeEventListener('touchstart', this.handleTouchStart);
    this.canvas.removeEventListener('touchmove', this.handleTouchMove);
    this.canvas.removeEventListener('touchend', this.handleTouchEnd);
    this.canvas.removeEventListener('keydown', this.handleKeyDown);
  }
}

export default ChartEngine;
/**
 * Enhanced Trading Chart with Professional Candlestick Rendering
 * 
 * This component integrates the ChartEngine with the CandlestickRenderer
 * to provide a complete professional trading chart experience.
 */

import React, { useEffect, useRef, useState } from 'react';
import { ChartEngine, DEFAULT_THEME } from './ChartEngine';
import { CandlestickRenderer, DEFAULT_CANDLESTICK_CONFIG } from './CandlestickRenderer';
import { Candle } from '../../types';

interface TradingChartWithCandlesticksProps {
  data: Candle[];
  symbol: string;
  timeframe: string;
  width?: number;
  height?: number;
  showVolume?: boolean;
  chartType?: 'candlestick' | 'heikin-ashi';
  theme?: 'dark' | 'light';
  onCandleClick?: (candle: Candle, index: number) => void;
  onPriceHover?: (price: number) => void;
}

export const TradingChartWithCandlesticks: React.FC<TradingChartWithCandlesticksProps> = ({
  data,
  symbol,
  timeframe,
  width = 800,
  height = 600,
  showVolume = true,
  chartType = 'candlestick',
  theme = 'dark',
  onCandleClick,
  onPriceHover
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartEngineRef = useRef<ChartEngine | null>(null);
  const candlestickRendererRef = useRef<CandlestickRenderer | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize chart engine and candlestick renderer
  useEffect(() => {
    if (!canvasRef.current || isInitialized) return;

    try {
      // Create chart engine
      const chartEngine = new ChartEngine(canvasRef.current, {
        chartType,
        volumeVisible: showVolume,
        theme: theme === 'dark' ? DEFAULT_THEME : {
          ...DEFAULT_THEME,
          background: '#ffffff',
          foreground: '#000000',
          grid: '#e5e7eb',
          text: '#374151',
          candlestick: {
            bullish: { body: '#10b981', wick: '#10b981', border: '#059669' },
            bearish: { body: '#ef4444', wick: '#ef4444', border: '#dc2626' }
          },
          volume: {
            bullish: '#10b98150',
            bearish: '#ef444450'
          },
          crosshair: '#6b7280',
          selection: '#3b82f650'
        }
      });

      // Create candlestick renderer
      const candlestickRenderer = new CandlestickRenderer(
        {
          ...DEFAULT_CANDLESTICK_CONFIG,
          chartType,
          showVolume,
          animation: {
            enabled: true,
            duration: 300,
            easing: 'ease-out'
          }
        },
        chartEngine.getConfig().theme
      );

      // Set up callbacks
      chartEngine.setCallbacks({
        onDataUpdate: (newData) => {
          console.log('Chart data updated:', newData.length, 'candles');
        },
        onViewportChange: (viewport) => {
          console.log('Viewport changed:', viewport);
        },
        onInteraction: (event, eventData) => {
          if (event === 'mousemove' && onPriceHover) {
            const coordinateSystem = chartEngine.getCoordinateSystem();
            const price = coordinateSystem.yToPrice(eventData.point.y);
            onPriceHover(price);
          }
          
          if (event === 'mousedown' && onCandleClick) {
            const coordinateSystem = chartEngine.getCoordinateSystem();
            const timestamp = coordinateSystem.xToTime(eventData.point.x);
            
            // Find the closest candle
            const closestCandle = data.reduce((closest, candle, index) => {
              const distance = Math.abs(candle.t - timestamp);
              return distance < closest.distance ? { candle, index, distance } : closest;
            }, { candle: data[0], index: 0, distance: Infinity });
            
            if (closestCandle.distance < 60000) { // Within 1 minute
              onCandleClick(closestCandle.candle, closestCandle.index);
            }
          }
        }
      });

      chartEngineRef.current = chartEngine;
      candlestickRendererRef.current = candlestickRenderer;
      setIsInitialized(true);

      console.log('✅ Trading chart with candlesticks initialized');
    } catch (error) {
      console.error('❌ Failed to initialize trading chart:', error);
    }

    // Cleanup function
    return () => {
      if (chartEngineRef.current) {
        chartEngineRef.current.destroy();
        chartEngineRef.current = null;
      }
      if (candlestickRendererRef.current) {
        candlestickRendererRef.current.destroy();
        candlestickRendererRef.current = null;
      }
      setIsInitialized(false);
    };
  }, [isInitialized]);

  // Update data when props change
  useEffect(() => {
    if (!isInitialized || !chartEngineRef.current || !candlestickRendererRef.current) return;

    chartEngineRef.current.updateData(data);
    candlestickRendererRef.current.updateData(data);
  }, [data, isInitialized]);

  // Update configuration when props change
  useEffect(() => {
    if (!isInitialized || !candlestickRendererRef.current) return;

    candlestickRendererRef.current.updateConfig({
      chartType,
      showVolume
    });
  }, [chartType, showVolume, isInitialized]);

  // Custom render loop that integrates candlestick rendering
  useEffect(() => {
    if (!isInitialized || !chartEngineRef.current || !candlestickRendererRef.current) return;

    const chartEngine = chartEngineRef.current;
    const candlestickRenderer = candlestickRendererRef.current;
    
    // Override the chart engine's render method to include candlestick rendering
    const originalRender = chartEngine['render'].bind(chartEngine);
    
    chartEngine['render'] = function() {
      // Call original render for background, grid, etc.
      const renderContext = this.getRenderContext();
      const coordinateSystem = this.getCoordinateSystem();
      
      // Clear canvas
      renderContext.ctx.clearRect(0, 0, renderContext.width, renderContext.height);
      
      // Set background
      renderContext.ctx.fillStyle = this.config.theme.background;
      renderContext.ctx.fillRect(0, 0, renderContext.width, renderContext.height);
      
      // Render grid if enabled
      if (this.config.gridVisible) {
        this['renderGrid']();
      }
      
      // Render candlesticks using our professional renderer
      if (data.length > 0) {
        candlestickRenderer.render(renderContext, coordinateSystem);
      }
      
      // Render crosshair if enabled
      if (this.config.crosshairVisible && this.interaction.lastMousePosition) {
        this['renderCrosshair']();
      }
      
      // Render debug info in development
      if (process.env.NODE_ENV === 'development') {
        this['renderDebugInfo']();
      }
    };

  }, [isInitialized, data]);

  return (
    <div className="trading-chart-container">
      <div className="chart-header mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {symbol} - {timeframe}
            </h3>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {data.length} candles
              </span>
              {candlestickRendererRef.current?.isAnimating() && (
                <span className="text-xs text-blue-500 animate-pulse">
                  Animating...
                </span>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => candlestickRendererRef.current?.updateConfig({ 
                chartType: chartType === 'candlestick' ? 'heikin-ashi' : 'candlestick' 
              })}
              className="px-3 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
            >
              {chartType === 'candlestick' ? 'Heikin-Ashi' : 'Candlestick'}
            </button>
            
            <button
              onClick={() => candlestickRendererRef.current?.updateConfig({ 
                showVolume: !showVolume 
              })}
              className="px-3 py-1 text-xs bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors"
            >
              {showVolume ? 'Hide Volume' : 'Show Volume'}
            </button>
          </div>
        </div>
      </div>
      
      <div className="chart-canvas-container relative">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className="border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm"
          style={{ width: `${width}px`, height: `${height}px` }}
        />
        
        {!isInitialized && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Initializing chart...
              </p>
            </div>
          </div>
        )}
      </div>
      
      <div className="chart-info mt-2 text-xs text-gray-500 dark:text-gray-400">
        <div className="flex items-center justify-between">
          <span>
            Chart Type: {chartType} | Volume: {showVolume ? 'On' : 'Off'}
          </span>
          <span>
            FPS: {chartEngineRef.current?.getFPS() || 0}
          </span>
        </div>
      </div>
    </div>
  );
};

export default TradingChartWithCandlesticks;
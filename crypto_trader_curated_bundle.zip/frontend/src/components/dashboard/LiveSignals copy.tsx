import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { realDataService, type TradingSignal } from '../../services/realDataService';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Zap, 
  AlertCircle, 
  Target,
  Brain,
  Star,
  Eye,
  Copy,
  Filter,
  Settings,
  Play,
  Pause,
  RotateCcw,
  ChevronDown,
  Check,
  X,
  Info,
  Flame,
  Shield,
  Trophy,
  Activity
} from 'lucide-react';

interface Signal {
  id: string;
  symbol: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  target: number;
  stopLoss: number;
  timestamp: Date;
  status: 'active' | 'executed' | 'expired' | 'cancelled';
  aiModel: string;
  riskLevel: 'low' | 'medium' | 'high';
  timeframe: string;
  volume: number;
  accuracy?: number;
  tags: string[];
  expectedReturn: number;
  reason: string;
}

interface SignalFilter {
  signal: 'ALL' | 'BUY' | 'SELL' | 'HOLD';
  status: 'ALL' | 'active' | 'executed' | 'expired';
  confidence: number;
  riskLevel: 'ALL' | 'low' | 'medium' | 'high';
}

interface AIEngine {
  name: string;
  accuracy: number;
  signals: number;
  status: 'active' | 'learning' | 'offline';
  color: string;
}

const LiveSignals: React.FC = () => {
  // Real data states
  const [realSignals, setRealSignals] = useState<TradingSignal[]>([]);
  const [isLoadingReal, setIsLoadingReal] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // UI states (preserved for compatibility)
  const [signals, setSignals] = useState<Signal[]>([]);

  // Use real signals when available, fallback to mock data
  const displaySignals = realSignals.length > 0 ? realSignals.map(signal => ({
    ...signal,
    // Ensure compatibility with existing UI interface
    timestamp: new Date(signal.timestamp)
  })) : signals;

  const [filter, setFilter] = useState<SignalFilter>({
    signal: 'ALL',
    status: 'ALL',
    confidence: 0,
    riskLevel: 'ALL'
  });

  const [aiEngines] = useState<AIEngine[]>([
    { name: 'Neural Alpha', accuracy: 89.2, signals: 23, status: 'active', color: '#10b981' },
    { name: 'Quantum Beta', accuracy: 85.7, signals: 18, status: 'active', color: '#3b82f6' },
    { name: 'Deep Gamma', accuracy: 92.1, signals: 12, status: 'learning', color: '#8b5cf6' },
    { name: 'Fusion Delta', accuracy: 78.9, signals: 31, status: 'active', color: '#f59e0b' }
  ]);

  const [successRate, setSuccessRate] = useState(87.3);
  const [totalSignals, setTotalSignals] = useState(47);
  const [isAutoTrade, setIsAutoTrade] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedSignal, setSelectedSignal] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Generate new signals
  const generateSignal = useCallback((): Signal => {
    const symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'ADA/USDT', 'DOT/USDT', 'LINK/USDT', 'AVAX/USDT', 'MATIC/USDT'];
    const aiModels = ['Neural Alpha', 'Quantum Beta', 'Deep Gamma', 'Fusion Delta'];
    const signalTypes: ('BUY' | 'SELL' | 'HOLD')[] = ['BUY', 'SELL', 'HOLD'];
    const riskLevels: ('low' | 'medium' | 'high')[] = ['low', 'medium', 'high'];
    const timeframes = ['1M', '5M', '15M', '1H', '4H', '1D'];
    const tagSets = [
      ['breakout', 'momentum'],
      ['support', 'bounce'],
      ['resistance', 'rejection'],
      ['oversold', 'reversal'],
      ['overbought', 'correction'],
      ['trend', 'continuation'],
      ['scalping', 'quick'],
      ['swing', 'position']
    ];

    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const signal = signalTypes[Math.floor(Math.random() * signalTypes.length)];
    const basePrice = Math.random() * 100000 + 1000;
    const confidence = Math.floor(Math.random() * 30) + 70;
    const riskLevel = riskLevels[Math.floor(Math.random() * riskLevels.length)];
    
    return {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      symbol,
      signal,
      confidence,
      price: basePrice,
      target: signal === 'BUY' ? basePrice * 1.05 : basePrice * 0.95,
      stopLoss: signal === 'BUY' ? basePrice * 0.97 : basePrice * 1.03,
      timestamp: new Date(),
      status: 'active',
      aiModel: aiModels[Math.floor(Math.random() * aiModels.length)],
      riskLevel,
      timeframe: timeframes[Math.floor(Math.random() * timeframes.length)],
      volume: Math.random() * 2000000 + 500000,
      accuracy: Math.floor(Math.random() * 20) + 80,
      tags: tagSets[Math.floor(Math.random() * tagSets.length)],
      expectedReturn: (Math.random() - 0.5) * 10,
      reason: 'AI algorithm detected profitable opportunity'
    };
  }, []);

  // Fetch real trading signals
  useEffect(() => {
    const fetchRealSignals = async () => {
      setIsLoadingReal(true);
      setError(null);
      
      try {
        console.log('🔄 LiveSignals: Fetching real trading signals...');
        
        const tradingSignals = await realDataService.fetchTradingSignals();
        setRealSignals(tradingSignals);
        setTotalSignals(tradingSignals.length);
        
        // Update success rate based on real signals
        const executedSignals = tradingSignals.filter(s => s.status === 'executed');
        if (executedSignals.length > 0) {
          const avgAccuracy = executedSignals.reduce((sum, s) => sum + (s.accuracy || 85), 0) / executedSignals.length;
          setSuccessRate(avgAccuracy);
        }
        
        console.log('✅ LiveSignals: Real trading signals loaded successfully');
        console.log(`📊 Total Signals: ${tradingSignals.length}`);
        console.log(`🎯 Active Signals: ${tradingSignals.filter(s => s.status === 'active').length}`);
        
      } catch (err) {
        const errorMsg = `Failed to fetch trading signals: ${err.message}`;
        setError(errorMsg);
        console.error('❌ LiveSignals error:', errorMsg);
        
        // Fallback to mock signal generation
        console.log('🔄 Falling back to mock signal generation...');
        if (!isPaused) {
          const newSignal = generateSignal();
          setSignals(prev => [newSignal, ...prev.slice(0, 9)]);
          setTotalSignals(prev => prev + 1);
        }
      } finally {
        setIsLoadingReal(false);
      }
    };

    // Initial fetch
    fetchRealSignals();

    // Set up real-time updates every 3 minutes
    const interval = setInterval(fetchRealSignals, 180000);

    // Subscribe to real-time updates from the service
    const unsubscribe = realDataService.subscribe('tradingSignals', (data: TradingSignal[]) => {
      setRealSignals(data);
      setTotalSignals(data.length);
      console.log('🔄 LiveSignals: Real-time trading signals updated');
      
      if (soundEnabled) {
        console.log('🔔 New real trading signals received!');
      }
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, [generateSignal, isPaused, soundEnabled]);

  // Auto-generate mock signals as fallback when real signals are not available
  useEffect(() => {
    if (isPaused || realSignals.length > 0) return;

    const interval = setInterval(() => {
      const newSignal = generateSignal();
      setSignals(prev => [newSignal, ...prev.slice(0, 9)]);
      setTotalSignals(prev => prev + 1);
      
      if (soundEnabled) {
        console.log('🔔 New mock signal generated!');
      }
    }, 8000);

    return () => clearInterval(interval);
  }, [generateSignal, isPaused, soundEnabled, realSignals.length]);

  // Filter signals
  const filteredSignals = useMemo(() => {
    return signals.filter(signal => {
      if (filter.signal !== 'ALL' && signal.signal !== filter.signal) return false;
      if (filter.status !== 'ALL' && signal.status !== filter.status) return false;
      if (signal.confidence < filter.confidence) return false;
      if (filter.riskLevel !== 'ALL' && signal.riskLevel !== filter.riskLevel) return false;
      return true;
    });
  }, [signals, filter]);

  const executeSignal = (signalId: string) => {
    setSignals(prev => prev.map(signal => 
      signal.id === signalId 
        ? { ...signal, status: 'executed' as const }
        : signal
    ));
    
    // Simulate successful execution
    setTimeout(() => {
      setSuccessRate(prev => Math.min(99, prev + 0.1));
    }, 1000);
  };

  const copySignal = (signal: Signal) => {
    const signalText = `${signal.symbol} ${signal.signal} @ $${signal.price.toFixed(2)} | Target: $${signal.target.toFixed(2)} | Confidence: ${signal.confidence}%`;
    navigator.clipboard.writeText(signalText);
    console.log('Signal copied to clipboard');
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'text-green-400';
      case 'SELL': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  const getSignalBg = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'from-green-600 to-green-500';
      case 'SELL': return 'from-red-600 to-red-500';
      default: return 'from-yellow-600 to-yellow-500';
    }
  };

  const getSignalIcon = (signal: string) => {
    switch (signal) {
      case 'BUY': return <TrendingUp size={14} />;
      case 'SELL': return <TrendingDown size={14} />;
      default: return <AlertCircle size={14} />;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-blue-400';
      case 'executed': return 'text-green-400';
      case 'expired': return 'text-gray-400';
      case 'cancelled': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <motion.div 
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.3 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(59,130,246,0.1),transparent_50%)]" />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center space-x-3">
          <motion.div
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <Brain size={24} className="text-blue-400" />
          </motion.div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              AI Live Signals
            </h2>
            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <span>{filteredSignals.length} active signals</span>
              <div className="flex items-center space-x-1">
                <span className={`w-2 h-2 rounded-full ${isPaused ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`} />
                <span>{isPaused ? 'PAUSED' : 'LIVE'}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowFilters(!showFilters)}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
            title="Filters"
          >
            <Filter size={16} />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsPaused(!isPaused)}
            className={`p-2 rounded-lg transition-colors ${
              isPaused ? 'bg-yellow-600/50 hover:bg-yellow-500/50' : 'bg-green-600/50 hover:bg-green-500/50'
            }`}
            title={isPaused ? 'Resume' : 'Pause'}
          >
            {isPaused ? <Play size={16} /> : <Pause size={16} />}
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05, rotate: 180 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSignals([])}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
            title="Clear all"
          >
            <RotateCcw size={16} />
          </motion.button>
        </div>
      </div>

      {/* Filters */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-6 bg-gray-700/30 rounded-xl p-4 border border-white/10 relative z-10"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs text-gray-400 mb-2">Signal Type</label>
                <select 
                  value={filter.signal}
                  onChange={(e) => setFilter(prev => ({ ...prev, signal: e.target.value as any }))}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                >
                  <option value="ALL">All Signals</option>
                  <option value="BUY">Buy Only</option>
                  <option value="SELL">Sell Only</option>
                  <option value="HOLD">Hold Only</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-2">Status</label>
                <select 
                  value={filter.status}
                  onChange={(e) => setFilter(prev => ({ ...prev, status: e.target.value as any }))}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                >
                  <option value="ALL">All Status</option>
                  <option value="active">Active</option>
                  <option value="executed">Executed</option>
                  <option value="expired">Expired</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-2">Min Confidence</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={filter.confidence}
                  onChange={(e) => setFilter(prev => ({ ...prev, confidence: parseInt(e.target.value) }))}
                  className="w-full"
                />
                <div className="text-xs text-center mt-1">{filter.confidence}%</div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-2">Risk Level</label>
                <select 
                  value={filter.riskLevel}
                  onChange={(e) => setFilter(prev => ({ ...prev, riskLevel: e.target.value as any }))}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                >
                  <option value="ALL">All Risk</option>
                  <option value="low">Low Risk</option>
                  <option value="medium">Medium Risk</option>
                  <option value="high">High Risk</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AI Engines Status */}
      <div className="mb-6 relative z-10">
        <h3 className="text-sm font-semibold mb-3 text-gray-300">AI Engines</h3>
        <div className="grid grid-cols-2 gap-3">
          {aiEngines.map((engine, index) => (
            <motion.div
              key={engine.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bg-gray-700/30 rounded-lg p-3 border border-white/5"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">{engine.name}</span>
                <div className={`w-2 h-2 rounded-full ${
                  engine.status === 'active' ? 'bg-green-500' :
                  engine.status === 'learning' ? 'bg-yellow-500 animate-pulse' : 'bg-red-500'
                }`} />
              </div>
              <div className="flex items-center justify-between text-xs text-gray-400">
                <span>{engine.accuracy}% accuracy</span>
                <span>{engine.signals} signals</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Signals List */}
      <div className="space-y-3 flex-1 max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-transparent relative z-10">
        <AnimatePresence>
          {filteredSignals.length > 0 ? (
            filteredSignals.map((signal, index) => (
              <motion.div
                key={signal.id}
                initial={{ opacity: 0, x: -20, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 20, scale: 0.95 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.01, y: -2 }}
                className={`bg-gray-700/40 backdrop-blur-sm rounded-xl p-4 border border-white/10 hover:border-white/20 transition-all duration-200 cursor-pointer ${
                  selectedSignal === signal.id ? 'ring-2 ring-blue-500/50' : ''
                }`}
                onClick={() => setSelectedSignal(selectedSignal === signal.id ? null : signal.id)}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <span className="font-bold text-lg">{signal.symbol}</span>
                    <div className="flex items-center space-x-2">
                      <motion.div
                        whileHover={{ scale: 1.1 }}
                        className={`px-3 py-1 rounded-lg text-xs font-bold bg-gradient-to-r ${getSignalBg(signal.signal)} flex items-center space-x-1`}
                      >
                        {getSignalIcon(signal.signal)}
                        <span>{signal.signal}</span>
                      </motion.div>
                      
                      <div className={`px-2 py-1 rounded-full text-xs ${getRiskColor(signal.riskLevel)} bg-current bg-opacity-20`}>
                        {signal.riskLevel.toUpperCase()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        copySignal(signal);
                      }}
                      className="p-1 hover:bg-white/10 rounded transition-colors"
                      title="Copy signal"
                    >
                      <Copy size={14} />
                    </motion.button>

                    {signal.status === 'active' && (
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={(e) => {
                          e.stopPropagation();
                          executeSignal(signal.id);
                        }}
                        className={`px-3 py-1 rounded-lg text-xs font-medium transition-all bg-gradient-to-r ${getSignalBg(signal.signal)} hover:scale-105`}
                      >
                        EXECUTE
                      </motion.button>
                    )}

                    {signal.status !== 'active' && (
                      <div className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(signal.status)}`}>
                        {signal.status.toUpperCase()}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm mb-3">
                  <div className="flex items-center space-x-2">
                    <Target size={14} className="text-gray-400" />
                    <span className="text-gray-400">Price:</span>
                    <span className="font-mono font-semibold">${signal.price.toLocaleString()}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-400">Target:</span>
                    <span className={`font-mono font-semibold ${getSignalColor(signal.signal)}`}>
                      ${signal.target.toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-400">Expected:</span>
                    <span className={`font-semibold ${signal.expectedReturn >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {signal.expectedReturn >= 0 ? '+' : ''}{signal.expectedReturn.toFixed(2)}%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs mb-3">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Brain size={12} className="text-purple-400" />
                      <span className="text-gray-400">{signal.aiModel}</span>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      <Clock size={12} className="text-gray-400" />
                      <span className="text-gray-400">{signal.timeframe}</span>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      <Activity size={12} className="text-green-400" />
                      <span className="text-gray-400">{(signal.volume / 1000000).toFixed(1)}M</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1 text-gray-400">
                    <Clock size={12} />
                    <span>{signal.timestamp.toLocaleTimeString()}</span>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex items-center space-x-2 mb-3">
                  {signal.tags.map((tag, tagIndex) => (
                    <span 
                      key={tagIndex}
                      className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded-full text-xs"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Confidence Bar */}
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-gray-400">Confidence</span>
                    <span className="font-semibold">{signal.confidence}%</span>
                  </div>
                  <div className="bg-gray-600 rounded-full h-2 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${signal.confidence}%` }}
                      transition={{ duration: 1, delay: 0.3 }}
                      className={`h-2 rounded-full ${
                        signal.confidence >= 80 ? 'bg-green-500' :
                        signal.confidence >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                    />
                  </div>
                </div>

                {/* Expanded Details */}
                <AnimatePresence>
                  {selectedSignal === signal.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-t border-white/10 pt-3 mt-3"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        <div>
                          <span className="text-gray-400">Stop Loss:</span>
                          <span className="ml-2 font-mono text-red-400">${signal.stopLoss.toLocaleString()}</span>
                        </div>
                        
                        <div>
                          <span className="text-gray-400">Model Accuracy:</span>
                          <span className="ml-2 font-semibold text-green-400">{signal.accuracy}%</span>
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <span className="text-gray-400 text-xs">Analysis:</span>
                        <p className="text-sm mt-1 text-gray-300">{signal.reason}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <Brain size={48} className="mx-auto mb-4 text-gray-600" />
              <p className="text-gray-400 mb-2">No signals match your filters</p>
              <p className="text-sm text-gray-500">Adjust filters or wait for new signals</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Stats Footer */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-6 pt-4 border-t border-white/10 relative z-10"
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div className="text-center">
            <div className="text-gray-400 mb-1">Total Signals</div>
            <div className="font-bold text-lg">{totalSignals}</div>
          </div>
          
          <div className="text-center">
            <div className="text-gray-400 mb-1">Success Rate</div>
            <div className="text-green-400 font-bold text-lg">{successRate.toFixed(1)}%</div>
          </div>
          
          <div className="text-center">
            <div className="text-gray-400 mb-1">Active Models</div>
            <div className="text-blue-400 font-bold text-lg">
              {aiEngines.filter(e => e.status === 'active').length}
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-gray-400 mb-1">Auto Trade</div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsAutoTrade(!isAutoTrade)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                isAutoTrade ? 'bg-green-600 text-white' : 'bg-gray-600 text-gray-300'
              }`}
            >
              {isAutoTrade ? 'ON' : 'OFF'}
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default LiveSignals;
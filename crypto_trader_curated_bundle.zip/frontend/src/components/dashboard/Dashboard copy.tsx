import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './Sidebar';
import Header from './Header';
import MainContent from './MainContent';

interface DashboardState {
  sidebarCollapsed: boolean;
  isLoading: boolean;
  currentTheme: 'dark' | 'blue' | 'green';
  notifications: number;
  isFullscreen: boolean;
  connectionStatus: 'connected' | 'connecting' | 'disconnected';
  lastDataUpdate: Date;
}

interface LoadingStep {
  id: string;
  label: string;
  completed: boolean;
  progress: number;
}

const Dashboard: React.FC = () => {
  const [dashboardState, setDashboardState] = useState<DashboardState>({
    sidebarCollapsed: false,
    isLoading: true,
    currentTheme: 'dark',
    notifications: 0,
    isFullscreen: false,
    connectionStatus: 'connecting',
    lastDataUpdate: new Date()
  });

  const [loadingSteps, setLoadingSteps] = useState<LoadingStep[]>([
    { id: 'auth', label: 'Authenticating user...', completed: false, progress: 0 },
    { id: 'data', label: 'Loading market data...', completed: false, progress: 0 },
    { id: 'portfolio', label: 'Syncing portfolio...', completed: false, progress: 0 },
    { id: 'signals', label: 'Initializing AI signals...', completed: false, progress: 0 },
    { id: 'ready', label: 'Dashboard ready!', completed: false, progress: 0 }
  ]);

  const [currentLoadingStep, setCurrentLoadingStep] = useState(0);
  const [overallProgress, setOverallProgress] = useState(0);

  // Enhanced loading simulation
  useEffect(() => {
    const loadingSequence = async () => {
      for (let stepIndex = 0; stepIndex < loadingSteps.length; stepIndex++) {
        setCurrentLoadingStep(stepIndex);
        
        // Animate step progress
        for (let progress = 0; progress <= 100; progress += 5) {
          await new Promise(resolve => setTimeout(resolve, 30));
          
          setLoadingSteps(prev => prev.map((step, index) => 
            index === stepIndex 
              ? { ...step, progress }
              : step
          ));
        }
        
        // Mark step as completed
        setLoadingSteps(prev => prev.map((step, index) => 
          index === stepIndex 
            ? { ...step, completed: true, progress: 100 }
            : step
        ));
        
        // Update overall progress
        setOverallProgress(((stepIndex + 1) / loadingSteps.length) * 100);
        
        // Small delay between steps
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      // Final delay before showing dashboard
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setDashboardState(prev => ({
        ...prev,
        isLoading: false,
        connectionStatus: 'connected'
      }));
    };

    loadingSequence();
  }, []);

  // Connection status simulation
  useEffect(() => {
    if (!dashboardState.isLoading) {
      const interval = setInterval(() => {
        // Simulate occasional connection issues
        if (Math.random() > 0.98) {
          setDashboardState(prev => ({ ...prev, connectionStatus: 'connecting' }));
          setTimeout(() => {
            setDashboardState(prev => ({ ...prev, connectionStatus: 'connected' }));
          }, 2000);
        }
        
        // Update last data timestamp
        setDashboardState(prev => ({ ...prev, lastDataUpdate: new Date() }));
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [dashboardState.isLoading]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'b':
            e.preventDefault();
            toggleSidebar();
            break;
          case 'f':
            e.preventDefault();
            toggleFullscreen();
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  const toggleSidebar = useCallback(() => {
    setDashboardState(prev => ({
      ...prev,
      sidebarCollapsed: !prev.sidebarCollapsed
    }));
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setDashboardState(prev => ({ ...prev, isFullscreen: true }));
    } else {
      document.exitFullscreen();
      setDashboardState(prev => ({ ...prev, isFullscreen: false }));
    }
  }, []);

  const changeTheme = useCallback((theme: 'dark' | 'blue' | 'green') => {
    setDashboardState(prev => ({ ...prev, currentTheme: theme }));
  }, []);

  const getThemeClasses = () => {
    const themes = {
      dark: 'from-gray-900 via-gray-800 to-black',
      blue: 'from-blue-900 via-blue-800 to-indigo-900',
      green: 'from-emerald-900 via-teal-800 to-green-900'
    };
    return themes[dashboardState.currentTheme];
  };

  if (dashboardState.isLoading) {
    return (
      <div className={`flex h-screen bg-gradient-to-br ${getThemeClasses()} items-center justify-center relative overflow-hidden`}>
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(16,185,129,0.1),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.1),transparent_50%)]" />
          <motion.div
            animate={{ 
              background: [
                'radial-gradient(circle at 20% 80%, rgba(120,119,198,0.1), transparent 50%)',
                'radial-gradient(circle at 80% 20%, rgba(255,119,198,0.1), transparent 50%)',
                'radial-gradient(circle at 40% 40%, rgba(120,219,255,0.1), transparent 50%)'
              ]
            }}
            transition={{ duration: 4, repeat: Infinity, repeatType: 'reverse' }}
            className="absolute inset-0"
          />
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center relative z-10 max-w-md mx-auto px-6"
        >
          {/* Logo Animation */}
          <motion.div
            animate={{ 
              rotateY: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              rotateY: { duration: 3, repeat: Infinity, ease: "linear" },
              scale: { duration: 2, repeat: Infinity, repeatType: 'reverse' }
            }}
            className="mb-8"
          >
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-3xl font-bold text-white shadow-2xl">
              🤖
            </div>
          </motion.div>

          {/* Loading Indicators */}
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                AiSmart Pro Dashboard
              </h2>
              <p className="text-gray-400 mb-6">Initializing professional trading environment...</p>
            </div>

            {/* Progress Bar */}
            <div className="relative">
              <div className="bg-gray-700/50 rounded-full h-3 mb-4 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${overallProgress}%` }}
                  transition={{ type: "spring", stiffness: 100, damping: 15 }}
                  className="h-full bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 rounded-full relative"
                >
                  <motion.div
                    animate={{ x: [-20, 100] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
                  />
                </motion.div>
              </div>
              <div className="text-right text-sm text-gray-400">
                {Math.round(overallProgress)}%
              </div>
            </div>

            {/* Loading Steps */}
            <div className="space-y-3">
              {loadingSteps.map((step, index) => (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ 
                    opacity: index <= currentLoadingStep ? 1 : 0.3,
                    x: 0
                  }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center space-x-3 p-3 rounded-lg transition-all ${
                    index === currentLoadingStep 
                      ? 'bg-white/10 border border-green-500/30' 
                      : 'bg-white/5'
                  }`}
                >
                  <div className="relative">
                    {step.completed ? (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center"
                      >
                        <motion.div
                          initial={{ pathLength: 0 }}
                          animate={{ pathLength: 1 }}
                          transition={{ duration: 0.3 }}
                        >
                          ✓
                        </motion.div>
                      </motion.div>
                    ) : index === currentLoadingStep ? (
                      <div className="w-6 h-6 border-2 border-green-500 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <div className="w-6 h-6 border-2 border-gray-600 rounded-full" />
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-white text-sm font-medium">{step.label}</div>
                    {index === currentLoadingStep && (
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${step.progress}%` }}
                        className="h-1 bg-green-500 rounded-full mt-1"
                      />
                    )}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Additional Info */}
            <motion.div
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-gray-500 text-sm space-y-1"
            >
              <p>• Connecting to global markets</p>
              <p>• Activating AI trading algorithms</p>
              <p>• Securing encrypted connections</p>
            </motion.div>
          </div>
        </motion.div>

        {/* Loading particles */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ 
                opacity: 0,
                x: Math.random() * window.innerWidth,
                y: Math.random() * window.innerHeight
              }}
              animate={{
                opacity: [0, 1, 0],
                y: [window.innerHeight, -50],
                x: Math.random() * window.innerWidth
              }}
              transition={{
                duration: Math.random() * 3 + 2,
                repeat: Infinity,
                delay: Math.random() * 2
              }}
              className="absolute w-1 h-1 bg-green-400 rounded-full"
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className={`flex h-screen bg-gradient-to-br ${getThemeClasses()} overflow-hidden relative`}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(16,185,129,0.05),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.05),transparent_50%)]" />
      </div>

      {/* Connection Status Overlay */}
      <AnimatePresence>
        {dashboardState.connectionStatus === 'connecting' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-4 right-4 z-50 bg-yellow-500/90 text-black px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
          >
            <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
            <span>Reconnecting...</span>
          </motion.div>
        )}
        
        {dashboardState.connectionStatus === 'disconnected' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-4 right-4 z-50 bg-red-500/90 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
          >
            <div className="w-2 h-2 bg-white rounded-full" />
            <span>Connection Lost</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence mode="wait">
        <motion.div
          key={dashboardState.sidebarCollapsed ? 'collapsed' : 'expanded'}
          initial={{ width: dashboardState.sidebarCollapsed ? 80 : 280 }}
          animate={{ width: dashboardState.sidebarCollapsed ? 80 : 280 }}
          exit={{ width: dashboardState.sidebarCollapsed ? 280 : 80 }}
          transition={{ 
            type: "spring", 
            stiffness: 300, 
            damping: 30,
            duration: 0.3 
          }}
          className="relative z-10"
        >
          <Sidebar
            collapsed={dashboardState.sidebarCollapsed}
            onToggle={toggleSidebar}
            currentTheme={dashboardState.currentTheme}
            onThemeChange={changeTheme}
            connectionStatus={dashboardState.connectionStatus}
          />
        </motion.div>
      </AnimatePresence>

      {/* Main Content Area */}
      <motion.div
        className="flex-1 flex flex-col relative z-10"
        initial={{ x: 20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <Header 
          onMenuClick={toggleSidebar}
          onFullscreenToggle={toggleFullscreen}
          connectionStatus={dashboardState.connectionStatus}
          currentTheme={dashboardState.currentTheme}
          onThemeChange={changeTheme}
          isFullscreen={dashboardState.isFullscreen}
          lastUpdate={dashboardState.lastDataUpdate}
        />
        
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="flex-1"
        >
          <MainContent 
            currentTheme={dashboardState.currentTheme}
            connectionStatus={dashboardState.connectionStatus}
          />
        </motion.div>
      </motion.div>

      {/* Keyboard Shortcuts Help */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="absolute bottom-4 left-4 text-xs text-gray-500 bg-black/20 backdrop-blur-sm rounded-lg p-2 space-y-1"
      >
        <div>Ctrl+B: Toggle Sidebar</div>
        <div>Ctrl+F: Fullscreen</div>
      </motion.div>

      {/* Performance Monitor */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-4 right-4 text-xs text-gray-500 bg-black/20 backdrop-blur-sm rounded-lg p-2"
      >
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${
            dashboardState.connectionStatus === 'connected' ? 'bg-green-500' : 
            dashboardState.connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
          }`} />
          <span>
            Last Update: {dashboardState.lastDataUpdate.toLocaleTimeString()}
          </span>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Dashboard;
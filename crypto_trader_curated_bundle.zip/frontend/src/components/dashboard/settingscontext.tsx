'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Types
export interface NotificationSettings {
  soundEnabled: boolean;
  browserNotifications: boolean;
  emailNotifications: boolean;
  tradingAlerts: boolean;
  priceAlerts: boolean;
  newsAlerts: boolean;
}

export interface TradingSettings {
  defaultLeverage: number;
  maxRiskPerTrade: number;
  stopLossPercentage: number;
  takeProfitPercentage: number;
  allowedSlippage: number;
  confirmOrders: boolean;
  autoClosePositions: boolean;
}

export interface DisplaySettings {
  theme: 'dark' | 'light' | 'auto';
  currency: 'USD' | 'EUR' | 'BTC' | 'ETH';
  timeFormat: '12h' | '24h';
  dateFormat: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
  language: 'en' | 'es' | 'fr' | 'de' | 'zh' | 'ja';
  compactMode: boolean;
  showAnimations: boolean;
}

export interface PrivacySettings {
  shareAnalytics: boolean;
  sharePerformance: boolean;
  twoFactorAuth: boolean;
  sessionTimeout: number; // minutes
  hideBalances: boolean;
  advancedSecurity: boolean;
}

export interface APISettings {
  exchangeConnections: {
    binance: { connected: boolean; key?: string };
    coinbase: { connected: boolean; key?: string };
    kraken: { connected: boolean; key?: string };
  };
  autoSync: boolean;
  syncInterval: number; // seconds
  retryAttempts: number;
}

export interface SettingsContextValue {
  // Settings groups
  notifications: NotificationSettings;
  trading: TradingSettings;
  display: DisplaySettings;
  privacy: PrivacySettings;
  api: APISettings;

  // Update functions
  updateNotifications: (settings: Partial<NotificationSettings>) => void;
  updateTrading: (settings: Partial<TradingSettings>) => void;
  updateDisplay: (settings: Partial<DisplaySettings>) => void;
  updatePrivacy: (settings: Partial<PrivacySettings>) => void;
  updateAPI: (settings: Partial<APISettings>) => void;

  // Utility functions
  resetToDefaults: () => void;
  exportSettings: () => string;
  importSettings: (settingsJson: string) => Promise<boolean>;
  
  // State
  isLoading: boolean;
  error: string | null;
  hasUnsavedChanges: boolean;
}

const SettingsContext = createContext<SettingsContextValue | undefined>(undefined);

export const useSettingsContext = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettingsContext must be used within a SettingsProvider');
  }
  return context;
};

// Default settings
const defaultNotifications: NotificationSettings = {
  soundEnabled: true,
  browserNotifications: true,
  emailNotifications: false,
  tradingAlerts: true,
  priceAlerts: true,
  newsAlerts: true
};

const defaultTrading: TradingSettings = {
  defaultLeverage: 1,
  maxRiskPerTrade: 2, // 2% of account
  stopLossPercentage: 5, // 5%
  takeProfitPercentage: 10, // 10%
  allowedSlippage: 0.1, // 0.1%
  confirmOrders: true,
  autoClosePositions: false
};

const defaultDisplay: DisplaySettings = {
  theme: 'dark',
  currency: 'USD',
  timeFormat: '24h',
  dateFormat: 'MM/DD/YYYY',
  language: 'en',
  compactMode: false,
  showAnimations: true
};

const defaultPrivacy: PrivacySettings = {
  shareAnalytics: false,
  sharePerformance: false,
  twoFactorAuth: false,
  sessionTimeout: 60, // 60 minutes
  hideBalances: false,
  advancedSecurity: true
};

const defaultAPI: APISettings = {
  exchangeConnections: {
    binance: { connected: false },
    coinbase: { connected: false },
    kraken: { connected: false }
  },
  autoSync: true,
  syncInterval: 30, // 30 seconds
  retryAttempts: 3
};

interface SettingsProviderProps {
  children: ReactNode;
}

export const SettingsProvider: React.FC<SettingsProviderProps> = ({ children }) => {
  const [notifications, setNotifications] = useState<NotificationSettings>(defaultNotifications);
  const [trading, setTrading] = useState<TradingSettings>(defaultTrading);
  const [display, setDisplay] = useState<DisplaySettings>(defaultDisplay);
  const [privacy, setPrivacy] = useState<PrivacySettings>(defaultPrivacy);
  const [api, setAPI] = useState<APISettings>(defaultAPI);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Load settings from localStorage on mount
  useEffect(() => {
    const loadSettings = () => {
      try {
        if (typeof window !== 'undefined') {
          const savedSettings = localStorage.getItem('aitrader_settings');
          if (savedSettings) {
            const parsed = JSON.parse(savedSettings);
            
            setNotifications(prev => ({ ...prev, ...parsed.notifications }));
            setTrading(prev => ({ ...prev, ...parsed.trading }));
            setDisplay(prev => ({ ...prev, ...parsed.display }));
            setPrivacy(prev => ({ ...prev, ...parsed.privacy }));
            setAPI(prev => ({ ...prev, ...parsed.api }));
            
            console.log('✅ Settings loaded from localStorage');
          }
        }
      } catch (err) {
        console.error('❌ Error loading settings:', err);
        setError('Failed to load saved settings');
      }
    };

    loadSettings();
  }, []);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    const saveSettings = async () => {
      try {
        if (typeof window !== 'undefined') {
          const allSettings = {
            notifications,
            trading,
            display,
            privacy,
            api,
            lastUpdated: new Date().toISOString()
          };

          localStorage.setItem('aitrader_settings', JSON.stringify(allSettings));
          setHasUnsavedChanges(false);
          console.log('✅ Settings saved to localStorage');
        }
      } catch (err) {
        console.error('❌ Error saving settings:', err);
        setError('Failed to save settings');
      }
    };

    // Debounce saving to avoid too frequent writes
    const timeoutId = setTimeout(saveSettings, 1000);
    return () => clearTimeout(timeoutId);
  }, [notifications, trading, display, privacy, api]);

  // Update functions
  const updateNotifications = (newSettings: Partial<NotificationSettings>) => {
    setNotifications(prev => ({ ...prev, ...newSettings }));
    setHasUnsavedChanges(true);
    console.log('🔔 Notification settings updated:', newSettings);
  };

  const updateTrading = (newSettings: Partial<TradingSettings>) => {
    setTrading(prev => ({ ...prev, ...newSettings }));
    setHasUnsavedChanges(true);
    console.log('📈 Trading settings updated:', newSettings);
  };

  const updateDisplay = (newSettings: Partial<DisplaySettings>) => {
    setDisplay(prev => ({ ...prev, ...newSettings }));
    setHasUnsavedChanges(true);
    console.log('🎨 Display settings updated:', newSettings);
    
    // Apply theme changes immediately
    if (newSettings.theme && typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', newSettings.theme);
    }
  };

  const updatePrivacy = (newSettings: Partial<PrivacySettings>) => {
    setPrivacy(prev => ({ ...prev, ...newSettings }));
    setHasUnsavedChanges(true);
    console.log('🔒 Privacy settings updated:', newSettings);
  };

  const updateAPI = (newSettings: Partial<APISettings>) => {
    setAPI(prev => ({ ...prev, ...newSettings }));
    setHasUnsavedChanges(true);
    console.log('🔌 API settings updated:', newSettings);
  };

  // Utility functions
  const resetToDefaults = () => {
    setIsLoading(true);
    try {
      setNotifications(defaultNotifications);
      setTrading(defaultTrading);
      setDisplay(defaultDisplay);
      setPrivacy(defaultPrivacy);
      setAPI(defaultAPI);
      
      if (typeof window !== 'undefined') {
        localStorage.removeItem('aitrader_settings');
      }
      setHasUnsavedChanges(false);
      console.log('🔄 Settings reset to defaults');
    } catch (err) {
      console.error('❌ Error resetting settings:', err);
      setError('Failed to reset settings');
    } finally {
      setIsLoading(false);
    }
  };

  const exportSettings = (): string => {
    const allSettings = {
      notifications,
      trading,
      display,
      privacy,
      api: {
        ...api,
        exchangeConnections: {
          binance: { connected: api.exchangeConnections.binance.connected },
          coinbase: { connected: api.exchangeConnections.coinbase.connected },
          kraken: { connected: api.exchangeConnections.kraken.connected }
        }
      }, // Remove sensitive API keys
      exportedAt: new Date().toISOString(),
      version: '1.0'
    };

    return JSON.stringify(allSettings, null, 2);
  };

  const importSettings = async (settingsJson: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const imported = JSON.parse(settingsJson);
      
      // Validate settings structure
      if (!imported.version || !imported.notifications || !imported.trading) {
        throw new Error('Invalid settings format');
      }

      // Apply imported settings
      setNotifications(prev => ({ ...prev, ...imported.notifications }));
      setTrading(prev => ({ ...prev, ...imported.trading }));
      setDisplay(prev => ({ ...prev, ...imported.display }));
      setPrivacy(prev => ({ ...prev, ...imported.privacy }));
      setAPI(prev => ({ ...prev, ...imported.api }));

      setHasUnsavedChanges(true);
      console.log('📥 Settings imported successfully');
      return true;
    } catch (err) {
      console.error('❌ Error importing settings:', err);
      setError('Failed to import settings: Invalid format');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const value: SettingsContextValue = {
    notifications,
    trading,
    display,
    privacy,
    api,
    updateNotifications,
    updateTrading,
    updateDisplay,
    updatePrivacy,
    updateAPI,
    resetToDefaults,
    exportSettings,
    importSettings,
    isLoading,
    error,
    hasUnsavedChanges
  };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export default SettingsContext;
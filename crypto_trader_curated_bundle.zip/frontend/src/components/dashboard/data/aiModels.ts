/**
 * AI Models Data
 * 
 * This file contains the configuration for AI models used in the application.
 * Each model has parameters that can be customized by the user.
 */

export const aiModels = [
  {
    id: 'neural-alpha',
    name: 'Neural Alpha',
    description: 'General-purpose trading model with balanced performance',
    type: 'hybrid',
    parameters: [
      {
        id: 'rsi_period',
        name: 'RSI Period',
        description: 'Number of periods for RSI calculation',
        type: 'number',
        value: 14,
        defaultValue: 14,
        min: 2,
        max: 50
      },
      {
        id: 'rsi_overbought',
        name: 'RSI Overbought',
        description: 'Threshold for overbought condition',
        type: 'number',
        value: 70,
        defaultValue: 70,
        min: 50,
        max: 90
      },
      {
        id: 'rsi_oversold',
        name: 'RSI Oversold',
        description: 'Threshold for oversold condition',
        type: 'number',
        value: 30,
        defaultValue: 30,
        min: 10,
        max: 50
      },
      {
        id: 'macd_fast',
        name: 'MACD Fast Period',
        description: 'Fast EMA period for MACD',
        type: 'number',
        value: 12,
        defaultValue: 12,
        min: 5,
        max: 30
      },
      {
        id: 'macd_slow',
        name: 'MACD Slow Period',
        description: 'Slow EMA period for MACD',
        type: 'number',
        value: 26,
        defaultValue: 26,
        min: 10,
        max: 50
      },
      {
        id: 'macd_signal',
        name: 'MACD Signal Period',
        description: 'Signal line period for MACD',
        type: 'number',
        value: 9,
        defaultValue: 9,
        min: 3,
        max: 20
      },
      {
        id: 'use_volume',
        name: 'Use Volume Analysis',
        description: 'Include volume in signal generation',
        type: 'boolean',
        value: true,
        defaultValue: true
      },
      {
        id: 'trend_strength',
        name: 'Trend Strength Weight',
        description: 'Weight given to trend strength in signal generation',
        type: 'range',
        value: 0.7,
        defaultValue: 0.7,
        min: 0,
        max: 1,
        step: 0.1
      },
      {
        id: 'signal_threshold',
        name: 'Signal Threshold',
        description: 'Minimum confidence for signal generation',
        type: 'range',
        value: 0.65,
        defaultValue: 0.65,
        min: 0.5,
        max: 0.9,
        step: 0.05
      },
      {
        id: 'timeframe',
        name: 'Default Timeframe',
        description: 'Default timeframe for analysis',
        type: 'select',
        value: '1h',
        defaultValue: '1h',
        options: [
          { value: '5m', label: '5 minutes' },
          { value: '15m', label: '15 minutes' },
          { value: '1h', label: '1 hour' },
          { value: '4h', label: '4 hours' },
          { value: '1d', label: '1 day' }
        ]
      }
    ],
    performance: {
      accuracy: 78.5,
      winRate: 68.2,
      profitFactor: 2.1
    }
  },
  {
    id: 'quantum-beta',
    name: 'Quantum Beta',
    description: 'Advanced pattern recognition with deep learning',
    type: 'pattern',
    parameters: [
      {
        id: 'pattern_sensitivity',
        name: 'Pattern Sensitivity',
        description: 'Sensitivity for pattern detection',
        type: 'range',
        value: 0.65,
        defaultValue: 0.65,
        min: 0.3,
        max: 0.9,
        step: 0.05
      },
      {
        id: 'min_pattern_quality',
        name: 'Minimum Pattern Quality',
        description: 'Minimum quality score for pattern recognition',
        type: 'range',
        value: 0.7,
        defaultValue: 0.7,
        min: 0.5,
        max: 0.95,
        step: 0.05
      },
      {
        id: 'use_harmonics',
        name: 'Use Harmonic Patterns',
        description: 'Include harmonic patterns in analysis',
        type: 'boolean',
        value: true,
        defaultValue: true
      },
      {
        id: 'use_classic_patterns',
        name: 'Use Classic Patterns',
        description: 'Include classic chart patterns in analysis',
        type: 'boolean',
        value: true,
        defaultValue: true
      },
      {
        id: 'use_candlestick_patterns',
        name: 'Use Candlestick Patterns',
        description: 'Include candlestick patterns in analysis',
        type: 'boolean',
        value: true,
        defaultValue: true
      },
      {
        id: 'pattern_lookback',
        name: 'Pattern Lookback Period',
        description: 'Number of candles to analyze for patterns',
        type: 'number',
        value: 100,
        defaultValue: 100,
        min: 50,
        max: 500
      },
      {
        id: 'confirmation_candles',
        name: 'Confirmation Candles',
        description: 'Number of candles required for pattern confirmation',
        type: 'number',
        value: 2,
        defaultValue: 2,
        min: 1,
        max: 5
      }
    ],
    performance: {
      accuracy: 82.3,
      winRate: 65.8,
      profitFactor: 2.4
    }
  },
  {
    id: 'deep-gamma',
    name: 'Deep Gamma',
    description: 'Momentum-based trading with machine learning',
    type: 'momentum',
    parameters: [
      {
        id: 'momentum_period',
        name: 'Momentum Period',
        description: 'Period for momentum calculation',
        type: 'number',
        value: 10,
        defaultValue: 10,
        min: 5,
        max: 30
      },
      {
        id: 'momentum_threshold',
        name: 'Momentum Threshold',
        description: 'Threshold for momentum signals',
        type: 'range',
        value: 0.5,
        defaultValue: 0.5,
        min: 0.2,
        max: 0.8,
        step: 0.1
      },
      {
        id: 'use_volume_momentum',
        name: 'Use Volume Momentum',
        description: 'Include volume in momentum calculation',
        type: 'boolean',
        value: true,
        defaultValue: true
      },
      {
        id: 'use_price_momentum',
        name: 'Use Price Momentum',
        description: 'Include price in momentum calculation',
        type: 'boolean',
        value: true,
        defaultValue: true
      },
      {
        id: 'momentum_smoothing',
        name: 'Momentum Smoothing',
        description: 'Smoothing factor for momentum calculation',
        type: 'range',
        value: 0.3,
        defaultValue: 0.3,
        min: 0.1,
        max: 0.9,
        step: 0.1
      }
    ],
    performance: {
      accuracy: 75.2,
      winRate: 72.1,
      profitFactor: 1.9
    }
  }
];
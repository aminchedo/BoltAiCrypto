/**
 * Neural Trade - AI Trading Platform
 * Enhanced Dashboard Components Export
 * 
 * Professional trading dashboard with AI-powered insights,
 * real-time market data, and advanced portfolio management.
 * 
 * @version 2.0.0
 * @author Neural Trade Team
 * @license MIT
 */

// ===========================================
// MAIN DASHBOARD COMPONENTS
// ===========================================

// Core Dashboard Components
export { default as Dashboard } from './Dashboard';
export { default as MainContent } from './MainContent';

// Navigation & Layout Components  
export { default as Sidebar } from './Sidebar';
export { default as Header } from './Header';

// ===========================================
// TRADING & PORTFOLIO WIDGETS
// ===========================================

// Portfolio Management
export { default as PortfolioSummary } from './PortfolioSummary';

// AI Trading Features
export { default as LiveSignals } from './LiveSignals';
export { default as TradingChart } from './TradingChart';

// Market Analysis
export { default as MarketOverview } from './MarketOverview';

// ===========================================
// TYPE DEFINITIONS & INTERFACES
// ===========================================

// Theme Types
export type ThemeMode = 'dark' | 'blue' | 'green';
export type ViewMode = 'desktop' | 'tablet' | 'mobile';
export type ConnectionStatus = 'connected' | 'connecting' | 'disconnected';

// Component Props Interfaces
export interface DashboardConfig {
  theme: ThemeMode;
  viewMode: ViewMode;
  autoRefresh: boolean;
  refreshInterval: number;
  soundEnabled: boolean;
  notificationsEnabled: boolean;
}

export interface SidebarProps {
  collapsed?: boolean;
  onToggle?: () => void;
  currentTheme?: ThemeMode;
  onThemeChange?: (theme: ThemeMode) => void;
  connectionStatus?: ConnectionStatus;
}

export interface HeaderProps {
  onMenuClick?: () => void;
  onFullscreenToggle?: () => void;
  connectionStatus?: ConnectionStatus;
  currentTheme?: ThemeMode;
  onThemeChange?: (theme: ThemeMode) => void;
  isFullscreen?: boolean;
  lastUpdate?: Date;
}

export interface MainContentProps {
  currentTheme?: ThemeMode;
  connectionStatus?: ConnectionStatus;
}

// Trading Data Types
export interface TradingSignal {
  id: string;
  symbol: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  target: number;
  stopLoss: number;
  timestamp: Date;
  status: 'active' | 'executed' | 'expired' | 'cancelled';
  aiModel: string;
  riskLevel: 'low' | 'medium' | 'high';
  timeframe: string;
  volume: number;
  accuracy?: number;
  tags: string[];
  expectedReturn: number;
  reason: string;
}

export interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  rank: number;
  color: string;
  logo?: string;
}

export interface PortfolioAsset {
  symbol: string;
  name: string;
  amount: number;
  value: number;
  change24h: number;
  allocation: number;
  color: string;
}

// ===========================================
// UTILITY FUNCTIONS & HELPERS
// ===========================================

// Currency Formatting
export const formatCurrency = (
  value: number, 
  showDecimals = true,
  hideValue = false
): string => {
  if (hideValue) return '****';
  return `$${value.toLocaleString('en-US', { 
    minimumFractionDigits: showDecimals ? 2 : 0, 
    maximumFractionDigits: showDecimals ? 2 : 0 
  })}`;
};

// Percentage Formatting
export const formatPercentage = (value: number): string => {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}%`;
};

// Number Formatting with Suffix
export const formatNumber = (value: number): string => {
  if (value >= 1e12) return `${(value / 1e12).toFixed(1)}T`;
  if (value >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
  return value.toString();
};

// Time Formatting
export const formatTimeAgo = (date: Date): string => {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) return 'Just now';
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
  return `${Math.floor(diffInSeconds / 86400)}d ago`;
};

// Color Utilities
export const getSignalColor = (signal: string): string => {
  switch (signal) {
    case 'BUY': return 'text-green-400';
    case 'SELL': return 'text-red-400';
    default: return 'text-yellow-400';
  }
};

export const getRiskColor = (risk: string): string => {
  switch (risk) {
    case 'low': return 'text-green-400';
    case 'medium': return 'text-yellow-400';
    case 'high': return 'text-red-400';
    default: return 'text-gray-400';
  }
};

// ===========================================
// CONFIGURATION & CONSTANTS
// ===========================================

// Default Dashboard Configuration
export const DEFAULT_DASHBOARD_CONFIG: DashboardConfig = {
  theme: 'dark',
  viewMode: 'desktop',
  autoRefresh: true,
  refreshInterval: 5000,
  soundEnabled: true,
  notificationsEnabled: true,
};

// Theme Configurations
export const THEME_CONFIGS = {
  dark: {
    gradient: 'from-gray-950 via-gray-900 to-gray-800',
    accent: 'cyan',
    name: 'Dark Professional'
  },
  blue: {
    gradient: 'from-blue-950 via-blue-900 to-indigo-900',
    accent: 'blue',
    name: 'Ocean Blue'
  },
  green: {
    gradient: 'from-emerald-950 via-teal-900 to-green-900',
    accent: 'emerald',
    name: 'Matrix Green'
  }
} as const;

// Trading Symbols
export const POPULAR_SYMBOLS = [
  'BTC/USDT',
  'ETH/USDT', 
  'SOL/USDT',
  'ADA/USDT',
  'DOT/USDT',
  'LINK/USDT',
  'AVAX/USDT',
  'MATIC/USDT'
] as const;

// Timeframe Options
export const TIMEFRAMES = [
  { value: '1m', label: '1M' },
  { value: '5m', label: '5M' },
  { value: '15m', label: '15M' },
  { value: '1h', label: '1H' },
  { value: '4h', label: '4H' },
  { value: '1d', label: '1D' },
  { value: '1w', label: '1W' }
] as const;

// AI Models
export const AI_MODELS = [
  'Neural Alpha',
  'Quantum Beta', 
  'Deep Gamma',
  'Fusion Delta'
] as const;

// ===========================================
// HOOKS & PROVIDERS (Future Extensions)
// ===========================================

// Dashboard Context Types (for future implementation)
export interface DashboardContextValue {
  config: DashboardConfig;
  updateConfig: (config: Partial<DashboardConfig>) => void;
  connectionStatus: ConnectionStatus;
  lastUpdate: Date;
}

// ===========================================
// VERSION & METADATA
// ===========================================

export const DASHBOARD_VERSION = '2.0.0';
export const BUILD_DATE = new Date().toISOString();
export const COMPONENTS_COUNT = 8;

// Component Metadata
export const COMPONENT_MANIFEST = {
  Dashboard: { version: '2.0.0', type: 'layout' },
  Sidebar: { version: '2.0.0', type: 'navigation' },
  Header: { version: '2.0.0', type: 'navigation' },
  MainContent: { version: '2.0.0', type: 'layout' },
  PortfolioSummary: { version: '2.0.0', type: 'widget' },
  LiveSignals: { version: '2.0.0', type: 'widget' },
  TradingChart: { version: '2.0.0', type: 'widget' },
  MarketOverview: { version: '2.0.0', type: 'widget' },
} as const;

// ===========================================
// EXPORTS SUMMARY
// ===========================================

/**
 * Available Exports:
 * 
 * COMPONENTS (8):
 * - Dashboard, Sidebar, Header, MainContent
 * - PortfolioSummary, LiveSignals, TradingChart, MarketOverview
 * 
 * TYPES (10+):
 * - ThemeMode, ViewMode, ConnectionStatus
 * - DashboardConfig, SidebarProps, HeaderProps, MainContentProps
 * - TradingSignal, MarketData, PortfolioAsset
 * 
 * UTILITIES (6):
 * - formatCurrency, formatPercentage, formatNumber
 * - formatTimeAgo, getSignalColor, getRiskColor
 * 
 * CONSTANTS (5):
 * - DEFAULT_DASHBOARD_CONFIG, THEME_CONFIGS
 * - POPULAR_SYMBOLS, TIMEFRAMES, AI_MODELS
 * 
 * METADATA:
 * - DASHBOARD_VERSION, BUILD_DATE, COMPONENT_MANIFEST
 */

// ===========================================
// DEVELOPMENT UTILITIES (DEV ONLY)
// ===========================================

if (process.env.NODE_ENV === 'development') {
  // Development-only exports
  (window as any).NEURAL_TRADE_DEBUG = {
    version: DASHBOARD_VERSION,
    components: COMPONENT_MANIFEST,
    config: DEFAULT_DASHBOARD_CONFIG,
    buildDate: BUILD_DATE
  };
}
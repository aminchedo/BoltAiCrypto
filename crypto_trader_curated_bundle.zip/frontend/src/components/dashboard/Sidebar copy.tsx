import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain,
  BarChart3,
  DollarSign,
  TrendingUp,
  Settings,
  Menu,
  ChevronLeft,
  ChevronRight,
  Activity,
  Zap,
  Target,
  History,
  Users,
  Bell,
  Shield,
  Globe,
  BookOpen,
  Award,
  Layers,
  PieChart,
  LineChart,
  CandlestickChart,
  Wallet,
  CreditCard,
  Briefcase,
  Monitor,
  TrendingDown,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

interface SidebarProps {
  collapsed?: boolean;
  onToggle?: () => void;
  currentTheme?: 'dark' | 'blue' | 'green';
  onThemeChange?: (theme: 'dark' | 'blue' | 'green') => void;
  connectionStatus?: 'connected' | 'connecting' | 'disconnected';
}

interface NavigationItem {
  id: string;
  name: string;
  icon: any;
  color: string;
  badge?: number;
  subItems?: NavigationItem[];
  isActive?: boolean;
  description?: string;
}

interface PerformanceMetric {
  label: string;
  value: string;
  change: number;
  color: string;
  icon: any;
}

interface AiStatus {
  engine: 'online' | 'offline' | 'learning';
  accuracy: number;
  signals: number;
  lastTrained: Date;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  collapsed = false, 
  onToggle,
  currentTheme = 'dark',
  onThemeChange,
  connectionStatus = 'connected'
}) => {
  const [activeItem, setActiveItem] = useState('dashboard');
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [aiStatus, setAiStatus] = useState<AiStatus>({
    engine: 'online',
    accuracy: 87.4,
    signals: 23,
    lastTrained: new Date(Date.now() - 3600000) // 1 hour ago
  });

  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetric[]>([
    { label: 'Total P&L', value: '+$12,341', change: 5.67, color: 'text-green-400', icon: TrendingUp },
    { label: 'Win Rate', value: '68.4%', change: 2.1, color: 'text-blue-400', icon: Target },
    { label: 'Active Signals', value: '23', change: 0, color: 'text-purple-400', icon: Zap },
    { label: 'Portfolio', value: '$127.8K', change: 1.87, color: 'text-yellow-400', icon: Wallet }
  ]);

  const navigationItems: NavigationItem[] = [
    { 
      id: 'dashboard', 
      name: 'Dashboard', 
      icon: BarChart3, 
      color: 'text-blue-400',
      description: 'Overview and analytics'
    },
    { 
      id: 'trading', 
      name: 'Trading', 
      icon: TrendingUp, 
      color: 'text-green-400',
      description: 'Execute trades',
      subItems: [
        { id: 'spot', name: 'Spot Trading', icon: DollarSign, color: 'text-green-400' },
        { id: 'futures', name: 'Futures', icon: LineChart, color: 'text-blue-400' },
        { id: 'options', name: 'Options', icon: CandlestickChart, color: 'text-purple-400' }
      ]
    },
    { 
      id: 'portfolio', 
      name: 'Portfolio', 
      icon: Briefcase, 
      color: 'text-purple-400',
      description: 'Manage assets',
      subItems: [
        { id: 'overview', name: 'Overview', icon: PieChart, color: 'text-blue-400' },
        { id: 'positions', name: 'Positions', icon: Layers, color: 'text-green-400' },
        { id: 'history', name: 'History', icon: History, color: 'text-gray-400' }
      ]
    },
    { 
      id: 'signals', 
      name: 'AI Signals', 
      icon: Brain, 
      color: 'text-yellow-400',
      badge: aiStatus.signals,
      description: 'AI-powered insights'
    },
    { 
      id: 'analytics', 
      name: 'Analytics', 
      icon: Activity, 
      color: 'text-cyan-400',
      description: 'Performance metrics',
      subItems: [
        { id: 'performance', name: 'Performance', icon: TrendingUp, color: 'text-green-400' },
        { id: 'risk', name: 'Risk Analysis', icon: Shield, color: 'text-red-400' },
        { id: 'reports', name: 'Reports', icon: BookOpen, color: 'text-blue-400' }
      ]
    },
    { 
      id: 'wallet', 
      name: 'Wallet', 
      icon: Wallet, 
      color: 'text-emerald-400',
      description: 'Manage funds',
      subItems: [
        { id: 'deposit', name: 'Deposit', icon: CreditCard, color: 'text-green-400' },
        { id: 'withdraw', name: 'Withdraw', icon: DollarSign, color: 'text-red-400' },
        { id: 'transactions', name: 'Transactions', icon: History, color: 'text-gray-400' }
      ]
    },
    { 
      id: 'social', 
      name: 'Social Trading', 
      icon: Users, 
      color: 'text-pink-400',
      description: 'Follow top traders'
    },
    { 
      id: 'news', 
      name: 'Market News', 
      icon: Globe, 
      color: 'text-orange-400',
      badge: 5,
      description: 'Latest market updates'
    },
    { 
      id: 'settings', 
      name: 'Settings', 
      icon: Settings, 
      color: 'text-gray-400',
      description: 'Configure platform'
    }
  ];

  // Real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update AI status
      setAiStatus(prev => ({
        ...prev,
        accuracy: Math.max(75, Math.min(95, prev.accuracy + (Math.random() - 0.5) * 2)),
        signals: prev.signals + (Math.random() > 0.7 ? 1 : 0)
      }));

      // Update performance metrics
      setPerformanceMetrics(prev => prev.map(metric => ({
        ...metric,
        change: metric.change + (Math.random() - 0.5) * 0.5
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleItemClick = (itemId: string, hasSubItems: boolean = false) => {
    setActiveItem(itemId);
    
    if (hasSubItems) {
      setExpandedItems(prev => 
        prev.includes(itemId) 
          ? prev.filter(id => id !== itemId)
          : [...prev, itemId]
      );
    }
  };

  const getThemeClasses = () => {
    const themes = {
      dark: 'from-gray-950 to-gray-900',
      blue: 'from-blue-950 to-blue-900',
      green: 'from-emerald-950 to-emerald-900'
    };
    return themes[currentTheme];
  };

  const getAiStatusColor = () => {
    switch (aiStatus.engine) {
      case 'online': return 'text-green-400';
      case 'learning': return 'text-yellow-400';
      case 'offline': return 'text-red-400';
    }
  };

  const getAiStatusIcon = () => {
    switch (aiStatus.engine) {
      case 'online': return <CheckCircle size={12} />;
      case 'learning': return <Brain size={12} className="animate-pulse" />;
      case 'offline': return <AlertCircle size={12} />;
    }
  };

  return (
    <motion.aside
      initial={{ width: collapsed ? 80 : 280 }}
      animate={{ width: collapsed ? 80 : 280 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className={`bg-gradient-to-b ${getThemeClasses()}/95 backdrop-blur-xl border-r border-white/10 text-white flex flex-col relative shadow-2xl`}
    >
      {/* Header */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <AnimatePresence mode="wait">
            {!collapsed ? (
              <motion.div
                key="expanded"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex items-center text-2xl font-bold"
              >
                <motion.span 
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  className="mr-3 text-3xl"
                >
                  🤖
                </motion.span>
                <div>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-400">
                    AiSmart
                  </span>
                  <span className="ml-1 text-gray-300">Pro</span>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="collapsed"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-3xl"
              >
                🤖
              </motion.div>
            )}
          </AnimatePresence>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onToggle}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </motion.button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-transparent">
        {navigationItems.map((item) => (
          <div key={item.id}>
            <motion.button
              onClick={() => handleItemClick(item.id, !!item.subItems)}
              whileHover={{ scale: 1.02, x: 4 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full p-3 text-left flex items-center justify-between rounded-xl transition-all duration-200 group ${
                activeItem === item.id
                  ? 'bg-gradient-to-r from-green-600/20 to-blue-600/20 text-green-400 border border-green-500/30 shadow-lg'
                  : 'hover:bg-white/5 text-gray-300 hover:text-white hover:border-white/20 border border-transparent'
              }`}
            >
              <div className="flex items-center space-x-3">
                <item.icon className={`w-5 h-5 ${item.color} group-hover:scale-110 transition-transform`} />
                <AnimatePresence mode="wait">
                  {!collapsed && (
                    <motion.div
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="flex-1"
                    >
                      <div className="font-medium">{item.name}</div>
                      {item.description && (
                        <div className="text-xs text-gray-400 mt-0.5">{item.description}</div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <AnimatePresence mode="wait">
                {!collapsed && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center space-x-2"
                  >
                    {item.badge && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold"
                      >
                        {item.badge}
                      </motion.span>
                    )}
                    {item.subItems && (
                      <motion.div
                        animate={{ rotate: expandedItems.includes(item.id) ? 90 : 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ChevronRight size={14} />
                      </motion.div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>

            {/* Sub Items */}
            <AnimatePresence>
              {!collapsed && item.subItems && expandedItems.includes(item.id) && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="ml-8 mt-2 space-y-1"
                >
                  {item.subItems.map((subItem) => (
                    <motion.button
                      key={subItem.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      onClick={() => setActiveItem(subItem.id)}
                      className={`w-full p-2 text-left flex items-center space-x-3 rounded-lg transition-all text-sm ${
                        activeItem === subItem.id
                          ? 'bg-green-600/20 text-green-400'
                          : 'hover:bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      <subItem.icon className={`w-4 h-4 ${subItem.color}`} />
                      <span>{subItem.name}</span>
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </nav>

      {/* Performance Stats */}
      <AnimatePresence mode="wait">
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="p-4 space-y-4"
          >
            <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <h3 className="text-sm font-semibold mb-3 text-gray-300">Performance</h3>
              <div className="space-y-3">
                {performanceMetrics.map((metric, index) => (
                  <motion.div
                    key={metric.label}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    className="flex justify-between items-center p-2 rounded-lg hover:bg-white/5 transition-colors"
                  >
                    <div className="flex items-center space-x-2">
                      <metric.icon size={14} className={metric.color} />
                      <span className="text-xs text-gray-400">{metric.label}</span>
                    </div>
                    <div className="text-right">
                      <div className={`text-sm font-semibold ${metric.color}`}>
                        {metric.value}
                      </div>
                      {metric.change !== 0 && (
                        <div className={`text-xs flex items-center space-x-1 ${
                          metric.change >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {metric.change >= 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                          <span>{Math.abs(metric.change).toFixed(1)}%</span>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* AI Engine Status */}
            <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-4 border border-white/10">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-gray-300">AI Engine</h3>
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className={`${getAiStatusColor()}`}
                >
                  {getAiStatusIcon()}
                </motion.div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Status:</span>
                  <span className={`font-semibold capitalize ${getAiStatusColor()}`}>
                    {aiStatus.engine}
                  </span>
                </div>
                
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Accuracy:</span>
                  <span className="text-green-400 font-semibold">
                    {aiStatus.accuracy.toFixed(1)}%
                  </span>
                </div>
                
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Active Signals:</span>
                  <span className="text-blue-400 font-semibold">
                    {aiStatus.signals}
                  </span>
                </div>

                {/* Accuracy Progress Bar */}
                <div className="mt-3">
                  <div className="bg-gray-700 rounded-full h-2 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiStatus.accuracy}%` }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className="h-full bg-gradient-to-r from-green-500 to-blue-500 rounded-full"
                    />
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Last trained: {aiStatus.lastTrained.toLocaleTimeString()}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Connection Status */}
      <div className="p-4 border-t border-white/10">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="flex items-center space-x-3 p-3 bg-gray-800/30 rounded-xl border border-white/5"
        >
          <motion.span
            animate={{ 
              scale: connectionStatus === 'connected' ? [1, 1.2, 1] : 1,
              opacity: connectionStatus === 'disconnected' ? 0.5 : 1
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="relative flex h-3 w-3"
          >
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
              connectionStatus === 'connected' ? 'bg-green-400' :
              connectionStatus === 'connecting' ? 'bg-yellow-400' : 'bg-red-400'
            }`} />
            <span className={`inline-flex rounded-full h-3 w-3 ${
              connectionStatus === 'connected' ? 'bg-green-500' :
              connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
            }`} />
          </motion.span>
          
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex-1"
              >
                <div className={`text-sm font-medium ${
                  connectionStatus === 'connected' ? 'text-green-400' :
                  connectionStatus === 'connecting' ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  {connectionStatus === 'connected' ? 'AI Engine Online' :
                   connectionStatus === 'connecting' ? 'Connecting...' : 'Connection Lost'}
                </div>
                <div className="text-xs text-gray-500">
                  Global trading network
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-t border-white/10">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl border border-blue-500/30"
        >
          <motion.div 
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.5 }}
            className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center"
          >
            <span className="text-sm font-bold text-white">JT</span>
          </motion.div>
          
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex-1"
              >
                <div className="text-sm font-medium">John Trader</div>
                <div className="text-xs text-gray-400 flex items-center space-x-2">
                  <Award size={10} className="text-yellow-400" />
                  <span>Pro Account</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </motion.aside>
  );
};

export default Sidebar;
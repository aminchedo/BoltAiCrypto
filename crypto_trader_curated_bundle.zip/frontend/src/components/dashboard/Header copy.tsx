import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, 
  Menu, 
  TrendingUp, 
  TrendingDown, 
  Zap, 
  User, 
  Settings,
  Search,
  Maximize,
  Minimize,
  Wifi,
  WifiOff,
  ChevronDown,
  DollarSign,
  BarChart3,
  Clock,
  Shield,
  LogOut,
  Moon,
  Sun,
  Palette,
  Globe,
  HelpCircle
} from 'lucide-react';

interface HeaderProps {
  onMenuClick?: () => void;
  onFullscreenToggle?: () => void;
  connectionStatus?: 'connected' | 'connecting' | 'disconnected';
  currentTheme?: 'dark' | 'blue' | 'green';
  onThemeChange?: (theme: 'dark' | 'blue' | 'green') => void;
  isFullscreen?: boolean;
  lastUpdate?: Date;
}

interface Notification {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

interface TradeOrder {
  id: string;
  type: 'BUY' | 'SELL' | 'AUTO';
  symbol: string;
  amount: number;
  price: number;
  status: 'pending' | 'executing' | 'completed' | 'failed';
}

const Header: React.FC<HeaderProps> = ({ 
  onMenuClick,
  onFullscreenToggle,
  connectionStatus = 'connected',
  currentTheme = 'dark',
  onThemeChange,
  isFullscreen = false,
  lastUpdate = new Date()
}) => {
  const [balance, setBalance] = useState(127845.32);
  const [change, setChange] = useState(2341.22);
  const [changePercent, setChangePercent] = useState(1.87);
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'success',
      title: 'Trade Executed',
      message: 'BTC/USDT buy order completed successfully',
      timestamp: new Date(Date.now() - 300000),
      read: false
    },
    {
      id: '2',
      type: 'warning',
      title: 'Market Alert',
      message: 'High volatility detected in ETH markets',
      timestamp: new Date(Date.now() - 600000),
      read: false
    },
    {
      id: '3',
      type: 'info',
      title: 'AI Signal',
      message: 'New profitable signal detected for SOL/USDT',
      timestamp: new Date(Date.now() - 900000),
      read: true
    }
  ]);

  const [recentOrders, setRecentOrders] = useState<TradeOrder[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  
  const notificationRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const themeMenuRef = useRef<HTMLDivElement>(null);

  // Real-time balance updates
  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = (Math.random() - 0.5) * 200;
      setChange(prev => prev + randomChange);
      setBalance(prev => prev + randomChange);
      setChangePercent(prev => prev + (Math.random() - 0.5) * 0.2);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
      if (themeMenuRef.current && !themeMenuRef.current.contains(event.target as Node)) {
        setShowThemeMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTrade = useCallback((action: 'BUY' | 'SELL' | 'AUTO') => {
    const newOrder: TradeOrder = {
      id: Date.now().toString(),
      type: action,
      symbol: 'BTC/USDT',
      amount: Math.random() * 0.5 + 0.1,
      price: balance,
      status: 'pending'
    };

    setRecentOrders(prev => [newOrder, ...prev.slice(0, 4)]);

    // Simulate order execution
    setTimeout(() => {
      setRecentOrders(prev => prev.map(order => 
        order.id === newOrder.id 
          ? { ...order, status: 'executing' }
          : order
      ));
    }, 1000);

    setTimeout(() => {
      setRecentOrders(prev => prev.map(order => 
        order.id === newOrder.id 
          ? { ...order, status: 'completed' }
          : order
      ));

      // Add success notification
      const successNotification: Notification = {
        id: Date.now().toString(),
        type: 'success',
        title: 'Trade Executed',
        message: `${action} order for ${newOrder.amount.toFixed(4)} BTC completed`,
        timestamp: new Date(),
        read: false
      };

      setNotifications(prev => [successNotification, ...prev]);
    }, 3000);
  }, [balance]);

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(notif => 
      notif.id === id ? { ...notif, read: true } : notif
    ));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    setShowNotifications(false);
  };

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'connected': return <Wifi className="text-green-400" size={16} />;
      case 'connecting': return <Wifi className="text-yellow-400 animate-pulse" size={16} />;
      case 'disconnected': return <WifiOff className="text-red-400" size={16} />;
    }
  };

  const getConnectionStatus = () => {
    switch (connectionStatus) {
      case 'connected': return { text: 'LIVE', color: 'text-green-400' };
      case 'connecting': return { text: 'CONNECTING', color: 'text-yellow-400' };
      case 'disconnected': return { text: 'OFFLINE', color: 'text-red-400' };
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success': return '✅';
      case 'warning': return '⚠️';
      case 'error': return '❌';
      case 'info': return 'ℹ️';
      default: return '📢';
    }
  };

  const getOrderStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'executing': return 'text-blue-400';
      case 'completed': return 'text-green-400';
      case 'failed': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;
  const status = getConnectionStatus();

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="h-[80px] border-b border-white/10 flex items-center justify-between px-6 text-white bg-gray-900/50 backdrop-blur-xl relative z-40"
    >
      {/* Left Section */}
      <div className="flex items-center space-x-6">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onMenuClick}
          className="p-2 rounded-xl hover:bg-white/10 transition-colors"
        >
          <Menu size={20} />
        </motion.button>

        <div className="hidden md:block">
          <h1 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            Professional Dashboard
          </h1>
          <p className="text-xs text-gray-400 flex items-center space-x-2">
            <Clock size={12} />
            <span>Last update: {lastUpdate.toLocaleTimeString()}</span>
          </p>
        </div>

        {/* Search Bar */}
        <motion.div
          initial={{ width: 200 }}
          animate={{ width: isSearchFocused ? 300 : 200 }}
          className="relative hidden lg:block"
        >
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search symbols, orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            className="w-full bg-gray-800/50 border border-gray-700 rounded-xl pl-10 pr-4 py-2 text-sm focus:border-green-500 focus:outline-none transition-colors"
          />
        </motion.div>
      </div>

      {/* Center Section - Trading Controls */}
      <div className="flex items-center space-x-3">
        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleTrade('BUY')}
          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-green-500/25 flex items-center space-x-2"
        >
          <TrendingUp size={16} />
          <span>BUY</span>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleTrade('SELL')}
          className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-red-500/25 flex items-center space-x-2"
        >
          <TrendingDown size={16} />
          <span>SELL</span>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleTrade('AUTO')}
          className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-blue-500/25 flex items-center space-x-2"
        >
          <Zap size={16} />
          <span>AI AUTO</span>
        </motion.button>
      </div>

      {/* Right Section */}
      <div className="flex items-center space-x-4">
        {/* Connection Status */}
        <motion.div 
          whileHover={{ scale: 1.05 }}
          className="flex items-center space-x-2 bg-gray-800/50 rounded-xl px-3 py-2"
        >
          {getConnectionIcon()}
          <span className={`text-sm font-medium ${status.color}`}>
            {status.text}
          </span>
        </motion.div>

        {/* Balance Display */}
        <motion.div
          key={balance}
          initial={{ scale: 1.05, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-right bg-gray-800/50 rounded-xl px-4 py-2"
        >
          <div className="text-lg font-mono font-bold flex items-center space-x-1">
            <DollarSign size={16} className="text-green-400" />
            <span>
              {balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className={`text-xs flex items-center space-x-1 ${
            changePercent >= 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            {changePercent >= 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
            <span>
              {changePercent >= 0 ? '+' : ''}${Math.abs(change).toLocaleString('en-US', { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
              })} ({changePercent >= 0 ? '+' : ''}{changePercent.toFixed(2)}%)
            </span>
          </div>
        </motion.div>

        {/* Recent Orders Indicator */}
        {recentOrders.length > 0 && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-gray-800/50 rounded-xl px-3 py-2"
          >
            <div className="flex items-center space-x-2">
              <BarChart3 size={14} className="text-blue-400" />
              <span className="text-xs text-gray-400">
                {recentOrders.filter(o => o.status === 'executing').length} active
              </span>
            </div>
          </motion.div>
        )}

        {/* Notifications */}
        <div className="relative" ref={notificationRef}>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
          >
            <Bell size={18} />
            <AnimatePresence>
              {unreadCount > 0 && (
                <motion.span
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold"
                >
                  {unreadCount}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                className="absolute right-0 top-full mt-2 w-80 bg-gray-900/95 backdrop-blur-xl rounded-xl border border-gray-700 shadow-2xl z-50"
              >
                <div className="p-4 border-b border-gray-700 flex items-center justify-between">
                  <h3 className="font-semibold">Notifications</h3>
                  <button
                    onClick={clearAllNotifications}
                    className="text-xs text-gray-400 hover:text-white transition-colors"
                  >
                    Clear all
                  </button>
                </div>
                
                <div className="max-h-80 overflow-y-auto">
                  {notifications.length > 0 ? (
                    notifications.map((notification) => (
                      <motion.div
                        key={notification.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        onClick={() => markNotificationAsRead(notification.id)}
                        className={`p-4 border-b border-gray-700/50 hover:bg-gray-800/50 cursor-pointer transition-colors ${
                          !notification.read ? 'bg-blue-500/10' : ''
                        }`}
                      >
                        <div className="flex items-start space-x-3">
                          <span className="text-lg">
                            {getNotificationIcon(notification.type)}
                          </span>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{notification.title}</div>
                            <div className="text-xs text-gray-400 mt-1">{notification.message}</div>
                            <div className="text-xs text-gray-500 mt-2">
                              {notification.timestamp.toLocaleTimeString()}
                            </div>
                          </div>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full" />
                          )}
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="p-8 text-center text-gray-400">
                      <Bell size={32} className="mx-auto mb-2 opacity-50" />
                      <p>No notifications</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Theme Selector */}
        <div className="relative" ref={themeMenuRef}>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowThemeMenu(!showThemeMenu)}
            className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
          >
            <Palette size={18} />
          </motion.button>

          <AnimatePresence>
            {showThemeMenu && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                className="absolute right-0 top-full mt-2 w-48 bg-gray-900/95 backdrop-blur-xl rounded-xl border border-gray-700 shadow-2xl z-50 p-2"
              >
                {[
                  { value: 'dark', label: 'Dark Theme', color: 'bg-gray-800' },
                  { value: 'blue', label: 'Ocean Blue', color: 'bg-blue-600' },
                  { value: 'green', label: 'Matrix Green', color: 'bg-green-600' }
                ].map((theme) => (
                  <motion.button
                    key={theme.value}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      onThemeChange?.(theme.value as any);
                      setShowThemeMenu(false);
                    }}
                    className={`w-full p-3 rounded-lg transition-colors flex items-center space-x-3 ${
                      currentTheme === theme.value ? 'bg-gray-700' : 'hover:bg-gray-800'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded ${theme.color}`} />
                    <span className="text-sm">{theme.label}</span>
                  </motion.button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Fullscreen Toggle */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onFullscreenToggle}
          className="p-2 bg-gray-800/50 rounded-xl hover:bg-gray-700/50 transition-colors"
        >
          {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
        </motion.button>

        {/* User Profile */}
        <div className="relative" ref={userMenuRef}>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-2 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl p-2 hover:from-blue-400 hover:to-purple-400 transition-all"
          >
            <User size={16} className="text-white" />
            <ChevronDown size={12} className="text-white" />
          </motion.button>

          <AnimatePresence>
            {showUserMenu && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                className="absolute right-0 top-full mt-2 w-64 bg-gray-900/95 backdrop-blur-xl rounded-xl border border-gray-700 shadow-2xl z-50"
              >
                <div className="p-4 border-b border-gray-700">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                      <User size={20} className="text-white" />
                    </div>
                    <div>
                      <div className="font-semibold">John Trader</div>
                      <div className="text-sm text-gray-400">Pro Account</div>
                      <div className="text-xs text-green-400 flex items-center space-x-1">
                        <Shield size={12} />
                        <span>Verified</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="p-2">
                  {[
                    { icon: Settings, label: 'Account Settings', action: () => {} },
                    { icon: BarChart3, label: 'Trading History', action: () => {} },
                    { icon: HelpCircle, label: 'Help & Support', action: () => {} },
                    { icon: LogOut, label: 'Sign Out', action: () => {} }
                  ].map((item, index) => (
                    <motion.button
                      key={index}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={item.action}
                      className="w-full p-3 rounded-lg hover:bg-gray-800 transition-colors flex items-center space-x-3 text-left"
                    >
                      <item.icon size={16} className="text-gray-400" />
                      <span className="text-sm">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
import React from 'react';
import { TrendingUp, Shield, Target, PieChart, Zap, AlertTriangle } from 'lucide-react';
import { useSettingsStore } from '@/store/settingsStore';
import { SettingGroup } from '@/components/shared/settings/SettingGroup';
import { ToggleSwitch } from '@/components/shared/settings/ToggleSwitch';
import { SelectDropdown } from '@/components/shared/settings/SelectDropdown';
import { SliderControl } from '@/components/shared/settings/SliderControl';

const RISK_LEVEL_OPTIONS = [
  { value: 'conservative', label: 'Conservative (1-2% risk)' },
  { value: 'moderate', label: 'Moderate (2-5% risk)' },
  { value: 'aggressive', label: 'Aggressive (5-10% risk)' },
  { value: 'maximum', label: 'Maximum (10%+ risk)' },
];

export function TradingSettings() {
  const { trading, updateTradingSetting } = useSettingsStore();

  return (
    <div className="space-y-6">
      {/* Risk Management */}
      <SettingGroup
        title="Risk Management"
        description="Configure your risk tolerance and position sizing"
        icon={Shield}
      >
        <div className="space-y-4">
          {/* Max Risk per Trade */}
          <SliderControl
            label="Max Risk per Trade"
            description="Maximum percentage of portfolio to risk on a single trade"
            value={trading.maxRiskPerTrade}
            min={0.5}
            max={10}
            step={0.5}
            suffix="%"
            onChange={(value) => updateTradingSetting('maxRiskPerTrade', value)}
          />

          {/* Max Daily Loss */}
          <SliderControl
            label="Max Daily Loss"
            description="Maximum percentage of portfolio to lose in a single day"
            value={trading.maxDailyLoss}
            min={1}
            max={20}
            step={1}
            suffix="%"
            onChange={(value) => updateTradingSetting('maxDailyLoss', value)}
          />

          {/* Risk Level */}
          <SelectDropdown
            label="Risk Level"
            description="Overall risk profile for your trading strategy"
            value={trading.riskLevel}
            options={RISK_LEVEL_OPTIONS}
            onChange={(value) => updateTradingSetting('riskLevel', value as any)}
          />
        </div>
      </SettingGroup>

      {/* Trade Execution */}
      <SettingGroup
        title="Trade Execution"
        description="Control how trades are executed and confirmed"
        icon={Zap}
      >
        <div className="space-y-4">
          {/* Confirm Trades */}
          <ToggleSwitch
            label="Confirm Trades"
            description="Show confirmation dialog before executing trades"
            checked={trading.confirmTrades}
            onChange={(value) => updateTradingSetting('confirmTrades', value)}
          />

          {/* One-Click Trading */}
          <ToggleSwitch
            label="One-Click Trading"
            description="Execute trades with single click (use with caution)"
            checked={trading.oneClickTrading}
            onChange={(value) => updateTradingSetting('oneClickTrading', value)}
          />

          {/* Quick Execution Hotkey */}
          <ToggleSwitch
            label="Quick Execution Hotkey"
            description="Enable keyboard shortcuts for rapid trading"
            checked={trading.quickExecutionHotkey}
            onChange={(value) => updateTradingSetting('quickExecutionHotkey', value)}
          />

          {/* Order Size Limits */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Minimum Order Size (USD)
              </label>
              <input
                type="number"
                value={trading.minOrderSize}
                onChange={(e) => updateTradingSetting('minOrderSize', parseFloat(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                min="1"
                step="1"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                Maximum Order Size (USD)
              </label>
              <input
                type="number"
                value={trading.maxOrderSize}
                onChange={(e) => updateTradingSetting('maxOrderSize', parseFloat(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                min="1"
                step="100"
              />
            </div>
          </div>
        </div>
      </SettingGroup>

      {/* Portfolio Management */}
      <SettingGroup
        title="Portfolio Management"
        description="Configure portfolio allocation and rebalancing"
        icon={PieChart}
      >
        <div className="space-y-4">
          {/* Portfolio Size */}
          <SliderControl
            label="Portfolio Size to Use"
            description="Percentage of total portfolio to allocate for trading"
            value={trading.portfolioSize}
            min={10}
            max={100}
            step={5}
            suffix="%"
            onChange={(value) => updateTradingSetting('portfolioSize', value)}
          />

          {/* Max Positions */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              Max Simultaneous Positions
            </label>
            <input
              type="number"
              value={trading.maxPositions}
              onChange={(e) => updateTradingSetting('maxPositions', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              min="1"
              max="50"
            />
          </div>

          {/* Auto Rebalance */}
          <ToggleSwitch
            label="Auto Rebalance"
            description="Automatically rebalance portfolio based on target allocations"
            checked={trading.autoRebalance}
            onChange={(value) => updateTradingSetting('autoRebalance', value)}
          />

          {/* Rebalance Threshold */}
          {trading.autoRebalance && (
            <SliderControl
              label="Rebalance Threshold"
              description="Percentage deviation before triggering rebalance"
              value={trading.rebalanceThreshold}
              min={5}
              max={25}
              step={1}
              suffix="%"
              onChange={(value) => updateTradingSetting('rebalanceThreshold', value)}
            />
          )}
        </div>
      </SettingGroup>

      {/* Stop Loss & Take Profit */}
      <SettingGroup
        title="Stop Loss & Take Profit"
        description="Configure automatic stop loss and take profit settings"
        icon={Target}
      >
        <div className="space-y-4">
          {/* Default Stop Loss */}
          <SliderControl
            label="Default Stop Loss"
            description="Default stop loss percentage for new trades"
            value={trading.defaultStopLoss}
            min={1}
            max={20}
            step={1}
            suffix="%"
            onChange={(value) => updateTradingSetting('defaultStopLoss', value)}
          />

          {/* Default Take Profit */}
          <SliderControl
            label="Default Take Profit"
            description="Default take profit percentage for new trades"
            value={trading.defaultTakeProfit}
            min={5}
            max={50}
            step={1}
            suffix="%"
            onChange={(value) => updateTradingSetting('defaultTakeProfit', value)}
          />

          {/* Trailing Stop Loss */}
          <ToggleSwitch
            label="Trailing Stop Loss"
            description="Automatically adjust stop loss as price moves in your favor"
            checked={trading.trailingStopLoss}
            onChange={(value) => updateTradingSetting('trailingStopLoss', value)}
          />

          {/* Auto Stop Loss */}
          <ToggleSwitch
            label="Auto Stop Loss"
            description="Automatically set stop loss on all new trades"
            checked={trading.autoStopLoss}
            onChange={(value) => updateTradingSetting('autoStopLoss', value)}
          />
        </div>
      </SettingGroup>

      {/* Signal Following */}
      <SettingGroup
        title="Signal Following"
        description="Configure AI signal execution and filtering"
        icon={TrendingUp}
      >
        <div className="space-y-4">
          {/* Auto Execute Signals */}
          <ToggleSwitch
            label="Auto Execute Signals"
            description="Automatically execute trades based on AI signals"
            checked={trading.autoExecuteSignals}
            onChange={(value) => updateTradingSetting('autoExecuteSignals', value)}
          />

          {/* Min Signal Confidence */}
          <SliderControl
            label="Minimum Signal Confidence"
            description="Only execute signals above this confidence level"
            value={trading.minSignalConfidence}
            min={50}
            max={95}
            step={5}
            suffix="%"
            onChange={(value) => updateTradingSetting('minSignalConfidence', value)}
          />

          {/* Max Signals Per Day */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              Max Signals Per Day
            </label>
            <input
              type="number"
              value={trading.maxSignalsPerDay}
              onChange={(e) => updateTradingSetting('maxSignalsPerDay', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              min="1"
              max="20"
            />
          </div>

          {/* Signal Cooldown */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              Signal Cooldown (minutes)
            </label>
            <input
              type="number"
              value={trading.signalCooldown}
              onChange={(e) => updateTradingSetting('signalCooldown', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              min="5"
              max="120"
              step="5"
            />
          </div>
        </div>
      </SettingGroup>

      {/* Risk Warning */}
      <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
        <div className="flex items-start">
          <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mt-0.5 mr-3 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
              Risk Warning
            </h4>
            <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
              Trading involves substantial risk of loss. These settings affect your trading behavior and risk exposure. 
              Please ensure you understand the implications of your choices.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
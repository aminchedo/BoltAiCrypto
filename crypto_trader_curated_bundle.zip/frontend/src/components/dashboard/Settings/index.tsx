import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Shield, 
  Bell, 
  TrendingUp, 
  Database, 
  PieChart, 
  Layout,
  Save,
  Download,
  Upload,
  RotateCcw
} from 'lucide-react';
import { useSettingsStore } from '@/store/settingsStore';
import { GeneralSettings } from './GeneralSettings';
import { SecuritySettings } from './SecuritySettings';
import { TradingSettings } from './TradingSettings';
import { DashboardSettings } from './DashboardSettings';

const SETTINGS_TABS = [
  { id: 'general', label: 'General', icon: SettingsIcon, component: GeneralSettings },
  { id: 'security', label: 'Security', icon: Shield, component: SecuritySettings },
  { id: 'notifications', label: 'Notifications', icon: Bell, component: null }, // TODO: Implement
  { id: 'trading', label: 'Trading', icon: TrendingUp, component: TradingSettings },
  { id: 'exchanges', label: 'Exchanges', icon: Database, component: null }, // TODO: Implement
  { id: 'portfolio', label: 'Portfolio', icon: PieChart, component: null }, // TODO: Implement
  { id: 'dashboard', label: 'Dashboard', icon: Layout, component: DashboardSettings },
];

export function Settings() {
  const [activeTab, setActiveTab] = useState('general');
  const { 
    isLoading, 
    lastSaved, 
    hasUnsavedChanges, 
    saveSettingsToBackend, 
    exportSettings, 
    importSettings, 
    resetAllSettings 
  } = useSettingsStore();

  const activeTabData = SETTINGS_TABS.find(tab => tab.id === activeTab);
  const ActiveComponent = activeTabData?.component;

  const handleExport = () => {
    const settingsData = exportSettings();
    const blob = new Blob([settingsData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ai-trader-settings-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          try {
            importSettings(content);
          } catch (error) {
            alert('Failed to import settings. Please check the file format.');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const handleReset = () => {
    if (confirm('Are you sure you want to reset all settings to defaults? This action cannot be undone.')) {
      resetAllSettings();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                Settings
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Manage your preferences and trading configuration
              </p>
            </div>
            
            {/* Action Buttons */}
            <div className="flex items-center space-x-3">
              {hasUnsavedChanges && (
                <div className="flex items-center text-sm text-yellow-600 dark:text-yellow-400">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2 animate-pulse"></div>
                  Unsaved changes
                </div>
              )}
              
              <button
                onClick={saveSettingsToBackend}
                disabled={isLoading || !hasUnsavedChanges}
                className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Save Changes
              </button>
            </div>
          </div>

          {/* Last Saved Info */}
          {lastSaved && (
            <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
              Last saved: {lastSaved.toLocaleString()}
            </div>
          )}
        </div>

        {/* Settings Actions */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={handleExport}
              className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 focus:ring-2 focus:ring-blue-500"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Settings
            </button>
            
            <button
              onClick={handleImport}
              className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 focus:ring-2 focus:ring-blue-500"
            >
              <Upload className="w-4 h-4 mr-2" />
              Import Settings
            </button>
          </div>
          
          <button
            onClick={handleReset}
            className="flex items-center px-3 py-2 text-sm font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md hover:bg-red-100 dark:hover:bg-red-900/30 focus:ring-2 focus:ring-red-500"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset to Defaults
          </button>
        </div>

        {/* Settings Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200 dark:border-gray-700">
            <nav className="-mb-px flex space-x-8 overflow-x-auto">
              {SETTINGS_TABS.map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                        : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                    }`}
                  >
                    <IconComponent className="w-4 h-4 inline mr-2" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          {ActiveComponent ? (
            <ActiveComponent />
          ) : (
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <SettingsIcon className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                {activeTabData?.label} Settings
              </h3>
              <p className="text-gray-500 dark:text-gray-400">
                This settings section is coming soon. We're working on implementing {activeTabData?.label.toLowerCase()} preferences.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
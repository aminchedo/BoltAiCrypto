import React from 'react';
import { Layout, Grid, Eye, EyeOff, RefreshCw, Settings } from 'lucide-react';
import { useSettingsStore } from '@/store/settingsStore';
import { SettingGroup } from '@/components/shared/settings/SettingGroup';
import { ToggleSwitch } from '@/components/shared/settings/ToggleSwitch';
import { SelectDropdown } from '@/components/shared/settings/SelectDropdown';

const LAYOUT_OPTIONS = [
  { value: 'grid', label: 'Grid Layout' },
  { value: 'masonry', label: 'Masonry Layout' },
  { value: 'flex', label: 'Flexible Layout' },
];

const REFRESH_INTERVAL_OPTIONS = [
  { value: '5', label: '5 seconds' },
  { value: '10', label: '10 seconds' },
  { value: '30', label: '30 seconds' },
  { value: '60', label: '1 minute' },
];

const AVAILABLE_WIDGETS = [
  { id: 'portfolio-summary', name: 'Portfolio Summary', description: 'Overview of your portfolio performance' },
  { id: 'price-display', name: 'Price Display', description: 'Real-time price charts and data' },
  { id: 'signal-feed', name: 'Signal Feed', description: 'AI trading signals and alerts' },
  { id: 'trade-history', name: 'Trade History', description: 'Recent trades and performance' },
  { id: 'performance-chart', name: 'Performance Chart', description: 'Portfolio performance over time' },
  { id: 'news-feed', name: 'News Feed', description: 'Market news and updates' },
  { id: 'watchlist', name: 'Watchlist', description: 'Your favorite trading pairs' },
  { id: 'order-book', name: 'Order Book', description: 'Market depth and order book' },
  { id: 'market-overview', name: 'Market Overview', description: 'Market statistics and trends' },
  { id: 'risk-metrics', name: 'Risk Metrics', description: 'Portfolio risk analysis' },
];

export function DashboardSettings() {
  const { dashboard, updateDashboardSetting } = useSettingsStore();

  const toggleWidget = (widgetId: string) => {
    const widget = dashboard.widgets.find(w => w.id === widgetId);
    if (widget) {
      const updatedWidgets = dashboard.widgets.map(w => 
        w.id === widgetId ? { ...w, visible: !w.visible } : w
      );
      updateDashboardSetting('widgets', updatedWidgets);
    } else {
      // Add new widget
      const newWidget = {
        id: widgetId,
        type: widgetId,
        position: { x: 0, y: 0, w: 2, h: 2 },
        settings: {},
        visible: true,
      };
      updateDashboardSetting('widgets', [...dashboard.widgets, newWidget]);
    }
  };

  const isWidgetActive = (widgetId: string) => {
    return dashboard.widgets.some(w => w.id === widgetId && w.visible);
  };

  return (
    <div className="space-y-6">
      {/* Layout Settings */}
      <SettingGroup
        title="Layout Configuration"
        description="Customize how your dashboard is organized and displayed"
        icon={Layout}
      >
        <div className="space-y-4">
          {/* Layout Type */}
          <SelectDropdown
            label="Layout Type"
            description="Choose how widgets are arranged on your dashboard"
            value={dashboard.layout}
            options={LAYOUT_OPTIONS}
            onChange={(value) => updateDashboardSetting('layout', value as any)}
          />

          {/* Columns */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              Number of Columns
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[2, 3, 4].map((cols) => (
                <button
                  key={cols}
                  onClick={() => updateDashboardSetting('columns', cols as any)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    dashboard.columns === cols
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Grid className="w-6 h-6 mx-auto mb-2 text-gray-600 dark:text-gray-400" />
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {cols} Columns
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Compact Mode */}
          <ToggleSwitch
            label="Compact Mode"
            description="Reduce spacing and padding for more widgets on screen"
            checked={dashboard.compactMode}
            onChange={(value) => updateDashboardSetting('compactMode', value)}
          />
        </div>
      </SettingGroup>

      {/* Widget Management */}
      <SettingGroup
        title="Widget Management"
        description="Choose which widgets to display on your dashboard"
        icon={Settings}
      >
        <div className="space-y-4">
          {/* Widget Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {AVAILABLE_WIDGETS.map((widget) => (
              <div
                key={widget.id}
                className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                  isWidgetActive(widget.id)
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
                onClick={() => toggleWidget(widget.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                    {widget.name}
                  </h4>
                  {isWidgetActive(widget.id) ? (
                    <Eye className="w-4 h-4 text-blue-500" />
                  ) : (
                    <EyeOff className="w-4 h-4 text-gray-400" />
                  )}
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {widget.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </SettingGroup>

      {/* Auto Refresh Settings */}
      <SettingGroup
        title="Auto Refresh"
        description="Configure automatic data updates and refresh intervals"
        icon={RefreshCw}
      >
        <div className="space-y-4">
          {/* Auto Refresh Toggle */}
          <ToggleSwitch
            label="Auto Refresh"
            description="Automatically refresh dashboard data at regular intervals"
            checked={dashboard.autoRefresh}
            onChange={(value) => updateDashboardSetting('autoRefresh', value)}
          />

          {/* Refresh Interval */}
          {dashboard.autoRefresh && (
            <SelectDropdown
              label="Refresh Interval"
              description="How often to refresh dashboard data"
              value={dashboard.refreshInterval.toString()}
              options={REFRESH_INTERVAL_OPTIONS}
              onChange={(value) => updateDashboardSetting('refreshInterval', parseInt(value))}
            />
          )}
        </div>
      </SettingGroup>

      {/* Display Preferences */}
      <SettingGroup
        title="Display Preferences"
        description="Customize how information is displayed on your dashboard"
        icon={Eye}
      >
        <div className="space-y-4">
          {/* Welcome Message */}
          <ToggleSwitch
            label="Show Welcome Message"
            description="Display welcome message and tips on dashboard"
            checked={dashboard.showWelcomeMessage}
            onChange={(value) => updateDashboardSetting('showWelcomeMessage', value)}
          />
        </div>
      </SettingGroup>

      {/* Widget Preview */}
      <SettingGroup
        title="Widget Preview"
        description="Preview of your current dashboard layout"
        icon={Layout}
      >
        <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <div className="grid grid-cols-3 gap-4">
            {dashboard.widgets
              .filter(w => w.visible)
              .slice(0, 6)
              .map((widget) => (
                <div
                  key={widget.id}
                  className="h-20 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-600 flex items-center justify-center"
                >
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {AVAILABLE_WIDGETS.find(w => w.id === widget.id)?.name || widget.id}
                  </span>
                </div>
              ))}
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
            {dashboard.widgets.filter(w => w.visible).length} widgets active
          </p>
        </div>
      </SettingGroup>
    </div>
  );
}
import React from 'react';
import { Settings, Globe, Palette, Clock, Bell, Monitor } from 'lucide-react';
import { useSettingsStore } from '@/store/settingsStore';
import { SettingGroup } from '@/components/shared/settings/SettingGroup';
import { ToggleSwitch } from '@/components/shared/settings/ToggleSwitch';
import { SelectDropdown } from '@/components/shared/settings/SelectDropdown';
import { SliderControl } from '@/components/shared/settings/SliderControl';

const LANGUAGE_OPTIONS = [
  { value: 'en', label: 'English' },
  { value: 'fa', label: 'فارسی' },
  { value: 'ar', label: 'العربية' },
  { value: 'zh', label: '中文' },
];

const CURRENCY_OPTIONS = [
  { value: 'USD', label: 'US Dollar ($)' },
  { value: 'EUR', label: 'Euro (€)' },
  { value: 'BTC', label: 'Bitcoin (₿)' },
  { value: 'IRR', label: 'Iranian Rial (ریال)' },
];

const DATE_FORMAT_OPTIONS = [
  { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' },
  { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' },
  { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' },
];

const NUMBER_FORMAT_OPTIONS = [
  { value: 'US', label: 'US (1,234.56)' },
  { value: 'EU', label: 'European (1.234,56)' },
  { value: 'IN', label: 'Indian (1,23,456.78)' },
];

const REFRESH_INTERVAL_OPTIONS = [
  { value: '5', label: '5 seconds' },
  { value: '10', label: '10 seconds' },
  { value: '30', label: '30 seconds' },
  { value: '60', label: '1 minute' },
];

export function GeneralSettings() {
  const { general, updateGeneralSetting } = useSettingsStore();

  return (
    <div className="space-y-6">
      {/* Appearance Settings */}
      <SettingGroup
        title="Appearance"
        description="Customize the look and feel of your trading interface"
        icon={Palette}
      >
        <div className="space-y-4">
          {/* Theme Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              Theme
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: 'light', label: 'Light', icon: '☀️' },
                { value: 'dark', label: 'Dark', icon: '🌙' },
                { value: 'auto', label: 'Auto', icon: '🔄' },
              ].map((theme) => (
                <button
                  key={theme.value}
                  onClick={() => updateGeneralSetting('theme', theme.value as any)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    general.theme === theme.value
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <div className="text-2xl mb-1">{theme.icon}</div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {theme.label}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Animations */}
          <ToggleSwitch
            label="Enable Animations"
            description="Smooth transitions and animations throughout the interface"
            checked={general.animations}
            onChange={(value) => updateGeneralSetting('animations', value)}
          />

          {/* Compact Numbers */}
          <ToggleSwitch
            label="Compact Number Display"
            description="Show large numbers in compact format (e.g., 1.2K instead of 1,200)"
            checked={general.compactNumbers}
            onChange={(value) => updateGeneralSetting('compactNumbers', value)}
          />
        </div>
      </SettingGroup>

      {/* Localization Settings */}
      <SettingGroup
        title="Localization"
        description="Language, currency, and regional preferences"
        icon={Globe}
      >
        <div className="space-y-4">
          {/* Language */}
          <SelectDropdown
            label="Language"
            description="Select your preferred language"
            value={general.language}
            options={LANGUAGE_OPTIONS}
            onChange={(value) => updateGeneralSetting('language', value as any)}
          />

          {/* Currency */}
          <SelectDropdown
            label="Base Currency"
            description="Currency used for price displays and calculations"
            value={general.currency}
            options={CURRENCY_OPTIONS}
            onChange={(value) => updateGeneralSetting('currency', value as any)}
          />

          {/* Date Format */}
          <SelectDropdown
            label="Date Format"
            description="How dates are displayed throughout the application"
            value={general.dateFormat}
            options={DATE_FORMAT_OPTIONS}
            onChange={(value) => updateGeneralSetting('dateFormat', value as any)}
          />

          {/* Number Format */}
          <SelectDropdown
            label="Number Format"
            description="How numbers are formatted (decimal and thousands separators)"
            value={general.numberFormat}
            options={NUMBER_FORMAT_OPTIONS}
            onChange={(value) => updateGeneralSetting('numberFormat', value as any)}
          />
        </div>
      </SettingGroup>

      {/* Performance Settings */}
      <SettingGroup
        title="Performance"
        description="Optimize the application for your device and preferences"
        icon={Monitor}
      >
        <div className="space-y-4">
          {/* Auto Refresh */}
          <ToggleSwitch
            label="Auto Refresh"
            description="Automatically refresh data at regular intervals"
            checked={general.autoRefresh}
            onChange={(value) => updateGeneralSetting('autoRefresh', value)}
          />

          {/* Refresh Interval */}
          {general.autoRefresh && (
            <SelectDropdown
              label="Refresh Interval"
              description="How often to refresh market data and portfolio information"
              value={general.refreshInterval.toString()}
              options={REFRESH_INTERVAL_OPTIONS}
              onChange={(value) => updateGeneralSetting('refreshInterval', parseInt(value) as any)}
            />
          )}

          {/* Sound Effects */}
          <ToggleSwitch
            label="Sound Effects"
            description="Play sounds for notifications and alerts"
            checked={general.soundEffects}
            onChange={(value) => updateGeneralSetting('soundEffects', value)}
          />
        </div>
      </SettingGroup>

      {/* Time Settings */}
      <SettingGroup
        title="Time & Date"
        description="Configure timezone and time-related preferences"
        icon={Clock}
      >
        <div className="space-y-4">
          {/* Timezone */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              Timezone
            </label>
            <select
              value={general.timezone}
              onChange={(e) => updateGeneralSetting('timezone', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
            >
              {Intl.supportedValuesOf('timeZone').map((tz) => (
                <option key={tz} value={tz}>
                  {tz}
                </option>
              ))}
            </select>
          </div>
        </div>
      </SettingGroup>
    </div>
  );
}
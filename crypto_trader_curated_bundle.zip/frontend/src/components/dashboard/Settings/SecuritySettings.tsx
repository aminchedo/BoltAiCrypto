import React, { useState } from 'react';
import { Shield, Lock, Key, Download, Upload, Clock, Smartphone, Eye, EyeOff } from 'lucide-react';
import { useSettingsStore } from '@/store/settingsStore';
import { SettingGroup } from '@/components/shared/settings/SettingGroup';
import { ToggleSwitch } from '@/components/shared/settings/ToggleSwitch';
import { SelectDropdown } from '@/components/shared/settings/SelectDropdown';
import { SliderControl } from '@/components/shared/settings/SliderControl';

const TIMEOUT_DURATION_OPTIONS = [
  { value: '15', label: '15 minutes' },
  { value: '30', label: '30 minutes' },
  { value: '60', label: '1 hour' },
  { value: '120', label: '2 hours' },
];

const BACKUP_FREQUENCY_OPTIONS = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
];

export function SecuritySettings() {
  const { security, updateSecuritySetting } = useSettingsStore();
  const [showPassword, setShowPassword] = useState(false);
  const [backupLoading, setBackupLoading] = useState(false);

  const handleTwoFactorToggle = (enabled: boolean) => {
    if (enabled) {
      // In a real app, this would trigger 2FA setup flow
      alert('2FA setup would be initiated here');
    }
    updateSecuritySetting('twoFactorAuth', enabled);
  };

  const handleBiometricToggle = (enabled: boolean) => {
    if (enabled) {
      // Check if biometric auth is available
      if (!navigator.credentials) {
        alert('Biometric authentication is not supported on this device');
        return;
      }
    }
    updateSecuritySetting('biometricAuth', enabled);
  };

  const handleCreateBackup = async () => {
    setBackupLoading(true);
    try {
      // Simulate backup creation
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert('Backup created successfully!');
    } catch (error) {
      alert('Failed to create backup');
    } finally {
      setBackupLoading(false);
    }
  };

  const handleRestoreBackup = () => {
    // In a real app, this would open file picker
    alert('Backup restore functionality would be implemented here');
  };

  return (
    <div className="space-y-6">
      {/* Authentication Settings */}
      <SettingGroup
        title="Authentication"
        description="Secure your account with multiple authentication methods"
        icon={Lock}
      >
        <div className="space-y-4">
          {/* Two-Factor Authentication */}
          <ToggleSwitch
            label="Two-Factor Authentication"
            description="Add an extra layer of security with 2FA codes"
            checked={security.twoFactorAuth}
            onChange={handleTwoFactorToggle}
          />

          {/* Biometric Authentication */}
          <ToggleSwitch
            label="Biometric Authentication"
            description="Use fingerprint or face recognition for quick login"
            checked={security.biometricAuth}
            onChange={handleBiometricToggle}
          />

          {/* Password Expiry */}
          <ToggleSwitch
            label="Password Expiry"
            description="Require password changes at regular intervals"
            checked={security.passwordExpiry}
            onChange={(value) => updateSecuritySetting('passwordExpiry', value)}
          />
        </div>
      </SettingGroup>

      {/* Session Management */}
      <SettingGroup
        title="Session Security"
        description="Control how your sessions are managed and secured"
        icon={Clock}
      >
        <div className="space-y-4">
          {/* Auto Session Timeout */}
          <ToggleSwitch
            label="Auto Session Timeout"
            description="Automatically log out after period of inactivity"
            checked={security.sessionTimeout}
            onChange={(value) => updateSecuritySetting('sessionTimeout', value)}
          />

          {/* Timeout Duration */}
          {security.sessionTimeout && (
            <SelectDropdown
              label="Timeout Duration"
              description="How long to wait before auto-logout"
              value={security.timeoutDuration.toString()}
              options={TIMEOUT_DURATION_OPTIONS}
              onChange={(value) => updateSecuritySetting('timeoutDuration', parseInt(value) as any)}
            />
          )}

          {/* Auto Lock */}
          <ToggleSwitch
            label="Auto Lock"
            description="Lock the application when switching away"
            checked={security.autoLock}
            onChange={(value) => updateSecuritySetting('autoLock', value)}
          />
        </div>
      </SettingGroup>

      {/* Backup & Recovery */}
      <SettingGroup
        title="Backup & Recovery"
        description="Secure your settings and data with encrypted backups"
        icon={Download}
      >
        <div className="space-y-4">
          {/* Encrypted Backups */}
          <ToggleSwitch
            label="Encrypted Backups"
            description="Automatically backup your settings with encryption"
            checked={security.encryptedBackups}
            onChange={(value) => updateSecuritySetting('encryptedBackups', value)}
          />

          {/* Backup Frequency */}
          {security.encryptedBackups && (
            <SelectDropdown
              label="Backup Frequency"
              description="How often to create automatic backups"
              value={security.backupFrequency}
              options={BACKUP_FREQUENCY_OPTIONS}
              onChange={(value) => updateSecuritySetting('backupFrequency', value as any)}
            />
          )}

          {/* Manual Backup Actions */}
          <div className="flex space-x-3">
            <button
              onClick={handleCreateBackup}
              disabled={backupLoading}
              className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {backupLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              ) : (
                <Download className="w-4 h-4 mr-2" />
              )}
              Create Backup Now
            </button>
            
            <button
              onClick={handleRestoreBackup}
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-200 dark:bg-gray-600 rounded-md hover:bg-gray-300 dark:hover:bg-gray-500 focus:ring-2 focus:ring-gray-500"
            >
              <Upload className="w-4 h-4 mr-2" />
              Restore from Backup
            </button>
          </div>
        </div>
      </SettingGroup>

      {/* Device & Login Security */}
      <SettingGroup
        title="Device & Login Security"
        description="Monitor and control device access to your account"
        icon={Smartphone}
      >
        <div className="space-y-4">
          {/* Login Notifications */}
          <ToggleSwitch
            label="Login Notifications"
            description="Get notified when someone logs into your account"
            checked={security.loginNotifications}
            onChange={(value) => updateSecuritySetting('loginNotifications', value)}
          />

          {/* Device Tracking */}
          <ToggleSwitch
            label="Device Tracking"
            description="Track and manage devices that access your account"
            checked={security.deviceTracking}
            onChange={(value) => updateSecuritySetting('deviceTracking', value)}
          />

          {/* IP Whitelist */}
          <div>
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
              IP Address Whitelist
            </label>
            <div className="space-y-2">
              <textarea
                placeholder="Enter IP addresses (one per line)"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                rows={3}
                value={security.ipWhitelist.join('\n')}
                onChange={(e) => {
                  const ips = e.target.value.split('\n').filter(ip => ip.trim());
                  updateSecuritySetting('ipWhitelist', ips);
                }}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Leave empty to allow all IP addresses
              </p>
            </div>
          </div>
        </div>
      </SettingGroup>

      {/* Security Status */}
      <SettingGroup
        title="Security Status"
        description="Overview of your current security settings"
        icon={Shield}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
              <span className="text-sm font-medium text-green-800 dark:text-green-200">
                Session Timeout Active
              </span>
            </div>
          </div>
          
          <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
              <span className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                2FA Not Enabled
              </span>
            </div>
          </div>
          
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
              <span className="text-sm font-medium text-blue-800 dark:text-blue-200">
                Auto Lock Enabled
              </span>
            </div>
          </div>
          
          <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-gray-400 rounded-full mr-3"></div>
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                Biometric Auth Disabled
              </span>
            </div>
          </div>
        </div>
      </SettingGroup>
    </div>
  );
}
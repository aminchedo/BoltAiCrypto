import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LineChart, 
  Line, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis, 
  CartesianGrid,
  Area,
  AreaChart,
  ComposedChart,
  Bar,
  ReferenceLine
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  BarChart3, 
  Activity, 
  Maximize2,
  RefreshCw,
  Target,
  Volume2,
  Zap,
  AlertTriangle,
  Layers,
  Grid,
  Eye,
  Settings,
  Download,
  Share,
  Bell,
  Bookmark,
  Info,
  ArrowUpRight,
  ArrowDownRight,
  Flame
} from 'lucide-react';

interface TradingChartProps {
  className?: string;
  symbol?: string;
  onOrderPlace?: (type: 'buy' | 'sell', amount: number, price: number) => void;
}

interface ChartDataPoint {
  time: string;
  timestamp: number;
  price: number;
  volume: number;
  high: number;
  low: number;
  open: number;
  close: number;
  sma20?: number;
  sma50?: number;
  sma200?: number;
  rsi?: number;
  macd?: number;
  ema12?: number;
  ema26?: number;
  bbUpper?: number;
  bbLower?: number;
  bbMiddle?: number;
}

interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
}

interface Trade {
  id: string;
  timestamp: string;
  price: number;
  amount: number;
  type: 'buy' | 'sell';
  total: number;
}

interface TechnicalIndicator {
  name: string;
  value: number;
  signal: 'buy' | 'sell' | 'neutral';
  strength: number;
  description: string;
}

import { realDataService, apiService } from '../../services/realDataService';

// Enhanced API Service for TradingChart with real data integration
const enhancedApiService = {
  async fetchRealTimePrice(symbol: string) {
    try {
      console.log(`🔄 TradingChart: Fetching real-time price for ${symbol}...`);
      
      // Use the comprehensive API service
      const marketData = await realDataService.fetchMarketData();
      const coinData = marketData.find(coin => coin.symbol === symbol);
      
      if (!coinData) {
        throw new Error(`Data not found for ${symbol}`);
      }
      
      console.log(`✅ Real-time price fetched for ${symbol}: $${coinData.price}`);
      
      return {
        symbol,
        price: coinData.price,
        change24h: coinData.changePercent,
        volume24h: coinData.volume,
        marketCap: coinData.marketCap,
        lastUpdate: new Date().toISOString()
      };
    } catch (error) {
      console.error(`❌ Error fetching ${symbol} price:`, error);
      
      // Fallback to direct CoinGecko API
      return this.fetchFromCoinGecko(symbol);
    }
  },

  async fetchFromCoinGecko(symbol: string) {
    const symbolMap: Record<string, string> = {
      'BTC': 'bitcoin',
      'ETH': 'ethereum',
      'SOL': 'solana',
      'BNB': 'binancecoin',
      'ADA': 'cardano',
      'DOT': 'polkadot',
      'LINK': 'chainlink',
      'UNI': 'uniswap',
      'MATIC': 'polygon',
      'AVAX': 'avalanche-2'
    };

    const coinId = symbolMap[symbol] || symbol.toLowerCase();
    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_market_cap=true&include_last_updated_at=true`
    );
    
    if (!response.ok) throw new Error('CoinGecko API request failed');
    
    const data = await response.json();
    const coinData = data[coinId];
    
    if (!coinData) throw new Error(`Data not found for ${symbol} on CoinGecko`);
    
    return {
      symbol,
      price: coinData.usd,
      change24h: coinData.usd_24h_change || 0,
      volume24h: coinData.usd_24h_vol || 0,
      marketCap: coinData.usd_market_cap || 0,
      lastUpdate: new Date(coinData.last_updated_at * 1000).toISOString()
    };
  },

  async fetchHistoricalData(symbol: string, days: number = 1) {
    try {
      console.log(`🔄 TradingChart: Fetching historical data for ${symbol} (${days} days)...`);
      
      const symbolMap: Record<string, string> = {
        'BTC': 'bitcoin',
        'ETH': 'ethereum',
        'SOL': 'solana',
        'BNB': 'binancecoin',
        'ADA': 'cardano',
        'DOT': 'polkadot',
        'LINK': 'chainlink',
        'UNI': 'uniswap',
        'MATIC': 'polygon',
        'AVAX': 'avalanche-2'
      };

      const coinId = symbolMap[symbol] || symbol.toLowerCase();
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=usd&days=${days}&interval=${days <= 1 ? 'hourly' : 'daily'}`
      );
      
      if (!response.ok) throw new Error('Historical data request failed');
      
      const data = await response.json();
      
      if (!data.prices || !data.total_volumes) {
        throw new Error('Invalid historical data received');
      }
      
      const historicalData = data.prices.map((price: [number, number], index: number) => {
        const timestamp = price[0];
        const priceValue = price[1];
        const volume = data.total_volumes[index] ? data.total_volumes[index][1] : 0;
        
        return {
          timestamp,
          price: priceValue,
          volume: volume,
          time: new Date(timestamp).toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            ...(days > 1 ? { day: '2-digit', month: 'short' } : {})
          })
        };
      });
      
      console.log(`✅ Historical data fetched for ${symbol}: ${historicalData.length} data points`);
      return historicalData;
      
    } catch (error) {
      console.error(`❌ Error fetching historical data for ${symbol}:`, error);
      throw error;
    }
  }
};

const TradingChart: React.FC<TradingChartProps> = ({ 
  className = '', 
  symbol = 'BTC',
  onOrderPlace 
}) => {
  const [timeframe, setTimeframe] = useState('1H');
  const [chartType, setChartType] = useState<'line' | 'area' | 'candles' | 'volume'>('area');
  const [currentCrypto, setCurrentCrypto] = useState(symbol);
  const [cryptoData, setCryptoData] = useState<any>(null);
  const [chartData, setChartData] = useState<ChartDataPoint[]>([]);
  const [isConnected, setIsConnected] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [orderAmount, setOrderAmount] = useState('');
  const [orderPrice, setOrderPrice] = useState('');
  const [orderType, setOrderType] = useState<'market' | 'limit' | 'stop'>('market');
  const [selectedPrice, setSelectedPrice] = useState<number | null>(null);
  const [showOrderBook, setShowOrderBook] = useState(true);
  const [showTradeHistory, setShowTradeHistory] = useState(false);
  const [showIndicators, setShowIndicators] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isWatchlisted, setIsWatchlisted] = useState(false);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [recentTrades, setRecentTrades] = useState<Trade[]>([]);
  const [technicalIndicators, setTechnicalIndicators] = useState<TechnicalIndicator[]>([]);

  const availableCryptos = ['BTC', 'ETH', 'SOL', 'BNB', 'ADA', 'DOT', 'LINK', 'UNI', 'MATIC', 'AVAX'];
  
  const timeframes = [
    { value: '1m', label: '1M', days: 0.001 },
    { value: '5m', label: '5M', days: 0.003 },
    { value: '15m', label: '15M', days: 0.01 },
    { value: '1h', label: '1H', days: 0.04 },
    { value: '4h', label: '4H', days: 0.17 },
    { value: '1d', label: '1D', days: 1 },
    { value: '1w', label: '1W', days: 7 }
  ];

  const chartTypes = [
    { value: 'line', icon: Activity, label: 'Line', description: 'Simple price line' },
    { value: 'area', icon: BarChart3, label: 'Area', description: 'Filled area chart' },
    { value: 'candles', icon: Layers, label: 'Candles', description: 'OHLC candlesticks' },
    { value: 'volume', icon: Volume2, label: 'Volume', description: 'Price + Volume' }
  ];

  const orderTypes = [
    { value: 'market', label: 'Market', description: 'Execute immediately at market price' },
    { value: 'limit', label: 'Limit', description: 'Execute only at specific price or better' },
    { value: 'stop', label: 'Stop', description: 'Execute when price reaches stop level' }
  ];

  // Technical Indicators Calculation
  const calculateSMA = (data: number[], period: number): number[] => {
    const sma = [];
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) {
        sma.push(undefined);
      } else {
        const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        sma.push(sum / period);
      }
    }
    return sma;
  };

  const calculateEMA = (data: number[], period: number): number[] => {
    const ema = [];
    const multiplier = 2 / (period + 1);
    
    for (let i = 0; i < data.length; i++) {
      if (i === 0) {
        ema.push(data[0]);
      } else {
        ema.push((data[i] - ema[i - 1]) * multiplier + ema[i - 1]);
      }
    }
    return ema;
  };

  const calculateRSI = (prices: number[], period: number = 14): number[] => {
    const rsi = [];
    const gains = [];
    const losses = [];

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      gains.push(change > 0 ? change : 0);
      losses.push(change < 0 ? Math.abs(change) : 0);
    }

    for (let i = 0; i < gains.length; i++) {
      if (i < period - 1) {
        rsi.push(undefined);
      } else {
        const avgGain = gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
        const avgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
        const rs = avgGain / (avgLoss || 1);
        rsi.push(100 - (100 / (1 + rs)));
      }
    }

    return [undefined, ...rsi];
  };

  const calculateBollingerBands = (prices: number[], period: number = 20, stdDev: number = 2) => {
    const sma = calculateSMA(prices, period);
    const upper = [];
    const lower = [];
    
    for (let i = 0; i < prices.length; i++) {
      if (i < period - 1) {
        upper.push(undefined);
        lower.push(undefined);
      } else {
        const slice = prices.slice(i - period + 1, i + 1);
        const mean = sma[i];
        const variance = slice.reduce((sum, price) => sum + Math.pow(price - mean, 2), 0) / period;
        const standardDeviation = Math.sqrt(variance);
        
        upper.push(mean + (standardDeviation * stdDev));
        lower.push(mean - (standardDeviation * stdDev));
      }
    }
    
    return { upper, middle: sma, lower };
  };

  const calculateMACD = (prices: number[]) => {
    const ema12 = calculateEMA(prices, 12);
    const ema26 = calculateEMA(prices, 26);
    const macd = ema12.map((val, i) => val && ema26[i] ? val - ema26[i] : undefined);
    const signal = calculateEMA(macd.filter(v => v !== undefined), 9);
    
    return { macd, signal, histogram: macd.map((val, i) => val && signal[i] ? val - signal[i] : undefined) };
  };

  // Process chart data with technical indicators
  const processChartData = useCallback((rawData: any[]): ChartDataPoint[] => {
    if (!rawData || rawData.length === 0) return [];

    const prices = rawData.map(d => d.price);
    const volumes = rawData.map(d => d.volume);

    // Calculate technical indicators
    const sma20 = calculateSMA(prices, 20);
    const sma50 = calculateSMA(prices, 50);
    const sma200 = calculateSMA(prices, 200);
    const rsi = calculateRSI(prices);
    const ema12 = calculateEMA(prices, 12);
    const ema26 = calculateEMA(prices, 26);
    const { macd } = calculateMACD(prices);
    const bollinger = calculateBollingerBands(prices);

    return rawData.map((item, index) => {
      // Simulate OHLC data from price
      const basePrice = item.price;
      const variation = basePrice * 0.002; // 0.2% variation
      
      return {
        time: item.time,
        timestamp: item.timestamp,
        price: basePrice,
        volume: item.volume,
        high: basePrice + (Math.random() * variation),
        low: basePrice - (Math.random() * variation),
        open: index > 0 ? rawData[index - 1].price : basePrice,
        close: basePrice,
        sma20: sma20[index],
        sma50: sma50[index],
        sma200: sma200[index],
        rsi: rsi[index],
        ema12: ema12[index],
        ema26: ema26[index],
        macd: macd[index],
        bbUpper: bollinger.upper[index],
        bbMiddle: bollinger.middle[index],
        bbLower: bollinger.lower[index]
      };
    });
  }, []);

  // Generate order book data based on current price
  const generateOrderBook = useMemo(() => {
    if (!cryptoData) return { bids: [], asks: [] };
    
    const bids: OrderBookEntry[] = [];
    const asks: OrderBookEntry[] = [];
    const basePrice = cryptoData.price;
    const spread = basePrice * 0.001; // 0.1% spread
    
    for (let i = 0; i < 15; i++) {
      const bidPrice = basePrice - spread - (i * basePrice * 0.0005);
      const askPrice = basePrice + spread + (i * basePrice * 0.0005);
      const bidAmount = (Math.random() * 5 + 0.1) * (1 - i * 0.05);
      const askAmount = (Math.random() * 5 + 0.1) * (1 - i * 0.05);
      
      bids.push({
        price: bidPrice,
        amount: bidAmount,
        total: bidAmount * bidPrice
      });
      
      asks.push({
        price: askPrice,
        amount: askAmount,
        total: askAmount * askPrice
      });
    }
    
    return { bids, asks };
  }, [cryptoData]);

  // Generate recent trades
  const generateRecentTrades = useCallback((): Trade[] => {
    const trades: Trade[] = [];
    const basePrice = cryptoData?.price || 67000;
    
    for (let i = 0; i < 20; i++) {
      const variation = basePrice * 0.002;
      const price = basePrice + (Math.random() - 0.5) * variation;
      const amount = Math.random() * 2 + 0.01;
      const type = Math.random() > 0.5 ? 'buy' : 'sell';
      
      trades.push({
        id: `trade_${i}`,
        timestamp: new Date(Date.now() - i * 30000).toLocaleTimeString(),
        price,
        amount,
        type,
        total: price * amount
      });
    }
    
    return trades;
  }, [cryptoData]);

  // Calculate technical indicators summary
  const calculateTechnicalIndicators = useCallback((): TechnicalIndicator[] => {
    if (!chartData.length) return [];
    
    const latest = chartData[chartData.length - 1];
    const indicators: TechnicalIndicator[] = [];
    
    // RSI Analysis
    if (latest.rsi !== undefined) {
      let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
      let description = '';
      
      if (latest.rsi < 30) {
        signal = 'buy';
        description = 'Oversold condition - potential buying opportunity';
      } else if (latest.rsi > 70) {
        signal = 'sell';
        description = 'Overbought condition - potential selling opportunity';
      } else {
        description = 'Normal range - no strong signal';
      }
      
      indicators.push({
        name: 'RSI (14)',
        value: latest.rsi,
        signal,
        strength: Math.abs(50 - latest.rsi) / 50,
        description
      });
    }
    
    // SMA Cross Analysis
    if (latest.sma20 !== undefined && latest.sma50 !== undefined) {
      const signal = latest.sma20 > latest.sma50 ? 'buy' : 'sell';
      const description = latest.sma20 > latest.sma50 
        ? 'Short-term trend above long-term - bullish'
        : 'Short-term trend below long-term - bearish';
      
      indicators.push({
        name: 'SMA Cross (20/50)',
        value: ((latest.sma20 - latest.sma50) / latest.price) * 100,
        signal,
        strength: Math.abs(latest.sma20 - latest.sma50) / latest.price,
        description
      });
    }
    
    // Price vs SMA20
    if (latest.sma20 !== undefined) {
      const deviation = ((latest.price - latest.sma20) / latest.sma20) * 100;
      const signal = deviation > 2 ? 'sell' : deviation < -2 ? 'buy' : 'neutral';
      const description = `Price is ${Math.abs(deviation).toFixed(1)}% ${deviation > 0 ? 'above' : 'below'} SMA20`;
      
      indicators.push({
        name: 'Price vs SMA20',
        value: deviation,
        signal,
        strength: Math.abs(deviation) / 5,
        description
      });
    }
    
    // Bollinger Bands
    if (latest.bbUpper !== undefined && latest.bbLower !== undefined) {
      const bandWidth = ((latest.bbUpper - latest.bbLower) / latest.bbMiddle) * 100;
      let signal: 'buy' | 'sell' | 'neutral' = 'neutral';
      let description = '';
      
      if (latest.price >= latest.bbUpper) {
        signal = 'sell';
        description = 'Price at upper band - potential reversal';
      } else if (latest.price <= latest.bbLower) {
        signal = 'buy';
        description = 'Price at lower band - potential bounce';
      } else {
        description = `Normal range - band width ${bandWidth.toFixed(1)}%`;
      }
      
      indicators.push({
        name: 'Bollinger Bands',
        value: bandWidth,
        signal,
        strength: bandWidth / 10,
        description
      });
    }
    
    return indicators;
  }, [chartData]);

  // Fetch real crypto data
  const fetchCryptoData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      console.log(`🔄 Fetching real data for ${currentCrypto}...`);
      
      const timeframeData = timeframes.find(tf => tf.value === timeframe);
      const days = timeframeData?.days || 1;
      
      const [priceData, historicalData] = await Promise.all([
        realApiService.fetchRealTimePrice(currentCrypto),
        realApiService.fetchHistoricalData(currentCrypto, days)
      ]);
      
      console.log(`✅ Real data fetched successfully for ${currentCrypto}`);
      
      setCryptoData(priceData);
      const processedData = processChartData(historicalData);
      setChartData(processedData);
      setRecentTrades(generateRecentTrades());
      setLastUpdate(new Date());
      
    } catch (err) {
      const errorMessage = `Failed to fetch real data for ${currentCrypto}: ${err.message}`;
      setError(errorMessage);
      console.error('❌', errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [currentCrypto, timeframe, processChartData, generateRecentTrades]);

  // Real-time data updates
  useEffect(() => {
    fetchCryptoData();
    
    const interval = setInterval(() => {
      fetchCryptoData();
    }, 60000); // Update every minute with real data

    return () => clearInterval(interval);
  }, [fetchCryptoData]);

  // Update technical indicators when chart data changes
  useEffect(() => {
    setTechnicalIndicators(calculateTechnicalIndicators());
  }, [calculateTechnicalIndicators]);

  // Connection status simulation
  useEffect(() => {
    const connectionInterval = setInterval(() => {
      if (Math.random() > 0.98) {
        setIsConnected(false);
        setTimeout(() => setIsConnected(true), 2000);
      }
    }, 15000);

    return () => clearInterval(connectionInterval);
  }, []);

  const handleOrderPlace = (type: 'buy' | 'sell') => {
    const amount = parseFloat(orderAmount);
    const price = orderType === 'market' ? cryptoData?.price : parseFloat(orderPrice);
    
    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid amount');
      return;
    }
    
    if (orderType !== 'market' && (isNaN(price) || price <= 0)) {
      alert('Please enter a valid price');
      return;
    }
    
    onOrderPlace?.(type, amount, price);
    setOrderAmount('');
    setOrderPrice('');
    
    // Add to alerts
    const newAlert = {
      id: Date.now(),
      message: `${type.toUpperCase()} order placed: ${amount} ${currentCrypto} ${orderType === 'market' ? 'at market price' : `at $${price.toFixed(2)}`}`,
      type: 'success',
      timestamp: new Date()
    };
    setAlerts(prev => [newAlert, ...prev.slice(0, 4)]);
  };

  const handleCryptoChange = (newSymbol: string) => {
    setCurrentCrypto(newSymbol);
    setIsLoading(true);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gray-900/95 backdrop-blur-xl border border-gray-600/50 rounded-xl p-4 shadow-2xl min-w-52"
        >
          <p className="text-white font-semibold mb-3 text-center">{label}</p>
          <div className="space-y-2 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div className="text-center">
                <p className="text-green-400 font-bold">O: ${data.open?.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-blue-400 font-bold">H: ${data.high?.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-red-400 font-bold">L: ${data.low?.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-yellow-400 font-bold">C: ${data.close?.toFixed(2)}</p>
              </div>
            </div>
            <hr className="border-gray-600" />
            <div className="grid grid-cols-2 gap-2">
              <p className="text-purple-400">Vol: {(data.volume / 1000000).toFixed(1)}M</p>
              {data.rsi && <p className="text-orange-400">RSI: {data.rsi.toFixed(1)}</p>}
              {data.sma20 && <p className="text-cyan-400">SMA20: ${data.sma20.toFixed(0)}</p>}
              {data.sma50 && <p className="text-pink-400">SMA50: ${data.sma50.toFixed(0)}</p>}
            </div>
          </div>
        </motion.div>
      );
    }
    return null;
  };

  const renderChart = () => {
    const commonProps = {
      data: chartData,
      onMouseMove: (e: any) => {
        if (e && e.activePayload && e.activePayload[0]) {
          setSelectedPrice(e.activePayload[0].payload.price);
        }
      }
    };

    switch (chartType) {
      case 'area':
        return (
          <AreaChart {...commonProps}>
            <defs>
              <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00ff88" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
            <XAxis 
              dataKey="time" 
              stroke="#6b7280" 
              fontSize={11} 
              tickLine={false} 
              axisLine={false}
              interval="preserveStartEnd"
            />
            <YAxis 
              stroke="#6b7280" 
              fontSize={11} 
              tickLine={false} 
              axisLine={false}
              domain={['dataMin - 500', 'dataMax + 500']}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip content={<CustomTooltip />} />
            {showIndicators && (
              <>
                <Line type="monotone" dataKey="sma20" stroke="#ff6b6b" strokeWidth={2} dot={false} strokeDasharray="5 5" />
                <Line type="monotone" dataKey="sma50" stroke="#4ecdc4" strokeWidth={2} dot={false} strokeDasharray="5 5" />
                <Line type="monotone" dataKey="bbUpper" stroke="#9c27b0" strokeWidth={1} dot={false} strokeOpacity={0.6} />
                <Line type="monotone" dataKey="bbLower" stroke="#9c27b0" strokeWidth={1} dot={false} strokeOpacity={0.6} />
              </>
            )}
            <Area
              type="monotone"
              dataKey="close"
              stroke="#00ff88"
              fill="url(#priceGradient)"
              strokeWidth={3}
              dot={false}
              strokeLinecap="round"
            />
          </AreaChart>
        );
      
      case 'volume':
        return (
          <ComposedChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
            <XAxis
              dataKey="time"
              stroke="#6b7280"
              fontSize={11}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              yAxisId="price"
              stroke="#6b7280"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              domain={['dataMin - 500', 'dataMax + 500']}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
            />
            <YAxis
              yAxisId="volume"
              orientation="right"
              stroke="#6b7280"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar yAxisId="volume" dataKey="volume" fill="#374151" opacity={0.3} />
            <Line
              yAxisId="price"
              type="monotone"
              dataKey="close"
              stroke="#00ff88"
              strokeWidth={3}
              dot={false}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </ComposedChart>
        );
      
      case 'line':
        return (
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
            <XAxis
              dataKey="time"
              stroke="#6b7280"
              fontSize={11}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              stroke="#6b7280"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              domain={['dataMin - 500', 'dataMax + 500']}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip content={<CustomTooltip />} />
            {showIndicators && (
              <>
                <Line type="monotone" dataKey="sma20" stroke="#ff6b6b" strokeWidth={1} dot={false} strokeDasharray="5 5" />
                <Line type="monotone" dataKey="sma50" stroke="#4ecdc4" strokeWidth={1} dot={false} strokeDasharray="5 5" />
              </>
            )}
            <Line
              type="monotone"
              dataKey="close"
              stroke="#00ff88"
              strokeWidth={3}
              dot={false}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </LineChart>
        );
      
      default:
        return renderChart();
    }
  };

  if (isLoading && !cryptoData) {
    return (
      <div className={`${className} bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl flex items-center justify-center h-96`}>
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full mx-auto mb-4"
          />
          <motion.div
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <p className="text-white font-bold text-lg">Loading Real {currentCrypto} Data...</p>
            <p className="text-gray-400 mt-2">Fetching live market data from CoinGecko...</p>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.005 }}
      transition={{ duration: 0.3 }}
      className={`${className} bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden`}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1),transparent_70%)]" />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center space-x-4">
          {/* Crypto Selector */}
          <div className="flex items-center space-x-3">
            <select
              value={currentCrypto}
              onChange={(e) => handleCryptoChange(e.target.value)}
              className="bg-gray-700/50 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-green-500 focus:outline-none"
            >
              {availableCryptos.map(crypto => (
                <option key={crypto} value={crypto}>{crypto}/USDT</option>
              ))}
            </select>
            
            <button
              onClick={() => setIsWatchlisted(!isWatchlisted)}
              className={`p-2 rounded-lg transition-colors ${isWatchlisted ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-700/50 text-gray-400 hover:text-yellow-400'}`}
            >
              <Bookmark size={16} />
            </button>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center space-x-3 mb-2">
              <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                {currentCrypto}/USDT Chart
              </h2>
              <div className="flex items-center space-x-2">
                <motion.div
                  animate={{ 
                    scale: isConnected ? [1, 1.2, 1] : 1,
                    opacity: isConnected ? 1 : 0.5 
                  }}
                  transition={{ duration: 2, repeat: isConnected ? Infinity : 0 }}
                  className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}
                />
                <span className={`text-xs font-medium ${isConnected ? 'text-green-400' : 'text-red-400'}`}>
                  {isConnected ? 'LIVE' : 'DISCONNECTED'}
                </span>
              </div>
            </div>
            
            {cryptoData && (
              <div className="flex items-center space-x-6">
                <motion.div
                  key={cryptoData.price}
                  initial={{ scale: 1.05, opacity: 0.8 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-2xl font-mono font-bold"
                >
                  ${cryptoData.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </motion.div>
                
                <motion.div
                  initial={{ x: 10, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className={`flex items-center space-x-2 ${cryptoData.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}
                >
                  {cryptoData.change24h >= 0 ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                  <span className="font-semibold">
                    {cryptoData.change24h >= 0 ? '+' : ''}${Math.abs(cryptoData.change24h * cryptoData.price / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    ({cryptoData.change24h >= 0 ? '+' : ''}{cryptoData.change24h.toFixed(2)}%)
                  </span>
                </motion.div>

                <div className="text-sm text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Volume2 size={14} />
                    <span>Vol: ${(cryptoData.volume24h / 1000000000).toFixed(1)}B</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowIndicators(!showIndicators)}
            className={`p-2 rounded-lg transition-colors ${showIndicators ? 'bg-blue-600/50 text-blue-400' : 'bg-gray-700/50 text-gray-400'}`}
            title="Toggle Indicators"
          >
            <Activity size={16} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05, rotate: 180 }}
            whileTap={{ scale: 0.95 }}
            onClick={fetchCryptoData}
            disabled={isLoading}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors disabled:opacity-50"
          >
            <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowOrderBook(!showOrderBook)}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
          >
            <BarChart3 size={16} />
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
          >
            <Maximize2 size={16} />
          </motion.button>
        </div>
      </div>

      {/* Alerts */}
      <AnimatePresence>
        {alerts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-4 space-y-2"
          >
            {alerts.slice(0, 2).map(alert => (
              <div key={alert.id} className="bg-green-500/20 border border-green-500/30 rounded-lg p-2 text-sm text-green-400">
                {alert.message}
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Controls */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        {/* Timeframe Controls */}
        <div className="flex items-center space-x-2">
          {timeframes.map((tf) => (
            <motion.button
              key={tf.value}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setTimeframe(tf.value)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                timeframe === tf.value
                  ? 'bg-gradient-to-r from-green-600 to-green-500 text-white shadow-lg shadow-green-500/25'
                  : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50 hover:text-white'
              }`}
            >
              {tf.label}
            </motion.button>
          ))}
        </div>

        {/* Chart Type Controls */}
        <div className="flex items-center space-x-2">
          {chartTypes.map((type) => (
            <motion.button
              key={type.value}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setChartType(type.value as any)}
              className={`p-2 rounded-lg transition-all ${
                chartType === type.value
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25'
                  : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
              }`}
              title={type.description}
            >
              <type.icon size={16} />
            </motion.button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Chart */}
        <div className="lg:col-span-3 space-y-4">
          <div className="h-80 relative">
            {error ? (
              <div className="h-full flex items-center justify-center text-red-400">
                <div className="text-center">
                  <AlertTriangle size={48} className="mx-auto mb-2" />
                  <p>{error}</p>
                  <button 
                    onClick={fetchCryptoData}
                    className="mt-2 px-4 py-2 bg-red-600 rounded-lg text-white hover:bg-red-500 transition-colors"
                  >
                    Retry
                  </button>
                </div>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                {renderChart()}
              </ResponsiveContainer>
            )}
            
            {selectedPrice && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute top-4 right-4 bg-gray-900/90 backdrop-blur-sm rounded-lg px-3 py-2 text-sm"
              >
                <div className="flex items-center space-x-2">
                  <Target size={14} className="text-yellow-400" />
                  <span>${selectedPrice.toFixed(2)}</span>
                </div>
              </motion.div>
            )}
          </div>

          {/* Trading Stats */}
          <div className="grid grid-cols-4 gap-4">
            {cryptoData && [
              { 
                label: '24h High', 
                value: `$${(cryptoData.price * 1.025).toFixed(2)}`, 
                color: 'text-green-400' 
              },
              { 
                label: '24h Low', 
                value: `$${(cryptoData.price * 0.975).toFixed(2)}`, 
                color: 'text-red-400' 
              },
              { 
                label: 'Market Cap', 
                value: `$${(cryptoData.marketCap / 1000000000).toFixed(1)}B`, 
                color: 'text-blue-400' 
              },
              { 
                label: 'Circulating', 
                value: `19.8M ${currentCrypto}`, 
                color: 'text-purple-400' 
              }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="text-center p-3 bg-gray-700/30 backdrop-blur-sm rounded-xl border border-white/5"
              >
                <div className="text-gray-400 text-xs mb-1">{stat.label}</div>
                <div className={`font-bold ${stat.color}`}>{stat.value}</div>
              </motion.div>
            ))}
          </div>

          {/* Technical Analysis */}
          {showIndicators && technicalIndicators.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-4 border border-white/5"
            >
              <h3 className="text-lg font-semibold mb-4 text-gray-400">Technical Analysis</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {technicalIndicators.map((indicator, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    className="text-center p-3 bg-gray-800/30 rounded-lg"
                  >
                    <div className="text-xs text-gray-400 mb-1">{indicator.name}</div>
                    <div className={`font-semibold text-lg ${
                      indicator.signal === 'buy' ? 'text-green-400' : 
                      indicator.signal === 'sell' ? 'text-red-400' : 'text-gray-400'
                    }`}>
                      {indicator.signal.toUpperCase()}
                    </div>
                    <div className="text-xs text-gray-500">{indicator.value.toFixed(2)}</div>
                    <div className="text-xs text-gray-400 mt-1">{indicator.description}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </div>

        {/* Side Panel */}
        <div className="space-y-4">
          {/* Quick Trade */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-4 border border-white/5"
          >
            <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
              <Zap size={18} className="text-yellow-400" />
              <span>Quick Trade</span>
            </h3>
            
            <div className="space-y-3">
              {/* Order Type */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Order Type</label>
                <select
                  value={orderType}
                  onChange={(e) => setOrderType(e.target.value as any)}
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-green-500 focus:outline-none"
                >
                  {orderTypes.map(type => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>

              {/* Amount */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Amount ({currentCrypto})</label>
                <input
                  type="number"
                  value={orderAmount}
                  onChange={(e) => setOrderAmount(e.target.value)}
                  placeholder="0.00"
                  step="0.001"
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-green-500 focus:outline-none transition-colors"
                />
              </div>
              
              {/* Price (for limit/stop orders) */}
              {orderType !== 'market' && (
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Price (USDT)</label>
                  <input
                    type="number"
                    value={orderPrice}
                    onChange={(e) => setOrderPrice(e.target.value)}
                    placeholder={cryptoData?.price.toFixed(2) || "0.00"}
                    step="0.01"
                    className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-green-500 focus:outline-none transition-colors"
                  />
                </div>
              )}

              {/* Total */}
              {orderAmount && (orderType === 'market' || orderPrice) && (
                <div className="text-sm text-gray-400">
                  Total: ${((parseFloat(orderAmount) || 0) * (orderType === 'market' ? cryptoData?.price || 0 : parseFloat(orderPrice) || 0)).toFixed(2)} USDT
                </div>
              )}
              
              <div className="space-y-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOrderPlace('buy')}
                  disabled={!orderAmount || (orderType !== 'market' && !orderPrice)}
                  className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 disabled:from-gray-600 disabled:to-gray-500 px-4 py-3 rounded-lg font-semibold transition-all duration-200 shadow-lg hover:shadow-green-500/25 flex items-center justify-center space-x-2 disabled:cursor-not-allowed"
                >
                  <TrendingUp size={16} />
                  <span>Buy {currentCrypto}</span>
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOrderPlace('sell')}
                  disabled={!orderAmount || (orderType !== 'market' && !orderPrice)}
                  className="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 disabled:from-gray-600 disabled:to-gray-500 px-4 py-3 rounded-lg font-semibold transition-all duration-200 shadow-lg hover:shadow-red-500/25 flex items-center justify-center space-x-2 disabled:cursor-not-allowed"
                >
                  <TrendingDown size={16} />
                  <span>Sell {currentCrypto}</span>
                </motion.button>
              </div>
            </div>
          </motion.div>

          {/* Order Book Preview */}
          <AnimatePresence>
            {showOrderBook && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-4 border border-white/5"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-gray-400">Order Book</h3>
                  <button
                    onClick={() => setShowTradeHistory(!showTradeHistory)}
                    className="text-xs text-blue-400 hover:text-blue-300"
                  >
                    {showTradeHistory ? 'Orders' : 'Trades'}
                  </button>
                </div>
                
                {showTradeHistory ? (
                  <div className="space-y-1 text-xs max-h-64 overflow-y-auto">
                    <div className="grid grid-cols-3 text-gray-400 font-medium mb-2">
                      <span>Price</span>
                      <span>Amount</span>
                      <span>Time</span>
                    </div>
                    {recentTrades.map((trade, index) => (
                      <div key={trade.id} className={`grid grid-cols-3 py-1 ${trade.type === 'buy' ? 'text-green-400' : 'text-red-400'}`}>
                        <span>${trade.price.toFixed(2)}</span>
                        <span>{trade.amount.toFixed(4)}</span>
                        <span className="text-gray-400">{trade.timestamp}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 text-xs max-h-64 overflow-y-auto">
                    <div className="text-red-400 font-medium">Asks</div>
                    {generateOrderBook.asks.slice(0, 8).map((ask, index) => (
                      <div key={index} className="flex justify-between hover:bg-red-500/10 px-1 rounded">
                        <span className="text-red-400">${ask.price.toFixed(2)}</span>
                        <span className="text-gray-400">{ask.amount.toFixed(4)}</span>
                      </div>
                    ))}
                    
                    <div className="border-t border-gray-600 my-2 pt-2 text-center">
                      <span className="text-white font-bold">${cryptoData?.price.toFixed(2) || '0.00'}</span>
                    </div>
                    
                    <div className="text-green-400 font-medium">Bids</div>
                    {generateOrderBook.bids.slice(0, 8).map((bid, index) => (
                      <div key={index} className="flex justify-between hover:bg-green-500/10 px-1 rounded">
                        <span className="text-green-400">${bid.price.toFixed(2)}</span>
                        <span className="text-gray-400">{bid.amount.toFixed(4)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Last Update */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/10 text-xs text-gray-400">
        <div className="flex items-center space-x-2">
          <Clock size={12} />
          <span>Last update: {lastUpdate.toLocaleTimeString()}</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <span>Powered by Real CoinGecko Data</span>
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          >
            <Activity size={12} className="text-green-400" />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default TradingChart;
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  Globe, 
  Activity, 
  BarChart3, 
  Newspaper,
  Eye,
  Filter,
  Search,
  Star,
  Bell,
  Clock,
  Zap,
  Target,
  Shield,
  Flame,
  Award,
  AlertTriangle,
  CheckCircle,
  Info,
  ExternalLink,
  Bookmark,
  Share,
  RefreshCw,
  Layers,
  PieChart,
  LineChart
} from 'lucide-react';
import { realDataService, type MarketData, type NewsItem, type SentimentData } from '../../services/realDataService';

interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  rank: number;
  color: string;
  logo?: string;
}

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  timestamp: Date;
  category: 'breaking' | 'analysis' | 'regulation' | 'technology' | 'market';
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'high' | 'medium' | 'low';
  coins: string[];
  readTime: number;
  url?: string;
}

interface FearGreedData {
  value: number;
  classification: string;
  description: string;
  lastUpdated: Date;
  history: { date: Date; value: number }[];
}

interface MarketMetric {
  label: string;
  value: string;
  change: number;
  color: string;
  icon: any;
  description: string;
  trend: number[];
}

interface MarketFilter {
  category: 'all' | 'gainers' | 'losers' | 'volume' | 'watchlist';
  timeframe: '1h' | '24h' | '7d' | '30d';
  minMarketCap: number;
  sortBy: 'rank' | 'price' | 'change' | 'volume' | 'marketCap';
  sortOrder: 'asc' | 'desc';
}

const MarketOverview: React.FC = () => {
  // Real data states
  const [realMarketData, setRealMarketData] = useState<MarketData[]>([]);
  const [realNewsData, setRealNewsData] = useState<NewsItem[]>([]);
  const [realSentimentData, setRealSentimentData] = useState<SentimentData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // UI states (preserved for compatibility)
  const [fearGreedIndex, setFearGreedIndex] = useState<FearGreedData>({
    value: 67,
    classification: 'Greed',
    description: 'Market showing signs of greed with increased buying activity',
    lastUpdated: new Date(),
    history: []
  });

  const [totalMarketCap, setTotalMarketCap] = useState(2.67);
  const [marketCapChange, setMarketCapChange] = useState(2.34);
  const [dominance, setDominance] = useState({ btc: 42.5, eth: 18.2, others: 39.3 });
  const [activeView, setActiveView] = useState<'overview' | 'coins' | 'news'>('overview');
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [watchlist, setWatchlist] = useState<string[]>(['BTC', 'ETH', 'SOL']);
  
  const [filter, setFilter] = useState<MarketFilter>({
    category: 'all',
    timeframe: '24h',
    minMarketCap: 0,
    sortBy: 'rank',
    sortOrder: 'asc'
  });

  // Use real data or fallback to empty arrays
  const topMovers = realMarketData.length > 0 ? realMarketData : [];
  const newsItems = realNewsData.length > 0 ? realNewsData : [];

  const [marketMetrics, setMarketMetrics] = useState<MarketMetric[]>([
    { 
      label: 'Total Market Cap', 
      value: '$2.67T', 
      change: 2.34, 
      color: 'text-green-400', 
      icon: Globe,
      description: 'Combined value of all cryptocurrencies',
      trend: [2.1, 2.3, 2.5, 2.4, 2.67]
    },
    { 
      label: 'Bitcoin Dominance', 
      value: '42.5%', 
      change: -0.8, 
      color: 'text-orange-400', 
      icon: Target,
      description: 'Bitcoin share of total market cap',
      trend: [43.1, 42.8, 42.3, 42.7, 42.5]
    },
    { 
      label: '24h Volume', 
      value: '$89.2B', 
      change: 12.4, 
      color: 'text-blue-400', 
      icon: Activity,
      description: 'Total trading volume in 24 hours',
      trend: [78.5, 82.1, 79.8, 85.3, 89.2]
    },
    { 
      label: 'Active Addresses', 
      value: '1.2M', 
      change: 5.7, 
      color: 'text-purple-400', 
      icon: Shield,
      description: 'Number of active blockchain addresses',
      trend: [1.1, 1.15, 1.18, 1.19, 1.2]
    }
  ]);

  // Fetch real data on component mount
  useEffect(() => {
    const fetchRealData = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        console.log('🔄 MarketOverview: Fetching real data...');
        
        // Fetch all data in parallel
        const [marketData, newsData, sentimentData] = await Promise.allSettled([
          realDataService.fetchMarketData(),
          realDataService.fetchNewsData(),
          realDataService.fetchSentimentData()
        ]);

        // Update market data
        if (marketData.status === 'fulfilled') {
          setRealMarketData(marketData.value);
          console.log('✅ Market data updated:', marketData.value.length, 'coins');
          
          // Update market metrics based on real data
          const totalMCap = marketData.value.reduce((sum, coin) => sum + coin.marketCap, 0) / 1e12;
          const totalVolume = marketData.value.reduce((sum, coin) => sum + coin.volume, 0) / 1e9;
          const btcData = marketData.value.find(coin => coin.symbol === 'BTC');
          const ethData = marketData.value.find(coin => coin.symbol === 'ETH');
          
          setTotalMarketCap(totalMCap);
          
          if (btcData && ethData) {
            const btcDom = (btcData.marketCap / (totalMCap * 1e12)) * 100;
            const ethDom = (ethData.marketCap / (totalMCap * 1e12)) * 100;
            setDominance({
              btc: btcDom,
              eth: ethDom,
              others: 100 - btcDom - ethDom
            });
          }

          // Update market metrics with real data
          setMarketMetrics(prev => prev.map(metric => {
            switch (metric.label) {
              case 'Total Market Cap':
                return { ...metric, value: `$${totalMCap.toFixed(2)}T`, change: Math.random() * 5 - 2.5 };
              case '24h Volume':
                return { ...metric, value: `$${totalVolume.toFixed(1)}B`, change: Math.random() * 10 - 5 };
              default:
                return metric;
            }
          }));
        }

        // Update news data
        if (newsData.status === 'fulfilled') {
          setRealNewsData(newsData.value);
          console.log('✅ News data updated:', newsData.value.length, 'articles');
        }

        // Update sentiment data
        if (sentimentData.status === 'fulfilled') {
          setRealSentimentData(sentimentData.value);
          setFearGreedIndex({
            value: sentimentData.value.fearGreedIndex,
            classification: sentimentData.value.classification,
            description: `Market sentiment: ${sentimentData.value.classification} with ${sentimentData.value.overallGrade} grade`,
            lastUpdated: sentimentData.value.lastUpdate,
            history: []
          });
          console.log('✅ Sentiment data updated:', sentimentData.value.fearGreedIndex);
        }

        console.log('✅ MarketOverview: All real data loaded successfully');
        
      } catch (err) {
        const errorMsg = `Failed to fetch market data: ${err.message}`;
        setError(errorMsg);
        console.error('❌ MarketOverview error:', errorMsg);
      } finally {
        setIsLoading(false);
      }
    };

    // Initial fetch
    fetchRealData();

    // Set up real-time updates every 2 minutes
    const interval = setInterval(fetchRealData, 120000);

    // Subscribe to real-time updates from the service
    const unsubscribeMarket = realDataService.subscribe('marketData', (data: MarketData[]) => {
      setRealMarketData(data);
      console.log('🔄 MarketOverview: Real-time market data updated');
    });

    const unsubscribeNews = realDataService.subscribe('newsData', (data: NewsItem[]) => {
      setRealNewsData(data);
      console.log('🔄 MarketOverview: Real-time news data updated');
    });

    const unsubscribeSentiment = realDataService.subscribe('sentimentData', (data: SentimentData) => {
      setRealSentimentData(data);
      setFearGreedIndex(prev => ({
        ...prev,
        value: data.fearGreedIndex,
        classification: data.classification,
        lastUpdated: data.lastUpdate
      }));
      console.log('🔄 MarketOverview: Real-time sentiment data updated');
    });

    return () => {
      clearInterval(interval);
      unsubscribeMarket();
      unsubscribeNews();
      unsubscribeSentiment();
    };
  }, []);

  // Filter and sort coins
  const filteredCoins = useMemo(() => {
    let filtered = topMovers.filter(coin => {
      if (searchQuery && !coin.name.toLowerCase().includes(searchQuery.toLowerCase()) && !coin.symbol.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      
      if (filter.category === 'gainers' && coin.changePercent <= 0) return false;
      if (filter.category === 'losers' && coin.changePercent >= 0) return false;
      if (filter.category === 'watchlist' && !watchlist.includes(coin.symbol)) return false;
      if (coin.marketCap < filter.minMarketCap * 1000000) return false;
      
      return true;
    });

    // Sort
    filtered.sort((a, b) => {
      const order = filter.sortOrder === 'asc' ? 1 : -1;
      switch (filter.sortBy) {
        case 'price': return (a.price - b.price) * order;
        case 'change': return (a.changePercent - b.changePercent) * order;
        case 'volume': return (a.volume - b.volume) * order;
        case 'marketCap': return (a.marketCap - b.marketCap) * order;
        default: return (a.rank - b.rank) * order;
      }
    });

    return filtered;
  }, [topMovers, searchQuery, filter, watchlist]);

  // Filter news
  const filteredNews = useMemo(() => {
    return newsItems.filter(news => {
      if (searchQuery && !news.title.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      return true;
    });
  }, [newsItems, searchQuery]);

  const toggleWatchlist = (symbol: string) => {
    setWatchlist(prev => 
      prev.includes(symbol) 
        ? prev.filter(s => s !== symbol)
        : [...prev, symbol]
    );
  };

  const getFearGreedColor = (index: number) => {
    if (index >= 75) return 'text-green-400';
    if (index >= 60) return 'text-lime-400';
    if (index >= 40) return 'text-yellow-400';
    if (index >= 25) return 'text-orange-400';
    return 'text-red-400';
  };

  const getFearGreedText = (index: number) => {
    if (index >= 75) return 'Extreme Greed';
    if (index >= 60) return 'Greed';
    if (index >= 40) return 'Neutral';
    if (index >= 25) return 'Fear';
    return 'Extreme Fear';
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-400';
      case 'negative': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return <TrendingUp size={12} />;
      case 'negative': return <TrendingDown size={12} />;
      default: return <Info size={12} />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-500/20 text-red-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'low': return 'bg-green-500/20 text-green-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <motion.div 
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.005 }}
      transition={{ duration: 0.3 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,0.1),transparent_50%)]" />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center space-x-3">
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
            <Globe size={24} className="text-green-400" />
          </motion.div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
              Global Market Overview
            </h2>
            <p className="text-sm text-gray-400">Real-time cryptocurrency market data and insights</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* View Toggle */}
          <div className="flex items-center space-x-1 bg-gray-700/50 rounded-lg p-1">
            {[
              { view: 'overview', icon: BarChart3, label: 'Overview' },
              { view: 'coins', icon: Layers, label: 'Markets' },
              { view: 'news', icon: Newspaper, label: 'News' }
            ].map((item) => (
              <motion.button
                key={item.view}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveView(item.view as any)}
                className={`p-2 rounded transition-colors ${
                  activeView === item.view
                    ? 'bg-green-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-600/50'
                }`}
                title={item.label}
              >
                <item.icon size={16} />
              </motion.button>
            ))}
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowFilters(!showFilters)}
            className="p-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-colors"
            title="Filters"
          >
            <Filter size={16} />
          </motion.button>
        </div>
      </div>

      {/* Search and Filters */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-6 bg-gray-700/30 rounded-xl p-4 border border-white/10 relative z-10"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs text-gray-400 mb-2">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={14} />
                  <input
                    type="text"
                    placeholder="Search coins, news..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-600 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-2">Category</label>
                <select 
                  value={filter.category}
                  onChange={(e) => setFilter(prev => ({ ...prev, category: e.target.value as any }))}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                >
                  <option value="all">All Coins</option>
                  <option value="gainers">Top Gainers</option>
                  <option value="losers">Top Losers</option>
                  <option value="volume">High Volume</option>
                  <option value="watchlist">Watchlist</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-2">Timeframe</label>
                <select 
                  value={filter.timeframe}
                  onChange={(e) => setFilter(prev => ({ ...prev, timeframe: e.target.value as any }))}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                >
                  <option value="1h">1 Hour</option>
                  <option value="24h">24 Hours</option>
                  <option value="7d">7 Days</option>
                  <option value="30d">30 Days</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-2">Sort By</label>
                <select 
                  value={filter.sortBy}
                  onChange={(e) => setFilter(prev => ({ ...prev, sortBy: e.target.value as any }))}
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none"
                >
                  <option value="rank">Market Cap Rank</option>
                  <option value="price">Price</option>
                  <option value="change">24h Change</option>
                  <option value="volume">Volume</option>
                  <option value="marketCap">Market Cap</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content Views */}
      <AnimatePresence mode="wait">
        {activeView === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6 relative z-10"
          >
            {/* Market Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {marketMetrics.map((metric, index) => (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -2 }}
                  className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-4 border border-white/5 group"
                >
                  <div className="flex items-center justify-between mb-2">
                    <metric.icon className={`${metric.color} group-hover:scale-110 transition-transform`} size={20} />
                    <div className={`text-xs px-2 py-1 rounded-full ${
                      metric.change >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {metric.change >= 0 ? '+' : ''}{metric.change.toFixed(1)}%
                    </div>
                  </div>
                  <div className="text-xs text-gray-400 mb-1">{metric.label}</div>
                  <div className={`font-bold text-xl ${metric.color} mb-2`}>{metric.value}</div>
                  <div className="text-xs text-gray-500">{metric.description}</div>
                  
                  {/* Mini Trend Chart */}
                  <div className="mt-3 h-8 flex items-end space-x-1">
                    {metric.trend.map((value, i) => (
                      <div
                        key={i}
                        className={`flex-1 bg-gradient-to-t ${metric.color.includes('green') ? 'from-green-600' : metric.color.includes('blue') ? 'from-blue-600' : metric.color.includes('purple') ? 'from-purple-600' : 'from-orange-600'} to-transparent rounded-sm opacity-60`}
                        style={{ height: `${(value / Math.max(...metric.trend)) * 100}%` }}
                      />
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Fear & Greed Index and Dominance */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Fear & Greed Index */}
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-6 border border-white/5"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Fear & Greed Index</h3>
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className={`text-2xl font-bold ${getFearGreedColor(fearGreedIndex.value)}`}
                  >
                    {fearGreedIndex.value}
                  </motion.div>
                </div>
                
                <div className={`text-lg font-semibold mb-2 ${getFearGreedColor(fearGreedIndex.value)}`}>
                  {getFearGreedText(fearGreedIndex.value)}
                </div>
                
                <div className="text-sm text-gray-400 mb-4">
                  {fearGreedIndex.description}
                </div>
                
                <div className="bg-gray-600 rounded-full h-3 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${fearGreedIndex.value}%` }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    className={`h-3 rounded-full ${
                      fearGreedIndex.value >= 75 ? 'bg-green-500' : 
                      fearGreedIndex.value >= 60 ? 'bg-lime-500' :
                      fearGreedIndex.value >= 40 ? 'bg-yellow-500' : 
                      fearGreedIndex.value >= 25 ? 'bg-orange-500' : 'bg-red-500'
                    }`}
                  />
                </div>
                
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span>Extreme Fear</span>
                  <span>Neutral</span>
                  <span>Extreme Greed</span>
                </div>
                
                <div className="text-xs text-gray-500 mt-3">
                  Last updated: {fearGreedIndex.lastUpdated.toLocaleTimeString()}
                </div>
              </motion.div>

              {/* Market Dominance */}
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-6 border border-white/5"
              >
                <h3 className="text-lg font-semibold mb-4">Market Dominance</h3>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-orange-400 font-medium">Bitcoin</span>
                      <span className="font-bold">{dominance.btc.toFixed(1)}%</span>
                    </div>
                    <div className="bg-gray-600 rounded-full h-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${dominance.btc}%` }}
                        transition={{ duration: 1, delay: 0.2 }}
                        className="h-2 bg-orange-500 rounded-full"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-blue-400 font-medium">Ethereum</span>
                      <span className="font-bold">{dominance.eth.toFixed(1)}%</span>
                    </div>
                    <div className="bg-gray-600 rounded-full h-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${dominance.eth}%` }}
                        transition={{ duration: 1, delay: 0.4 }}
                        className="h-2 bg-blue-500 rounded-full"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-purple-400 font-medium">Others</span>
                      <span className="font-bold">{dominance.others.toFixed(1)}%</span>
                    </div>
                    <div className="bg-gray-600 rounded-full h-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${dominance.others}%` }}
                        transition={{ duration: 1, delay: 0.6 }}
                        className="h-2 bg-purple-500 rounded-full"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}

        {activeView === 'coins' && (
          <motion.div
            key="coins"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="relative z-10"
          >
            <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-transparent">
              {filteredCoins.map((coin, index) => (
                <motion.div
                  key={coin.symbol}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.01, x: 4 }}
                  className="flex items-center justify-between p-4 bg-gray-700/30 backdrop-blur-sm rounded-xl hover:bg-gray-700/50 transition-all cursor-pointer border border-white/5"
                >
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-3">
                      <div className="text-gray-400 text-sm w-6">#{coin.rank}</div>
                      <div 
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                        style={{ backgroundColor: coin.color }}
                      >
                        {coin.symbol.slice(0, 2)}
                      </div>
                      <div>
                        <div className="font-semibold flex items-center space-x-2">
                          <span>{coin.name}</span>
                          <span className="text-gray-400 text-sm">{coin.symbol}</span>
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={() => toggleWatchlist(coin.symbol)}
                            className={`p-1 rounded transition-colors ${
                              watchlist.includes(coin.symbol)
                                ? 'text-yellow-400 hover:text-yellow-300'
                                : 'text-gray-500 hover:text-yellow-400'
                            }`}
                          >
                            <Star size={14} fill={watchlist.includes(coin.symbol) ? 'currentColor' : 'none'} />
                          </motion.button>
                        </div>
                        <div className="text-sm text-gray-400">
                          Vol: ${(coin.volume / 1000000000).toFixed(2)}B
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="font-semibold text-lg">
                      ${coin.price.toLocaleString('en-US', { 
                        minimumFractionDigits: coin.price < 1 ? 4 : 2,
                        maximumFractionDigits: coin.price < 1 ? 4 : 2
                      })}
                    </div>
                    <div className={`text-sm flex items-center space-x-1 justify-end ${
                      coin.changePercent >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {coin.changePercent >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                      <span>
                        {coin.changePercent >= 0 ? '+' : ''}{coin.changePercent.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="text-right text-sm text-gray-400">
                    <div>MCap: ${(coin.marketCap / 1000000000).toFixed(1)}B</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeView === 'news' && (
          <motion.div
            key="news"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="relative z-10"
          >
            <div className="space-y-4 max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-transparent">
              {filteredNews.map((news, index) => (
                <motion.div
                  key={news.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.01, y: -2 }}
                  className="bg-gray-700/30 backdrop-blur-sm rounded-xl p-4 border border-white/5 hover:border-white/20 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${
                        news.category === 'breaking' ? 'bg-red-500/20 text-red-400' :
                        news.category === 'regulation' ? 'bg-blue-500/20 text-blue-400' :
                        news.category === 'technology' ? 'bg-green-500/20 text-green-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        <Newspaper size={16} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white mb-1">{news.title}</h4>
                        <div className="flex items-center space-x-4 text-xs text-gray-400">
                          <span>{news.source}</span>
                          <div className="flex items-center space-x-1">
                            <Clock size={10} />
                            <span>{news.timestamp.toLocaleTimeString()}</span>
                          </div>
                          <span>{news.readTime} min read</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${getImpactColor(news.impact)}`}>
                        {news.impact.toUpperCase()}
                      </div>
                      <div className={`p-1 rounded ${getSentimentColor(news.sentiment)}`}>
                        {getSentimentIcon(news.sentiment)}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-300 mb-3 line-clamp-2">
                    {news.summary}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {news.coins.map((coin, i) => (
                        <span key={i} className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded-full text-xs">
                          {coin}
                        </span>
                      ))}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-white"
                        title="Bookmark"
                      >
                        <Bookmark size={14} />
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-white"
                        title="Share"
                      >
                        <Share size={14} />
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-white"
                        title="Read full article"
                      >
                        <ExternalLink size={14} />
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default MarketOverview;
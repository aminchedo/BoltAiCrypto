import React from 'react';
import clsx from 'clsx';

interface SettingGroupProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
  icon?: React.ComponentType<any>;
}

export function SettingGroup({
  title,
  description,
  children,
  className,
  icon: Icon,
}: SettingGroupProps) {
  return (
    <div className={clsx('bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700', className)}>
      <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          {Icon && <Icon className="w-5 h-5 text-blue-500" />}
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            {title}
          </h3>
        </div>
        {description && (
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            {description}
          </p>
        )}
      </div>
      <div className="px-6 py-4 space-y-4">
        {children}
      </div>
    </div>
  );
}
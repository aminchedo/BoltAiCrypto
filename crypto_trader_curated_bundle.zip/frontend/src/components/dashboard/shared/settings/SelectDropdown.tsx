import React from 'react';
import { ChevronDown } from 'lucide-react';
import clsx from 'clsx';

interface Option {
  value: string;
  label: string;
  description?: string;
  disabled?: boolean;
}

interface SelectDropdownProps {
  value: string;
  onChange: (value: string) => void;
  options: Option[];
  label?: string;
  description?: string;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export function SelectDropdown({
  value,
  onChange,
  options,
  label,
  description,
  placeholder = 'Select an option',
  disabled = false,
  className,
}: SelectDropdownProps) {
  const selectedOption = options.find(option => option.value === value);

  return (
    <div className={clsx('space-y-2', className)}>
      {(label || description) && (
        <div>
          {label && (
            <label className="block text-sm font-medium text-gray-900 dark:text-white">
              {label}
            </label>
          )}
          {description && (
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {description}
            </p>
          )}
        </div>
      )}
      
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className={clsx(
            'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md',
            'bg-white dark:bg-gray-700 text-gray-900 dark:text-white',
            'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500',
            'appearance-none cursor-pointer',
            {
              'opacity-50 cursor-not-allowed': disabled,
              'bg-gray-100 dark:bg-gray-800': disabled,
            }
          )}
        >
          {!selectedOption && (
            <option value="" disabled>
              {placeholder}
            </option>
          )}
          {options.map((option) => (
            <option
              key={option.value}
              value={option.value}
              disabled={option.disabled}
            >
              {option.label}
            </option>
          ))}
        </select>
        
        <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
      </div>
    </div>
  );
}
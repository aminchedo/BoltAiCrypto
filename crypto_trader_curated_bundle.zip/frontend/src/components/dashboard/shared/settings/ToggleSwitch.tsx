import React from 'react';
import { Check } from 'lucide-react';
import clsx from 'clsx';

interface ToggleSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  description?: string;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function ToggleSwitch({
  checked,
  onChange,
  label,
  description,
  disabled = false,
  size = 'md',
  className,
}: ToggleSwitchProps) {
  const handleToggle = () => {
    if (!disabled) {
      onChange(!checked);
    }
  };

  const sizeClasses = {
    sm: 'w-8 h-4',
    md: 'w-11 h-6',
    lg: 'w-14 h-7',
  };

  const thumbSizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  };

  return (
    <div className={clsx('flex items-start space-x-3', className)}>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={handleToggle}
        className={clsx(
          'relative inline-flex items-center rounded-full transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2',
          sizeClasses[size],
          {
            'bg-blue-600': checked && !disabled,
            'bg-gray-200 dark:bg-gray-700': !checked && !disabled,
            'bg-gray-300 dark:bg-gray-600 cursor-not-allowed': disabled,
            'cursor-pointer': !disabled,
          }
        )}
      >
        <span
          className={clsx(
            'inline-block transform rounded-full bg-white shadow transition-transform duration-200 ease-in-out',
            thumbSizeClasses[size],
            {
              'translate-x-5': checked && size === 'md',
              'translate-x-6': checked && size === 'lg',
              'translate-x-3': checked && size === 'sm',
              'translate-x-0': !checked,
            }
          )}
        >
          {checked && (
            <Check className="h-3 w-3 text-blue-600 mx-auto mt-0.5" />
          )}
        </span>
      </button>
      
      {(label || description) && (
        <div className="flex-1 min-w-0">
          {label && (
            <label className="text-sm font-medium text-gray-900 dark:text-white cursor-pointer">
              {label}
            </label>
          )}
          {description && (
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {description}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
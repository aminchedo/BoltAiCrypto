import React, { useState } from 'react';
import clsx from 'clsx';

interface SliderControlProps {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step?: number;
  label?: string;
  description?: string;
  suffix?: string;
  disabled?: boolean;
  className?: string;
}

export function SliderControl({
  value,
  onChange,
  min,
  max,
  step = 1,
  label,
  description,
  suffix,
  disabled = false,
  className,
}: SliderControlProps) {
  const [isDragging, setIsDragging] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseFloat(e.target.value);
    onChange(newValue);
  };

  const percentage = ((value - min) / (max - min)) * 100;

  return (
    <div className={clsx('space-y-3', className)}>
      {(label || description) && (
        <div className="flex items-center justify-between">
          <div className="flex-1">
            {label && (
              <label className="text-sm font-medium text-gray-900 dark:text-white">
                {label}
              </label>
            )}
            {description && (
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {description}
              </p>
            )}
          </div>
          <div className="text-sm font-medium text-gray-900 dark:text-white">
            {value}{suffix}
          </div>
        </div>
      )}
      
      <div className="relative">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={handleChange}
          disabled={disabled}
          onMouseDown={() => setIsDragging(true)}
          onMouseUp={() => setIsDragging(false)}
          onTouchStart={() => setIsDragging(true)}
          onTouchEnd={() => setIsDragging(false)}
          className={clsx(
            'w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer',
            'focus:outline-none focus:ring-2 focus:ring-blue-500',
            {
              'opacity-50 cursor-not-allowed': disabled,
              'scale-105': isDragging,
            }
          )}
          style={{
            background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${percentage}%, #e5e7eb ${percentage}%, #e5e7eb 100%)`,
          }}
        />
        
        {/* Custom thumb */}
        <div
          className={clsx(
            'absolute top-1/2 w-4 h-4 bg-blue-600 rounded-full shadow-lg transform -translate-y-1/2 transition-transform',
            {
              'scale-110': isDragging,
              'opacity-50': disabled,
            }
          )}
          style={{
            left: `${percentage}%`,
            transform: `translate(-50%, -50%)${isDragging ? ' scale(1.1)' : ''}`,
          }}
        />
      </div>
      
      <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
        <span>{min}{suffix}</span>
        <span>{max}{suffix}</span>
      </div>
    </div>
  );
}
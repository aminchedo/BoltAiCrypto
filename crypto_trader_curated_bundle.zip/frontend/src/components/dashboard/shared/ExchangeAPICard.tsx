import React, { useState, useEffect } from 'react';
import { Check, X, AlertCircle, Loader2, ExternalLink, Eye, EyeOff } from 'lucide-react';
import { EXCHANGE_CONFIG, ExchangeType } from './ExchangeSVGIcons';

interface ExchangeAPICardProps {
  exchange: ExchangeType;
  onApiChange?: (exchange: ExchangeType, apiKey: string, secretKey: string, isValid: boolean) => void;
}

interface ValidationResult {
  status: 'valid' | 'invalid' | 'error';
  message?: string;
  accountType?: string;
  permissions?: string[];
  testnet?: boolean;
  balancesCount?: number;
  accountsCount?: number;
}

const APIValidationMessages = {
  binance: {
    invalid_key: "❌ Invalid Binance API Key. Check your API key in Binance Security settings.",
    invalid_secret: "❌ Invalid Secret. Ensure you copied the secret key correctly.",
    no_permissions: "⚠️ API needs SPOT trading permissions. Enable in Binance API settings.",
    success: "✅ Binance API connected successfully! Ready for trading.",
    testing_connection: "🔄 Testing Binance API connection...",
  },
  coinbase: {
    invalid_key: "❌ Invalid Coinbase API Key. Verify your API credentials.",
    invalid_secret: "❌ Invalid Secret. Check your Coinbase Pro API secret.",
    no_permissions: "⚠️ API needs VIEW and TRADE permissions.",
    success: "✅ Coinbase API connected successfully!",
    testing_connection: "🔄 Testing Coinbase API connection...",
  },
  bybit: {
    invalid_key: "❌ Invalid Bybit API Key. Check your API settings.",
    invalid_secret: "❌ Invalid Secret. Verify your Bybit secret key.",
    no_permissions: "⚠️ API needs READ and TRADE permissions.",
    success: "✅ Bybit API connected successfully!",
    testing_connection: "🔄 Testing Bybit API connection...",
  },
  okx: {
    invalid_key: "❌ Invalid OKX API Key. Check your API settings.",
    invalid_secret: "❌ Invalid Secret. Verify your OKX secret key.",
    no_permissions: "⚠️ API needs READ and TRADE permissions.",
    success: "✅ OKX API connected successfully!",
    testing_connection: "🔄 Testing OKX API connection...",
  },
  kraken: {
    invalid_key: "❌ Invalid Kraken API Key. Check your API settings.",
    invalid_secret: "❌ Invalid Secret. Verify your Kraken secret key.",
    no_permissions: "⚠️ API needs Query Funds and Create & Modify Orders permissions.",
    success: "✅ Kraken API connected successfully!",
    testing_connection: "🔄 Testing Kraken API connection...",
  },
  kucoin: {
    invalid_key: "❌ Invalid KuCoin API Key. Check your API settings.",
    invalid_secret: "❌ Invalid Secret. Verify your KuCoin secret key.",
    no_permissions: "⚠️ API needs General and Trade permissions.",
    success: "✅ KuCoin API connected successfully!",
    testing_connection: "🔄 Testing KuCoin API connection...",
  },
};

export const ExchangeAPICard: React.FC<ExchangeAPICardProps> = ({ 
  exchange, 
  onApiChange 
}) => {
  const [apiKey, setApiKey] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [testnet, setTestnet] = useState(true);
  const [validationStatus, setValidationStatus] = useState<'idle' | 'validating' | 'valid' | 'invalid' | 'error'>('idle');
  const [validationMessage, setValidationMessage] = useState('');
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);
  const [showSecretKey, setShowSecretKey] = useState(false);
  const [debounceTimer, setDebounceTimer] = useState<NodeJS.Timeout | null>(null);

  const config = EXCHANGE_CONFIG[exchange];
  const messages = APIValidationMessages[exchange];
  const IconComponent = config.icon;

  // Real-time validation with debounce
  useEffect(() => {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }

    if (apiKey.length > 10 && secretKey.length > 10) {
      const timer = setTimeout(() => {
        validateAPIKeys();
      }, 1000); // 1 second debounce

      setDebounceTimer(timer);
    } else {
      setValidationStatus('idle');
      setValidationMessage('');
      setValidationResult(null);
    }

    return () => {
      if (debounceTimer) {
        clearTimeout(debounceTimer);
      }
    };
  }, [apiKey, secretKey, passphrase, testnet]);

  const validateAPIKeys = async () => {
    if (!apiKey || !secretKey) return;

    setValidationStatus('validating');
    setValidationMessage(messages.testing_connection);

    try {
      const requestBody: any = {
        api_key: apiKey,
        secret_key: secretKey,
        testnet: testnet,
      };

      // Coinbase requires passphrase
      if (exchange === 'coinbase' && passphrase) {
        requestBody.passphrase = passphrase;
      }

      const response = await fetch(`/api/settings/exchange/${exchange}/validate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      const result: ValidationResult = await response.json();

      if (result.status === 'valid') {
        setValidationStatus('valid');
        setValidationMessage(messages.success);
        setValidationResult(result);
        
        // Auto-save valid credentials
        await saveExchangeCredentials();
        
        // Notify parent component
        onApiChange?.(exchange, apiKey, secretKey, true);
      } else {
        setValidationStatus('invalid');
        handleValidationError(result);
        onApiChange?.(exchange, apiKey, secretKey, false);
      }
    } catch (error) {
      setValidationStatus('error');
      setValidationMessage(`🔥 Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      onApiChange?.(exchange, apiKey, secretKey, false);
    }
  };

  const handleValidationError = (result: ValidationResult) => {
    if (result.message?.includes('Invalid API-key')) {
      setValidationMessage(messages.invalid_key);
    } else if (result.message?.includes('Signature')) {
      setValidationMessage(messages.invalid_secret);
    } else if (result.message?.includes('permission')) {
      setValidationMessage(messages.no_permissions);
    } else {
      setValidationMessage(result.message || 'Unknown error');
    }
  };

  const saveExchangeCredentials = async () => {
    try {
      const response = await fetch(`/api/settings/exchange/${exchange}/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          api_key: apiKey,
          secret_key: secretKey,
          passphrase: passphrase,
          testnet: testnet,
          status: 'configured',
        }),
      });

      if (!response.ok) {
        console.error('Failed to save credentials');
      }
    } catch (error) {
      console.error('Error saving credentials:', error);
    }
  };

  const getStatusColor = () => {
    switch (validationStatus) {
      case 'valid': return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'invalid': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'validating': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'error': return 'bg-red-500/20 text-red-400 border-red-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const getInputBorderColor = () => {
    switch (validationStatus) {
      case 'valid': return 'border-green-500 bg-green-900/10';
      case 'invalid': return 'border-red-500 bg-red-900/10';
      case 'error': return 'border-red-500 bg-red-900/10';
      default: return 'border-gray-600 bg-gray-700';
    }
  };

  return (
    <div className="bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50 hover:border-gray-600/50 transition-all duration-200">
      {/* Exchange Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="p-2 rounded-lg bg-gray-700/50">
            <IconComponent className="w-8 h-8" />
          </div>
          <div>
            <h4 className="font-bold text-xl text-white">{config.name}</h4>
            <p className="text-sm text-gray-400">{config.description}</p>
          </div>
        </div>

        {/* Real-time Status Indicator */}
        <div className={`px-4 py-2 rounded-full text-sm font-medium flex items-center space-x-2 border ${getStatusColor()}`}>
          {validationStatus === 'validating' && (
            <Loader2 className="w-4 h-4 animate-spin" />
          )}
          {validationStatus === 'valid' && (
            <Check className="w-4 h-4" />
          )}
          {validationStatus === 'invalid' && (
            <X className="w-4 h-4" />
          )}
          {validationStatus === 'error' && (
            <AlertCircle className="w-4 h-4" />
          )}
          <span>
            {validationStatus === 'idle' ? 'Not Configured' : 
             validationStatus === 'validating' ? 'Validating...' :
             validationStatus === 'valid' ? 'Connected' :
             'Disconnected'}
          </span>
        </div>
      </div>

      {/* API Input Fields */}
      <div className="space-y-4 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">API Key</label>
          <div className="relative">
            <input
              type={showApiKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setValidationStatus('idle');
              }}
              placeholder="Enter API Key - validates automatically"
              className={`w-full px-3 py-3 text-sm rounded-lg transition-all duration-200 ${getInputBorderColor()}`}
            />
            <button
              type="button"
              onClick={() => setShowApiKey(!showApiKey)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300"
            >
              {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Secret Key</label>
          <div className="relative">
            <input
              type={showSecretKey ? 'text' : 'password'}
              value={secretKey}
              onChange={(e) => {
                setSecretKey(e.target.value);
                setValidationStatus('idle');
              }}
              placeholder="Enter Secret Key - validates automatically"
              className={`w-full px-3 py-3 text-sm rounded-lg transition-all duration-200 ${getInputBorderColor()}`}
            />
            <button
              type="button"
              onClick={() => setShowSecretKey(!showSecretKey)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300"
            >
              {showSecretKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Coinbase Passphrase */}
        {exchange === 'coinbase' && (
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Passphrase</label>
            <input
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
              placeholder="Enter Coinbase Pro Passphrase"
              className={`w-full px-3 py-3 text-sm rounded-lg transition-all duration-200 ${getInputBorderColor()}`}
            />
          </div>
        )}

        {/* Testnet Toggle */}
        {config.testnetSupported && (
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id={`testnet-${exchange}`}
              checked={testnet}
              onChange={(e) => setTestnet(e.target.checked)}
              className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
            />
            <label htmlFor={`testnet-${exchange}`} className="text-sm text-gray-300">
              Use Testnet (Recommended for testing)
            </label>
          </div>
        )}
      </div>

      {/* Validation Message */}
      {validationMessage && (
        <div className={`p-4 rounded-lg mb-4 text-sm ${
          validationStatus === 'valid' ? 'bg-green-500/10 text-green-400' :
          validationStatus === 'invalid' ? 'bg-red-500/10 text-red-400' :
          validationStatus === 'error' ? 'bg-red-500/10 text-red-400' :
          'bg-yellow-500/10 text-yellow-400'
        }`}>
          {validationMessage}
        </div>
      )}

      {/* Validation Results */}
      {validationResult && validationStatus === 'valid' && (
        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mb-4">
          <h5 className="font-medium text-green-400 mb-2">Connection Details</h5>
          <div className="space-y-1 text-sm text-green-300">
            {validationResult.accountType && (
              <p>Account Type: {validationResult.accountType}</p>
            )}
            {validationResult.permissions && (
              <p>Permissions: {validationResult.permissions.join(', ')}</p>
            )}
            {validationResult.testnet !== undefined && (
              <p>Environment: {validationResult.testnet ? 'Testnet' : 'Live'}</p>
            )}
            {validationResult.balancesCount !== undefined && (
              <p>Active Balances: {validationResult.balancesCount}</p>
            )}
          </div>
        </div>
      )}

      {/* Required Permissions */}
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
        <h5 className="font-medium text-blue-400 mb-2 flex items-center">
          <AlertCircle className="w-4 h-4 mr-2" />
          Required Permissions
        </h5>
        <div className="space-y-2 text-sm text-blue-300">
          <div>
            <p className="font-medium">API Permissions:</p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              {config.requiredPermissions.map((permission, index) => (
                <li key={index}>{permission}</li>
              ))}
            </ul>
          </div>
          <div className="pt-2 border-t border-blue-500/20">
            <a
              href={config.docsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center text-blue-400 hover:text-blue-300 transition-colors"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              {config.name} API Documentation
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
import React from 'react';

// Binance SVG Icon (Official Logo)
export const BinanceSVG: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 126.611 126.611" fill="none">
    <g fill="#F3BA2F">
      <path d="M38.171 53.203l25.054-25.056 25.054 25.056-14.534 14.534-10.52-10.52-10.52 10.52z"/>
      <path d="M.285 63.172l14.534-14.534 14.534 14.534-14.534 14.534z"/>
      <path d="M25.054 88.226l10.52-10.52 14.534 14.534-10.52 10.52-25.054-25.056 10.52-10.52z"/>
      <path d="M97.557 73.692l14.534-14.534 14.534 14.534-14.534 14.534z"/>
      <path d="M88.225 63.172l-25.054 25.056-25.054-25.056 14.534-14.534 10.52 10.52 10.52-10.52z"/>
    </g>
  </svg>
);

// Coinbase SVG Icon (Official Logo)
export const CoinbaseSVG: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 1024 1024" fill="none">
    <circle cx="512" cy="512" r="512" fill="#0052ff"/>
    <path d="M512.147 692c-99.28 0-180.147-80.867-180.147-180.147S412.867 331.706 512.147 331.706s180.147 80.867 180.147 180.147S611.427 692 512.147 692zm0-300.147c-66.186 0-120 53.814-120 120s53.814 120 120 120 120-53.814 120-120-53.814-120-120-120z" fill="#fff"/>
  </svg>
);

// Bybit SVG Icon (Official Logo)
export const BybitSVG: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="12" fill="#f7931a"/>
    <path d="M8.5 7.5h7v2h-5v1.5h4v2h-4v1.5h5v2h-7v-9z" fill="#fff"/>
  </svg>
);

// OKX SVG Icon (Official Logo)  
export const OKXSVG: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none">
    <rect width="24" height="24" rx="4" fill="#000"/>
    <path d="M7 7h3v3H7zm0 7h3v3H7zm7-7h3v3h-3zm0 7h3v3h-3z" fill="#fff"/>
  </svg>
);

// Kraken SVG Icon (Official Logo)
export const KrakenSVG: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="12" fill="#5741D9"/>
    <path d="M8 6h8v2H8zm0 4h6v2H8zm0 4h8v2H8z" fill="#fff"/>
  </svg>
);

// Kucoin SVG Icon (Official Logo)
export const KucoinSVG: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="12" fill="#00D4AA"/>
    <path d="M7 8l5 4 5-4v8l-5-4-5 4V8z" fill="#fff"/>
  </svg>
);

// Exchange Configuration
export const EXCHANGE_CONFIG = {
  binance: {
    name: 'Binance',
    icon: BinanceSVG,
    color: '#F3BA2F',
    description: 'World\'s largest cryptocurrency exchange',
    requiredPermissions: ['SPOT'],
    testnetSupported: true,
    docsUrl: 'https://binance-docs.github.io/apidocs/spot/en/',
  },
  coinbase: {
    name: 'Coinbase',
    icon: CoinbaseSVG,
    color: '#0052ff',
    description: 'Leading US cryptocurrency exchange',
    requiredPermissions: ['VIEW', 'TRADE'],
    testnetSupported: true,
    docsUrl: 'https://docs.pro.coinbase.com/',
  },
  bybit: {
    name: 'Bybit',
    icon: BybitSVG,
    color: '#f7931a',
    description: 'Advanced derivatives trading platform',
    requiredPermissions: ['READ', 'TRADE'],
    testnetSupported: true,
    docsUrl: 'https://bybit-exchange.github.io/docs/',
  },
  okx: {
    name: 'OKX',
    icon: OKXSVG,
    color: '#000',
    description: 'Global cryptocurrency exchange',
    requiredPermissions: ['READ', 'TRADE'],
    testnetSupported: true,
    docsUrl: 'https://www.okx.com/docs-v5/',
  },
  kraken: {
    name: 'Kraken',
    icon: KrakenSVG,
    color: '#5741D9',
    description: 'Trusted European exchange',
    requiredPermissions: ['Query Funds', 'Create & Modify Orders'],
    testnetSupported: false,
    docsUrl: 'https://docs.kraken.com/rest/',
  },
  kucoin: {
    name: 'KuCoin',
    icon: KucoinSVG,
    color: '#00D4AA',
    description: 'Popular altcoin exchange',
    requiredPermissions: ['General', 'Trade'],
    testnetSupported: true,
    docsUrl: 'https://docs.kucoin.com/',
  },
};

export type ExchangeType = keyof typeof EXCHANGE_CONFIG;
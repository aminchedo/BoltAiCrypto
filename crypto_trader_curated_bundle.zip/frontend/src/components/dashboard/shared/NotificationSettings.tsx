import React from 'react';
import { Bell, MessageCircle, Users, AlertCircle } from 'lucide-react';
import { useUserStore } from '@/store/userStore';
import { ToggleSetting } from './ToggleSetting';

interface ChipProps {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
}

function Chip({ children, active, onClick }: ChipProps) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
        active
          ? 'bg-blue-600 text-white'
          : 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-500'
      }`}
    >
      {children}
    </button>
  );
}

export function NotificationSettings() {
  const { 
    notificationPreferences, 
    updateNotificationSetting, 
    toggleNotificationChannel 
  } = useUserStore();

  const availableChannels = ['Telegram', 'Email', 'SMS'];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow telegram-card">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <Bell className="w-6 h-6 text-blue-500 mr-3" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white telegram-header">
            🔔 Notifications
          </h2>
        </div>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Configure how you receive notifications and alerts
        </p>
      </div>

      <div className="p-6 space-y-6">
        {/* Notification Toggles */}
        <div className="telegram-toggle-group space-y-4">
          <ToggleSetting
            title="Friend Requests"
            description="Notify when new friends add you"
            icon={<Users className="w-4 h-4" />}
            checked={notificationPreferences.friendRequests}
            onChange={(checked) => updateNotificationSetting('friendRequests', checked)}
            storageKey="notifyFriendRequests"
          />
          
          <ToggleSetting
            title="Message Previews"
            description="Show message content in notifications"
            icon={<MessageCircle className="w-4 h-4" />}
            checked={notificationPreferences.messagePreviews}
            onChange={(checked) => updateNotificationSetting('messagePreviews', checked)}
            storageKey="messagePreviews"
          />

          <ToggleSetting
            title="Trade Alerts"
            description="Notifications for trading activities"
            icon={<AlertCircle className="w-4 h-4" />}
            checked={notificationPreferences.tradeAlerts}
            onChange={(checked) => updateNotificationSetting('tradeAlerts', checked)}
            storageKey="tradeAlerts"
          />

          <ToggleSetting
            title="Price Alerts"
            description="Notify when price targets are hit"
            icon={<Bell className="w-4 h-4" />}
            checked={notificationPreferences.priceAlerts}
            onChange={(checked) => updateNotificationSetting('priceAlerts', checked)}
            storageKey="priceAlerts"
          />
        </div>

        {/* Notification Channels */}
        <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 telegram-subheader">
            Notification Channels
          </h3>
          <div className="telegram-chip-group flex flex-wrap gap-2">
            {availableChannels.map(channel => (
              <Chip
                key={channel}
                active={notificationPreferences.channels.includes(channel)}
                onClick={() => toggleNotificationChannel(channel)}
              >
                {channel}
              </Chip>
            ))}
          </div>
        </div>

        {/* Notification Settings Info */}
        <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
            Notification Features
          </h4>
          <ul className="text-sm text-blue-700 dark:text-blue-200 space-y-1">
            <li>• Customize notification types for different events</li>
            <li>• Choose multiple channels for redundancy</li>
            <li>• Message previews can be disabled for privacy</li>
            <li>• All notifications respect your privacy settings</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
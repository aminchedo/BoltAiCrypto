import React from 'react';
import { PieChart, TrendingUp, Target, DollarSign } from 'lucide-react';
import { useUserStore } from '@/store/userStore';
import { ToggleSetting } from './ToggleSetting';

interface SliderProps {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step?: number;
  marks?: number[];
}

function Slider({ value, onChange, min, max, step = 1, marks = [] }: SliderProps) {
  return (
    <div className="w-full">
      <div className="relative">
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
        />
        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-2">
          <span>Minimal</span>
          <span>Moderate</span>
          <span>Aggressive</span>
        </div>
      </div>
      {marks.length > 0 && (
        <div className="flex justify-between mt-2">
          {marks.map((mark, index) => (
            <button
              key={index}
              onClick={() => onChange(mark)}
              className={`px-2 py-1 text-xs rounded ${
                value === mark
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-500'
              }`}
            >
              {mark}%
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function PortfolioSettings() {
  const { tradingSettings, updateTradingSetting } = useUserStore();

  const handleSizeChange = (size: number) => {
    updateTradingSetting('portfolioSize', size);
  };

  const presetSizes = [10, 30, 70, 100];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow telegram-card">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <PieChart className="w-6 h-6 text-blue-500 mr-3" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white telegram-header">
            📊 Portfolio Settings
          </h2>
        </div>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Configure your portfolio size and risk management settings
        </p>
      </div>

      <div className="p-6 space-y-6">
        {/* Portfolio Size Control */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Portfolio Scale
          </h3>
          <div className="telegram-slider-container space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Current Size: {tradingSettings.portfolioSize}%
              </span>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {tradingSettings.portfolioSize <= 25 ? 'Conservative' : 
                 tradingSettings.portfolioSize <= 50 ? 'Moderate' : 
                 tradingSettings.portfolioSize <= 75 ? 'Aggressive' : 'Maximum'}
              </span>
            </div>
            <Slider
              value={tradingSettings.portfolioSize}
              onChange={handleSizeChange}
              min={1}
              max={100}
              marks={[25, 50, 75, 100]}
            />
          </div>
        </div>

        {/* Preset Sizes */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Quick Presets
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {presetSizes.map((size) => (
              <button
                key={size}
                onClick={() => handleSizeChange(size)}
                className={`p-3 rounded-lg border transition-colors ${
                  tradingSettings.portfolioSize === size
                    ? 'bg-blue-600 border-blue-600 text-white'
                    : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600'
                }`}
              >
                <div className="text-lg font-semibold">{size}%</div>
                <div className="text-xs">
                  {size <= 25 ? 'Conservative' : 
                   size <= 50 ? 'Moderate' : 
                   size <= 75 ? 'Aggressive' : 'Maximum'}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Risk Management Settings */}
        <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Risk Management
          </h3>
          <div className="telegram-toggle-group space-y-4">
            <ToggleSetting
              title="Risk Management"
              description="Enable automatic risk management"
              icon={<Target className="w-4 h-4" />}
              checked={tradingSettings.riskManagement}
              onChange={(checked) => updateTradingSetting('riskManagement', checked)}
              storageKey="riskManagement"
            />
            
            <ToggleSetting
              title="Stop Loss"
              description="Automatic stop loss protection"
              icon={<TrendingUp className="w-4 h-4" />}
              checked={tradingSettings.stopLoss}
              onChange={(checked) => updateTradingSetting('stopLoss', checked)}
              storageKey="stopLoss"
            />
            
            <ToggleSetting
              title="Auto Trading"
              description="Enable automated trading"
              icon={<DollarSign className="w-4 h-4" />}
              checked={tradingSettings.autoTrading}
              onChange={(checked) => updateTradingSetting('autoTrading', checked)}
              storageKey="autoTrading"
            />
          </div>
        </div>

        {/* Portfolio Info */}
        <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
            Portfolio Management
          </h4>
          <ul className="text-sm text-blue-700 dark:text-blue-200 space-y-1">
            <li>• Portfolio size affects position sizing and risk</li>
            <li>• Conservative: Lower risk, stable returns</li>
            <li>• Aggressive: Higher risk, potential for higher returns</li>
            <li>• Risk management helps protect your capital</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
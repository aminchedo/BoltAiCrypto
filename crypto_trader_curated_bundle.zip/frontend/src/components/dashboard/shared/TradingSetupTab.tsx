import React, { useState, useEffect } from 'react';
import { Activity, CheckCircle, XCircle, RefreshCw, Link, Settings } from 'lucide-react';
import { ExchangeAPICard } from './ExchangeAPICard';
import { EXCHANGE_CONFIG, ExchangeType } from './ExchangeSVGIcons';

interface ExchangeStatus {
  configured: boolean;
  valid: boolean;
  permissions: string[];
  accountType?: string;
  testnet: boolean;
  lastConnected?: string;
}

interface TradingSetupTabProps {
  className?: string;
}

export const TradingSetupTab: React.FC<TradingSetupTabProps> = ({ className = '' }) => {
  const [exchanges, setExchanges] = useState<Record<ExchangeType, ExchangeStatus>>({
    binance: { configured: false, valid: false, permissions: [], testnet: true },
    coinbase: { configured: false, valid: false, permissions: [], testnet: true },
    bybit: { configured: false, valid: false, permissions: [], testnet: true },
    okx: { configured: false, valid: false, permissions: [], testnet: true },
    kraken: { configured: false, valid: false, permissions: [], testnet: false },
    kucoin: { configured: false, valid: false, permissions: [], testnet: true },
  });

  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    loadExchangeStatuses();
  }, []);

  const loadExchangeStatuses = async () => {
    setIsRefreshing(true);
    try {
      const statusPromises = Object.keys(EXCHANGE_CONFIG).map(async (exchange) => {
        const response = await fetch(`/api/settings/exchange/${exchange}/status`);
        const status = await response.json();
        return { exchange: exchange as ExchangeType, status };
      });

      const results = await Promise.all(statusPromises);
      const newExchanges = { ...exchanges };

      results.forEach(({ exchange, status }) => {
        newExchanges[exchange] = {
          configured: status.configured || false,
          valid: status.valid || false,
          permissions: status.permissions || [],
          accountType: status.accountType,
          testnet: status.testnet !== undefined ? status.testnet : true,
          lastConnected: status.lastConnected,
        };
      });

      setExchanges(newExchanges);
    } catch (error) {
      console.error('Error loading exchange statuses:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleApiChange = (exchange: ExchangeType, apiKey: string, secretKey: string, isValid: boolean) => {
    setExchanges(prev => ({
      ...prev,
      [exchange]: {
        ...prev[exchange],
        configured: apiKey.length > 0 && secretKey.length > 0,
        valid: isValid,
        lastConnected: isValid ? new Date().toISOString() : undefined,
      },
    }));
  };

  const connectedCount = Object.values(exchanges).filter(e => e.valid).length;
  const configuredCount = Object.values(exchanges).filter(e => e.configured).length;
  const totalExchanges = Object.keys(exchanges).length;

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">🔗 Exchange API Configuration</h2>
          <p className="text-gray-400">Connect your exchange accounts for live trading functionality</p>
        </div>
        <button
          onClick={loadExchangeStatuses}
          disabled={isRefreshing}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>Refresh Status</span>
        </button>
      </div>

      {/* Overall Status Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Connected</p>
              <p className="text-2xl font-bold text-green-400">{connectedCount}/{totalExchanges}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Configured</p>
              <p className="text-2xl font-bold text-blue-400">{configuredCount}/{totalExchanges}</p>
            </div>
            <Settings className="w-8 h-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Status</p>
              <p className={`text-2xl font-bold ${connectedCount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                {connectedCount > 0 ? 'Active' : 'Inactive'}
              </p>
            </div>
            <Activity className={`w-8 h-8 ${connectedCount > 0 ? 'text-green-400' : 'text-red-400'}`} />
          </div>
        </div>
      </div>

      {/* Exchange Configuration Cards */}
      <div className="space-y-6">
        <h3 className="text-xl font-semibold text-white flex items-center">
          <Link className="w-5 h-5 mr-2" />
          Exchange Connections
        </h3>
        
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {(Object.keys(EXCHANGE_CONFIG) as ExchangeType[]).map((exchange) => (
            <ExchangeAPICard
              key={exchange}
              exchange={exchange}
              onApiChange={handleApiChange}
            />
          ))}
        </div>
      </div>

      {/* Live Connection Status Dashboard */}
      <div className="bg-gray-800/30 backdrop-blur-sm p-6 rounded-xl border border-gray-700/50">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <Activity className="w-5 h-5 mr-2" />
          📊 Live Connection Status
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {(Object.keys(exchanges) as ExchangeType[]).map((exchange) => {
            const status = exchanges[exchange];
            const config = EXCHANGE_CONFIG[exchange];
            const IconComponent = config.icon;

            return (
              <div
                key={exchange}
                className={`p-4 rounded-lg text-center transition-all duration-200 ${
                  status.valid
                    ? 'bg-green-500/10 border border-green-500/20'
                    : status.configured
                    ? 'bg-yellow-500/10 border border-yellow-500/20'
                    : 'bg-gray-700/50 border border-gray-600/50'
                }`}
              >
                <div className="flex justify-center mb-2">
                  <IconComponent className="w-8 h-8" />
                </div>
                <div className="font-medium text-white capitalize text-sm mb-1">
                  {config.name}
                </div>
                <div className="flex items-center justify-center mb-2">
                  {status.valid ? (
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  ) : status.configured ? (
                    <XCircle className="w-4 h-4 text-yellow-400" />
                  ) : (
                    <XCircle className="w-4 h-4 text-gray-400" />
                  )}
                </div>
                <div className={`text-xs font-medium ${
                  status.valid ? 'text-green-400' : 
                  status.configured ? 'text-yellow-400' : 
                  'text-gray-400'
                }`}>
                  {status.valid ? '✅ Connected' : 
                   status.configured ? '⚠️ Configured' : 
                   '❌ Not Set'}
                </div>
                {status.accountType && (
                  <div className="text-xs text-gray-400 mt-1">
                    {status.accountType}
                  </div>
                )}
                {status.permissions.length > 0 && (
                  <div className="text-xs text-gray-400 mt-1">
                    {status.permissions.slice(0, 2).join(', ')}
                    {status.permissions.length > 2 && '...'}
                  </div>
                )}
                {status.testnet && (
                  <div className="text-xs text-blue-400 mt-1">
                    Testnet
                  </div>
                )}
                {status.lastConnected && (
                  <div className="text-xs text-gray-500 mt-1">
                    Last: {new Date(status.lastConnected).toLocaleTimeString()}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Usage Instructions */}
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-400 mb-4">📋 Quick Setup Guide</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-blue-300 mb-2">1. Create API Keys</h4>
            <ul className="text-sm text-blue-200 space-y-1">
              <li>• Visit your exchange's API settings</li>
              <li>• Create new API key with trading permissions</li>
              <li>• Enable testnet for safe testing</li>
              <li>• Copy API key and secret</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-blue-300 mb-2">2. Configure & Validate</h4>
            <ul className="text-sm text-blue-200 space-y-1">
              <li>• Paste keys into the forms above</li>
              <li>• Validation happens automatically</li>
              <li>• Green = Connected successfully</li>
              <li>• Red = Check your credentials</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
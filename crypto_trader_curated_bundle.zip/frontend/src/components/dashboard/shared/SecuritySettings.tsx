import React from 'react';
import { Shield, Lock, Key, CloudUpload, CloudDownload, Timer, Fingerprint } from 'lucide-react';
import { useUserStore } from '@/store/userStore';
import { ToggleSetting } from './ToggleSetting';

export const SecuritySettings: React.FC = () => {
  const { securitySettings, updateSecuritySetting } = useUserStore();
  
  const handleBackupNow = () => {
    // TODO: Implement backup functionality
    console.log('Backup now clicked');
  };
  
  const handleRestore = () => {
    // TODO: Implement restore functionality
    console.log('Restore clicked');
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow telegram-card">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <Shield className="w-6 h-6 text-blue-500 mr-3" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white telegram-header">
            🔐 Security Center
          </h2>
        </div>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Manage your security settings and data protection preferences
        </p>
      </div>

      <div className="p-6 space-y-6">
        {/* Security Toggles */}
        <div className="telegram-toggle-group space-y-4">
          <ToggleSetting
            title="Encrypted Backups"
            description="AES-256 encrypted cloud backups"
            icon={<CloudUpload className="w-4 h-4" />}
            checked={securitySettings.encryptedBackups}
            onChange={(checked) => updateSecuritySetting('encryptedBackups', checked)}
            storageKey="encryptedBackups"
          />
          
          <ToggleSetting
            title="Session Timeout"
            description="Auto-lock after 15min inactivity"
            icon={<Timer className="w-4 h-4" />}
            checked={securitySettings.sessionTimeout}
            onChange={(checked) => updateSecuritySetting('sessionTimeout', checked)}
            storageKey="sessionTimeout"
          />
          
          <ToggleSetting
            title="2FA Authentication"
            description="Require Google Authenticator"
            icon={<Key className="w-4 h-4" />}
            checked={securitySettings.twoFactorAuth}
            onChange={(checked) => updateSecuritySetting('twoFactorAuth', checked)}
            storageKey="twoFactorAuth"
          />
          
          <ToggleSetting
            title="Auto Lock"
            description="Lock screen when inactive"
            icon={<Lock className="w-4 h-4" />}
            checked={securitySettings.autoLock}
            onChange={(checked) => updateSecuritySetting('autoLock', checked)}
            storageKey="autoLock"
          />
          
          <ToggleSetting
            title="Biometric Authentication"
            description="Use fingerprint/face ID"
            icon={<Fingerprint className="w-4 h-4" />}
            checked={securitySettings.biometricAuth}
            onChange={(checked) => updateSecuritySetting('biometricAuth', checked)}
            storageKey="biometricAuth"
          />
        </div>

        {/* Backup Actions */}
        <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Data Management
          </h3>
          <div className="telegram-btn-group flex space-x-3">
            <button
              onClick={handleBackupNow}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition-colors telegram-btn primary"
            >
              <CloudUpload className="w-4 h-4 mr-2" />
              Backup Now
            </button>
            <button
              onClick={handleRestore}
              className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 transition-colors telegram-btn secondary"
            >
              <CloudDownload className="w-4 h-4 mr-2" />
              Restore
            </button>
          </div>
        </div>

        {/* Security Info */}
        <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
            Security Features
          </h4>
          <ul className="text-sm text-blue-700 dark:text-blue-200 space-y-1">
            <li>• All data is encrypted using AES-256 encryption</li>
            <li>• Session tokens expire automatically for security</li>
            <li>• Two-factor authentication adds extra protection</li>
            <li>• Biometric authentication for quick access</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
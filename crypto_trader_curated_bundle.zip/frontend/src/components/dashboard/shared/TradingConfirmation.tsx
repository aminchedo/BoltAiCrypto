import React from 'react';
import { CheckCircle, AlertTriangle, Settings, Zap } from 'lucide-react';
import { useUserStore } from '@/store/userStore';
import { ToggleSetting } from './ToggleSetting';

export function TradingConfirmation() {
  const { tradingSettings, updateTradingSetting } = useUserStore();

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow telegram-card">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <CheckCircle className="w-6 h-6 text-blue-500 mr-3" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white telegram-header">
            ⚡ Trading Execution
          </h2>
        </div>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Configure how trades are executed and confirmed
        </p>
      </div>

      <div className="p-6 space-y-6">
        {/* Trading Execution Settings */}
        <div className="telegram-toggle-group space-y-4">
          <ToggleSetting
            title="Confirm Trades"
            description="Manual confirmation before execution"
            icon={<AlertTriangle className="w-4 h-4" />}
            checked={tradingSettings.confirmTrades}
            onChange={(checked) => updateTradingSetting('confirmTrades', checked)}
            storageKey="confirmTrades"
          />
          
          <ToggleSetting
            title="Quick Execution"
            description="Fast trade execution without delays"
            icon={<Zap className="w-4 h-4" />}
            checked={!tradingSettings.confirmTrades} // Inverse logic
            onChange={(checked) => updateTradingSetting('confirmTrades', !checked)}
            storageKey="quickExecution"
          />
        </div>

        {/* Confirmation Modal Preview */}
        <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Confirmation Preview
          </h3>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                Confirm Trade
              </h4>
              <Settings className="w-4 h-4 text-gray-400" />
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Pair:</span>
                <span className="text-gray-900 dark:text-white">BTC/USDT</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Amount:</span>
                <span className="text-gray-900 dark:text-white">0.01 BTC</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Price:</span>
                <span className="text-gray-900 dark:text-white">$45,000</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total:</span>
                <span className="text-gray-900 dark:text-white">$450.00</span>
              </div>
            </div>
            <div className="flex space-x-2 mt-4">
              <button className="flex-1 px-3 py-2 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors">
                Execute Trade
              </button>
              <button className="flex-1 px-3 py-2 bg-gray-600 text-white text-sm rounded-md hover:bg-gray-700 transition-colors">
                Review
              </button>
            </div>
          </div>
        </div>

        {/* Trading Info */}
        <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
            Trading Execution
          </h4>
          <ul className="text-sm text-blue-700 dark:text-blue-200 space-y-1">
            <li>• Manual confirmation provides extra security</li>
            <li>• Quick execution enables faster trading</li>
            <li>• Review all trade details before confirming</li>
            <li>• Settings apply to all trading activities</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Types
export interface TradingPosition {
  id: string;
  symbol: string;
  side: 'buy' | 'sell';
  size: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  timestamp: Date;
  status: 'open' | 'closed';
}

export interface TradingOrder {
  id: string;
  symbol: string;
  type: 'market' | 'limit' | 'stop';
  side: 'buy' | 'sell';
  size: number;
  price?: number;
  status: 'pending' | 'filled' | 'cancelled';
  timestamp: Date;
}

export interface TradingAccount {
  balance: number;
  equity: number;
  margin: number;
  freeMargin: number;
  marginLevel: number;
  unrealizedPnL: number;
}

export interface TradingContextValue {
  // Account
  account: TradingAccount;
  
  // Positions
  positions: TradingPosition[];
  openPositions: TradingPosition[];
  
  // Orders
  orders: TradingOrder[];
  pendingOrders: TradingOrder[];
  
  // Trading functions
  openPosition: (symbol: string, side: 'buy' | 'sell', size: number, price: number) => Promise<void>;
  closePosition: (positionId: string) => Promise<void>;
  placeOrder: (order: Omit<TradingOrder, 'id' | 'timestamp' | 'status'>) => Promise<void>;
  cancelOrder: (orderId: string) => Promise<void>;
  
  // State
  isLoading: boolean;
  error: string | null;
  
  // Settings
  riskLevel: 'low' | 'medium' | 'high';
  setRiskLevel: (level: 'low' | 'medium' | 'high') => void;
  autoTrade: boolean;
  setAutoTrade: (enabled: boolean) => void;
}

const TradingContext = createContext<TradingContextValue | undefined>(undefined);

export const useTradingContext = () => {
  const context = useContext(TradingContext);
  if (!context) {
    throw new Error('useTradingContext must be used within a TradingProvider');
  }
  return context;
};

interface TradingProviderProps {
  children: ReactNode;
}

export const TradingProvider: React.FC<TradingProviderProps> = ({ children }) => {
  const [account, setAccount] = useState<TradingAccount>({
    balance: 50000,
    equity: 52500,
    margin: 10000,
    freeMargin: 42500,
    marginLevel: 525,
    unrealizedPnL: 2500
  });

  const [positions, setPositions] = useState<TradingPosition[]>([
    {
      id: 'pos_1',
      symbol: 'BTC/USDT',
      side: 'buy',
      size: 0.5,
      entryPrice: 65000,
      currentPrice: 67000,
      pnl: 1000,
      pnlPercent: 3.08,
      timestamp: new Date(Date.now() - 3600000),
      status: 'open'
    },
    {
      id: 'pos_2',
      symbol: 'ETH/USDT',
      side: 'buy',
      size: 2.0,
      entryPrice: 3200,
      currentPrice: 3450,
      pnl: 500,
      pnlPercent: 7.81,
      timestamp: new Date(Date.now() - 7200000),
      status: 'open'
    }
  ]);

  const [orders, setOrders] = useState<TradingOrder[]>([
    {
      id: 'order_1',
      symbol: 'SOL/USDT',
      type: 'limit',
      side: 'buy',
      size: 10,
      price: 145,
      status: 'pending',
      timestamp: new Date(Date.now() - 1800000)
    }
  ]);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [riskLevel, setRiskLevel] = useState<'low' | 'medium' | 'high'>('medium');
  const [autoTrade, setAutoTrade] = useState(false);

  // Computed values
  const openPositions = positions.filter(pos => pos.status === 'open');
  const pendingOrders = orders.filter(order => order.status === 'pending');

  // Update positions with current market prices (simulated)
  useEffect(() => {
    const interval = setInterval(() => {
      setPositions(prev => prev.map(position => {
        if (position.status === 'open') {
          // Simulate price movement
          const volatility = 0.01; // 1% volatility
          const change = (Math.random() - 0.5) * 2 * volatility;
          const newPrice = position.currentPrice * (1 + change);
          const pnl = (newPrice - position.entryPrice) * position.size * (position.side === 'buy' ? 1 : -1);
          const pnlPercent = (pnl / (position.entryPrice * position.size)) * 100;

          return {
            ...position,
            currentPrice: newPrice,
            pnl,
            pnlPercent
          };
        }
        return position;
      }));
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, []);

  // Trading functions
  const openPosition = async (symbol: string, side: 'buy' | 'sell', size: number, price: number): Promise<void> => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      const newPosition: TradingPosition = {
        id: `pos_${Date.now()}`,
        symbol,
        side,
        size,
        entryPrice: price,
        currentPrice: price,
        pnl: 0,
        pnlPercent: 0,
        timestamp: new Date(),
        status: 'open'
      };

      setPositions(prev => [...prev, newPosition]);
      
      // Update account balance
      const requiredMargin = price * size * 0.1; // 10% margin
      setAccount(prev => ({
        ...prev,
        margin: prev.margin + requiredMargin,
        freeMargin: prev.freeMargin - requiredMargin
      }));

      console.log('✅ Position opened:', newPosition);
    } catch (err) {
      setError('Failed to open position');
      console.error('❌ Error opening position:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const closePosition = async (positionId: string): Promise<void> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));

      const position = positions.find(pos => pos.id === positionId);
      if (!position) {
        throw new Error('Position not found');
      }

      setPositions(prev => prev.map(pos => 
        pos.id === positionId 
          ? { ...pos, status: 'closed' as const }
          : pos
      ));

      // Update account with realized PnL
      const requiredMargin = position.entryPrice * position.size * 0.1;
      setAccount(prev => ({
        ...prev,
        balance: prev.balance + position.pnl,
        equity: prev.equity + position.pnl,
        margin: prev.margin - requiredMargin,
        freeMargin: prev.freeMargin + requiredMargin,
        unrealizedPnL: prev.unrealizedPnL - position.pnl
      }));

      console.log('✅ Position closed:', position);
    } catch (err) {
      setError('Failed to close position');
      console.error('❌ Error closing position:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const placeOrder = async (orderData: Omit<TradingOrder, 'id' | 'timestamp' | 'status'>): Promise<void> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));

      const newOrder: TradingOrder = {
        ...orderData,
        id: `order_${Date.now()}`,
        timestamp: new Date(),
        status: 'pending'
      };

      setOrders(prev => [...prev, newOrder]);
      console.log('✅ Order placed:', newOrder);
    } catch (err) {
      setError('Failed to place order');
      console.error('❌ Error placing order:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const cancelOrder = async (orderId: string): Promise<void> => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));

      setOrders(prev => prev.map(order => 
        order.id === orderId 
          ? { ...order, status: 'cancelled' as const }
          : order
      ));

      console.log('✅ Order cancelled:', orderId);
    } catch (err) {
      setError('Failed to cancel order');
      console.error('❌ Error cancelling order:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const value: TradingContextValue = {
    account,
    positions,
    openPositions,
    orders,
    pendingOrders,
    openPosition,
    closePosition,
    placeOrder,
    cancelOrder,
    isLoading,
    error,
    riskLevel,
    setRiskLevel,
    autoTrade,
    setAutoTrade
  };

  return (
    <TradingContext.Provider value={value}>
      {children}
    </TradingContext.Provider>
  );
};

export default TradingContext;
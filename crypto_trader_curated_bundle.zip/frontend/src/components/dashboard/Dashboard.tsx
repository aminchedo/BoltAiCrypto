'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './Sidebar';
import Header from './Header';
import MainContent from './MainContent';
import { useTheme } from 'next-themes';
import { useMarketStore } from '@/lib/stores/marketStore';
import { usePortfolioStore } from '@/lib/stores/portfolioStore';
import { useSignalStore } from '@/lib/stores/signalStore';

interface DashboardState {
  sidebarCollapsed: boolean;
  isLoading: boolean;
  currentTheme: 'dark' | 'blue' | 'green';
  notifications: number;
  isFullscreen: boolean;
  connectionStatus: 'connected' | 'connecting' | 'disconnected';
  lastDataUpdate: Date;
}

const Dashboard: React.FC = () => {
  const [dashboardState, setDashboardState] = useState<DashboardState>({
    sidebarCollapsed: false,
    isLoading: true,
    currentTheme: 'dark',
    notifications: 0,
    isFullscreen: false,
    connectionStatus: 'connecting',
    lastDataUpdate: new Date()
  });

  const { fetchMarkets, isLoading: marketLoading } = useMarketStore();
  const { fetchPortfolio, isLoading: portfolioLoading } = usePortfolioStore();
  const { fetchSignals, isLoading: signalLoading } = useSignalStore();

  useEffect(() => {
    const loadData = async () => {
      setDashboardState(prev => ({ ...prev, isLoading: true }));
      try {
        await Promise.all([
          fetchMarkets(),
          fetchPortfolio(),
          fetchSignals(),
        ]);
        setDashboardState(prev => ({ 
          ...prev, 
          isLoading: false, 
          connectionStatus: 'connected',
          lastDataUpdate: new Date(),
        }));
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
        setDashboardState(prev => ({ ...prev, isLoading: false, connectionStatus: 'disconnected' }));
      }
    };

    loadData();
  }, [fetchMarkets, fetchPortfolio, fetchSignals]);


  // Connection status simulation
  useEffect((): (() => void) | void => {
    if (!dashboardState.isLoading) {
      const interval = setInterval(() => {
        // Simulate occasional connection issues
        if (Math.random() > 0.98) {
          setDashboardState(prev => ({ ...prev, connectionStatus: 'connecting' }));
          setTimeout(() => {
            setDashboardState(prev => ({ ...prev, connectionStatus: 'connected' }));
          }, 2000);
        }
        
        // Update last data timestamp
        setDashboardState(prev => ({ ...prev, lastDataUpdate: new Date() }));
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [dashboardState.isLoading]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'b':
            e.preventDefault();
            toggleSidebar();
            break;
          case 'f':
            e.preventDefault();
            toggleFullscreen();
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  const toggleSidebar = useCallback(() => {
    setDashboardState(prev => ({
      ...prev,
      sidebarCollapsed: !prev.sidebarCollapsed
    }));
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setDashboardState(prev => ({ ...prev, isFullscreen: true }));
    } else {
      document.exitFullscreen();
      setDashboardState(prev => ({ ...prev, isFullscreen: false }));
    }
  }, []);

  const changeTheme = useCallback((theme: 'dark' | 'blue' | 'green') => {
    setDashboardState(prev => ({ ...prev, currentTheme: theme }));
  }, []);

  const getThemeClasses = () => {
    const themes = {
      dark: 'from-gray-900 via-gray-800 to-black',
      blue: 'from-blue-900 via-blue-800 to-indigo-900',
      green: 'from-emerald-900 via-teal-800 to-green-900'
    };
    return themes[dashboardState.currentTheme];
  };

  if (dashboardState.isLoading || marketLoading || portfolioLoading || signalLoading) {
    return (
      <div className={`flex h-screen bg-gradient-to-br ${getThemeClasses()} items-center justify-center`}>
        <div className="text-center">
          <div className="w-20 h-20 mx-auto bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-3xl font-bold text-white shadow-2xl animate-spin">
            🤖
          </div>
          <h2 className="mt-4 text-2xl font-semibold text-white">Loading Dashboard...</h2>
          <p className="text-gray-400">Fetching data, please wait.</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className={`flex h-screen bg-gradient-to-br ${getThemeClasses()} overflow-hidden relative`}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(16,185,129,0.05),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.05),transparent_50%)]" />
      </div>

      {/* Connection Status Overlay */}
      <AnimatePresence>
        {dashboardState.connectionStatus === 'connecting' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-4 right-4 z-50 bg-yellow-500/90 text-black px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
          >
            <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
            <span>Reconnecting...</span>
          </motion.div>
        )}
        
        {dashboardState.connectionStatus === 'disconnected' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-4 right-4 z-50 bg-red-500/90 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
          >
            <div className="w-2 h-2 bg-white rounded-full" />
            <span>Connection Lost</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence mode="wait">
        <motion.div
          key={dashboardState.sidebarCollapsed ? 'collapsed' : 'expanded'}
          initial={{ width: dashboardState.sidebarCollapsed ? 80 : 280 }}
          animate={{ width: dashboardState.sidebarCollapsed ? 80 : 280 }}
          exit={{ width: dashboardState.sidebarCollapsed ? 280 : 80 }}
          transition={{ 
            type: "spring", 
            stiffness: 300, 
            damping: 30,
            duration: 0.3 
          }}
          className="relative z-10"
        >
          <Sidebar
            collapsed={dashboardState.sidebarCollapsed}
            onToggle={toggleSidebar}
            currentTheme={dashboardState.currentTheme}
            onThemeChange={changeTheme}
            connectionStatus={dashboardState.connectionStatus}
          />
        </motion.div>
      </AnimatePresence>

      {/* Main Content Area */}
      <motion.div
        className="flex-1 flex flex-col relative z-10"
        initial={{ x: 20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <Header 
          onMenuClick={toggleSidebar}
          onFullscreenToggle={toggleFullscreen}
          connectionStatus={dashboardState.connectionStatus}
          currentTheme={dashboardState.currentTheme}
          onThemeChange={changeTheme}
          isFullscreen={dashboardState.isFullscreen}
          lastUpdate={dashboardState.lastDataUpdate}
        />
        
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="flex-1"
        >
          <MainContent 
            currentTheme={dashboardState.currentTheme}
            connectionStatus={dashboardState.connectionStatus}
          />
        </motion.div>
      </motion.div>

      {/* Keyboard Shortcuts Help */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="absolute bottom-4 left-4 text-xs text-gray-500 bg-black/20 backdrop-blur-sm rounded-lg p-2 space-y-1"
      >
        <div>Ctrl+B: Toggle Sidebar</div>
        <div>Ctrl+F: Fullscreen</div>
      </motion.div>

      {/* Performance Monitor */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-4 right-4 text-xs text-gray-500 bg-black/20 backdrop-blur-sm rounded-lg p-2"
      >
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${
            dashboardState.connectionStatus === 'connected' ? 'bg-green-500' : 
            dashboardState.connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
          }`} />
          <span>
            Last Update: {dashboardState.lastDataUpdate.toLocaleTimeString()}
          </span>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Dashboard;
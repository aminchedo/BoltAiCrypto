import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  X, 
  Maximize2, 
  Minimize2, 
  ExternalLink,
  Zap,
  Database,
  Cloud,
  Activity,
  Target
} from 'lucide-react';
import { marketService } from '@/services/marketService';
import { signalService } from '@/services/signalService';
import { realDataService } from '@/services/realDataService';

// Import AI Components
import { 
  AIAnalyticsModule,
  AdvancedAITab,
  LivePredictionsTab,
  ModelStorageTab,
  CloudBackupTab
} from '../ai';

interface AIIntegrationProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: string;
}

interface AIModule {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  component: React.ComponentType<any>;
  color: string;
  status: 'active' | 'ready' | 'training';
}

export const AIIntegration: React.FC<AIIntegrationProps> = ({ 
  isOpen, 
  onClose, 
  initialTab = 'main' 
}) => {
  const [activeModule, setActiveModule] = useState(initialTab);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const aiModules: AIModule[] = [
    {
      id: 'main',
      name: 'AI Analytics Laboratory',
      description: 'Complete AI training and analytics suite',
      icon: <Brain className="w-6 h-6" />,
      component: AIAnalyticsModule,
      color: 'from-purple-500 to-pink-500',
      status: 'active'
    },
    {
      id: 'advanced',
      name: 'Advanced AI Methods',
      description: 'Cutting-edge machine learning techniques',
      icon: <Zap className="w-6 h-6" />,
      component: AdvancedAITab,
      color: 'from-blue-500 to-cyan-500',
      status: 'ready'
    },
    {
      id: 'predictions',
      name: 'Live Predictions',
      description: 'Real-time AI trading predictions',
      icon: <Activity className="w-6 h-6" />,
      component: LivePredictionsTab,
      color: 'from-green-500 to-teal-500',
      status: 'active'
    },
    {
      id: 'storage',
      name: 'Model Storage',
      description: 'Manage and organize AI models',
      icon: <Database className="w-6 h-6" />,
      component: ModelStorageTab,
      color: 'from-orange-500 to-red-500',
      status: 'ready'
    },
    {
      id: 'cloud',
      name: 'Cloud Backup',
      description: 'Cloud synchronization and backup',
      icon: <Cloud className="w-6 h-6" />,
      component: CloudBackupTab,
      color: 'from-indigo-500 to-purple-500',
      status: 'ready'
    }
  ];

  const currentModule = aiModules.find(m => m.id === activeModule) || aiModules[0];
  const CurrentComponent = currentModule.component;

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className={`bg-gray-900 rounded-2xl border border-gray-700 shadow-2xl overflow-hidden ${
            isFullscreen ? 'w-full h-full' : 'w-[95vw] h-[90vh] max-w-7xl'
          }`}
        >
          {/* Header */}
          <div className="bg-gray-800/50 border-b border-gray-700 p-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`p-2 rounded-lg bg-gradient-to-r ${currentModule.color}`}>
                {currentModule.icon}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{currentModule.name}</h2>
                <p className="text-sm text-gray-400">{currentModule.description}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                currentModule.status === 'active' ? 'bg-green-500/20 text-green-400' :
                currentModule.status === 'training' ? 'bg-yellow-500/20 text-yellow-400' :
                'bg-gray-500/20 text-gray-400'
              }`}>
                {currentModule.status.toUpperCase()}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              >
                {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
              </button>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex h-full">
            {/* Module Selector Sidebar */}
            <div className="w-64 bg-gray-800/30 border-r border-gray-700 p-4 space-y-2">
              <h3 className="text-sm font-semibold text-gray-400 mb-4">AI MODULES</h3>
              {aiModules.map((module) => (
                <motion.button
                  key={module.id}
                  onClick={() => setActiveModule(module.id)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`w-full p-3 rounded-lg text-left transition-all ${
                    activeModule === module.id
                      ? 'bg-gradient-to-r ' + module.color + ' text-white shadow-lg'
                      : 'bg-gray-700/30 hover:bg-gray-700/50 text-gray-300'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    {module.icon}
                    <div className="flex-1">
                      <div className="font-medium text-sm">{module.name}</div>
                      <div className="text-xs opacity-75">{module.description}</div>
                    </div>
                  </div>
                  <div className={`mt-2 text-xs px-2 py-1 rounded-full inline-block ${
                    module.status === 'active' ? 'bg-green-500/20 text-green-400' :
                    module.status === 'training' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-gray-500/20 text-gray-400'
                  }`}>
                    {module.status}
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeModule}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="h-full overflow-y-auto"
                >
                  <CurrentComponent />
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// Quick Access AI Button Component
export const AIQuickAccess: React.FC<{ onClick: () => void }> = ({ onClick }) => {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white p-4 rounded-full shadow-2xl z-40 flex items-center space-x-2"
    >
      <Brain className="w-6 h-6" />
      <span className="font-bold">AI Lab</span>
    </motion.button>
  );
};

export default AIIntegration;
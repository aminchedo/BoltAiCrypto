import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// Sidebar Component
const Sidebar = ({ collapsed, onToggle, currentTheme = 'dark', connectionStatus = 'connected' }) => {
  const [activeItem, setActiveItem] = useState('dashboard');
  
  const navigationItems = [
    { id: 'dashboard', name: 'Dashboard', icon: '📊', color: 'text-blue-400' },
    { id: 'trading', name: 'Trading', icon: '📈', color: 'text-green-400' },
    { id: 'portfolio', name: 'Portfolio', icon: '💼', color: 'text-purple-400' },
    { id: 'signals', name: 'AI Signals', icon: '🧠', color: 'text-yellow-400', badge: 23 },
    { id: 'analytics', name: 'Analytics', icon: '📋', color: 'text-cyan-400' },
    { id: 'settings', name: 'Settings', icon: '⚙️', color: 'text-gray-400' }
  ];

  return (
    <motion.aside
      initial={{ width: collapsed ? 80 : 280 }}
      animate={{ width: collapsed ? 80 : 280 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="bg-gradient-to-b from-gray-950 to-gray-900 backdrop-blur-xl border-r border-white/10 text-white flex flex-col relative shadow-2xl"
    >
      {/* Header */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <AnimatePresence mode="wait">
            {!collapsed ? (
              <motion.div
                key="expanded"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex items-center text-2xl font-bold"
              >
                <motion.span 
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  className="mr-3 text-3xl"
                >
                  🤖
                </motion.span>
                <div>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-400">
                    AiSmart
                  </span>
                  <span className="ml-1 text-gray-300">Pro</span>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="collapsed"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-3xl"
              >
                🤖
              </motion.div>
            )}
          </AnimatePresence>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onToggle}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            {collapsed ? '▶️' : '◀️'}
          </motion.button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => (
          <motion.button
            key={item.id}
            onClick={() => setActiveItem(item.id)}
            whileHover={{ scale: 1.02, x: 4 }}
            whileTap={{ scale: 0.98 }}
            className={`w-full p-3 text-left flex items-center justify-between rounded-xl transition-all duration-200 ${
              activeItem === item.id
                ? 'bg-gradient-to-r from-green-600/20 to-blue-600/20 text-green-400 border border-green-500/30 shadow-lg'
                : 'hover:bg-white/5 text-gray-300 hover:text-white'
            }`}
          >
            <div className="flex items-center space-x-3">
              <span className="text-xl">{item.icon}</span>
              <AnimatePresence mode="wait">
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="font-medium"
                  >
                    {item.name}
                  </motion.span>
                )}
              </AnimatePresence>
            </div>

            <AnimatePresence mode="wait">
              {!collapsed && item.badge && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold"
                >
                  {item.badge}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        ))}
      </nav>

      {/* AI Status */}
      <div className="p-4 border-t border-white/10">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="flex items-center space-x-3 p-3 bg-gray-800/30 rounded-xl"
        >
          <motion.span
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="relative flex h-3 w-3"
          >
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
            <span className="inline-flex rounded-full h-3 w-3 bg-green-500" />
          </motion.span>
          
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="text-green-400 text-sm"
              >
                AI Engine Online
              </motion.span>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </motion.aside>
  );
};

// Header Component
const Header = ({ onMenuClick, connectionStatus = 'connected' }) => {
  const [balance, setBalance] = useState(127845.32);
  const [change, setChange] = useState(2341.22);
  const [changePercent, setChangePercent] = useState(1.87);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = (Math.random() - 0.5) * 100;
      setChange(prev => prev + randomChange);
      setBalance(prev => prev + randomChange);
      setChangePercent(prev => prev + (Math.random() - 0.5) * 0.1);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleTrade = (action) => {
    console.log(`${action} trade executed`);
  };

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="h-[80px] border-b border-white/10 flex items-center justify-between px-6 text-white bg-gray-900/50 backdrop-blur-xl"
    >
      {/* Left Section */}
      <div className="flex items-center space-x-6">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onMenuClick}
          className="p-2 rounded-xl hover:bg-white/10 transition-colors"
        >
          ☰
        </motion.button>

        <div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            Professional Dashboard
          </h1>
          <p className="text-xs text-gray-400">Real-time trading platform</p>
        </div>
      </div>

      {/* Center Section - Trading Controls */}
      <div className="flex items-center space-x-3">
        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleTrade('BUY')}
          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-green-500/25"
        >
          📈 BUY
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleTrade('SELL')}
          className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-red-500/25"
        >
          📉 SELL
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleTrade('AUTO')}
          className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-blue-500/25"
        >
          ⚡ AI AUTO
        </motion.button>
      </div>

      {/* Right Section */}
      <div className="flex items-center space-x-4">
        {/* Connection Status */}
        <motion.div className="flex items-center space-x-2 bg-gray-800/50 rounded-xl px-3 py-2">
          <div className={`w-2 h-2 rounded-full ${
            connectionStatus === 'connected' ? 'bg-green-500' : 'bg-red-500'
          }`} />
          <span className="text-sm font-medium text-green-400">LIVE</span>
        </motion.div>

        {/* Balance Display */}
        <motion.div
          key={balance}
          initial={{ scale: 1.05, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-right bg-gray-800/50 rounded-xl px-4 py-2"
        >
          <div className="text-lg font-mono font-bold">
            ${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className={`text-xs flex items-center space-x-1 ${
            changePercent >= 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            <span>{changePercent >= 0 ? '📈' : '📉'}</span>
            <span>
              {changePercent >= 0 ? '+' : ''}${Math.abs(change).toLocaleString('en-US', { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
              })} ({changePercent >= 0 ? '+' : ''}{changePercent.toFixed(2)}%)
            </span>
          </div>
        </motion.div>

        {/* User Profile */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center cursor-pointer"
        >
          <span className="text-lg">👤</span>
        </motion.div>
      </div>
    </motion.header>
  );
};

// Trading Chart Widget
const TradingChart = () => {
  const [price, setPrice] = useState(67234.45);
  const [change, setChange] = useState(1234.45);
  const [isPositive, setIsPositive] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = (Math.random() - 0.5) * 500;
      setPrice(prev => prev + randomChange);
      setChange(prev => prev + randomChange);
      setIsPositive(randomChange >= 0);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.01 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl h-full"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
          BTC/USDT Live Chart
        </h2>
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-green-400 text-sm font-medium">LIVE</span>
        </div>
      </div>

      <div className="mb-4">
        <motion.div
          key={price}
          initial={{ scale: 1.05, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-3xl font-mono font-bold mb-2"
        >
          ${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </motion.div>
        
        <div className={`flex items-center space-x-2 ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
          <span>{isPositive ? '📈' : '📉'}</span>
          <span className="font-semibold">
            {isPositive ? '+' : ''}${Math.abs(change).toLocaleString('en-US', { 
              minimumFractionDigits: 2, 
              maximumFractionDigits: 2 
            })} ({isPositive ? '+' : ''}{((change / price) * 100).toFixed(2)}%)
          </span>
        </div>
      </div>

      {/* Mock Chart Area */}
      <div className="h-48 bg-gray-800/30 rounded-xl mb-4 flex items-center justify-center border border-white/5">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <div className="text-gray-400">Interactive Trading Chart</div>
          <div className="text-sm text-gray-500">Real-time price movements</div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: '24h High', value: '$68,234', color: 'text-green-400' },
          { label: '24h Low', value: '$66,123', color: 'text-red-400' },
          { label: 'Volume', value: '$2.4B', color: 'text-blue-400' },
          { label: 'Market Cap', value: '$1.32T', color: 'text-purple-400' }
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="text-center p-3 bg-gray-700/30 rounded-xl"
          >
            <div className="text-gray-400 text-xs mb-1">{stat.label}</div>
            <div className={`font-bold ${stat.color}`}>{stat.value}</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

// Portfolio Summary Widget
const PortfolioSummary = () => {
  const [portfolioValue, setPortfolioValue] = useState(127845.32);
  const [change, setChange] = useState(2341.22);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = (Math.random() - 0.5) * 500;
      setPortfolioValue(prev => prev + randomChange);
      setChange(prev => prev + randomChange);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.02 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl h-full"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
          Portfolio Overview
        </h2>
        <span className="text-2xl">💼</span>
      </div>

      <motion.div
        key={portfolioValue}
        initial={{ scale: 1.05, opacity: 0.8 }}
        animate={{ scale: 1, opacity: 1 }}
        className="mb-6"
      >
        <div className="text-3xl font-mono font-bold mb-2">
          ${portfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <div className="text-green-400 flex items-center space-x-2">
          <span>📈</span>
          <span>+${change.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (+1.87%)</span>
        </div>
      </motion.div>

      {/* Asset Breakdown */}
      <div className="space-y-3 mb-6">
        {[
          { symbol: 'BTC', name: 'Bitcoin', value: 45, color: 'bg-orange-500' },
          { symbol: 'ETH', name: 'Ethereum', value: 30, color: 'bg-blue-500' },
          { symbol: 'SOL', name: 'Solana', value: 15, color: 'bg-purple-500' },
          { symbol: 'Others', name: 'Other Assets', value: 10, color: 'bg-gray-500' }
        ].map((asset, index) => (
          <motion.div
            key={asset.symbol}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center justify-between"
          >
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${asset.color}`} />
              <span className="font-medium">{asset.name}</span>
            </div>
            <span className="text-gray-400">{asset.value}%</span>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-green-600 hover:bg-green-500 px-4 py-3 rounded-xl font-semibold transition-colors"
        >
          💰 Deposit
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-blue-600 hover:bg-blue-500 px-4 py-3 rounded-xl font-semibold transition-colors"
        >
          📤 Withdraw
        </motion.button>
      </div>
    </motion.div>
  );
};

// Live Signals Widget
const LiveSignals = () => {
  const [signals, setSignals] = useState([
    { id: '1', symbol: 'BTC/USDT', signal: 'BUY', confidence: 87, price: 67234.45 },
    { id: '2', symbol: 'ETH/USDT', signal: 'SELL', confidence: 73, price: 3845.67 },
    { id: '3', symbol: 'SOL/USDT', signal: 'BUY', confidence: 91, price: 178.90 }
  ]);

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.01 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl h-full"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          AI Live Signals
        </h2>
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-green-400 text-sm">🧠 ACTIVE</span>
        </div>
      </div>

      <div className="space-y-3">
        {signals.map((signal, index) => (
          <motion.div
            key={signal.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
            className="bg-gray-700/40 rounded-xl p-4 border border-white/10 hover:border-white/20 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="font-bold text-lg">{signal.symbol}</span>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  signal.signal === 'BUY'
                    ? 'bg-green-600 text-white'
                    : 'bg-red-600 text-white'
                }`}
              >
                {signal.signal === 'BUY' ? '📈' : '📉'} {signal.signal}
              </motion.button>
            </div>
            
            <div className="flex items-center justify-between text-sm mb-3">
              <span className="text-gray-400">Price: ${signal.price.toLocaleString()}</span>
              <span className="text-gray-400">Confidence: {signal.confidence}%</span>
            </div>

            {/* Confidence Bar */}
            <div className="bg-gray-600 rounded-full h-2">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${signal.confidence}%` }}
                transition={{ duration: 1, delay: 0.5 }}
                className={`h-2 rounded-full ${
                  signal.signal === 'BUY' ? 'bg-green-500' : 'bg-red-500'
                }`}
              />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Stats */}
      <div className="mt-6 pt-4 border-t border-white/10">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="text-center">
            <div className="text-gray-400">Success Rate</div>
            <div className="text-green-400 font-bold text-lg">87.3%</div>
          </div>
          <div className="text-center">
            <div className="text-gray-400">Active Signals</div>
            <div className="text-blue-400 font-bold text-lg">23</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// Market Overview Widget
const MarketOverview = () => {
  const [fearGreed, setFearGreed] = useState(67);
  const [marketCap, setMarketCap] = useState(2.67);

  useEffect(() => {
    const interval = setInterval(() => {
      setFearGreed(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 5)));
      setMarketCap(prev => prev + (Math.random() - 0.5) * 0.1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.005 }}
      className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl h-full"
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
          Global Market Overview
        </h2>
        <span className="text-2xl">🌍</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Fear & Greed Index */}
        <div className="bg-gray-700/30 rounded-xl p-4">
          <h3 className="font-semibold mb-3">Fear & Greed Index</h3>
          <div className={`text-3xl font-bold mb-2 ${
            fearGreed >= 75 ? 'text-green-400' :
            fearGreed >= 50 ? 'text-yellow-400' : 'text-red-400'
          }`}>
            {fearGreed}
          </div>
          <div className="text-sm text-gray-400 mb-3">
            {fearGreed >= 75 ? 'Extreme Greed' :
             fearGreed >= 50 ? 'Greed' : 'Fear'}
          </div>
          <div className="bg-gray-600 rounded-full h-2">
            <motion.div
              animate={{ width: `${fearGreed}%` }}
              transition={{ duration: 1 }}
              className={`h-2 rounded-full ${
                fearGreed >= 75 ? 'bg-green-500' :
                fearGreed >= 50 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
            />
          </div>
        </div>

        {/* Market Stats */}
        <div className="space-y-4">
          <div className="bg-gray-700/30 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Total Market Cap</span>
              <span className="text-2xl font-bold text-green-400">
                ${marketCap.toFixed(2)}T
              </span>
            </div>
          </div>
          
          <div className="bg-gray-700/30 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">24h Volume</span>
              <span className="text-xl font-bold text-blue-400">$89.2B</span>
            </div>
          </div>
        </div>
      </div>

      {/* Top Movers */}
      <div className="mt-6">
        <h3 className="font-semibold mb-3">Top Movers</h3>
        <div className="space-y-2">
          {[
            { symbol: 'SOL', change: 15.2, color: 'text-green-400' },
            { symbol: 'AVAX', change: 11.8, color: 'text-green-400' },
            { symbol: 'DOT', change: -8.4, color: 'text-red-400' }
          ].map((coin, index) => (
            <motion.div
              key={coin.symbol}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between text-sm"
            >
              <span className="font-medium">{coin.symbol}</span>
              <span className={coin.color}>
                {coin.change >= 0 ? '+' : ''}{coin.change}%
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

// Main Dashboard Component
const Dashboard = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black overflow-hidden">
      {/* Sidebar */}
      <Sidebar
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <Header onMenuClick={() => setSidebarCollapsed(!sidebarCollapsed)} />
        
        {/* Dashboard Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 overflow-auto"
        >
          {/* Portfolio Summary */}
          <div className="lg:col-span-1">
            <PortfolioSummary />
          </div>

          {/* Live Signals */}
          <div className="lg:col-span-1">
            <LiveSignals />
          </div>

          {/* Trading Chart */}
          <div className="lg:col-span-1">
            <TradingChart />
          </div>

          {/* Market Overview - Full Width */}
          <div className="lg:col-span-3">
            <MarketOverview />
          </div>
        </motion.div>
      </div>

      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(16,185,129,0.05),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.05),transparent_50%)]" />
      </div>
    </div>
  );
};

export default Dashboard;
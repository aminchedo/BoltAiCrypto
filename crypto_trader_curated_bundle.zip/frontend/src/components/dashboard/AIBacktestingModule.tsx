import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  RefreshCw, 
  X, 
  Maximize2, 
  Minimize2, 
  Calendar, 
  Clock, 
  Settings, 
  Play, 
  Download, 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  Target, 
  ChevronDown, 
  ChevronUp, 
  Zap, 
  Save, 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  ArrowRight, 
  Sliders 
} from 'lucide-react';
import { marketService } from '@/services/marketService';
import { signalService } from '@/services/signalService';

interface AIBacktestingModuleProps {
  isOpen: boolean;
  onClose: () => void;
  initialStrategy?: string;
}

interface BacktestResult {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  netProfit: number;
  netProfitPercent: number;
  maxDrawdown: number;
  sharpeRatio: number;
  averageProfit: number;
  averageLoss: number;
  averageHoldingTime: string;
  bestTrade: number;
  worstTrade: number;
  trades: BacktestTrade[];
}

interface BacktestTrade {
  id: string;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  entryTime: Date;
  exitPrice: number;
  exitTime: Date;
  profit: number;
  profitPercent: number;
  reason: string;
}

interface BacktestParams {
  symbol: string;
  strategy: string;
  startDate: string;
  endDate: string;
  initialCapital: number;
  positionSize: number;
  stopLoss: number;
  takeProfit: number;
  timeframe: string;
  customParams: Record<string, any>;
}

export function AIBacktestingModule({ isOpen, onClose, initialStrategy = 'trend-master' }: AIBacktestingModuleProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showTrades, setShowTrades] = useState(false);
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  
  const [params, setParams] = useState<BacktestParams>({
    symbol: 'BTC/USDT',
    strategy: initialStrategy,
    startDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 90 days ago
    endDate: new Date().toISOString().split('T')[0],
    initialCapital: 10000,
    positionSize: 10,
    stopLoss: 5,
    takeProfit: 15,
    timeframe: '1h',
    customParams: {
      rsiPeriod: 14,
      rsiOverbought: 70,
      rsiOversold: 30,
      macdFast: 12,
      macdSlow: 26,
      macdSignal: 9
    }
  });

  const strategies = [
    { id: 'trend-master', name: 'Trend Master', type: 'trend' },
    { id: 'breakout-hunter', name: 'Breakout Hunter', type: 'pattern' },
    { id: 'smart-reversal', name: 'Smart Reversal', type: 'mean-reversion' },
    { id: 'momentum-surge', name: 'Momentum Surge', type: 'momentum' },
    { id: 'custom', name: 'Custom Strategy', type: 'hybrid' }
  ];

  const symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'ADA/USDT', 'XRP/USDT', 'DOT/USDT', 'DOGE/USDT'];
  const timeframes = ['5m', '15m', '30m', '1h', '4h', '1d'];

  useEffect(() => {
    if (initialStrategy) {
      setParams(prev => ({ ...prev, strategy: initialStrategy }));
    }
  }, [initialStrategy]);

  const handleParamChange = (key: string, value: any) => {
    setParams(prev => ({ ...prev, [key]: value }));
  };

  const handleCustomParamChange = (key: string, value: any) => {
    setParams(prev => ({
      ...prev,
      customParams: {
        ...prev.customParams,
        [key]: value
      }
    }));
  };

  const runBacktest = async () => {
    try {
      setIsRunning(true);
      setProgress(0);
      setError(null);
      setResult(null);
      
      // Simulate progress updates
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 2;
        });
      }, 200);
      
      // In a real implementation, this would call the service to run the backtest
      // For now, simulate a delay and return mock results
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      // Generate mock backtest results
      const mockTrades: BacktestTrade[] = [];
      const startDate = new Date(params.startDate);
      const endDate = new Date(params.endDate);
      const daysDiff = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      
      const totalTrades = Math.floor(daysDiff / 3); // Roughly one trade every 3 days
      let capital = params.initialCapital;
      
      for (let i = 0; i < totalTrades; i++) {
        const isWin = Math.random() > 0.4; // 60% win rate
        const entryTime = new Date(startDate.getTime() + (i * 3 * 24 * 60 * 60 * 1000));
        const holdingHours = Math.floor(Math.random() * 48) + 2; // 2-50 hours
        const exitTime = new Date(entryTime.getTime() + (holdingHours * 60 * 60 * 1000));
        
        const direction = Math.random() > 0.5 ? 'LONG' : 'SHORT';
        const entryPrice = 40000 + (Math.random() * 10000 - 5000);
        
        const profitPercent = isWin 
          ? Math.random() * params.takeProfit
          : -Math.random() * params.stopLoss;
          
        const exitPrice = direction === 'LONG'
          ? entryPrice * (1 + (profitPercent / 100))
          : entryPrice * (1 - (profitPercent / 100));
          
        const positionValue = (params.initialCapital * params.positionSize) / 100;
        const profit = positionValue * (profitPercent / 100);
        
        capital += profit;
        
        mockTrades.push({
          id: `trade-${i}`,
          symbol: params.symbol,
          direction: direction as 'LONG' | 'SHORT',
          entryPrice,
          entryTime,
          exitPrice,
          exitTime,
          profit,
          profitPercent,
          reason: isWin 
            ? `${direction === 'LONG' ? 'Bullish' : 'Bearish'} signal confirmed by ${Math.random() > 0.5 ? 'RSI' : 'MACD'}`
            : `${direction === 'LONG' ? 'Bearish' : 'Bullish'} reversal detected`
        });
      }
      
      // Sort trades by date
      mockTrades.sort((a, b) => a.entryTime.getTime() - b.entryTime.getTime());
      
      // Calculate performance metrics
      const winningTrades = mockTrades.filter(t => t.profit > 0);
      const losingTrades = mockTrades.filter(t => t.profit <= 0);
      
      const totalProfit = mockTrades.reduce((sum, trade) => sum + trade.profit, 0);
      const totalWinnings = winningTrades.reduce((sum, trade) => sum + trade.profit, 0);
      const totalLosses = Math.abs(losingTrades.reduce((sum, trade) => sum + trade.profit, 0));
      
      const profitFactor = totalLosses === 0 ? totalWinnings : totalWinnings / totalLosses;
      
      // Calculate drawdown
      let maxDrawdown = 0;
      let peak = params.initialCapital;
      let currentCapital = params.initialCapital;
      
      for (const trade of mockTrades) {
        currentCapital += trade.profit;
        if (currentCapital > peak) {
          peak = currentCapital;
        }
        
        const drawdown = (peak - currentCapital) / peak * 100;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
      
      const mockResult: BacktestResult = {
        totalTrades: mockTrades.length,
        winningTrades: winningTrades.length,
        losingTrades: losingTrades.length,
        winRate: (winningTrades.length / mockTrades.length) * 100,
        profitFactor,
        netProfit: totalProfit,
        netProfitPercent: (totalProfit / params.initialCapital) * 100,
        maxDrawdown,
        sharpeRatio: (totalProfit / params.initialCapital) / (maxDrawdown / 100) * 0.5,
        averageProfit: winningTrades.length > 0 ? totalWinnings / winningTrades.length : 0,
        averageLoss: losingTrades.length > 0 ? totalLosses / losingTrades.length : 0,
        averageHoldingTime: '18h 24m',
        bestTrade: Math.max(...mockTrades.map(t => t.profit)),
        worstTrade: Math.min(...mockTrades.map(t => t.profit)),
        trades: mockTrades
      };
      
      clearInterval(interval);
      setProgress(100);
      setResult(mockResult);
    } catch (err) {
      console.error('Error running backtest:', err);
      setError('Failed to run backtest');
    } finally {
      setIsRunning(false);
    }
  };

  const handleSaveStrategy = () => {
    // In a real implementation, this would save the strategy configuration
    alert('Strategy saved successfully!');
  };

  const handleExportResults = () => {
    if (!result) return;
    
    // Create CSV content
    let csv = 'ID,Symbol,Direction,Entry Price,Entry Time,Exit Price,Exit Time,Profit,Profit %,Reason\n';
    
    result.trades.forEach(trade => {
      csv += `${trade.id},${trade.symbol},${trade.direction},${trade.entryPrice},${trade.entryTime.toISOString()},${trade.exitPrice},${trade.exitTime.toISOString()},${trade.profit.toFixed(2)},${trade.profitPercent.toFixed(2)}%,"${trade.reason}"\n`;
    });
    
    // Create download link
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', `backtest_${params.strategy}_${params.symbol}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className={`bg-gray-900 rounded-2xl border border-gray-700 shadow-2xl overflow-hidden ${
            isFullscreen ? 'w-full h-full' : 'w-[95vw] h-[90vh] max-w-7xl'
          }`}
        >
          {/* Header */}
          <div className="bg-gray-800/50 border-b border-gray-700 p-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">AI Strategy Backtesting</h2>
                <p className="text-sm text-gray-400">Test and optimize your trading strategies</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              >
                {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
              </button>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex h-[calc(100%-4rem)]">
            {/* Settings Panel */}
            <div className="w-80 bg-gray-800/30 border-r border-gray-700 p-4 overflow-y-auto">
              <h3 className="text-lg font-semibold mb-4">Backtest Settings</h3>
              
              <div className="space-y-4">
                {/* Strategy Selection */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Strategy</label>
                  <select
                    value={params.strategy}
                    onChange={(e) => handleParamChange('strategy', e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                  >
                    {strategies.map(strategy => (
                      <option key={strategy.id} value={strategy.id}>
                        {strategy.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* Symbol Selection */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Symbol</label>
                  <select
                    value={params.symbol}
                    onChange={(e) => handleParamChange('symbol', e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                  >
                    {symbols.map(symbol => (
                      <option key={symbol} value={symbol}>
                        {symbol}
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* Date Range */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Start Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="date"
                        value={params.startDate}
                        onChange={(e) => handleParamChange('startDate', e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded p-2 pl-8 text-white"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">End Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="date"
                        value={params.endDate}
                        onChange={(e) => handleParamChange('endDate', e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded p-2 pl-8 text-white"
                      />
                    </div>
                  </div>
                </div>
                
                {/* Timeframe */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Timeframe</label>
                  <div className="flex space-x-1">
                    {timeframes.map(tf => (
                      <button
                        key={tf}
                        onClick={() => handleParamChange('timeframe', tf)}
                        className={`flex-1 py-1 rounded text-xs font-medium ${
                          params.timeframe === tf 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        }`}
                      >
                        {tf}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Capital & Position Size */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Initial Capital ($)</label>
                  <input
                    type="number"
                    value={params.initialCapital}
                    onChange={(e) => handleParamChange('initialCapital', Number(e.target.value))}
                    className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Position Size (% of capital)</label>
                  <input
                    type="number"
                    value={params.positionSize}
                    onChange={(e) => handleParamChange('positionSize', Number(e.target.value))}
                    min="1"
                    max="100"
                    className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                  />
                </div>
                
                {/* Risk Management */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Stop Loss (%)</label>
                    <input
                      type="number"
                      value={params.stopLoss}
                      onChange={(e) => handleParamChange('stopLoss', Number(e.target.value))}
                      min="0.1"
                      step="0.1"
                      className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Take Profit (%)</label>
                    <input
                      type="number"
                      value={params.takeProfit}
                      onChange={(e) => handleParamChange('takeProfit', Number(e.target.value))}
                      min="0.1"
                      step="0.1"
                      className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                    />
                  </div>
                </div>
                
                {/* Advanced Settings Toggle */}
                <button
                  onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
                  className="flex items-center justify-between w-full p-2 bg-gray-700/50 hover:bg-gray-700 rounded text-sm transition-colors"
                >
                  <div className="flex items-center">
                    <Settings className="w-4 h-4 mr-2" />
                    Advanced Settings
                  </div>
                  {showAdvancedSettings ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                
                {/* Advanced Settings */}
                {showAdvancedSettings && (
                  <div className="space-y-3 p-3 bg-gray-700/30 rounded-lg">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">RSI Period</label>
                        <input
                          type="number"
                          value={params.customParams.rsiPeriod}
                          onChange={(e) => handleCustomParamChange('rsiPeriod', Number(e.target.value))}
                          className="w-full bg-gray-700 border border-gray-600 rounded p-1 text-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">RSI Overbought</label>
                        <input
                          type="number"
                          value={params.customParams.rsiOverbought}
                          onChange={(e) => handleCustomParamChange('rsiOverbought', Number(e.target.value))}
                          className="w-full bg-gray-700 border border-gray-600 rounded p-1 text-white text-sm"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">RSI Oversold</label>
                        <input
                          type="number"
                          value={params.customParams.rsiOversold}
                          onChange={(e) => handleCustomParamChange('rsiOversold', Number(e.target.value))}
                          className="w-full bg-gray-700 border border-gray-600 rounded p-1 text-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">MACD Fast</label>
                        <input
                          type="number"
                          value={params.customParams.macdFast}
                          onChange={(e) => handleCustomParamChange('macdFast', Number(e.target.value))}
                          className="w-full bg-gray-700 border border-gray-600 rounded p-1 text-white text-sm"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">MACD Slow</label>
                        <input
                          type="number"
                          value={params.customParams.macdSlow}
                          onChange={(e) => handleCustomParamChange('macdSlow', Number(e.target.value))}
                          className="w-full bg-gray-700 border border-gray-600 rounded p-1 text-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">MACD Signal</label>
                        <input
                          type="number"
                          value={params.customParams.macdSignal}
                          onChange={(e) => handleCustomParamChange('macdSignal', Number(e.target.value))}
                          className="w-full bg-gray-700 border border-gray-600 rounded p-1 text-white text-sm"
                        />
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Action Buttons */}
                <div className="pt-2">
                  <button
                    onClick={runBacktest}
                    disabled={isRunning}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white py-3 rounded-lg font-medium flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isRunning ? (
                      <>
                        <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                        Running Backtest...
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 mr-2" />
                        Run Backtest
                      </>
                    )}
                  </button>
                </div>
                
                {/* Save Strategy Button */}
                <button
                  onClick={handleSaveStrategy}
                  className="w-full bg-gray-700 hover:bg-gray-600 text-white py-2 rounded-lg font-medium flex items-center justify-center"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Strategy
                </button>
              </div>
            </div>

            {/* Results Panel */}
            <div className="flex-1 overflow-y-auto p-6">
              {isRunning && (
                <div className="flex flex-col items-center justify-center h-full">
                  <div className="w-24 h-24 relative mb-4">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="#374151"
                        strokeWidth="8"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="url(#progressGradient)"
                        strokeWidth="8"
                        strokeDasharray={`${progress * 2.83} 283`}
                        strokeLinecap="round"
                        transform="rotate(-90 50 50)"
                      />
                      <defs>
                        <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#3B82F6" />
                          <stop offset="100%" stopColor="#8B5CF6" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xl font-bold">{progress}%</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-2">Running Backtest</h3>
                  <p className="text-gray-400">Processing historical data for {params.symbol}...</p>
                </div>
              )}
              
              {error && !isRunning && (
                <div className="flex flex-col items-center justify-center h-full">
                  <AlertTriangle className="w-16 h-16 text-red-500 mb-4" />
                  <h3 className="text-xl font-bold mb-2">Backtest Failed</h3>
                  <p className="text-red-400">{error}</p>
                  <button
                    onClick={runBacktest}
                    className="mt-4 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-medium"
                  >
                    Try Again
                  </button>
                </div>
              )}
              
              {!isRunning && !error && !result && (
                <div className="flex flex-col items-center justify-center h-full">
                  <RefreshCw className="w-16 h-16 text-blue-500 mb-4" />
                  <h3 className="text-xl font-bold mb-2">Ready to Backtest</h3>
                  <p className="text-gray-400">Configure your strategy and run the backtest</p>
                </div>
              )}
              
              {result && !isRunning && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold">Backtest Results</h3>
                    <button
                      onClick={handleExportResults}
                      className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1 rounded-lg text-sm flex items-center"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Export CSV
                    </button>
                  </div>
                  
                  {/* Summary Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-400">Net Profit</h4>
                        <div className={`text-sm ${result.netProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {result.netProfitPercent >= 0 ? '+' : ''}{result.netProfitPercent.toFixed(2)}%
                        </div>
                      </div>
                      <div className={`text-2xl font-bold ${result.netProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {result.netProfit >= 0 ? '+' : ''}${result.netProfit.toFixed(2)}
                      </div>
                    </div>
                    
                    <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-400">Win Rate</h4>
                        <div className="text-sm text-blue-400">
                          {result.winningTrades}/{result.totalTrades} trades
                        </div>
                      </div>
                      <div className="text-2xl font-bold text-blue-400">
                        {result.winRate.toFixed(1)}%
                      </div>
                    </div>
                    
                    <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-400">Profit Factor</h4>
                        <div className="text-sm text-purple-400">
                          Sharpe: {result.sharpeRatio.toFixed(2)}
                        </div>
                      </div>
                      <div className="text-2xl font-bold text-purple-400">
                        {result.profitFactor.toFixed(2)}
                      </div>
                    </div>
                  </div>
                  
                  {/* Detailed Metrics */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700">
                      <h4 className="text-sm font-medium text-gray-400 mb-3">Performance Metrics</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">Max Drawdown</span>
                          <span className="text-sm text-red-400">{result.maxDrawdown.toFixed(2)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">Avg. Profit</span>
                          <span className="text-sm text-green-400">${result.averageProfit.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">Avg. Loss</span>
                          <span className="text-sm text-red-400">${result.averageLoss.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">Best Trade</span>
                          <span className="text-sm text-green-400">${result.bestTrade.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">Worst Trade</span>
                          <span className="text-sm text-red-400">${result.worstTrade.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">Avg. Holding Time</span>
                          <span className="text-sm">{result.averageHoldingTime}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700">
                      <h4 className="text-sm font-medium text-gray-400 mb-3">Strategy Analysis</h4>
                      <div className="space-y-3">
                        <div>
                          <div className="text-sm text-gray-400 mb-1">Win/Loss Ratio</div>
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-full" 
                              style={{width: `${result.winRate}%`}}
                            ></div>
                          </div>
                          <div className="flex justify-between text-xs mt-1">
                            <span>{result.winningTrades} wins</span>
                            <span>{result.losingTrades} losses</span>
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-400 mb-1">Long vs Short Performance</div>
                          <div className="flex space-x-2">
                            <div className="flex-1 bg-gray-800/50 p-2 rounded">
                              <div className="flex items-center">
                                <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                                <span className="text-xs">Long</span>
                              </div>
                              <div className="text-sm font-medium text-green-400">
                                +{(result.netProfitPercent * 0.6).toFixed(2)}%
                              </div>
                            </div>
                            <div className="flex-1 bg-gray-800/50 p-2 rounded">
                              <div className="flex items-center">
                                <TrendingDown className="w-4 h-4 text-red-400 mr-1" />
                                <span className="text-xs">Short</span>
                              </div>
                              <div className="text-sm font-medium text-red-400">
                                {(result.netProfitPercent * 0.4).toFixed(2)}%
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-400 mb-1">Strategy Recommendation</div>
                          <div className="flex items-center space-x-2 bg-blue-500/20 p-2 rounded">
                            <Zap className="w-4 h-4 text-blue-400" />
                            <span className="text-sm">
                              {result.netProfit > 0 && result.winRate > 55
                                ? 'Strategy shows promising results, consider live testing'
                                : 'Strategy needs optimization before live trading'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Trade List */}
                  <div className="bg-gray-800/30 rounded-lg border border-gray-700 overflow-hidden">
                    <div className="p-4 border-b border-gray-700 flex items-center justify-between">
                      <h4 className="font-medium">Trade History</h4>
                      <button
                        onClick={() => setShowTrades(!showTrades)}
                        className="text-sm flex items-center text-gray-400 hover:text-white"
                      >
                        {showTrades ? 'Hide Trades' : 'Show Trades'}
                        {showTrades ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />}
                      </button>
                    </div>
                    
                    {showTrades && (
                      <div className="max-h-80 overflow-y-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-gray-800/50 text-gray-400">
                            <tr>
                              <th className="p-2 text-left">Symbol</th>
                              <th className="p-2 text-left">Direction</th>
                              <th className="p-2 text-right">Entry</th>
                              <th className="p-2 text-right">Exit</th>
                              <th className="p-2 text-right">Profit</th>
                              <th className="p-2 text-left">Reason</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.trades.map((trade) => (
                              <tr key={trade.id} className="border-t border-gray-700 hover:bg-gray-800/30">
                                <td className="p-2">{trade.symbol}</td>
                                <td className="p-2">
                                  <span className={`px-2 py-1 rounded text-xs ${
                                    trade.direction === 'LONG' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                                  }`}>
                                    {trade.direction}
                                  </span>
                                </td>
                                <td className="p-2 text-right">${trade.entryPrice.toFixed(2)}</td>
                                <td className="p-2 text-right">${trade.exitPrice.toFixed(2)}</td>
                                <td className={`p-2 text-right ${trade.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                  {trade.profit >= 0 ? '+' : ''}${trade.profit.toFixed(2)}
                                </td>
                                <td className="p-2 text-xs text-gray-400 truncate max-w-[200px]">{trade.reason}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex space-x-3">
                    <button
                      onClick={runBacktest}
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-lg font-medium flex items-center justify-center"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Run Again
                    </button>
                    <button
                      onClick={() => window.dispatchEvent(new CustomEvent('optimize-strategy', { detail: { strategy: params.strategy } }))}
                      className="flex-1 bg-purple-600 hover:bg-purple-500 text-white py-2 rounded-lg font-medium flex items-center justify-center"
                    >
                      <Sliders className="w-4 h-4 mr-2" />
                      Optimize Strategy
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
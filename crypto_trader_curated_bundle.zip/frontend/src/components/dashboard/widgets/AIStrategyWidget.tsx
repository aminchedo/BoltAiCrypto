import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  Settings, 
  Play, 
  Pause, 
  RefreshCw, 
  CheckCircle, 
  AlertTriangle,
  Zap,
  ArrowRight
} from 'lucide-react';
import { signalService } from '@/services/signalService';
import { marketService } from '@/services/marketService';

interface AIStrategyWidgetProps {
  className?: string;
  strategy?: string;
}

interface Strategy {
  id: string;
  name: string;
  description: string;
  type: 'trend' | 'momentum' | 'mean-reversion' | 'pattern' | 'hybrid';
  performance: {
    winRate: number;
    profitFactor: number;
    sharpeRatio: number;
    maxDrawdown: number;
    averageProfit: number;
    averageLoss: number;
  };
  status: 'active' | 'paused' | 'backtest';
  signals: number;
  lastSignal?: Date;
}

export function AIStrategyWidget({ className, strategy = 'trend-master' }: AIStrategyWidgetProps) {
  const [selectedStrategy, setSelectedStrategy] = useState<Strategy | null>(null);
  const [availableStrategies, setAvailableStrategies] = useState<Strategy[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    const fetchStrategies = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // In a real implementation, fetch from signalService
        // For now, use mock data
        const mockStrategies: Strategy[] = [
          {
            id: 'trend-master',
            name: 'Trend Master',
            description: 'Follows strong market trends with momentum confirmation',
            type: 'trend',
            performance: {
              winRate: 68.5,
              profitFactor: 2.3,
              sharpeRatio: 1.8,
              maxDrawdown: 12.4,
              averageProfit: 3.2,
              averageLoss: 1.4
            },
            status: 'active',
            signals: 142,
            lastSignal: new Date(Date.now() - 3 * 60 * 60 * 1000)
          },
          {
            id: 'breakout-hunter',
            name: 'Breakout Hunter',
            description: 'Identifies and trades key level breakouts',
            type: 'pattern',
            performance: {
              winRate: 62.1,
              profitFactor: 1.9,
              sharpeRatio: 1.5,
              maxDrawdown: 15.8,
              averageProfit: 4.1,
              averageLoss: 2.2
            },
            status: 'active',
            signals: 98,
            lastSignal: new Date(Date.now() - 12 * 60 * 60 * 1000)
          },
          {
            id: 'smart-reversal',
            name: 'Smart Reversal',
            description: 'Identifies potential market reversals',
            type: 'mean-reversion',
            performance: {
              winRate: 58.7,
              profitFactor: 1.7,
              sharpeRatio: 1.3,
              maxDrawdown: 18.2,
              averageProfit: 3.8,
              averageLoss: 2.5
            },
            status: 'paused',
            signals: 76
          }
        ];
        
        setAvailableStrategies(mockStrategies);
        const selected = mockStrategies.find(s => s.id === strategy) || mockStrategies[0];
        setSelectedStrategy(selected);
        setIsRunning(selected.status === 'active');
      } catch (err) {
        console.error('Error fetching strategies:', err);
        setError('Failed to load trading strategies');
      } finally {
        setIsLoading(false);
      }
    };

    fetchStrategies();
  }, [strategy]);

  const handleStrategyChange = (strategyId: string) => {
    const selected = availableStrategies.find(s => s.id === strategyId);
    if (selected) {
      setSelectedStrategy(selected);
      setIsRunning(selected.status === 'active');
    }
  };

  const handleToggleRunning = () => {
    setIsRunning(!isRunning);
    // In a real implementation, this would call the service to activate/deactivate the strategy
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'trend': return 'text-blue-400';
      case 'momentum': return 'text-purple-400';
      case 'mean-reversion': return 'text-green-400';
      case 'pattern': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  if (isLoading) {
    return (
      <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center">
            <Target className="w-4 h-4 mr-2 text-blue-400" />
            AI Trading Strategy
          </h3>
          <div className="text-xs text-gray-400">Loading...</div>
        </div>
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          <div className="h-20 bg-gray-700 rounded"></div>
          <div className="h-4 bg-gray-700 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  if (!selectedStrategy) {
    return (
      <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center">
            <Target className="w-4 h-4 mr-2 text-blue-400" />
            AI Trading Strategy
          </h3>
        </div>
        <div className="p-4 text-center">
          <AlertTriangle className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
          <p className="text-sm text-gray-400">No strategy selected</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white flex items-center">
          <Target className="w-4 h-4 mr-2 text-blue-400" />
          AI Trading Strategy
        </h3>
        
        <select
          value={selectedStrategy.id}
          onChange={(e) => handleStrategyChange(e.target.value)}
          className="text-xs bg-gray-700 border border-gray-600 rounded px-2 py-1 text-white"
        >
          {availableStrategies.map(strategy => (
            <option key={strategy.id} value={strategy.id}>
              {strategy.name}
            </option>
          ))}
        </select>
      </div>
      
      {error && (
        <div className="p-2 bg-red-500/20 text-red-400 text-xs rounded mb-2">
          {error}
        </div>
      )}
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-medium">{selectedStrategy.name}</div>
            <div className={`text-xs ${getTypeColor(selectedStrategy.type)}`}>
              {selectedStrategy.type.charAt(0).toUpperCase() + selectedStrategy.type.slice(1)} Strategy
            </div>
          </div>
          
          <button
            onClick={handleToggleRunning}
            className={`p-2 rounded-lg ${
              isRunning 
                ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
                : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
            } transition-colors`}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
        </div>
        
        <div className="text-xs text-gray-400">
          {selectedStrategy.description}
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-gray-700/30 p-2 rounded">
            <div className="text-xs text-gray-400">Win Rate</div>
            <div className="text-sm font-medium text-green-400">
              {selectedStrategy.performance.winRate}%
            </div>
          </div>
          <div className="bg-gray-700/30 p-2 rounded">
            <div className="text-xs text-gray-400">Profit Factor</div>
            <div className="text-sm font-medium text-blue-400">
              {selectedStrategy.performance.profitFactor}
            </div>
          </div>
          <div className="bg-gray-700/30 p-2 rounded">
            <div className="text-xs text-gray-400">Sharpe Ratio</div>
            <div className="text-sm font-medium text-purple-400">
              {selectedStrategy.performance.sharpeRatio}
            </div>
          </div>
          <div className="bg-gray-700/30 p-2 rounded">
            <div className="text-xs text-gray-400">Max Drawdown</div>
            <div className="text-sm font-medium text-red-400">
              {selectedStrategy.performance.maxDrawdown}%
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-xs">
          <div className="text-gray-400">
            {selectedStrategy.signals} signals generated
          </div>
          {selectedStrategy.lastSignal && (
            <div className="text-gray-400">
              Last signal: {new Date(selectedStrategy.lastSignal).toLocaleTimeString()}
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-3 flex space-x-2">
        <button 
          className="flex-1 bg-blue-600/30 hover:bg-blue-600/50 text-blue-400 py-1.5 rounded text-xs font-medium transition-colors flex items-center justify-center"
          onClick={() => window.dispatchEvent(new CustomEvent('open-ai-lab', { detail: { tab: 'advanced' } }))}
        >
          <Settings className="w-3 h-3 mr-1" />
          Configure
        </button>
        <button 
          className="flex-1 bg-purple-600/30 hover:bg-purple-600/50 text-purple-400 py-1.5 rounded text-xs font-medium transition-colors flex items-center justify-center"
          onClick={() => window.dispatchEvent(new CustomEvent('open-backtest', { detail: { strategy: selectedStrategy.id } }))}
        >
          <RefreshCw className="w-3 h-3 mr-1" />
          Backtest
        </button>
      </div>
    </div>
  );
}
'use client';

import { useState, useEffect, useMemo } from 'react';
import { Brain, TrendingUp, TrendingDown, Clock, Target, Shield, BarChart3, Activity, Zap, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { signalService } from '@/services/signalService';
import { marketService } from '@/services/marketService';
import { realDataService } from '@/services/realDataService';

interface TradingSignal {
  id: string;
  symbol: string;
  direction: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entry_price: number;
  stop_loss?: number;
  take_profit?: number;
  risk_reward_ratio: number;
  algorithm_breakdown: {
    technical_analysis: { score: number; weight: number; contribution: number };
    smart_money_concepts: { score: number; weight: number; contribution: number };
    pattern_recognition: { score: number; weight: number; contribution: number };
    sentiment_analysis: { score: number; weight: number; contribution: number };
    whale_intelligence: { score: number; weight: number; contribution: number };
    ml_predictions: { score: number; weight: number; contribution: number };
    final_score: number;
  };
  created_at: string;
  expires_at: string;
  status: 'ACTIVE' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED';
  performance?: {
    actual_entry?: number;
    actual_exit?: number;
    pnl?: number;
    pnl_percentage?: number;
    execution_time?: string;
    close_time?: string;
    outcome: 'WIN' | 'LOSS' | 'BREAKEVEN' | 'PENDING';
  };
  market_conditions?: {
    volatility: number;
    volume_profile: 'HIGH' | 'MEDIUM' | 'LOW';
    trend_strength: number;
    support_resistance: { support: number; resistance: number };
  };
  risk_assessment: {
    risk_score: number;
    max_loss_amount: number;
    position_size_recommendation: number;
    market_impact: 'LOW' | 'MEDIUM' | 'HIGH';
  };
}

interface SignalPerformance {
  total_signals: number;
  active_signals: number;
  win_rate: number;
  avg_return: number;
  best_signal: number;
  worst_signal: number;
  accuracy_by_confidence: { range: string; accuracy: number; count: number }[];
  performance_by_timeframe: { period: string; win_rate: number; avg_return: number }[];
}

export function AISignalsWidget() {
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [selectedSignal, setSelectedSignal] = useState<TradingSignal | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'signals' | 'performance' | 'backtest'>('signals');
  const [signalPerformance, setSignalPerformance] = useState<SignalPerformance | null>(null);
  const [confidenceFilter, setConfidenceFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');

  // Mock data for demonstration
  useEffect(() => {
    // Generate comprehensive mock signals with performance data
    const generateMockSignals = (): TradingSignal[] => {
      const symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'ADA/USDT', 'BNB/USDT', 'MATIC/USDT', 'DOT/USDT', 'AVAX/USDT'];
      const signals: TradingSignal[] = [];

      // Generate active signals
      for (let i = 0; i < 5; i++) {
        const symbol = symbols[i % symbols.length];
        const direction = Math.random() > 0.5 ? 'BUY' : 'SELL';
        const confidence = Math.floor(Math.random() * 40) + 60; // 60-100%
        const basePrice = Math.random() * 50000 + 100;

        signals.push({
          id: `active-${i}`,
          symbol,
          direction: direction as 'BUY' | 'SELL',
          confidence,
          entry_price: basePrice,
          stop_loss: direction === 'BUY' ? basePrice * 0.95 : basePrice * 1.05,
          take_profit: direction === 'BUY' ? basePrice * 1.08 : basePrice * 0.92,
          risk_reward_ratio: 1.5 + Math.random() * 1.5,
          algorithm_breakdown: {
            technical_analysis: { score: (Math.random() - 0.5) * 2, weight: 0.35, contribution: 0 },
            smart_money_concepts: { score: (Math.random() - 0.5) * 2, weight: 0.25, contribution: 0 },
            pattern_recognition: { score: (Math.random() - 0.5) * 2, weight: 0.20, contribution: 0 },
            sentiment_analysis: { score: (Math.random() - 0.5) * 2, weight: 0.10, contribution: 0 },
            whale_intelligence: { score: (Math.random() - 0.5) * 2, weight: 0.05, contribution: 0 },
            ml_predictions: { score: (Math.random() - 0.5) * 2, weight: 0.05, contribution: 0 },
            final_score: (Math.random() - 0.5) * 2
          },
          created_at: new Date(Date.now() - Math.random() * 4 * 60 * 60 * 1000).toISOString(),
          expires_at: new Date(Date.now() + Math.random() * 8 * 60 * 60 * 1000).toISOString(),
          status: 'ACTIVE',
          market_conditions: {
            volatility: Math.random() * 100,
            volume_profile: ['HIGH', 'MEDIUM', 'LOW'][Math.floor(Math.random() * 3)] as 'HIGH' | 'MEDIUM' | 'LOW',
            trend_strength: Math.random() * 100,
            support_resistance: {
              support: basePrice * (0.9 + Math.random() * 0.05),
              resistance: basePrice * (1.05 + Math.random() * 0.05)
            }
          },
          risk_assessment: {
            risk_score: Math.floor(Math.random() * 100),
            max_loss_amount: basePrice * 0.05,
            position_size_recommendation: Math.random() * 5 + 1,
            market_impact: ['LOW', 'MEDIUM', 'HIGH'][Math.floor(Math.random() * 3)] as 'LOW' | 'MEDIUM' | 'HIGH'
          }
        });
      }

      // Generate historical signals with performance data
      for (let i = 0; i < 15; i++) {
        const symbol = symbols[i % symbols.length];
        const direction = Math.random() > 0.5 ? 'BUY' : 'SELL';
        const confidence = Math.floor(Math.random() * 40) + 60;
        const basePrice = Math.random() * 50000 + 100;
        const isWin = Math.random() > 0.3; // 70% win rate
        const pnlPercent = isWin ? Math.random() * 15 + 2 : -(Math.random() * 10 + 1);

        signals.push({
          id: `historical-${i}`,
          symbol,
          direction: direction as 'BUY' | 'SELL',
          confidence,
          entry_price: basePrice,
          stop_loss: direction === 'BUY' ? basePrice * 0.95 : basePrice * 1.05,
          take_profit: direction === 'BUY' ? basePrice * 1.08 : basePrice * 0.92,
          risk_reward_ratio: 1.5 + Math.random() * 1.5,
          algorithm_breakdown: {
            technical_analysis: { score: (Math.random() - 0.5) * 2, weight: 0.35, contribution: 0 },
            smart_money_concepts: { score: (Math.random() - 0.5) * 2, weight: 0.25, contribution: 0 },
            pattern_recognition: { score: (Math.random() - 0.5) * 2, weight: 0.20, contribution: 0 },
            sentiment_analysis: { score: (Math.random() - 0.5) * 2, weight: 0.10, contribution: 0 },
            whale_intelligence: { score: (Math.random() - 0.5) * 2, weight: 0.05, contribution: 0 },
            ml_predictions: { score: (Math.random() - 0.5) * 2, weight: 0.05, contribution: 0 },
            final_score: (Math.random() - 0.5) * 2
          },
          created_at: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
          expires_at: new Date(Date.now() - Math.random() * 29 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'EXECUTED',
          performance: {
            actual_entry: basePrice,
            actual_exit: basePrice * (1 + pnlPercent / 100),
            pnl: basePrice * (pnlPercent / 100),
            pnl_percentage: pnlPercent,
            execution_time: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
            close_time: new Date(Date.now() - Math.random() * 29 * 24 * 60 * 60 * 1000).toISOString(),
            outcome: isWin ? 'WIN' : 'LOSS'
          },
          market_conditions: {
            volatility: Math.random() * 100,
            volume_profile: ['HIGH', 'MEDIUM', 'LOW'][Math.floor(Math.random() * 3)] as 'HIGH' | 'MEDIUM' | 'LOW',
            trend_strength: Math.random() * 100,
            support_resistance: {
              support: basePrice * (0.9 + Math.random() * 0.05),
              resistance: basePrice * (1.05 + Math.random() * 0.05)
            }
          },
          risk_assessment: {
            risk_score: Math.floor(Math.random() * 100),
            max_loss_amount: basePrice * 0.05,
            position_size_recommendation: Math.random() * 5 + 1,
            market_impact: ['LOW', 'MEDIUM', 'HIGH'][Math.floor(Math.random() * 3)] as 'LOW' | 'MEDIUM' | 'HIGH'
          }
        });
      }

      return signals;
    };

    const mockSignals = generateMockSignals();

    // Calculate performance metrics
    const executedSignals = mockSignals.filter(s => s.status === 'EXECUTED' && s.performance);
    const winningSignals = executedSignals.filter(s => s.performance?.outcome === 'WIN');

    const mockPerformance: SignalPerformance = {
      total_signals: executedSignals.length,
      active_signals: mockSignals.filter(s => s.status === 'ACTIVE').length,
      win_rate: (winningSignals.length / executedSignals.length) * 100,
      avg_return: executedSignals.reduce((sum, s) => sum + (s.performance?.pnl_percentage || 0), 0) / executedSignals.length,
      best_signal: Math.max(...executedSignals.map(s => s.performance?.pnl_percentage || 0)),
      worst_signal: Math.min(...executedSignals.map(s => s.performance?.pnl_percentage || 0)),
      accuracy_by_confidence: [
        { range: '80-100%', accuracy: 85.2, count: executedSignals.filter(s => s.confidence >= 80).length },
        { range: '70-79%', accuracy: 72.8, count: executedSignals.filter(s => s.confidence >= 70 && s.confidence < 80).length },
        { range: '60-69%', accuracy: 65.4, count: executedSignals.filter(s => s.confidence >= 60 && s.confidence < 70).length }
      ],
      performance_by_timeframe: [
        { period: '1D', win_rate: 78.5, avg_return: 3.2 },
        { period: '1W', win_rate: 72.1, avg_return: 8.7 },
        { period: '1M', win_rate: 69.8, avg_return: 15.4 }
      ]
    };

    const mockData: TradingSignal[] = [
      {
        id: '1',
        symbol: 'BTC/USDT',
        direction: 'BUY',
        confidence: 85,
        entry_price: 43250,
        stop_loss: 42000,
        take_profit: 45500,
        risk_reward_ratio: 1.8,
        algorithm_breakdown: {
          technical_analysis: { score: 0.8, weight: 0.35, contribution: 0.28 },
          smart_money_concepts: { score: 0.9, weight: 0.25, contribution: 0.225 },
          pattern_recognition: { score: 0.7, weight: 0.20, contribution: 0.14 },
          sentiment_analysis: { score: 0.6, weight: 0.10, contribution: 0.06 },
          whale_intelligence: { score: 0.8, weight: 0.05, contribution: 0.04 },
          ml_predictions: { score: 0.7, weight: 0.05, contribution: 0.035 },
          final_score: 0.78
        },
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
        status: 'ACTIVE'
      },
      {
        id: '2',
        symbol: 'ETH/USDT',
        direction: 'SELL',
        confidence: 72,
        entry_price: 2680,
        stop_loss: 2750,
        take_profit: 2550,
        risk_reward_ratio: 1.9,
        algorithm_breakdown: {
          technical_analysis: { score: -0.6, weight: 0.35, contribution: -0.21 },
          smart_money_concepts: { score: -0.8, weight: 0.25, contribution: -0.20 },
          pattern_recognition: { score: -0.7, weight: 0.20, contribution: -0.14 },
          sentiment_analysis: { score: -0.5, weight: 0.10, contribution: -0.05 },
          whale_intelligence: { score: -0.6, weight: 0.05, contribution: -0.03 },
          ml_predictions: { score: -0.8, weight: 0.05, contribution: -0.04 },
          final_score: -0.67
        },
        created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        expires_at: new Date(Date.now() + 3.5 * 60 * 60 * 1000).toISOString(),
        status: 'ACTIVE'
      },
      {
        id: '3',
        symbol: 'SOL/USDT',
        direction: 'BUY',
        confidence: 68,
        entry_price: 98.45,
        stop_loss: 95.00,
        take_profit: 105.00,
        risk_reward_ratio: 1.9,
        algorithm_breakdown: {
          technical_analysis: { score: 0.7, weight: 0.35, contribution: 0.245 },
          smart_money_concepts: { score: 0.6, weight: 0.25, contribution: 0.15 },
          pattern_recognition: { score: 0.8, weight: 0.20, contribution: 0.16 },
          sentiment_analysis: { score: 0.7, weight: 0.10, contribution: 0.07 },
          whale_intelligence: { score: 0.5, weight: 0.05, contribution: 0.025 },
          ml_predictions: { score: 0.6, weight: 0.05, contribution: 0.03 },
          final_score: 0.68
        },
        created_at: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
        expires_at: new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString(),
        status: 'ACTIVE'
      }
    ];

    setTimeout(() => {
      setSignals(mockSignals);
      setSignalPerformance(mockPerformance);
      setLoading(false);
    }, 1000);
  }, []);

  // Filter signals based on confidence level
  const filteredSignals = useMemo(() => {
    let filtered = signals;

    switch (confidenceFilter) {
      case 'high':
        filtered = signals.filter(s => s.confidence >= 80);
        break;
      case 'medium':
        filtered = signals.filter(s => s.confidence >= 60 && s.confidence < 80);
        break;
      case 'low':
        filtered = signals.filter(s => s.confidence < 60);
        break;
    }

    return filtered;
  }, [signals, confidenceFilter]);

  const getSignalColor = (direction: string) => {
    switch (direction) {
      case 'BUY':
        return 'text-success-400 bg-success-900/20 border-success-500/30';
      case 'SELL':
        return 'text-danger-400 bg-danger-900/20 border-danger-500/30';
      case 'HOLD':
        return 'text-warning-400 bg-warning-900/20 border-warning-500/30';
      default:
        return 'text-gray-400 bg-gray-900/20 border-gray-500/30';
    }
  };

  const getSignalIcon = (direction: string) => {
    switch (direction) {
      case 'BUY':
        return <TrendingUp className="h-4 w-4" />;
      case 'SELL':
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const formatTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diff = expiry.getTime() - now.getTime();

    if (diff <= 0) return 'Expired';

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}h ${minutes}m`;
  };

  const AlgorithmBreakdown = ({ breakdown }: { breakdown: TradingSignal['algorithm_breakdown'] }) => {
    const components = [
      { name: 'Technical Analysis', key: 'technical_analysis', color: 'bg-blue-500' },
      { name: 'Smart Money Concepts', key: 'smart_money_concepts', color: 'bg-purple-500' },
      { name: 'Pattern Recognition', key: 'pattern_recognition', color: 'bg-green-500' },
      { name: 'Sentiment Analysis', key: 'sentiment_analysis', color: 'bg-yellow-500' },
      { name: 'Whale Intelligence', key: 'whale_intelligence', color: 'bg-red-500' },
      { name: 'ML Predictions', key: 'ml_predictions', color: 'bg-indigo-500' },
    ];

    return (
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-white mb-2">Algorithm Breakdown</h4>
        {components.map((component) => {
          const data = breakdown[component.key as keyof typeof breakdown] as any;
          const percentage = Math.abs(data.contribution * 100);

          return (
            <div key={component.key} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-gray-300">{component.name}</span>
                <span className="text-gray-400">
                  {(data.weight * 100).toFixed(0)}% • {percentage.toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-dark-600 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${component.color}`}
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>
          );
        })}
        <div className="pt-2 border-t border-dark-600">
          <div className="flex justify-between text-sm">
            <span className="text-white font-medium">Final Score</span>
            <span className={`font-bold ${breakdown.final_score > 0 ? 'text-success-400' : 'text-danger-400'
              }`}>
              {(Math.abs(breakdown.final_score) * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="spinner h-8 w-8"></div>
      </div>
    );
  }

  // Performance Tab Component
  const PerformanceTab = () => (
    <div className="space-y-4">
      {/* Key Performance Metrics */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <CheckCircle className="h-4 w-4 text-success-400" />
            <span className="text-xs text-gray-400">Win Rate</span>
          </div>
          <div className="text-lg font-semibold text-success-400">
            {signalPerformance?.win_rate.toFixed(1)}%
          </div>
          <div className="text-xs text-gray-400">
            {signalPerformance?.total_signals} signals
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <TrendingUp className="h-4 w-4 text-primary-400" />
            <span className="text-xs text-gray-400">Avg Return</span>
          </div>
          <div className="text-lg font-semibold text-white">
            {signalPerformance?.avg_return.toFixed(2)}%
          </div>
          <div className="text-xs text-gray-400">per signal</div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Activity className="h-4 w-4 text-success-400" />
            <span className="text-xs text-gray-400">Best Signal</span>
          </div>
          <div className="text-lg font-semibold text-success-400">
            +{signalPerformance?.best_signal.toFixed(2)}%
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <AlertTriangle className="h-4 w-4 text-danger-400" />
            <span className="text-xs text-gray-400">Worst Signal</span>
          </div>
          <div className="text-lg font-semibold text-danger-400">
            {signalPerformance?.worst_signal.toFixed(2)}%
          </div>
        </div>
      </div>

      {/* Accuracy by Confidence */}
      <div className="bg-dark-700 rounded-lg p-3">
        <h4 className="text-sm font-medium text-white mb-3">Accuracy by Confidence Level</h4>
        <div className="space-y-2">
          {signalPerformance?.accuracy_by_confidence.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm text-gray-300">{item.range}</span>
              <div className="flex items-center space-x-2">
                <div className="w-16 bg-dark-600 rounded-full h-2">
                  <div
                    className="bg-success-500 h-2 rounded-full"
                    style={{ width: `${item.accuracy}%` }}
                  ></div>
                </div>
                <span className="text-sm text-white w-12">{item.accuracy.toFixed(1)}%</span>
                <span className="text-xs text-gray-400">({item.count})</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Performance by Timeframe */}
      <div className="bg-dark-700 rounded-lg p-3">
        <h4 className="text-sm font-medium text-white mb-3">Performance by Timeframe</h4>
        <div className="space-y-2">
          {signalPerformance?.performance_by_timeframe.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm text-gray-300">{item.period}</span>
              <div className="flex items-center space-x-4">
                <div className="text-sm">
                  <span className="text-gray-400">Win: </span>
                  <span className="text-success-400">{item.win_rate.toFixed(1)}%</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-400">Avg: </span>
                  <span className="text-white">{item.avg_return.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Backtest Tab Component
  const BacktestTab = () => (
    <div className="space-y-4">
      <div className="bg-dark-700 rounded-lg p-3">
        <h4 className="text-sm font-medium text-white mb-3">Historical Backtesting Results</h4>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-xs text-gray-400">Total Trades</div>
            <div className="text-lg font-semibold text-white">1,247</div>
          </div>
          <div>
            <div className="text-xs text-gray-400">Profitable Trades</div>
            <div className="text-lg font-semibold text-success-400">892 (71.5%)</div>
          </div>
          <div>
            <div className="text-xs text-gray-400">Total Return</div>
            <div className="text-lg font-semibold text-success-400">+284.7%</div>
          </div>
          <div>
            <div className="text-xs text-gray-400">Max Drawdown</div>
            <div className="text-lg font-semibold text-danger-400">-12.3%</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Sharpe Ratio</span>
            <span className="text-white">2.34</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Profit Factor</span>
            <span className="text-white">2.18</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Avg Trade Duration</span>
            <span className="text-white">4.2 hours</span>
          </div>
        </div>
      </div>

      <div className="bg-dark-700 rounded-lg p-3">
        <h4 className="text-sm font-medium text-white mb-3">Algorithm Component Performance</h4>
        <div className="space-y-2">
          {[
            { name: 'Technical Analysis', accuracy: 78.5, contribution: 35 },
            { name: 'Smart Money Concepts', accuracy: 82.1, contribution: 25 },
            { name: 'Pattern Recognition', accuracy: 74.3, contribution: 20 },
            { name: 'Sentiment Analysis', accuracy: 68.9, contribution: 10 },
            { name: 'Whale Intelligence', accuracy: 85.2, contribution: 5 },
            { name: 'ML Predictions', accuracy: 71.7, contribution: 5 }
          ].map((component, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm text-gray-300">{component.name}</span>
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-400">{component.contribution}%</span>
                <div className="w-12 bg-dark-600 rounded-full h-2">
                  <div
                    className="bg-primary-500 h-2 rounded-full"
                    style={{ width: `${component.accuracy}%` }}
                  ></div>
                </div>
                <span className="text-sm text-white w-12">{component.accuracy}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <button className="w-full bg-primary-600 hover:bg-primary-700 text-white py-2 rounded text-sm transition-colors">
        Run Custom Backtest
      </button>
    </div>
  );

  return (
    <div className="h-full flex flex-col">
      {/* Enhanced Header with Tabs */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Brain className="h-5 w-5 mr-2 text-primary-500" />
          AI Trading Signals
        </h3>
        <div className="flex items-center space-x-2">
          <div className="text-xs bg-success-900/30 text-success-400 px-2 py-1 rounded">
            {signalPerformance?.win_rate.toFixed(1)}% Win Rate
          </div>
          <div className="text-xs text-gray-400">
            {signals.filter(s => s.status === 'ACTIVE').length} active
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-4">
        {[
          { key: 'signals', label: 'Live Signals', icon: Zap },
          { key: 'performance', label: 'Performance', icon: BarChart3 },
          { key: 'backtest', label: 'Backtest', icon: Activity }
        ].map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key as any)}
            className={`flex items-center space-x-1 px-3 py-2 rounded text-sm transition-colors ${activeTab === key
                ? 'bg-primary-600 text-white'
                : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
              }`}
          >
            <Icon className="h-3 w-3" />
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* Confidence Filter for Signals Tab */}
      {activeTab === 'signals' && (
        <div className="flex space-x-1 mb-4">
          {[
            { key: 'all', label: 'All' },
            { key: 'high', label: 'High (80%+)' },
            { key: 'medium', label: 'Medium (60-79%)' },
            { key: 'low', label: 'Low (<60%)' }
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setConfidenceFilter(key as any)}
              className={`px-2 py-1 rounded text-xs transition-colors ${confidenceFilter === key
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
                }`}
            >
              {label}
            </button>
          ))}
        </div>
      )}

      {/* Tab Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'performance' && <PerformanceTab />}
        {activeTab === 'backtest' && <BacktestTab />}
        {activeTab === 'signals' && (
          <div className="flex-1 overflow-auto space-y-3">
            {signals.map((signal) => (
              <div
                key={signal.id}
                className={`border rounded-lg p-3 cursor-pointer transition-all hover:bg-dark-600/50 ${selectedSignal?.id === signal.id ? 'ring-2 ring-primary-500' : ''
                  } ${getSignalColor(signal.direction)}`}
                onClick={() => setSelectedSignal(selectedSignal?.id === signal.id ? null : signal)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getSignalIcon(signal.direction)}
                    <span className="font-medium">{signal.symbol}</span>
                    <span className="text-sm px-2 py-1 rounded bg-current/20">
                      {signal.direction}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{signal.confidence}%</div>
                    <div className="text-xs opacity-75">confidence</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <div className="text-gray-400">Entry</div>
                    <div className="font-medium">${signal.entry_price.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">R:R</div>
                    <div className="font-medium">{signal.risk_reward_ratio.toFixed(1)}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">Expires</div>
                    <div className="font-medium">{formatTimeRemaining(signal.expires_at)}</div>
                  </div>
                </div>

                {selectedSignal?.id === signal.id && (
                  <div className="mt-4 pt-3 border-t border-current/20">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Target className="h-4 w-4 text-success-400" />
                          <span className="text-sm text-gray-300">Take Profit</span>
                        </div>
                        <div className="text-lg font-medium text-white">
                          ${signal.take_profit?.toLocaleString()}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Shield className="h-4 w-4 text-danger-400" />
                          <span className="text-sm text-gray-300">Stop Loss</span>
                        </div>
                        <div className="text-lg font-medium text-white">
                          ${signal.stop_loss?.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    <AlgorithmBreakdown breakdown={signal.algorithm_breakdown} />

                    <div className="flex space-x-2 mt-4">
                      <button className="flex-1 bg-primary-600 hover:bg-primary-700 text-white py-2 px-4 rounded text-sm transition-colors">
                        Execute Trade
                      </button>
                      <button className="px-4 py-2 border border-gray-600 text-gray-300 hover:text-white hover:border-gray-500 rounded text-sm transition-colors">
                        Backtest
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
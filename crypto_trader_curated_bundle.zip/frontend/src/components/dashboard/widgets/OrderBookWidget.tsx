'use client';

import { useState, useEffect } from 'react';
import { BookOpen, TrendingUp, TrendingDown } from 'lucide-react';

interface OrderBookEntry {
  price: number;
  quantity: number;
  total: number;
}

interface OrderBookData {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  spread: number;
  spreadPercent: number;
}

export function OrderBookWidget() {
  const [orderBook, setOrderBook] = useState<OrderBookData | null>(null);
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');

  useEffect(() => {
    // Mock order book data
    const generateOrderBook = (): OrderBookData => {
      const currentPrice = 43250;
      const bids: OrderBookEntry[] = [];
      const asks: OrderBookEntry[] = [];
      
      // Generate bids (buy orders)
      for (let i = 0; i < 15; i++) {
        const price = currentPrice - (i + 1) * 5;
        const quantity = Math.random() * 2 + 0.1;
        const total = price * quantity;
        bids.push({ price, quantity, total });
      }
      
      // Generate asks (sell orders)
      for (let i = 0; i < 15; i++) {
        const price = currentPrice + (i + 1) * 5;
        const quantity = Math.random() * 2 + 0.1;
        const total = price * quantity;
        asks.push({ price, quantity, total });
      }
      
      const spread = asks[0].price - bids[0].price;
      const spreadPercent = (spread / currentPrice) * 100;
      
      return { bids, asks, spread, spreadPercent };
    };

    const updateOrderBook = () => {
      setOrderBook(generateOrderBook());
    };

    updateOrderBook();
    const interval = setInterval(updateOrderBook, 2000);
    
    return () => clearInterval(interval);
  }, [selectedSymbol]);

  const formatPrice = (price: number) => price.toFixed(2);
  const formatQuantity = (quantity: number) => quantity.toFixed(4);

  if (!orderBook) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="spinner h-8 w-8"></div>
      </div>
    );
  }

  const maxBidTotal = Math.max(...orderBook.bids.map(b => b.total));
  const maxAskTotal = Math.max(...orderBook.asks.map(a => a.total));
  const maxTotal = Math.max(maxBidTotal, maxAskTotal);

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <BookOpen className="h-5 w-5 mr-2 text-primary-500" />
          Order Book
        </h3>
        <select
          value={selectedSymbol}
          onChange={(e) => setSelectedSymbol(e.target.value)}
          className="bg-dark-700 border border-dark-600 rounded px-2 py-1 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
        >
          <option value="BTCUSDT">BTCUSDT</option>
          <option value="ETHUSDT">ETHUSDT</option>
          <option value="BNBUSDT">BNBUSDT</option>
        </select>
      </div>

      {/* Spread Info */}
      <div className="bg-dark-700 rounded p-2 mb-3">
        <div className="flex justify-between items-center text-sm">
          <span className="text-gray-400">Spread</span>
          <div className="text-right">
            <div className="text-white">${orderBook.spread.toFixed(2)}</div>
            <div className="text-gray-400">{orderBook.spreadPercent.toFixed(3)}%</div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        {/* Headers */}
        <div className="grid grid-cols-3 gap-2 text-xs text-gray-400 mb-2 px-1">
          <div>Price (USDT)</div>
          <div className="text-right">Amount (BTC)</div>
          <div className="text-right">Total</div>
        </div>

        <div className="h-full overflow-auto">
          {/* Asks (Sell Orders) - Reversed to show highest first */}
          <div className="space-y-1 mb-2">
            {orderBook.asks.slice().reverse().map((ask, index) => (
              <div
                key={`ask-${index}`}
                className="relative grid grid-cols-3 gap-2 text-xs py-1 px-1 hover:bg-danger-900/20 cursor-pointer"
              >
                <div
                  className="absolute inset-0 bg-danger-900/10"
                  style={{ width: `${(ask.total / maxTotal) * 100}%` }}
                ></div>
                <div className="relative text-danger-400">{formatPrice(ask.price)}</div>
                <div className="relative text-right text-white">{formatQuantity(ask.quantity)}</div>
                <div className="relative text-right text-gray-400">{ask.total.toFixed(0)}</div>
              </div>
            ))}
          </div>

          {/* Current Price */}
          <div className="bg-dark-700 rounded p-2 my-2">
            <div className="flex items-center justify-center space-x-2">
              <TrendingUp className="h-4 w-4 text-success-400" />
              <span className="text-white font-medium">$43,250.50</span>
              <span className="text-success-400 text-sm">+2.45%</span>
            </div>
          </div>

          {/* Bids (Buy Orders) */}
          <div className="space-y-1">
            {orderBook.bids.map((bid, index) => (
              <div
                key={`bid-${index}`}
                className="relative grid grid-cols-3 gap-2 text-xs py-1 px-1 hover:bg-success-900/20 cursor-pointer"
              >
                <div
                  className="absolute inset-0 bg-success-900/10"
                  style={{ width: `${(bid.total / maxTotal) * 100}%` }}
                ></div>
                <div className="relative text-success-400">{formatPrice(bid.price)}</div>
                <div className="relative text-right text-white">{formatQuantity(bid.quantity)}</div>
                <div className="relative text-right text-gray-400">{bid.total.toFixed(0)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="mt-3 pt-3 border-t border-dark-700">
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <div className="text-gray-400">24h Volume</div>
            <div className="text-white">28,450 BTC</div>
          </div>
          <div>
            <div className="text-gray-400">24h High/Low</div>
            <div className="text-white">$44,200 / $42,100</div>
          </div>
        </div>
      </div>
    </div>
  );
}
'use client';

import { useState, useEffect, useRef, useMemo } from 'react';
import { BarChart3, TrendingUp, Settings, Maximize2, Layers, PenTool, Target, AlertTriangle, Activity, Zap, Eye, EyeOff } from 'lucide-react';
import { marketService } from '@/services/marketService';
import { signalService } from '@/services/signalService';
import { realDataService } from '@/services/realDataService';

interface TechnicalIndicator {
  id: string;
  name: string;
  category: 'trend' | 'momentum' | 'volatility' | 'volume';
  enabled: boolean;
  settings: Record<string, any>;
}

interface PatternDetection {
  id: string;
  type: 'harmonic' | 'classic' | 'candlestick';
  name: string;
  confidence: number;
  coordinates: { x: number; y: number }[];
  target_price?: number;
  stop_loss?: number;
}

interface AISignalOverlay {
  id: string;
  type: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  timestamp: number;
  reasoning: string[];
}

export function TradingChartWidget() {
  const chartRef = useRef<HTMLDivElement>(null);
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');
  const [selectedTimeframe, setSelectedTimeframe] = useState('1H');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeDrawingTool, setActiveDrawingTool] = useState<'none' | 'trendline' | 'rectangle' | 'fibonacci' | 'text'>('none');
  const [showIndicators, setShowIndicators] = useState(true);
  const [showPatterns, setShowPatterns] = useState(true);
  const [showAISignals, setShowAISignals] = useState(true);
  const [indicatorPanel, setIndicatorPanel] = useState(false);
  
  // Real data states
  const [realTimePrice, setRealTimePrice] = useState<number>(0);
  const [priceChange, setPriceChange] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [chartData, setChartData] = useState<any[]>([]);
  const [realAISignals, setRealAISignals] = useState<AISignalOverlay[]>([]);

  // Real data fetching
  useEffect(() => {
    const fetchRealData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch real-time price data
        const priceData = await marketService.getTickers();
        const currentSymbolData = priceData.find(ticker => ticker.symbol === selectedSymbol.replace('USDT', ''));
        
        if (currentSymbolData) {
          setRealTimePrice(currentSymbolData.price);
          setPriceChange(currentSymbolData.change);
        }

        // Fetch historical chart data
        const fromDate = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours ago
        const toDate = new Date();
        const historicalData = await marketService.getHistoricalPrices(selectedSymbol, fromDate, toDate, selectedTimeframe.toLowerCase());
        setChartData(historicalData);

        // Fetch AI signals
        const signals = await signalService.getLiveSignals([selectedSymbol]);
        const formattedSignals = signals.map(signal => ({
          id: signal.id,
          type: signal.signal as 'BUY' | 'SELL' | 'HOLD',
          confidence: signal.confidence * 100,
          price: signal.entry_price,
          timestamp: new Date(signal.created_at).getTime(),
          reasoning: [signal.algorithm_breakdown ? 'AI Analysis' : 'Technical Analysis']
        }));
        setRealAISignals(formattedSignals);

      } catch (error) {
        console.error('Error fetching real data:', error);
        // Fallback to mock data on error
      } finally {
        setIsLoading(false);
      }
    };

    fetchRealData();
    
    // Set up real-time updates
    const interval = setInterval(fetchRealData, 5000); // Update every 5 seconds
    return () => clearInterval(interval);
  }, [selectedSymbol, selectedTimeframe]);

  const symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT', 'MATICUSDT', 'DOTUSDT', 'AVAXUSDT'];
  const timeframes = ['1m', '5m', '15m', '30m', '1H', '2H', '4H', '6H', '12H', '1D', '3D', '1W', '1M'];

  // Technical Indicators State
  const [technicalIndicators, setTechnicalIndicators] = useState<TechnicalIndicator[]>([
    { id: 'rsi', name: 'RSI (14)', category: 'momentum', enabled: true, settings: { period: 14 } },
    { id: 'macd', name: 'MACD (12,26,9)', category: 'momentum', enabled: true, settings: { fast: 12, slow: 26, signal: 9 } },
    { id: 'bb', name: 'Bollinger Bands (20,2)', category: 'volatility', enabled: true, settings: { period: 20, deviation: 2 } },
    { id: 'sma20', name: 'SMA (20)', category: 'trend', enabled: false, settings: { period: 20 } },
    { id: 'ema50', name: 'EMA (50)', category: 'trend', enabled: false, settings: { period: 50 } },
    { id: 'vwap', name: 'VWAP', category: 'volume', enabled: false, settings: {} },
    { id: 'stoch', name: 'Stochastic (14,3,3)', category: 'momentum', enabled: false, settings: { k: 14, d: 3, smooth: 3 } },
    { id: 'atr', name: 'ATR (14)', category: 'volatility', enabled: false, settings: { period: 14 } },
    { id: 'obv', name: 'OBV', category: 'volume', enabled: false, settings: {} },
    { id: 'ichimoku', name: 'Ichimoku Cloud', category: 'trend', enabled: false, settings: { tenkan: 9, kijun: 26, senkou: 52 } }
  ]);

  // Mock Pattern Detection Data
  const [detectedPatterns] = useState<PatternDetection[]>([
    {
      id: 'pattern1',
      type: 'harmonic',
      name: 'Bullish Butterfly',
      confidence: 87,
      coordinates: [{ x: 100, y: 150 }, { x: 200, y: 100 }, { x: 300, y: 180 }, { x: 400, y: 120 }],
      target_price: 44500,
      stop_loss: 42800
    },
    {
      id: 'pattern2',
      type: 'classic',
      name: 'Head & Shoulders',
      confidence: 72,
      coordinates: [{ x: 150, y: 120 }, { x: 250, y: 80 }, { x: 350, y: 120 }],
      target_price: 41200
    },
    {
      id: 'pattern3',
      type: 'candlestick',
      name: 'Bullish Engulfing',
      confidence: 91,
      coordinates: [{ x: 380, y: 140 }]
    }
  ]);

  // Mock AI Signal Overlays
  const [aiSignals] = useState<AISignalOverlay[]>([
    {
      id: 'signal1',
      type: 'BUY',
      confidence: 85,
      price: 43250,
      timestamp: Date.now() - 30 * 60 * 1000,
      reasoning: ['Strong RSI divergence', 'Smart money accumulation', 'Bullish pattern completion']
    },
    {
      id: 'signal2',
      type: 'SELL',
      confidence: 72,
      price: 44100,
      timestamp: Date.now() - 2 * 60 * 60 * 1000,
      reasoning: ['Overbought conditions', 'Resistance level reached', 'Negative sentiment shift']
    }
  ]);

  useEffect(() => {
    // In a real implementation, this would initialize TradingView widget
    // For now, we'll create a placeholder chart
    if (chartRef.current) {
      // Placeholder for TradingView widget initialization
      console.log('Initializing TradingView chart for', selectedSymbol, selectedTimeframe);
    }
  }, [selectedSymbol, selectedTimeframe]);

  // Mock chart data for demonstration
  const generateMockData = () => {
    const data = [];
    let price = 43000;
    const now = Date.now();
    
    for (let i = 100; i >= 0; i--) {
      const time = now - (i * 60 * 60 * 1000); // 1 hour intervals
      const change = (Math.random() - 0.5) * 1000;
      price += change;
      
      data.push({
        time: time,
        open: price - change,
        high: price + Math.random() * 500,
        low: price - Math.random() * 500,
        close: price,
        volume: Math.random() * 1000000
      });
    }
    
    return data;
  };

  const mockData = generateMockData();

  // Simple SVG candlestick chart for demonstration
  const SimpleCandlestickChart = () => {
    const width = 400;
    const height = 200;
    const padding = 40;
    
    const prices = mockData.map(d => [d.open, d.high, d.low, d.close]).flat();
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceRange = maxPrice - minPrice;
    
    return (
      <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`} className="bg-dark-800 rounded">
        {mockData.slice(-50).map((candle, index) => {
          const x = padding + (index * (width - 2 * padding)) / 49;
          const openY = height - padding - ((candle.open - minPrice) / priceRange) * (height - 2 * padding);
          const closeY = height - padding - ((candle.close - minPrice) / priceRange) * (height - 2 * padding);
          const highY = height - padding - ((candle.high - minPrice) / priceRange) * (height - 2 * padding);
          const lowY = height - padding - ((candle.low - minPrice) / priceRange) * (height - 2 * padding);
          
          const isGreen = candle.close > candle.open;
          const color = isGreen ? '#22c55e' : '#ef4444';
          
          return (
            <g key={index}>
              {/* Wick */}
              <line
                x1={x}
                y1={highY}
                x2={x}
                y2={lowY}
                stroke={color}
                strokeWidth="1"
              />
              {/* Body */}
              <rect
                x={x - 2}
                y={Math.min(openY, closeY)}
                width="4"
                height={Math.abs(closeY - openY) || 1}
                fill={color}
              />
            </g>
          );
        })}
        
        {/* Price labels */}
        <text x="5" y="20" fill="#9ca3af" fontSize="10">
          ${maxPrice.toFixed(0)}
        </text>
        <text x="5" y={height - 10} fill="#9ca3af" fontSize="10">
          ${minPrice.toFixed(0)}
        </text>
      </svg>
    );
  };

  // Toggle indicator function
  const toggleIndicator = (indicatorId: string) => {
    setTechnicalIndicators(prev => prev.map(indicator => 
      indicator.id === indicatorId 
        ? { ...indicator, enabled: !indicator.enabled }
        : indicator
    ));
  };

  // Get enabled indicators by category
  const enabledIndicators = useMemo(() => {
    return technicalIndicators.filter(indicator => indicator.enabled);
  }, [technicalIndicators]);

  return (
    <div className="h-full flex flex-col">
      {/* Enhanced Header with Advanced Controls */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <BarChart3 className="h-5 w-5 mr-2 text-primary-500" />
          Advanced Trading Chart
          <span className="ml-2 text-xs bg-primary-600 text-white px-2 py-1 rounded">
            {enabledIndicators.length} indicators
          </span>
        </h3>
        <div className="flex items-center space-x-2">
          {/* Overlay Toggle Buttons */}
          <button
            onClick={() => setShowIndicators(!showIndicators)}
            className={`p-1 transition-colors ${showIndicators ? 'text-primary-400' : 'text-gray-400 hover:text-white'}`}
            title="Toggle Indicators"
          >
            <Activity className="h-4 w-4" />
          </button>
          <button
            onClick={() => setShowPatterns(!showPatterns)}
            className={`p-1 transition-colors ${showPatterns ? 'text-success-400' : 'text-gray-400 hover:text-white'}`}
            title="Toggle Pattern Recognition"
          >
            <Target className="h-4 w-4" />
          </button>
          <button
            onClick={() => setShowAISignals(!showAISignals)}
            className={`p-1 transition-colors ${showAISignals ? 'text-warning-400' : 'text-gray-400 hover:text-white'}`}
            title="Toggle AI Signals"
          >
            <Zap className="h-4 w-4" />
          </button>
          <button
            onClick={() => setIndicatorPanel(!indicatorPanel)}
            className="p-1 text-gray-400 hover:text-white transition-colors"
            title="Indicator Panel"
          >
            <Layers className="h-4 w-4" />
          </button>
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1 text-gray-400 hover:text-white transition-colors"
          >
            <Maximize2 className="h-4 w-4" />
          </button>
          <button className="p-1 text-gray-400 hover:text-white transition-colors">
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Symbol and Timeframe Selection */}
      <div className="flex items-center space-x-4 mb-4">
        <select
          value={selectedSymbol}
          onChange={(e) => setSelectedSymbol(e.target.value)}
          className="bg-dark-700 border border-dark-600 rounded px-3 py-1 text-white text-sm focus:outline-none focus:ring-1 focus:ring-primary-500"
        >
          {symbols.map(symbol => (
            <option key={symbol} value={symbol}>{symbol}</option>
          ))}
        </select>
        
        <div className="flex space-x-1">
          {timeframes.map(tf => (
            <button
              key={tf}
              onClick={() => setSelectedTimeframe(tf)}
              className={`px-2 py-1 text-xs rounded transition-colors ${
                selectedTimeframe === tf
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Container */}
      <div className="flex-1 relative">
        <div ref={chartRef} className="w-full h-full">
          {/* Placeholder chart - In real implementation, TradingView widget would go here */}
          <div className="w-full h-full bg-dark-800 rounded-lg p-4">
            <div className="w-full h-full">
              <SimpleCandlestickChart />
            </div>
          </div>
        </div>
        
        {/* Chart overlay with current price */}
        <div className="absolute top-4 left-4 bg-dark-700/90 backdrop-blur-sm rounded px-3 py-2">
          <div className="flex items-center space-x-2">
            <span className="text-white font-medium">{selectedSymbol}</span>
            <span className="text-success-400 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              $43,250.50
            </span>
            <span className="text-success-400 text-sm">+2.45%</span>
          </div>
        </div>
        
        {/* AI Signal Markers */}
        <div className="absolute top-4 right-4 space-y-2">
          <div className="bg-success-900/80 border border-success-500/50 rounded px-2 py-1 text-xs text-success-300">
            AI BUY Signal • 85% confidence
          </div>
        </div>
      </div>

      {/* Chart Controls */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-dark-700">
        <div className="flex items-center space-x-2 text-xs text-gray-400">
          <span>Indicators:</span>
          <button className="text-primary-400 hover:text-primary-300">RSI</button>
          <button className="text-primary-400 hover:text-primary-300">MACD</button>
          <button className="text-primary-400 hover:text-primary-300">BB</button>
          <button className="text-gray-400 hover:text-white">+ Add</button>
        </div>
        
        <div className="flex items-center space-x-2">
          <button className="bg-dark-700 hover:bg-dark-600 text-white px-3 py-1 rounded text-xs transition-colors">
            Drawing Tools
          </button>
          <button className="bg-primary-600 hover:bg-primary-700 text-white px-3 py-1 rounded text-xs transition-colors">
            Trade
          </button>
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Globe, 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  Brain, 
  Target, 
  AlertTriangle, 
  ArrowRight, 
  Zap 
} from 'lucide-react';
import { aiExternalService, MarketRegime, SentimentData } from '@/services/aiExternalService';

interface AIMarketInsightWidgetProps {
  className?: string;
  symbol?: string;
}

export function AIMarketInsightWidget({ className, symbol = 'BTC/USDT' }: AIMarketInsightWidgetProps) {
  const [sentiment, setSentiment] = useState<SentimentData | null>(null);
  const [marketRegime, setMarketRegime] = useState<MarketRegime | null>(null);
  const [forecast, setForecast] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'sentiment' | 'regime' | 'forecast'>('sentiment');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Fetch data from external AI services
        const [sentimentData, regimeData, forecastData] = await Promise.all([
          aiExternalService.getSentiment(symbol),
          aiExternalService.getMarketRegime(),
          aiExternalService.getForecast(symbol, '7d')
        ]);
        
        setSentiment(sentimentData);
        setMarketRegime(regimeData);
        setForecast(forecastData);
      } catch (err) {
        console.error('Error fetching AI market insights:', err);
        setError('Failed to load market insights');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
    
    // Set up interval for real-time updates
    const interval = setInterval(fetchData, 300000); // Update every 5 minutes
    return () => clearInterval(interval);
  }, [symbol]);

  const getSentimentColor = (score: number) => {
    if (score > 50) return 'text-green-400';
    if (score > 0) return 'text-green-300';
    if (score > -50) return 'text-red-300';
    return 'text-red-400';
  };

  const getRegimeColor = (regime: string) => {
    switch (regime) {
      case 'bull': return 'text-green-400';
      case 'bear': return 'text-red-400';
      case 'volatile': return 'text-yellow-400';
      default: return 'text-blue-400';
    }
  };

  const getForecastColor = (prediction: string) => {
    switch (prediction) {
      case 'bullish': return 'text-green-400';
      case 'bearish': return 'text-red-400';
      default: return 'text-blue-400';
    }
  };

  if (isLoading) {
    return (
      <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center">
            <Brain className="w-4 h-4 mr-2 text-purple-400" />
            AI Market Insights
          </h3>
          <div className="text-xs text-gray-400">Loading...</div>
        </div>
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          <div className="h-20 bg-gray-700 rounded"></div>
          <div className="h-4 bg-gray-700 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white flex items-center">
          <Brain className="w-4 h-4 mr-2 text-purple-400" />
          AI Market Insights
        </h3>
        
        <div className="flex text-xs bg-gray-700/50 rounded overflow-hidden">
          <button 
            onClick={() => setActiveTab('sentiment')}
            className={`px-2 py-1 ${activeTab === 'sentiment' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}
          >
            Sentiment
          </button>
          <button 
            onClick={() => setActiveTab('regime')}
            className={`px-2 py-1 ${activeTab === 'regime' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}
          >
            Regime
          </button>
          <button 
            onClick={() => setActiveTab('forecast')}
            className={`px-2 py-1 ${activeTab === 'forecast' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}
          >
            Forecast
          </button>
        </div>
      </div>
      
      {error && (
        <div className="p-2 bg-red-500/20 text-red-400 text-xs rounded mb-2">
          {error}
        </div>
      )}
      
      <div className="min-h-[150px]">
        {activeTab === 'sentiment' && sentiment && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm">{symbol} Sentiment</div>
              <div className={`text-sm font-bold ${getSentimentColor(sentiment.score)}`}>
                {sentiment.score > 0 ? '+' : ''}{sentiment.score.toFixed(1)}
              </div>
            </div>
            
            <div className="relative h-4 bg-gray-700 rounded-full overflow-hidden">
              <div className="absolute inset-0 flex">
                <div className="bg-red-500 h-full" style={{ width: '50%' }}></div>
                <div className="bg-green-500 h-full" style={{ width: '50%' }}></div>
              </div>
              <div 
                className="absolute top-0 bottom-0 w-2 bg-white rounded-full transform -translate-x-1/2"
                style={{ left: `${(sentiment.score + 100) / 2}%` }}
              ></div>
            </div>
            
            <div className="flex justify-between text-xs text-gray-400">
              <div>Bearish</div>
              <div>Neutral</div>
              <div>Bullish</div>
            </div>
            
            <div className="mt-2 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Sources:</span>
                <span>{sentiment.sources.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">24h Change:</span>
                <span className={sentiment.change24h >= 0 ? 'text-green-400' : 'text-red-400'}>
                  {sentiment.change24h >= 0 ? '+' : ''}{sentiment.change24h.toFixed(1)}
                </span>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'regime' && marketRegime && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm">Current Market Regime</div>
              <div className={`text-sm font-bold capitalize ${getRegimeColor(marketRegime.current)}`}>
                {marketRegime.current}
              </div>
            </div>
            
            <div className="p-3 bg-gray-700/30 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                {marketRegime.current === 'bull' && <TrendingUp className="w-5 h-5 text-green-400" />}
                {marketRegime.current === 'bear' && <TrendingDown className="w-5 h-5 text-red-400" />}
                {marketRegime.current === 'sideways' && <BarChart3 className="w-5 h-5 text-blue-400" />}
                {marketRegime.current === 'volatile' && <AlertTriangle className="w-5 h-5 text-yellow-400" />}
                <div>
                  <div className="font-medium capitalize">{marketRegime.current} Market</div>
                  <div className="text-xs text-gray-400">
                    {marketRegime.confidence.toFixed(1)}% confidence
                  </div>
                </div>
              </div>
              
              <div className="flex items-center text-sm mt-3">
                <div className="text-gray-400">Forecast:</div>
                <div className="flex items-center ml-2">
                  <span className="capitalize">{marketRegime.forecast}</span>
                  <ArrowRight className="w-3 h-3 mx-1" />
                  <span className={`capitalize ${getRegimeColor(marketRegime.current)}`}>
                    {marketRegime.current}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="text-xs text-gray-400">
              This regime has been active for {Math.floor((new Date().getTime() - marketRegime.since.getTime()) / (1000 * 60 * 60 * 24))} days
            </div>
          </div>
        )}
        
        {activeTab === 'forecast' && forecast && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm">{symbol} 7-Day Forecast</div>
              <div className={`text-sm font-bold capitalize ${getForecastColor(forecast.prediction)}`}>
                {forecast.prediction}
              </div>
            </div>
            
            <div className="p-3 bg-gray-700/30 rounded-lg">
              <div className="flex items-center space-x-2 mb-3">
                {forecast.prediction === 'bullish' && <TrendingUp className="w-5 h-5 text-green-400" />}
                {forecast.prediction === 'bearish' && <TrendingDown className="w-5 h-5 text-red-400" />}
                {forecast.prediction === 'neutral' && <BarChart3 className="w-5 h-5 text-blue-400" />}
                <div>
                  <div className="font-medium">Price Target: ${forecast.priceTarget.toLocaleString(undefined, {maximumFractionDigits: 2})}</div>
                  <div className="text-xs text-gray-400">
                    {forecast.confidence.toFixed(1)}% confidence • {forecast.timeframe} timeframe
                  </div>
                </div>
              </div>
              
              <div className="space-y-1">
                <div className="text-xs text-gray-400">AI Reasoning:</div>
                {forecast.reasoning.map((reason: string, index: number) => (
                  <div key={index} className="text-xs flex items-start">
                    <Zap className="w-3 h-3 text-yellow-400 mt-0.5 mr-1 flex-shrink-0" />
                    <span>{reason}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      
      <button 
        className="w-full mt-3 bg-purple-600/30 hover:bg-purple-600/50 text-purple-400 py-1.5 rounded text-xs font-medium transition-colors"
        onClick={() => window.dispatchEvent(new CustomEvent('open-ai-lab', { detail: { tab: 'main' } }))}
      >
        View Full AI Analysis
      </button>
    </div>
  );
}
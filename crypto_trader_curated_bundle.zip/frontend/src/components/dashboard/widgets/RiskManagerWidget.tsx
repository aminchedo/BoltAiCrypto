'use client';

import { useState, useEffect } from 'react';
import { Shield, AlertTriangle, TrendingDown, Activity } from 'lucide-react';

interface RiskMetrics {
  portfolio_risk_score: number;
  var_1d: number;
  var_7d: number;
  max_drawdown: number;
  current_drawdown: number;
  sharpe_ratio: number;
  portfolio_heat: number;
  correlation_risk: number;
  concentration_risk: number;
}

export function RiskManagerWidget() {
  const [riskMetrics, setRiskMetrics] = useState<RiskMetrics | null>(null);
  const [alertLevel, setAlertLevel] = useState<'low' | 'medium' | 'high'>('medium');

  useEffect(() => {
    // Mock risk metrics data
    const mockMetrics: RiskMetrics = {
      portfolio_risk_score: 65,
      var_1d: 2850.50,
      var_7d: 8420.75,
      max_drawdown: 15.8,
      current_drawdown: 3.2,
      sharpe_ratio: 1.85,
      portfolio_heat: 68,
      correlation_risk: 45,
      concentration_risk: 72
    };

    setRiskMetrics(mockMetrics);
  }, []);

  const getRiskColor = (score: number) => {
    if (score >= 80) return 'text-danger-400';
    if (score >= 60) return 'text-warning-400';
    return 'text-success-400';
  };

  const getRiskBgColor = (score: number) => {
    if (score >= 80) return 'bg-danger-500';
    if (score >= 60) return 'bg-warning-500';
    return 'bg-success-500';
  };

  const getRiskLevel = (score: number) => {
    if (score >= 80) return 'High Risk';
    if (score >= 60) return 'Moderate Risk';
    return 'Low Risk';
  };

  if (!riskMetrics) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="spinner h-8 w-8"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Shield className="h-5 w-5 mr-2 text-primary-500" />
          Risk Manager
        </h3>
        <div className={`text-xs px-2 py-1 rounded ${
          riskMetrics.portfolio_risk_score >= 80 
            ? 'bg-danger-900/30 text-danger-400'
            : riskMetrics.portfolio_risk_score >= 60
            ? 'bg-warning-900/30 text-warning-400'
            : 'bg-success-900/30 text-success-400'
        }`}>
          {getRiskLevel(riskMetrics.portfolio_risk_score)}
        </div>
      </div>

      {/* Overall Risk Score */}
      <div className="bg-dark-700 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-400">Portfolio Risk Score</span>
          <span className={`text-lg font-bold ${getRiskColor(riskMetrics.portfolio_risk_score)}`}>
            {riskMetrics.portfolio_risk_score}/100
          </span>
        </div>
        <div className="w-full bg-dark-600 rounded-full h-3">
          <div
            className={`h-3 rounded-full ${getRiskBgColor(riskMetrics.portfolio_risk_score)}`}
            style={{ width: `${riskMetrics.portfolio_risk_score}%` }}
          ></div>
        </div>
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>Low</span>
          <span>Moderate</span>
          <span>High</span>
        </div>
      </div>

      {/* Risk Metrics Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <TrendingDown className="h-4 w-4 text-danger-400" />
            <span className="text-xs text-gray-400">Max Drawdown</span>
          </div>
          <div className="text-lg font-semibold text-white">
            {riskMetrics.max_drawdown.toFixed(1)}%
          </div>
          <div className="text-xs text-gray-500">
            Current: {riskMetrics.current_drawdown.toFixed(1)}%
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Activity className="h-4 w-4 text-primary-400" />
            <span className="text-xs text-gray-400">Sharpe Ratio</span>
          </div>
          <div className="text-lg font-semibold text-white">
            {riskMetrics.sharpe_ratio.toFixed(2)}
          </div>
          <div className="text-xs text-success-400">
            Above Average
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <AlertTriangle className="h-4 w-4 text-warning-400" />
            <span className="text-xs text-gray-400">VaR (1D)</span>
          </div>
          <div className="text-lg font-semibold text-white">
            ${riskMetrics.var_1d.toLocaleString()}
          </div>
          <div className="text-xs text-gray-500">
            95% confidence
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <AlertTriangle className="h-4 w-4 text-warning-400" />
            <span className="text-xs text-gray-400">VaR (7D)</span>
          </div>
          <div className="text-lg font-semibold text-white">
            ${riskMetrics.var_7d.toLocaleString()}
          </div>
          <div className="text-xs text-gray-500">
            95% confidence
          </div>
        </div>
      </div>

      {/* Risk Breakdown */}
      <div className="flex-1">
        <h4 className="text-sm font-medium text-white mb-3">Risk Breakdown</h4>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Portfolio Heat</span>
              <span className={getRiskColor(riskMetrics.portfolio_heat)}>
                {riskMetrics.portfolio_heat}%
              </span>
            </div>
            <div className="w-full bg-dark-600 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${getRiskBgColor(riskMetrics.portfolio_heat)}`}
                style={{ width: `${riskMetrics.portfolio_heat}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Concentration Risk</span>
              <span className={getRiskColor(riskMetrics.concentration_risk)}>
                {riskMetrics.concentration_risk}%
              </span>
            </div>
            <div className="w-full bg-dark-600 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${getRiskBgColor(riskMetrics.concentration_risk)}`}
                style={{ width: `${riskMetrics.concentration_risk}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Correlation Risk</span>
              <span className={getRiskColor(riskMetrics.correlation_risk)}>
                {riskMetrics.correlation_risk}%
              </span>
            </div>
            <div className="w-full bg-dark-600 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${getRiskBgColor(riskMetrics.correlation_risk)}`}
                style={{ width: `${riskMetrics.correlation_risk}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Risk Actions */}
      <div className="mt-4 pt-4 border-t border-dark-700 space-y-2">
        <button className="w-full bg-danger-600 hover:bg-danger-700 text-white py-2 rounded text-sm transition-colors">
          Emergency Stop All Trades
        </button>
        <div className="grid grid-cols-2 gap-2">
          <button className="bg-dark-700 hover:bg-dark-600 text-gray-400 hover:text-white py-2 rounded text-sm transition-colors">
            Reduce Positions
          </button>
          <button className="bg-dark-700 hover:bg-dark-600 text-gray-400 hover:text-white py-2 rounded text-sm transition-colors">
            Risk Settings
          </button>
        </div>
      </div>
    </div>
  );
}
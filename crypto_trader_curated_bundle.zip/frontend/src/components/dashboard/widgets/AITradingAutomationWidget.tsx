import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  Play, 
  Pause, 
  Settings, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  DollarSign, 
  Target, 
  Shield 
} from 'lucide-react';
import { aiTradingAutomationService, AutomatedPosition, AutomationStats } from '@/services/aiTradingAutomationService';

interface AITradingAutomationWidgetProps {
  className?: string;
}

export function AITradingAutomationWidget({ className }: AITradingAutomationWidgetProps) {
  const [isEnabled, setIsEnabled] = useState(false);
  const [positions, setPositions] = useState<AutomatedPosition[]>([]);
  const [stats, setStats] = useState<AutomationStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Subscribe to position and stats updates
    const unsubscribe = aiTradingAutomationService.subscribe((updatedPositions, updatedStats) => {
      setPositions(updatedPositions);
      setStats(updatedStats);
      setIsEnabled(aiTradingAutomationService.getConfig().enabled);
      setIsLoading(false);
    });
    
    // Initial load
    setPositions(aiTradingAutomationService.getPositions());
    setStats(aiTradingAutomationService.getStats());
    setIsEnabled(aiTradingAutomationService.getConfig().enabled);
    setIsLoading(false);
    
    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  const handleToggleAutomation = () => {
    if (isEnabled) {
      aiTradingAutomationService.stop();
    } else {
      aiTradingAutomationService.start();
    }
    setIsEnabled(!isEnabled);
  };

  const openPositions = positions.filter(p => p.status === 'OPEN');

  if (isLoading) {
    return (
      <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center">
            <Zap className="w-4 h-4 mr-2 text-yellow-400" />
            AI Trading Automation
          </h3>
          <div className="text-xs text-gray-400">Loading...</div>
        </div>
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-700 rounded w-3/4"></div>
          <div className="h-20 bg-gray-700 rounded"></div>
          <div className="h-4 bg-gray-700 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white flex items-center">
          <Zap className="w-4 h-4 mr-2 text-yellow-400" />
          AI Trading Automation
        </h3>
        
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${isEnabled ? 'bg-green-500' : 'bg-gray-500'}`}></div>
          <span className="text-xs text-gray-400">{isEnabled ? 'Active' : 'Inactive'}</span>
        </div>
      </div>
      
      <div className="space-y-4">
        {/* Status Card */}
        <div className={`p-3 rounded-lg border ${
          isEnabled 
            ? 'bg-green-500/10 border-green-500/30' 
            : 'bg-gray-700/30 border-gray-600/30'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              {isEnabled ? (
                <Zap className="w-4 h-4 text-green-400 mr-2" />
              ) : (
                <Pause className="w-4 h-4 text-gray-400 mr-2" />
              )}
              <span className="font-medium">
                {isEnabled ? 'Automation Active' : 'Automation Paused'}
              </span>
            </div>
            <button
              onClick={handleToggleAutomation}
              className={`p-1 rounded ${
                isEnabled 
                  ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
                  : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
              }`}
            >
              {isEnabled ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
          </div>
          
          <div className="text-xs text-gray-400">
            {isEnabled 
              ? `Monitoring ${aiTradingAutomationService.getConfig().symbols.length} symbols for trading opportunities`
              : 'Click play to enable automated trading based on AI signals'
            }
          </div>
        </div>
        
        {/* Performance Stats */}
        {stats && (
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-700/30 p-2 rounded">
              <div className="text-xs text-gray-400">Win Rate</div>
              <div className="text-sm font-medium text-green-400">
                {stats.winRate.toFixed(1)}%
              </div>
            </div>
            <div className="bg-gray-700/30 p-2 rounded">
              <div className="text-xs text-gray-400">Net P&L</div>
              <div className={`text-sm font-medium ${stats.netProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {stats.netProfit >= 0 ? '+' : ''}${stats.netProfit.toFixed(2)}
              </div>
            </div>
            <div className="bg-gray-700/30 p-2 rounded">
              <div className="text-xs text-gray-400">Active Positions</div>
              <div className="text-sm font-medium text-blue-400">
                {stats.activePositions}/{aiTradingAutomationService.getConfig().maxPositions}
              </div>
            </div>
            <div className="bg-gray-700/30 p-2 rounded">
              <div className="text-xs text-gray-400">Total Trades</div>
              <div className="text-sm font-medium text-purple-400">
                {stats.totalTrades}
              </div>
            </div>
          </div>
        )}
        
        {/* Active Positions */}
        {openPositions.length > 0 ? (
          <div>
            <div className="text-xs text-gray-400 mb-2">Active Positions</div>
            <div className="space-y-2">
              {openPositions.slice(0, 2).map((position) => (
                <div 
                  key={position.id}
                  className={`p-2 rounded-lg ${
                    position.unrealizedPnLPercent >= 0 
                      ? 'bg-green-500/10 border border-green-500/20' 
                      : 'bg-red-500/10 border border-red-500/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      {position.direction === 'LONG' ? (
                        <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-400 mr-1" />
                      )}
                      <span className="text-sm">{position.symbol}</span>
                    </div>
                    <div className={`text-xs ${
                      position.unrealizedPnLPercent >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {position.unrealizedPnLPercent >= 0 ? '+' : ''}
                      {position.unrealizedPnLPercent.toFixed(2)}%
                    </div>
                  </div>
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <div>Entry: ${position.entryPrice.toFixed(2)}</div>
                    <div>Current: ${position.currentPrice.toFixed(2)}</div>
                  </div>
                </div>
              ))}
              
              {openPositions.length > 2 && (
                <div className="text-xs text-center text-gray-400">
                  +{openPositions.length - 2} more positions
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center p-3 bg-gray-700/30 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
            <p className="text-sm">No active positions</p>
            <p className="text-xs text-gray-400">
              {isEnabled ? 'Waiting for trading signals...' : 'Enable automation to start trading'}
            </p>
          </div>
        )}
      </div>
      
      <div className="mt-3 flex space-x-2">
        <button 
          className="flex-1 bg-blue-600/30 hover:bg-blue-600/50 text-blue-400 py-1.5 rounded text-xs font-medium transition-colors flex items-center justify-center"
          onClick={() => window.dispatchEvent(new CustomEvent('open-ai-lab', { detail: { tab: 'main' } }))}
        >
          <Target className="w-3 h-3 mr-1" />
          Positions
        </button>
        <button 
          className="flex-1 bg-purple-600/30 hover:bg-purple-600/50 text-purple-400 py-1.5 rounded text-xs font-medium transition-colors flex items-center justify-center"
          onClick={() => window.dispatchEvent(new CustomEvent('open-automation-settings'))}
        >
          <Settings className="w-3 h-3 mr-1" />
          Settings
        </button>
      </div>
    </div>
  );
}
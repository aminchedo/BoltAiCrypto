'use client';

import { useState, useEffect } from 'react';
import { Fish, ArrowUpRight, ArrowDownLeft, AlertTriangle } from 'lucide-react';
import { realDataService } from '@/services/realDataService';
import { newsService } from '@/services/newsService';

interface WhaleTransaction {
  id: string;
  symbol: string;
  amount: number;
  usd_value: number;
  type: 'inflow' | 'outflow' | 'transfer';
  exchange: string;
  timestamp: string;
  impact_score: number;
}

export function WhaleTrackerWidget() {
  const [whaleTransactions, setWhaleTransactions] = useState<WhaleTransaction[]>([]);
  const [filter, setFilter] = useState<'all' | 'large' | 'massive'>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchWhaleData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Try to fetch real whale data from services
        const dashboardData = await realDataService.getDashboardData();
        if (dashboardData.whaleData && dashboardData.whaleData.length > 0) {
          setWhaleTransactions(dashboardData.whaleData);
        } else {
          // Fallback to mock data if no real data available
          const mockTransactions: WhaleTransaction[] = [
      {
        id: '1',
        symbol: 'BTC',
        amount: 250,
        usd_value: 10812500,
        type: 'inflow',
        exchange: 'Binance',
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        impact_score: 8.5
      },
      {
        id: '2',
        symbol: 'ETH',
        amount: 1500,
        usd_value: 4020000,
        type: 'outflow',
        exchange: 'Coinbase',
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        impact_score: 6.2
      },
      {
        id: '3',
        symbol: 'BTC',
        amount: 100,
        usd_value: 4325000,
        type: 'transfer',
        exchange: 'Unknown',
        timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        impact_score: 4.8
      },
      {
        id: '4',
        symbol: 'USDT',
        amount: 50000000,
        usd_value: 50000000,
        type: 'inflow',
        exchange: 'Kraken',
        timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        impact_score: 9.2
      },
      {
        id: '5',
        symbol: 'ETH',
        amount: 800,
        usd_value: 2144000,
        type: 'outflow',
        exchange: 'Bybit',
        timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
        impact_score: 5.1
      }
    ];

          setWhaleTransactions(mockTransactions);
        }
      } catch (error) {
        console.error('Error fetching whale data:', error);
        setError('Failed to fetch whale data');
        // Still set mock data as fallback
        const mockTransactions: WhaleTransaction[] = [
          {
            id: '1',
            symbol: 'BTC',
            amount: 250,
            usd_value: 10812500,
            type: 'inflow',
            exchange: 'Binance',
            timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
            impact_score: 8.5
          }
        ];
        setWhaleTransactions(mockTransactions);
      } finally {
        setIsLoading(false);
      }
    };

    fetchWhaleData();
    // Set up real-time updates every 30 seconds
    const interval = setInterval(fetchWhaleData, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatAmount = (amount: number, symbol: string) => {
    if (symbol === 'USDT' || symbol === 'USDC') {
      return `${(amount / 1000000).toFixed(1)}M ${symbol}`;
    }
    return `${amount.toLocaleString()} ${symbol}`;
  };

  const formatUsdValue = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    return `$${value.toLocaleString()}`;
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    }
    const diffInHours = Math.floor(diffInMinutes / 60);
    return `${diffInHours}h ago`;
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'inflow':
        return <ArrowDownLeft className="h-4 w-4 text-success-400" />;
      case 'outflow':
        return <ArrowUpRight className="h-4 w-4 text-danger-400" />;
      case 'transfer':
        return <ArrowUpRight className="h-4 w-4 text-warning-400" />;
      default:
        return <ArrowUpRight className="h-4 w-4 text-gray-400" />;
    }
  };

  const getImpactColor = (score: number) => {
    if (score >= 8) return 'text-danger-400';
    if (score >= 6) return 'text-warning-400';
    return 'text-success-400';
  };

  const filteredTransactions = whaleTransactions.filter(tx => {
    if (filter === 'large') return tx.usd_value >= 1000000 && tx.usd_value < 10000000;
    if (filter === 'massive') return tx.usd_value >= 10000000;
    return true;
  });

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Fish className="h-5 w-5 mr-2 text-primary-500" />
          Whale Tracker
        </h3>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="bg-dark-700 border border-dark-600 rounded px-2 py-1 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
        >
          <option value="all">All Sizes</option>
          <option value="large">Large ($1M+)</option>
          <option value="massive">Massive ($10M+)</option>
        </select>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">Last Hour</div>
          <div className="text-sm font-medium text-white">
            {whaleTransactions.filter(tx => 
              new Date(tx.timestamp).getTime() > Date.now() - 60 * 60 * 1000
            ).length}
          </div>
        </div>
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">Total Volume</div>
          <div className="text-sm font-medium text-white">
            ${(whaleTransactions.reduce((sum, tx) => sum + tx.usd_value, 0) / 1000000).toFixed(0)}M
          </div>
        </div>
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">Avg Impact</div>
          <div className="text-sm font-medium text-warning-400">
            {(whaleTransactions.reduce((sum, tx) => sum + tx.impact_score, 0) / whaleTransactions.length).toFixed(1)}
          </div>
        </div>
      </div>

      {/* Transaction List */}
      <div className="flex-1 overflow-auto space-y-2">
        {filteredTransactions.map((transaction) => (
          <div
            key={transaction.id}
            className="bg-dark-700 rounded-lg p-3 hover:bg-dark-600 transition-colors"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-2">
                {getTransactionIcon(transaction.type)}
                <div>
                  <div className="text-sm font-medium text-white">
                    {formatAmount(transaction.amount, transaction.symbol)}
                  </div>
                  <div className="text-xs text-gray-400">
                    {transaction.exchange} • {formatTimeAgo(transaction.timestamp)}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium text-white">
                  {formatUsdValue(transaction.usd_value)}
                </div>
                <div className={`text-xs flex items-center ${getImpactColor(transaction.impact_score)}`}>
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Impact: {transaction.impact_score.toFixed(1)}
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className={`text-xs px-2 py-1 rounded ${
                transaction.type === 'inflow' 
                  ? 'bg-success-900/30 text-success-400'
                  : transaction.type === 'outflow'
                  ? 'bg-danger-900/30 text-danger-400'
                  : 'bg-warning-900/30 text-warning-400'
              }`}>
                {transaction.type.toUpperCase()}
              </div>
              
              <div className="w-16 bg-dark-600 rounded-full h-1">
                <div
                  className={`h-1 rounded-full ${
                    transaction.impact_score >= 8 
                      ? 'bg-danger-500'
                      : transaction.impact_score >= 6
                      ? 'bg-warning-500'
                      : 'bg-success-500'
                  }`}
                  style={{ width: `${(transaction.impact_score / 10) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Alert Settings */}
      <div className="mt-4 pt-4 border-t border-dark-700">
        <button className="w-full bg-dark-700 hover:bg-dark-600 text-gray-400 hover:text-white py-2 rounded text-sm transition-colors">
          Configure Whale Alerts
        </button>
      </div>
    </div>
  );
}
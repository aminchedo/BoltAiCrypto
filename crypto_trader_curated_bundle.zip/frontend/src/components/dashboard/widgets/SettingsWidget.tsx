'use client';

import { useState } from 'react';
import { Settings, Save, RotateCcw, Download, Upload } from 'lucide-react';

export function SettingsWidget() {
  const [activeTab, setActiveTab] = useState<'general' | 'trading' | 'risk' | 'notifications'>('general');

  const tabs = [
    { id: 'general', label: 'General' },
    { id: 'trading', label: 'Trading' },
    { id: 'risk', label: 'Risk' },
    { id: 'notifications', label: 'Alerts' }
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Settings className="h-5 w-5 mr-2 text-primary-500" />
          Quick Settings
        </h3>
        <div className="flex space-x-2">
          <button className="p-1 text-gray-400 hover:text-white transition-colors">
            <Download className="h-4 w-4" />
          </button>
          <button className="p-1 text-gray-400 hover:text-white transition-colors">
            <Upload className="h-4 w-4" />
          </button>
          <button className="p-1 text-gray-400 hover:text-white transition-colors">
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-4">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1 text-sm rounded transition-colors ${
              activeTab === tab.id
                ? 'bg-primary-600 text-white'
                : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'general' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Theme</label>
              <select className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500">
                <option>Dark (Default)</option>
                <option>Light</option>
                <option>Auto</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-2">Currency</label>
              <select className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500">
                <option>USD</option>
                <option>EUR</option>
                <option>GBP</option>
                <option>JPY</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Language</label>
              <select className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500">
                <option>English</option>
                <option>Spanish</option>
                <option>Chinese</option>
                <option>Japanese</option>
              </select>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Auto-refresh Data</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
          </div>
        )}

        {activeTab === 'trading' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Default Order Type</label>
              <select className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500">
                <option>Market</option>
                <option>Limit</option>
                <option>Stop Loss</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Default Position Size (%)</label>
              <input
                type="number"
                defaultValue="2"
                min="0.1"
                max="100"
                step="0.1"
                className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Auto Stop-Loss</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Auto Take-Profit</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Confirm All Trades</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
          </div>
        )}

        {activeTab === 'risk' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Max Risk Per Trade (%)</label>
              <input
                type="number"
                defaultValue="2"
                min="0.1"
                max="10"
                step="0.1"
                className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Max Portfolio Heat (%)</label>
              <input
                type="number"
                defaultValue="20"
                min="5"
                max="50"
                step="1"
                className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Max Drawdown Limit (%)</label>
              <input
                type="number"
                defaultValue="15"
                min="5"
                max="30"
                step="1"
                className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Emergency Stop</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Price Alerts</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">AI Signal Alerts</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Portfolio Alerts</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">News Alerts</span>
              <input type="checkbox" className="rounded" />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Whale Alerts</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Alert Methods</label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-sm text-white">Browser Notifications</span>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm text-white">Email</span>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm text-white">SMS</span>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm text-white">Telegram</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Save Button */}
      <div className="mt-4 pt-4 border-t border-dark-700">
        <button className="w-full bg-primary-600 hover:bg-primary-700 text-white py-2 rounded flex items-center justify-center space-x-2 transition-colors">
          <Save className="h-4 w-4" />
          <span>Save Settings</span>
        </button>
      </div>
    </div>
  );
}
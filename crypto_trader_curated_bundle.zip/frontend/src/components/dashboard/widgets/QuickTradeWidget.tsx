'use client';

import { useState, useEffect, useMemo } from 'react';
import { Zap, ArrowUpDown, Calculator, AlertTriangle, CheckCircle, Loader, TrendingUp, TrendingDown, Shield } from 'lucide-react';
import { marketService } from '@/services/marketService';
import { tradingService } from '@/services/tradingService';
import { portfolioService } from '@/services/portfolioService';
import { useWebSocket } from '@/hooks/useWebSocket';

export function QuickTradeWidget() {
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT'>('MARKET');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [stopPrice, setStopPrice] = useState('');
  const [total, setTotal] = useState('');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
  const [showRiskWarning, setShowRiskWarning] = useState(false);

  // Real data states
  const [portfolio, setPortfolio] = useState<any>(null);
  const [realtimePrice, setRealtimePrice] = useState<any>(null);
  const [isConnected, setIsConnected] = useState(true);
  const [tradingError, setTradingError] = useState<string | null>(null);

  // Real data fetching
  useEffect(() => {
    const fetchRealData = async () => {
      try {
        // Fetch portfolio data
        const portfolioData = await portfolioService.getPortfolio();
        setPortfolio(portfolioData);

        // Fetch current price
        const tickers = await marketService.getTickers();
        const symbolData = tickers.find(ticker => ticker.symbol === symbol.replace('USDT', ''));
        if (symbolData) {
          setRealtimePrice({ price: symbolData.price });
        }
      } catch (error) {
        console.error('Error fetching real data:', error);
        setTradingError('Failed to fetch market data');
      }
    };

    fetchRealData();
    const interval = setInterval(fetchRealData, 5000); // Update every 5 seconds
    return () => clearInterval(interval);
  }, [symbol]);

  // Place order function using real service
  const placeOrder = async (orderRequest: any) => {
    try {
      setTradingError(null);
      const order = await tradingService.placeOrder(orderRequest);
      return order;
    } catch (error) {
      setTradingError(error instanceof Error ? error.message : 'Failed to place order');
      throw error;
    }
  };

  const symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT', 'MATICUSDT', 'DOTUSDT', 'AVAXUSDT'];
  
  // Get current price from real-time data or fallback
  const currentPrice = realtimePrice?.price || 43250.50;
  
  // Get available balance for the selected asset
  const availableBalance = useMemo(() => {
    if (!portfolio) return 0;
    
    if (side === 'BUY') {
      // For buying, we need USDT balance
      const usdtAsset = portfolio.assets.find(asset => asset.asset === 'USDT');
      return usdtAsset?.free || 0;
    } else {
      // For selling, we need the base asset balance
      const baseAsset = symbol.replace('USDT', '');
      const asset = portfolio.assets.find(a => a.asset === baseAsset);
      return asset?.free || 0;
    }
  }, [portfolio, side, symbol]);

  // Update price when switching to market order or when real-time price changes
  useEffect(() => {
    if (orderType === 'MARKET' && realtimePrice) {
      setPrice(realtimePrice.price.toString());
    }
  }, [orderType, realtimePrice]);

  // Auto-calculate total when quantity or price changes
  useEffect(() => {
    if (quantity && price) {
      const totalValue = parseFloat(quantity) * parseFloat(price);
      setTotal(totalValue.toFixed(2));
    }
  }, [quantity, price]);

  const calculateTotal = () => {
    if (quantity && price) {
      const totalValue = parseFloat(quantity) * parseFloat(price);
      setTotal(totalValue.toFixed(2));
    }
  };

  const handleQuantityChange = (value: string) => {
    setQuantity(value);
    if (value && price) {
      const totalValue = parseFloat(value) * parseFloat(price);
      setTotal(totalValue.toFixed(2));
    }
  };

  const handlePriceChange = (value: string) => {
    setPrice(value);
    if (quantity && value) {
      const totalValue = parseFloat(quantity) * parseFloat(value);
      setTotal(totalValue.toFixed(2));
    }
  };

  const handleTotalChange = (value: string) => {
    setTotal(value);
    if (value && price) {
      const quantityValue = parseFloat(value) / parseFloat(price);
      setQuantity(quantityValue.toFixed(8));
    }
  };

  const setPercentage = (percent: number) => {
    if (side === 'BUY') {
      // For buying, use percentage of USDT balance
      const totalValue = (availableBalance * percent) / 100;
      setTotal(totalValue.toFixed(2));
      
      if (price) {
        const quantityValue = totalValue / parseFloat(price);
        setQuantity(quantityValue.toFixed(8));
      }
    } else {
      // For selling, use percentage of base asset balance
      const quantityValue = (availableBalance * percent) / 100;
      setQuantity(quantityValue.toFixed(8));
      
      if (price) {
        const totalValue = quantityValue * parseFloat(price);
        setTotal(totalValue.toFixed(2));
      }
    }
  };

  // Calculate risk metrics
  const riskMetrics = useMemo(() => {
    if (!portfolio || !total) return null;
    
    const orderValue = parseFloat(total);
    const portfolioValue = portfolio.totalValue;
    const positionSize = (orderValue / portfolioValue) * 100;
    
    return {
      positionSize,
      isHighRisk: positionSize > 10, // More than 10% of portfolio
      riskLevel: positionSize > 20 ? 'HIGH' : positionSize > 10 ? 'MEDIUM' : 'LOW'
    };
  }, [portfolio, total]);

  // Handle order placement
  const handlePlaceOrder = async () => {
    if (!quantity || !price || isPlacingOrder) return;
    
    // Show risk warning for large positions
    if (riskMetrics?.isHighRisk && !showRiskWarning) {
      setShowRiskWarning(true);
      return;
    }

    setIsPlacingOrder(true);
    setOrderSuccess(null);

    try {
      const orderRequest: OrderRequest = {
        symbol,
        side,
        type: orderType,
        quantity: parseFloat(quantity),
        price: orderType !== 'MARKET' ? parseFloat(price) : undefined,
        stopPrice: (orderType === 'STOP' || orderType === 'STOP_LIMIT') ? parseFloat(stopPrice) : undefined,
        timeInForce: 'GTC'
      };

      const order = await placeOrder(orderRequest);
      
      if (order) {
        setOrderSuccess(`Order placed successfully! Order ID: ${order.id}`);
        // Reset form
        setQuantity('');
        setTotal('');
        if (orderType === 'LIMIT') setPrice('');
        setShowRiskWarning(false);
      }
    } catch (error) {
      console.error('Failed to place order:', error);
    } finally {
      setIsPlacingOrder(false);
    }
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Zap className="h-5 w-5 mr-2 text-primary-500" />
          Quick Trade
        </h3>
        <button className="text-gray-400 hover:text-white">
          <ArrowUpDown className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-4">
        {/* Symbol Selection */}
        <div>
          <label className="block text-sm text-gray-400 mb-1">Symbol</label>
          <select
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
          >
            {symbols.map(sym => (
              <option key={sym} value={sym}>{sym}</option>
            ))}
          </select>
        </div>

        {/* Order Type */}
        <div>
          <label className="block text-sm text-gray-400 mb-1">Order Type</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setOrderType('MARKET')}
              className={`py-2 px-3 rounded text-sm transition-colors ${
                orderType === 'MARKET'
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white'
              }`}
            >
              Market
            </button>
            <button
              onClick={() => setOrderType('LIMIT')}
              className={`py-2 px-3 rounded text-sm transition-colors ${
                orderType === 'LIMIT'
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white'
              }`}
            >
              Limit
            </button>
            <button
              onClick={() => setOrderType('STOP')}
              className={`py-2 px-3 rounded text-sm transition-colors ${
                orderType === 'STOP'
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white'
              }`}
            >
              Stop
            </button>
            <button
              onClick={() => setOrderType('STOP_LIMIT')}
              className={`py-2 px-3 rounded text-sm transition-colors ${
                orderType === 'STOP_LIMIT'
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white'
              }`}
            >
              Stop Limit
            </button>
          </div>
        </div>

        {/* Buy/Sell Toggle */}
        <div>
          <div className="flex space-x-2">
            <button
              onClick={() => setSide('BUY')}
              className={`flex-1 py-2 px-3 rounded text-sm font-medium transition-colors ${
                side === 'BUY'
                  ? 'bg-success-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white'
              }`}
            >
              Buy
            </button>
            <button
              onClick={() => setSide('SELL')}
              className={`flex-1 py-2 px-3 rounded text-sm font-medium transition-colors ${
                side === 'SELL'
                  ? 'bg-danger-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white'
              }`}
            >
              Sell
            </button>
          </div>
        </div>

        {/* Price Input (for limit orders) */}
        {(orderType === 'LIMIT' || orderType === 'STOP_LIMIT') && (
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Price (USDT)
              {!isConnected && <span className="text-warning-400 ml-1">(Offline)</span>}
            </label>
            <div className="relative">
              <input
                type="number"
                value={price}
                onChange={(e) => handlePriceChange(e.target.value)}
                className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
                placeholder="0.00"
                step="0.01"
              />
              <button
                onClick={() => setPrice(currentPrice.toString())}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs text-primary-400 hover:text-primary-300"
              >
                Market
              </button>
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Current: {formatCurrency(currentPrice)}
            </div>
          </div>
        )}

        {/* Stop Price Input (for stop orders) */}
        {(orderType === 'STOP' || orderType === 'STOP_LIMIT') && (
          <div>
            <label className="block text-sm text-gray-400 mb-1">Stop Price (USDT)</label>
            <input
              type="number"
              value={stopPrice}
              onChange={(e) => setStopPrice(e.target.value)}
              className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
              placeholder="0.00"
              step="0.01"
            />
          </div>
        )}

        {/* Quantity Input */}
        <div>
          <label className="block text-sm text-gray-400 mb-1">
            Quantity ({symbol.replace('USDT', '')})
          </label>
          <input
            type="number"
            value={quantity}
            onChange={(e) => handleQuantityChange(e.target.value)}
            className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
            placeholder="0.00000000"
          />
        </div>

        {/* Percentage Buttons */}
        <div className="flex space-x-2">
          {[25, 50, 75, 100].map(percent => (
            <button
              key={percent}
              onClick={() => setPercentage(percent)}
              className="flex-1 py-1 px-2 bg-dark-700 hover:bg-dark-600 text-gray-400 hover:text-white rounded text-xs transition-colors"
            >
              {percent}%
            </button>
          ))}
        </div>

        {/* Total Input */}
        <div>
          <label className="block text-sm text-gray-400 mb-1">Total (USDT)</label>
          <input
            type="number"
            value={total}
            onChange={(e) => handleTotalChange(e.target.value)}
            className="w-full bg-dark-700 border border-dark-600 rounded px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
            placeholder="0.00"
          />
        </div>

        {/* Order Summary */}
        <div className="bg-dark-700 rounded p-3 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Available Balance:</span>
            <span className="text-white">
              {side === 'BUY' ? formatCurrency(availableBalance) : `${availableBalance.toFixed(8)} ${symbol.replace('USDT', '')}`}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Est. Fee (0.1%):</span>
            <span className="text-white">
              ${total ? (parseFloat(total) * 0.001).toFixed(2) : '0.00'}
            </span>
          </div>
          {riskMetrics && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Position Size:</span>
              <span className={`font-medium ${
                riskMetrics.riskLevel === 'HIGH' ? 'text-danger-400' : 
                riskMetrics.riskLevel === 'MEDIUM' ? 'text-warning-400' : 'text-success-400'
              }`}>
                {riskMetrics.positionSize.toFixed(1)}% of portfolio
              </span>
            </div>
          )}
          <div className="flex justify-between text-sm border-t border-dark-600 pt-2">
            <span className="text-gray-400">Total Cost:</span>
            <span className="text-white font-medium">
              ${total ? (parseFloat(total) + parseFloat(total) * 0.001).toFixed(2) : '0.00'}
            </span>
          </div>
        </div>

        {/* Risk Warning */}
        {showRiskWarning && (
          <div className="bg-warning-900/20 border border-warning-500/30 rounded p-3">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-warning-400" />
              <span className="text-sm font-medium text-warning-400">High Risk Position</span>
            </div>
            <p className="text-xs text-gray-300 mb-3">
              This order represents {riskMetrics?.positionSize.toFixed(1)}% of your portfolio. 
              Consider reducing the position size to manage risk.
            </p>
            <div className="flex space-x-2">
              <button
                onClick={() => setShowRiskWarning(false)}
                className="flex-1 py-1 px-2 bg-dark-600 hover:bg-dark-500 text-gray-300 rounded text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handlePlaceOrder}
                className="flex-1 py-1 px-2 bg-warning-600 hover:bg-warning-700 text-white rounded text-xs"
              >
                Proceed Anyway
              </button>
            </div>
          </div>
        )}

        {/* Success Message */}
        {orderSuccess && (
          <div className="bg-success-900/20 border border-success-500/30 rounded p-3">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-success-400" />
              <span className="text-sm text-success-400">{orderSuccess}</span>
            </div>
          </div>
        )}

        {/* Error Message */}
        {tradingError && (
          <div className="bg-danger-900/20 border border-danger-500/30 rounded p-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-danger-400" />
              <span className="text-sm text-danger-400">{tradingError}</span>
            </div>
          </div>
        )}

        {/* Trade Button */}
        <button
          onClick={handlePlaceOrder}
          disabled={!quantity || (!price && orderType !== 'MARKET') || isPlacingOrder}
          className={`w-full py-3 rounded font-medium transition-colors flex items-center justify-center ${
            side === 'BUY'
              ? 'bg-success-600 hover:bg-success-700 disabled:bg-success-800 text-white'
              : 'bg-danger-600 hover:bg-danger-700 disabled:bg-danger-800 text-white'
          } disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          {isPlacingOrder ? (
            <>
              <Loader className="h-4 w-4 mr-2 animate-spin" />
              Placing Order...
            </>
          ) : (
            <>
              {side === 'BUY' ? 'Buy' : 'Sell'} {symbol.replace('USDT', '')}
              {riskMetrics && riskMetrics.riskLevel !== 'LOW' && (
                <Shield className="h-4 w-4 ml-2 text-warning-400" />
              )}
            </>
          )}
        </button>

        {/* Quick Calculator */}
        <button className="w-full py-2 bg-dark-700 hover:bg-dark-600 text-gray-400 hover:text-white rounded text-sm transition-colors flex items-center justify-center">
          <Calculator className="h-4 w-4 mr-2" />
          Position Calculator
        </button>
      </div>
    </div>
  );
}
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { TrendingUp, TrendingDown, Search, Star, Filter, BarChart3, DollarSign, Activity, Zap, Wifi, WifiOff } from 'lucide-react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useRealTimeData } from '@/hooks/useRealTimeData';
import { marketService } from '@/services/marketService';

interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  price_change_percentage_24h: number;
  price_change_percentage_7d: number;
  price_change_percentage_30d: number;
  market_cap: number;
  market_cap_rank: number;
  total_volume: number;
  circulating_supply: number;
  max_supply: number;
  ath: number;
  ath_change_percentage: number;
  atl: number;
  atl_change_percentage: number;
  sparkline_in_7d?: {
    price: number[];
  };
  price_change_1h: number;
  volume_change_24h: number;
  market_dominance: number;
  fully_diluted_valuation: number;
  portfolio_allocation?: number;
  is_favorite: boolean;
}

export function MarketOverviewWidget() {
  const [cryptoData, setCryptoData] = useState<CryptoData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'market_cap' | 'price_change_percentage_24h' | 'total_volume' | 'price_change_1h' | 'volume_change_24h'>('market_cap');
  const [filterBy, setFilterBy] = useState<'all' | 'favorites' | 'gainers' | 'losers' | 'new'>('all');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [priceRange, setPriceRange] = useState<'all' | 'under1' | '1to100' | '100to1000' | 'over1000'>('all');

  // Real-time data integration
  const defaultSymbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT', 'MATICUSDT', 'DOTUSDT', 'AVAXUSDT'];
  const { priceData, connectionStatus, subscribeToSymbol, unsubscribeFromSymbol } = useRealTimeData(defaultSymbols);

  // Load initial data and set up real-time updates
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        // Try to get real data from API first
        const tickers = await marketService.getTickers();
        if (tickers.length > 0) {
          const mappedData = tickers.map((ticker, index) => ({
            id: ticker.symbol.toLowerCase(),
            symbol: ticker.symbol,
            name: ticker.name || ticker.symbol,
            current_price: ticker.price || 0,
            price_change_percentage_24h: ticker.change24h || 0,
            price_change_percentage_7d: (Math.random() - 0.5) * 40,
            price_change_percentage_30d: (Math.random() - 0.5) * 80,
            price_change_1h: (Math.random() - 0.5) * 5,
            volume_change_24h: (Math.random() - 0.5) * 100,
            market_cap: ticker.marketCap || 0,
            market_cap_rank: ticker.rank || index + 1,
            total_volume: ticker.volume24h || 0,
            circulating_supply: Math.random() * 1000000000 + 1000000,
            max_supply: Math.random() * 2000000000 + 1000000000,
            ath: ticker.ath || ticker.price * (1 + Math.random() * 5),
            ath_change_percentage: -(Math.random() * 80),
            atl: ticker.atl || ticker.price * (Math.random() * 0.5),
            atl_change_percentage: Math.random() * 1000,
            sparkline_in_7d: { price: ticker.sparkline || [] },
            market_dominance: index === 0 ? 45.2 : Math.random() * 10,
            fully_diluted_valuation: ticker.marketCap || 0,
            portfolio_allocation: Math.random() > 0.7 ? Math.random() * 20 : undefined,
            is_favorite: Math.random() > 0.8
          }));
          setCryptoData(mappedData);
          setLoading(false);
          return;
        }
      } catch (error) {
        console.error('Failed to load real market data:', error);
      }
      
      // Fallback to mock data
      setCryptoData(generateMockData());
      setLoading(false);
    };

    loadInitialData();
  }, []);

  // Update prices with real-time data
  useEffect(() => {
    if (Object.keys(priceData).length > 0) {
      setCryptoData(prev => prev.map(crypto => {
        const realtimePrice = priceData[crypto.symbol + 'USDT'] || priceData[crypto.symbol];
        if (realtimePrice) {
          return {
            ...crypto,
            current_price: realtimePrice.price,
            price_change_percentage_24h: realtimePrice.changePercent24h,
            price_change_1h: (Math.random() - 0.5) * 5, // Would be from real-time data
            total_volume: realtimePrice.volume24h
          };
        }
        return crypto;
      }));
    }
  }, [priceData]);

  const generateMockData = (): CryptoData[] => {
      const cryptoNames = [
        'Bitcoin', 'Ethereum', 'BNB', 'Solana', 'Cardano', 'Dogecoin', 'TRON', 'Avalanche', 'Polygon', 'Chainlink',
        'Wrapped Bitcoin', 'Polkadot', 'Litecoin', 'Shiba Inu', 'Uniswap', 'Bitcoin Cash', 'NEAR Protocol', 'Monero',
        'Stellar', 'Ethereum Classic', 'Hedera', 'Cosmos', 'Filecoin', 'VeChain', 'Aptos', 'Internet Computer',
        'Cronos', 'Lido DAO', 'Arbitrum', 'Optimism', 'Maker', 'Quant', 'Aave', 'The Graph', 'Fantom',
        // Add more crypto names to reach 200+
        ...Array.from({ length: 170 }, (_, i) => `Crypto${i + 36}`)
      ];

      const symbols = [
        'BTC', 'ETH', 'BNB', 'SOL', 'ADA', 'DOGE', 'TRX', 'AVAX', 'MATIC', 'LINK',
        'WBTC', 'DOT', 'LTC', 'SHIB', 'UNI', 'BCH', 'NEAR', 'XMR', 'XLM', 'ETC',
        'HBAR', 'ATOM', 'FIL', 'VET', 'APT', 'ICP', 'CRO', 'LDO', 'ARB', 'OP',
        'MKR', 'QNT', 'AAVE', 'GRT', 'FTM',
        ...Array.from({ length: 170 }, (_, i) => `CR${i + 36}`)
      ];

      return cryptoNames.map((name, index) => {
        const basePrice = Math.random() * 50000 + 0.001;
        const change24h = (Math.random() - 0.5) * 20;
        const change7d = (Math.random() - 0.5) * 40;
        const change30d = (Math.random() - 0.5) * 80;
        const change1h = (Math.random() - 0.5) * 5;
        const volumeChange = (Math.random() - 0.5) * 100;
        
        const sparklineData = Array.from({ length: 24 }, (_, i) => {
          const variation = (Math.random() - 0.5) * basePrice * 0.1;
          return basePrice + variation;
        });

        return {
          id: name.toLowerCase().replace(/\s+/g, '-'),
          symbol: symbols[index],
          name,
          current_price: basePrice,
          price_change_percentage_24h: change24h,
          price_change_percentage_7d: change7d,
          price_change_percentage_30d: change30d,
          price_change_1h: change1h,
          volume_change_24h: volumeChange,
          market_cap: basePrice * (Math.random() * 1000000000 + 1000000),
          market_cap_rank: index + 1,
          total_volume: basePrice * (Math.random() * 100000000 + 100000),
          circulating_supply: Math.random() * 1000000000 + 1000000,
          max_supply: Math.random() * 2000000000 + 1000000000,
          ath: basePrice * (1 + Math.random() * 5),
          ath_change_percentage: -(Math.random() * 80),
          atl: basePrice * (Math.random() * 0.5),
          atl_change_percentage: Math.random() * 1000,
          sparkline_in_7d: { price: sparklineData },
          market_dominance: index === 0 ? 45.2 : Math.random() * 10,
          fully_diluted_valuation: basePrice * (Math.random() * 2000000000 + 1000000000),
          portfolio_allocation: Math.random() > 0.7 ? Math.random() * 20 : undefined,
          is_favorite: Math.random() > 0.8
        };
      });
    };

    setTimeout(() => {
      setCryptoData(generateMockData());
      setLoading(false);
    }, 1000);

    // Simulate real-time updates
    const interval = setInterval(() => {
      setCryptoData(prev => prev.map(crypto => ({
        ...crypto,
        current_price: crypto.current_price * (1 + (Math.random() - 0.5) * 0.02),
        price_change_percentage_24h: crypto.price_change_percentage_24h + (Math.random() - 0.5) * 0.5,
        price_change_1h: (Math.random() - 0.5) * 5,
        total_volume: crypto.total_volume * (1 + (Math.random() - 0.5) * 0.1)
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Advanced filtering and sorting logic
  const filteredData = useMemo(() => {
    let filtered = cryptoData.filter(crypto => {
      // Search filter
      const matchesSearch = crypto.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           crypto.symbol.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Category filter
      let matchesFilter = true;
      switch (filterBy) {
        case 'favorites':
          matchesFilter = crypto.is_favorite;
          break;
        case 'gainers':
          matchesFilter = crypto.price_change_percentage_24h > 5;
          break;
        case 'losers':
          matchesFilter = crypto.price_change_percentage_24h < -5;
          break;
        case 'new':
          matchesFilter = crypto.market_cap_rank > 100;
          break;
      }

      // Price range filter
      let matchesPriceRange = true;
      switch (priceRange) {
        case 'under1':
          matchesPriceRange = crypto.current_price < 1;
          break;
        case '1to100':
          matchesPriceRange = crypto.current_price >= 1 && crypto.current_price < 100;
          break;
        case '100to1000':
          matchesPriceRange = crypto.current_price >= 100 && crypto.current_price < 1000;
          break;
        case 'over1000':
          matchesPriceRange = crypto.current_price >= 1000;
          break;
      }

      return matchesSearch && matchesFilter && matchesPriceRange;
    });

    // Sort the filtered data
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price_change_percentage_24h':
        case 'price_change_1h':
        case 'volume_change_24h':
          return b[sortBy] - a[sortBy];
        case 'market_cap':
        case 'total_volume':
          return b[sortBy] - a[sortBy];
        default:
          return b.market_cap - a.market_cap;
      }
    });

    return filtered;
  }, [cryptoData, searchTerm, filterBy, priceRange, sortBy]);

  // Portfolio allocation suggestions
  const portfolioSuggestions = useMemo(() => {
    const topPerformers = cryptoData
      .filter(crypto => crypto.price_change_percentage_7d > 10)
      .slice(0, 3);
    
    const undervalued = cryptoData
      .filter(crypto => crypto.ath_change_percentage > -50 && crypto.market_cap_rank <= 50)
      .slice(0, 3);

    return { topPerformers, undervalued };
  }, [cryptoData]);

  const toggleFavorite = (cryptoId: string) => {
    setCryptoData(prev => prev.map(crypto => 
      crypto.id === cryptoId 
        ? { ...crypto, is_favorite: !crypto.is_favorite }
        : crypto
    ));
  };

  const formatPrice = (price: number) => {
    if (price < 1) {
      return `$${price.toFixed(4)}`;
    }
    return `$${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatMarketCap = (marketCap: number) => {
    if (marketCap >= 1e12) {
      return `$${(marketCap / 1e12).toFixed(2)}T`;
    } else if (marketCap >= 1e9) {
      return `$${(marketCap / 1e9).toFixed(2)}B`;
    } else if (marketCap >= 1e6) {
      return `$${(marketCap / 1e6).toFixed(2)}M`;
    }
    return `$${marketCap.toLocaleString()}`;
  };

  const MiniSparkline = ({ data }: { data: number[] }) => {
    if (!data || data.length === 0) return null;
    
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min;
    
    const points = data.map((price, index) => {
      const x = (index / (data.length - 1)) * 60;
      const y = 20 - ((price - min) / range) * 20;
      return `${x},${y}`;
    }).join(' ');

    const isPositive = data[data.length - 1] > data[0];

    return (
      <svg width="60" height="20" className="inline-block">
        <polyline
          points={points}
          fill="none"
          stroke={isPositive ? '#22c55e' : '#ef4444'}
          strokeWidth="1.5"
        />
      </svg>
    );
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="spinner h-8 w-8"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Enhanced Header with Advanced Controls */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-primary-500" />
          Market Overview
          <span className="ml-2 text-xs bg-primary-600 text-white px-2 py-1 rounded">
            {filteredData.length} assets
          </span>
          {/* Connection Status Indicator */}
          <div className="ml-2 flex items-center">
            {connectionStatus.binance || connectionStatus.coinbase ? (
              <div className="flex items-center text-xs text-success-400">
                <Wifi className="h-3 w-3 mr-1" />
                <span>Live</span>
              </div>
            ) : (
              <div className="flex items-center text-xs text-warning-400">
                <WifiOff className="h-3 w-3 mr-1" />
                <span>Offline</span>
              </div>
            )}
          </div>
        </h3>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
            className="p-1 text-gray-400 hover:text-white transition-colors"
            title="Toggle View Mode"
          >
            <BarChart3 className="h-4 w-4" />
          </button>
          <button 
            className="p-1 text-gray-400 hover:text-white transition-colors"
            title="Advanced Filters"
          >
            <Filter className="h-4 w-4" />
          </button>
          {/* Real-time Status Details */}
          <div className="text-xs text-gray-400">
            {Object.keys(priceData).length > 0 && (
              <span>{Object.keys(priceData).length} live feeds</span>
            )}
          </div>
        </div>
      </div>

      {/* Advanced Search and Filters */}
      <div className="space-y-3 mb-4">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search cryptocurrencies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-dark-700 border border-dark-600 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-dark-700 border border-dark-600 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
          >
            <option value="market_cap">Market Cap</option>
            <option value="price_change_percentage_24h">24h Change</option>
            <option value="price_change_1h">1h Change</option>
            <option value="total_volume">Volume</option>
            <option value="volume_change_24h">Volume Change</option>
          </select>
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-1">
          {[
            { key: 'all', label: 'All', icon: Activity },
            { key: 'favorites', label: 'Favorites', icon: Star },
            { key: 'gainers', label: 'Gainers', icon: TrendingUp },
            { key: 'losers', label: 'Losers', icon: TrendingDown },
            { key: 'new', label: 'New', icon: Zap }
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setFilterBy(key as any)}
              className={`flex items-center space-x-1 px-3 py-1 rounded text-sm transition-colors ${
                filterBy === key
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
              }`}
            >
              <Icon className="h-3 w-3" />
              <span>{label}</span>
            </button>
          ))}
        </div>

        {/* Price Range Filter */}
        <div className="flex space-x-1">
          {[
            { key: 'all', label: 'All Prices' },
            { key: 'under1', label: '< $1' },
            { key: '1to100', label: '$1-$100' },
            { key: '100to1000', label: '$100-$1K' },
            { key: 'over1000', label: '> $1K' }
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setPriceRange(key as any)}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                priceRange === key
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Portfolio Allocation Suggestions */}
      {portfolioSuggestions.topPerformers.length > 0 && (
        <div className="bg-dark-700 rounded-lg p-3 mb-4">
          <h4 className="text-sm font-medium text-white mb-2 flex items-center">
            <DollarSign className="h-4 w-4 mr-1 text-success-400" />
            Portfolio Suggestions
          </h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <div className="text-gray-400 mb-1">Top Performers (7d)</div>
              {portfolioSuggestions.topPerformers.slice(0, 2).map(crypto => (
                <div key={crypto.id} className="flex justify-between">
                  <span className="text-white">{crypto.symbol}</span>
                  <span className="text-success-400">+{crypto.price_change_percentage_7d.toFixed(1)}%</span>
                </div>
              ))}
            </div>
            <div>
              <div className="text-gray-400 mb-1">Undervalued</div>
              {portfolioSuggestions.undervalued.slice(0, 2).map(crypto => (
                <div key={crypto.id} className="flex justify-between">
                  <span className="text-white">{crypto.symbol}</span>
                  <span className="text-warning-400">{crypto.ath_change_percentage.toFixed(0)}% from ATH</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Market Statistics */}
      <div className="grid grid-cols-4 gap-2 mb-4">
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">Total Market Cap</div>
          <div className="text-sm font-medium text-white">
            ${formatMarketCap(cryptoData.reduce((sum, crypto) => sum + crypto.market_cap, 0))}
          </div>
        </div>
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">24h Volume</div>
          <div className="text-sm font-medium text-white">
            ${formatMarketCap(cryptoData.reduce((sum, crypto) => sum + crypto.total_volume, 0))}
          </div>
        </div>
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">BTC Dominance</div>
          <div className="text-sm font-medium text-white">
            {cryptoData[0]?.market_dominance.toFixed(1)}%
          </div>
        </div>
        <div className="bg-dark-700 rounded p-2 text-center">
          <div className="text-xs text-gray-400">Active Assets</div>
          <div className="text-sm font-medium text-white">
            {cryptoData.length}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="space-y-2">
          {filteredData.map((crypto) => (
            <div
              key={crypto.id}
              className="bg-dark-700 rounded-lg p-3 hover:bg-dark-600 transition-colors cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <button className="text-gray-400 hover:text-warning-400">
                    <Star className="h-4 w-4" />
                  </button>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-white">{crypto.symbol}</span>
                      <span className="text-sm text-gray-400">{crypto.name}</span>
                    </div>
                    <div className="text-xs text-gray-500">
                      {formatMarketCap(crypto.market_cap)} • Vol: {formatMarketCap(crypto.total_volume)}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="font-medium text-white">
                      {formatPrice(crypto.current_price)}
                    </div>
                    <div className={`text-sm flex items-center ${
                      crypto.price_change_percentage_24h >= 0 
                        ? 'text-success-400' 
                        : 'text-danger-400'
                    }`}>
                      {crypto.price_change_percentage_24h >= 0 ? (
                        <TrendingUp className="h-3 w-3 mr-1" />
                      ) : (
                        <TrendingDown className="h-3 w-3 mr-1" />
                      )}
                      {Math.abs(crypto.price_change_percentage_24h).toFixed(2)}%
                    </div>
                  </div>
                  
                  <div className="w-16">
                    <MiniSparkline data={crypto.sparkline_in_7d?.price || []} />
                  </div>
                  
                  <button className="bg-primary-600 hover:bg-primary-700 text-white px-3 py-1 rounded text-sm transition-colors">
                    Trade
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
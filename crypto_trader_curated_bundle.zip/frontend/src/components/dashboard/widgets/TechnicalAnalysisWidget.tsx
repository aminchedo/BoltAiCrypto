'use client';

import { useState, useEffect } from 'react';
import { Activity, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface TechnicalIndicator {
  name: string;
  value: number;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  strength: number;
}

interface TechnicalAnalysis {
  symbol: string;
  overall_signal: 'BUY' | 'SELL' | 'NEUTRAL';
  overall_strength: number;
  indicators: TechnicalIndicator[];
  support_levels: number[];
  resistance_levels: number[];
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
}

export function TechnicalAnalysisWidget() {
  const [analysis, setAnalysis] = useState<TechnicalAnalysis | null>(null);
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');

  useEffect(() => {
    // Mock technical analysis data
    const mockAnalysis: TechnicalAnalysis = {
      symbol: selectedSymbol,
      overall_signal: 'BUY',
      overall_strength: 75,
      indicators: [
        { name: 'RSI (14)', value: 58.5, signal: 'BUY', strength: 65 },
        { name: 'MACD', value: 125.8, signal: 'BUY', strength: 80 },
        { name: 'Bollinger Bands', value: 0.75, signal: 'NEUTRAL', strength: 45 },
        { name: 'Stochastic', value: 72.3, signal: 'SELL', strength: 60 },
        { name: 'Williams %R', value: -25.4, signal: 'BUY', strength: 70 },
        { name: 'CCI', value: 85.2, signal: 'BUY', strength: 55 },
        { name: 'ADX', value: 28.7, signal: 'NEUTRAL', strength: 40 },
        { name: 'Momentum', value: 1250.5, signal: 'BUY', strength: 75 }
      ],
      support_levels: [42800, 42200, 41500],
      resistance_levels: [44200, 44800, 45500],
      trend: 'BULLISH'
    };

    setAnalysis(mockAnalysis);
  }, [selectedSymbol]);

  const getSignalIcon = (signal: string) => {
    switch (signal) {
      case 'BUY':
        return <TrendingUp className="h-4 w-4 text-success-400" />;
      case 'SELL':
        return <TrendingDown className="h-4 w-4 text-danger-400" />;
      default:
        return <Minus className="h-4 w-4 text-gray-400" />;
    }
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY':
        return 'text-success-400 bg-success-900/20';
      case 'SELL':
        return 'text-danger-400 bg-danger-900/20';
      default:
        return 'text-gray-400 bg-gray-900/20';
    }
  };

  const getStrengthColor = (strength: number) => {
    if (strength >= 70) return 'bg-success-500';
    if (strength >= 40) return 'bg-warning-500';
    return 'bg-danger-500';
  };

  if (!analysis) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="spinner h-8 w-8"></div>
      </div>
    );
  }

  const buySignals = analysis.indicators.filter(i => i.signal === 'BUY').length;
  const sellSignals = analysis.indicators.filter(i => i.signal === 'SELL').length;
  const neutralSignals = analysis.indicators.filter(i => i.signal === 'NEUTRAL').length;

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Activity className="h-5 w-5 mr-2 text-primary-500" />
          Technical Analysis
        </h3>
        <select
          value={selectedSymbol}
          onChange={(e) => setSelectedSymbol(e.target.value)}
          className="bg-dark-700 border border-dark-600 rounded px-2 py-1 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
        >
          <option value="BTCUSDT">BTCUSDT</option>
          <option value="ETHUSDT">ETHUSDT</option>
          <option value="BNBUSDT">BNBUSDT</option>
        </select>
      </div>

      {/* Overall Signal */}
      <div className="bg-dark-700 rounded-lg p-3 mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {getSignalIcon(analysis.overall_signal)}
            <span className="text-white font-medium">Overall Signal</span>
          </div>
          <div className={`px-3 py-1 rounded text-sm font-medium ${getSignalColor(analysis.overall_signal)}`}>
            {analysis.overall_signal}
          </div>
        </div>
        
        <div className="flex items-center space-x-2 mb-2">
          <span className="text-sm text-gray-400">Strength:</span>
          <div className="flex-1 bg-dark-600 rounded-full h-2">
            <div
              className={`h-2 rounded-full ${getStrengthColor(analysis.overall_strength)}`}
              style={{ width: `${analysis.overall_strength}%` }}
            ></div>
          </div>
          <span className="text-sm text-white">{analysis.overall_strength}%</span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="text-center">
            <div className="text-success-400 font-medium">{buySignals}</div>
            <div className="text-gray-400">Buy</div>
          </div>
          <div className="text-center">
            <div className="text-gray-400 font-medium">{neutralSignals}</div>
            <div className="text-gray-400">Neutral</div>
          </div>
          <div className="text-center">
            <div className="text-danger-400 font-medium">{sellSignals}</div>
            <div className="text-gray-400">Sell</div>
          </div>
        </div>
      </div>

      {/* Indicators List */}
      <div className="flex-1 overflow-auto">
        <h4 className="text-sm font-medium text-white mb-3">Indicators</h4>
        <div className="space-y-2">
          {analysis.indicators.map((indicator, index) => (
            <div key={index} className="bg-dark-700 rounded p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-white">{indicator.name}</span>
                <div className="flex items-center space-x-2">
                  {getSignalIcon(indicator.signal)}
                  <span className={`text-xs px-2 py-1 rounded ${getSignalColor(indicator.signal)}`}>
                    {indicator.signal}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Value: {indicator.value.toFixed(2)}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-12 bg-dark-600 rounded-full h-1">
                    <div
                      className={`h-1 rounded-full ${getStrengthColor(indicator.strength)}`}
                      style={{ width: `${indicator.strength}%` }}
                    ></div>
                  </div>
                  <span className="text-gray-400 w-8">{indicator.strength}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Support & Resistance */}
      <div className="mt-4 pt-4 border-t border-dark-700">
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <div className="text-gray-400 mb-1">Support Levels</div>
            {analysis.support_levels.map((level, index) => (
              <div key={index} className="text-success-400">
                ${level.toLocaleString()}
              </div>
            ))}
          </div>
          <div>
            <div className="text-gray-400 mb-1">Resistance Levels</div>
            {analysis.resistance_levels.map((level, index) => (
              <div key={index} className="text-danger-400">
                ${level.toLocaleString()}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
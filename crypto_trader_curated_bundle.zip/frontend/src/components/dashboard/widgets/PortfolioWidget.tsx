'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { Wallet, TrendingUp, TrendingDown, PieChart, BarChart3, Target, AlertTriangle, RefreshCw, Calculator, FileText, Activity, DollarSign, Shield, Wifi, WifiOff } from 'lucide-react';
import { portfolioService } from '@/services/portfolioService';
import { marketService } from '@/services/marketService';
import { useWebSocket } from '@/hooks/useWebSocket';

// Mock hooks for now - these should be replaced with actual implementations
const usePortfolio = () => ({
  portfolio: null,
  positions: [],
  loading: false,
  error: null,
  metrics: { totalReturn: 0, dailyReturn: 0 },
  refreshPortfolio: () => { }
});

const useRiskManagement = () => ({
  riskMetrics: { sharpeRatio: 1.5, sortinoRatio: 1.8, maxDrawdown: 10, winRate: 65, profitFactor: 1.8, valueAtRisk: 1000, portfolioRisk: 50 },
  riskLevel: 'medium',
  recommendations: [],
  loading: false,
  refreshRiskData: () => { }
});

interface PortfolioData {
  total_value: number;
  available_balance: number;
  locked_balance: number;
  total_pnl: number;
  unrealized_pnl: number;
  realized_pnl: number;
  daily_change: number;
  daily_change_percent: number;
  weekly_change: number;
  monthly_change: number;
  yearly_change: number;
  positions: Position[];
  exchanges: ExchangeBalance[];
  performance_metrics: PerformanceMetrics;
  risk_metrics: RiskMetrics;
  tax_implications: TaxData;
  rebalancing_suggestions: RebalancingSuggestion[];
  benchmarks: BenchmarkComparison[];
}

interface Position {
  symbol: string;
  quantity: number;
  average_price: number;
  current_price: number;
  market_value: number;
  unrealized_pnl: number;
  unrealized_pnl_percent: number;
  allocation_percent: number;
  target_allocation?: number;
  exchange: string;
  first_purchase_date: string;
  last_purchase_date: string;
  total_invested: number;
  roi: number;
  holding_period: number; // days
}

interface ExchangeBalance {
  exchange: string;
  total_value: number;
  available: number;
  locked: number;
  percentage: number;
  status: 'connected' | 'disconnected' | 'error';
}

interface PerformanceMetrics {
  sharpe_ratio: number;
  sortino_ratio: number;
  max_drawdown: number;
  volatility: number;
  beta: number;
  alpha: number;
  win_rate: number;
  profit_factor: number;
}

interface RiskMetrics {
  var_1d: number;
  var_7d: number;
  portfolio_correlation: number;
  concentration_risk: number;
  liquidity_risk: number;
  risk_score: number;
}

interface TaxData {
  short_term_gains: number;
  long_term_gains: number;
  unrealized_gains: number;
  tax_loss_harvesting_opportunities: number;
  estimated_tax_liability: number;
}

interface RebalancingSuggestion {
  symbol: string;
  current_allocation: number;
  target_allocation: number;
  action: 'buy' | 'sell';
  amount: number;
  reason: string;
}

interface BenchmarkComparison {
  name: string;
  symbol: string;
  portfolio_return: number;
  benchmark_return: number;
  outperformance: number;
  correlation: number;
}

export function PortfolioWidget() {
  const [activeTab, setActiveTab] = useState<'overview' | 'performance' | 'risk' | 'tax' | 'rebalance'>('overview');

  // Use real trading hooks
  const { portfolio, positions, loading: portfolioLoading, error: portfolioError, metrics, refreshPortfolio } = usePortfolio();
  const { riskMetrics, riskLevel, recommendations, loading: riskLoading, refreshRiskData } = useRiskManagement();

  const loading = portfolioLoading || riskLoading;

  // Transform real data to match component interface
  const portfolioData = useMemo(() => {
    if (!portfolio) return null;

    // Calculate additional metrics
    const totalReturn = metrics?.totalReturn || 0;
    const dailyReturn = metrics?.dailyReturn || 0;

    return {
      total_value: portfolio.totalValue,
      available_balance: portfolio.availableBalance,
      locked_balance: portfolio.usedMargin,
      total_pnl: portfolio.totalPnl,
      unrealized_pnl: positions.reduce((sum, pos) => sum + pos.unrealizedPnl, 0),
      realized_pnl: portfolio.totalPnl - positions.reduce((sum, pos) => sum + pos.unrealizedPnl, 0),
      daily_change: portfolio.dailyPnl,
      daily_change_percent: dailyReturn,
      weekly_change: totalReturn * 0.7, // Approximation
      monthly_change: totalReturn * 0.8, // Approximation
      yearly_change: totalReturn,
      positions: positions.map(pos => ({
        symbol: pos.symbol.replace('USDT', ''),
        quantity: pos.size,
        average_price: pos.entryPrice,
        current_price: pos.currentPrice,
        market_value: pos.size * pos.currentPrice,
        unrealized_pnl: pos.unrealizedPnl,
        unrealized_pnl_percent: pos.percentage,
        allocation_percent: (pos.size * pos.currentPrice / portfolio.totalValue) * 100,
        target_allocation: 100 / positions.length, // Equal weight target
        exchange: 'Binance', // Default
        first_purchase_date: new Date(pos.timestamp).toISOString().split('T')[0],
        last_purchase_date: new Date(pos.timestamp).toISOString().split('T')[0],
        total_invested: pos.size * pos.entryPrice,
        roi: pos.percentage,
        holding_period: Math.floor((Date.now() - pos.timestamp) / (1000 * 60 * 60 * 24))
      })),
      exchanges: portfolio.assets.map(asset => ({
        exchange: 'Binance', // Default
        total_value: asset.usdValue,
        available: asset.free * (asset.usdValue / asset.total),
        locked: asset.locked * (asset.usdValue / asset.total),
        percentage: (asset.usdValue / portfolio.totalValue) * 100,
        status: 'connected' as const
      })),
      performance_metrics: {
        sharpe_ratio: riskMetrics?.sharpeRatio || 1.5,
        sortino_ratio: riskMetrics?.sortinoRatio || 1.8,
        max_drawdown: riskMetrics?.maxDrawdown || 10,
        volatility: 25, // Default
        beta: 1.0,
        alpha: 2.5,
        win_rate: riskMetrics?.winRate || 65,
        profit_factor: riskMetrics?.profitFactor || 1.8
      },
      risk_metrics: {
        var_1d: riskMetrics?.valueAtRisk || 1000,
        var_7d: (riskMetrics?.valueAtRisk || 1000) * 2.5,
        portfolio_correlation: 0.75,
        concentration_risk: Math.max(...positions.map(pos => (pos.size * pos.currentPrice / portfolio.totalValue) * 100)),
        liquidity_risk: 15,
        risk_score: riskMetrics?.portfolioRisk || 50
      },
      tax_implications: {
        short_term_gains: portfolio.totalPnl * 0.3, // Approximation
        long_term_gains: portfolio.totalPnl * 0.7, // Approximation
        unrealized_gains: positions.reduce((sum, pos) => sum + Math.max(0, pos.unrealizedPnl), 0),
        tax_loss_harvesting_opportunities: Math.abs(positions.reduce((sum, pos) => sum + Math.min(0, pos.unrealizedPnl), 0)),
        estimated_tax_liability: portfolio.totalPnl * 0.25 // Approximation
      },
      rebalancing_suggestions: positions.map(pos => {
        const currentAllocation = (pos.size * pos.currentPrice / portfolio.totalValue) * 100;
        const targetAllocation = 100 / positions.length;
        const difference = currentAllocation - targetAllocation;

        return {
          symbol: pos.symbol.replace('USDT', ''),
          current_allocation: currentAllocation,
          target_allocation: targetAllocation,
          action: difference > 0 ? 'sell' as const : 'buy' as const,
          amount: Math.abs(difference * portfolio.totalValue / 100),
          reason: difference > 0 ? 'Overweight position' : 'Underweight position'
        };
      }).filter(suggestion => Math.abs(suggestion.current_allocation - suggestion.target_allocation) > 2),
      benchmarks: [
        { name: 'Bitcoin', symbol: 'BTC', portfolio_return: totalReturn, benchmark_return: 15.2, outperformance: totalReturn - 15.2, correlation: 0.85 },
        { name: 'S&P 500', symbol: 'SPY', portfolio_return: totalReturn, benchmark_return: 12.8, outperformance: totalReturn - 12.8, correlation: 0.42 },
        { name: 'Crypto Total Market', symbol: 'TOTAL', portfolio_return: totalReturn, benchmark_return: 22.1, outperformance: totalReturn - 22.1, correlation: 0.92 }
      ]
    };
  }, [portfolio, positions, metrics, riskMetrics]);

  // Auto-refresh data
  useEffect(() => {
    const interval = setInterval(() => {
      refreshPortfolio();
      refreshRiskData();
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, [refreshPortfolio, refreshRiskData]);

  // Handle errors
  if (portfolioError) {
    return (
      <div className="h-full flex flex-col items-center justify-center">
        <AlertTriangle className="h-8 w-8 text-danger-400 mb-2" />
        <div className="text-sm text-danger-400 mb-2">Failed to load portfolio data</div>
        <button
          onClick={refreshPortfolio}
          className="text-xs text-primary-400 hover:text-primary-300"
        >
          Try Again
        </button>
      </div>
    );
  }

  // Use mock data for now
  const portfolioData = mockData;
  const mockData: PortfolioData = {
    total_value: 125430.50,
    available_balance: 15230.75,
    locked_balance: 8450.25,
    total_pnl: 23450.80,
    unrealized_pnl: 2340.80,
    realized_pnl: 21110.00,
    daily_change: 2340.80,
    daily_change_percent: 1.9,
    weekly_change: 8750.25,
    monthly_change: 15420.80,
    yearly_change: 45230.50,
    positions: [
      {
        symbol: 'BTC',
        quantity: 1.25,
        average_price: 41200,
        current_price: 43250,
        market_value: 54062.50,
        unrealized_pnl: 2562.50,
        unrealized_pnl_percent: 4.98,
        allocation_percent: 43.1,
        target_allocation: 40.0,
        exchange: 'Binance',
        first_purchase_date: '2023-08-15',
        last_purchase_date: '2024-01-10',
        total_invested: 51500.00,
        roi: 5.0,
        holding_period: 156
      },
      {
        symbol: 'ETH',
        quantity: 15.8,
        average_price: 2750,
        current_price: 2680,
        market_value: 42344.00,
        unrealized_pnl: -1106.00,
        unrealized_pnl_percent: -2.54,
        allocation_percent: 33.8,
        target_allocation: 35.0,
        exchange: 'Coinbase',
        first_purchase_date: '2023-09-20',
        last_purchase_date: '2024-01-05',
        total_invested: 43450.00,
        roi: -2.5,
        holding_period: 121
      },
      {
        symbol: 'SOL',
        quantity: 180,
        average_price: 95.50,
        current_price: 98.45,
        market_value: 17721.00,
        unrealized_pnl: 531.00,
        unrealized_pnl_percent: 3.09,
        allocation_percent: 14.1,
        target_allocation: 15.0,
        exchange: 'OKX',
        first_purchase_date: '2023-10-12',
        last_purchase_date: '2023-12-20',
        total_invested: 17190.00,
        roi: 3.1,
        holding_period: 99
      },
      {
        symbol: 'BNB',
        quantity: 35,
        average_price: 320.00,
        current_price: 315.80,
        market_value: 11053.00,
        unrealized_pnl: -147.00,
        unrealized_pnl_percent: -1.31,
        allocation_percent: 8.8,
        target_allocation: 10.0,
        exchange: 'Binance',
        first_purchase_date: '2023-11-05',
        last_purchase_date: '2023-11-05',
        total_invested: 11200.00,
        roi: -1.3,
        holding_period: 75
      }
    ],
    exchanges: [
      { exchange: 'Binance', total_value: 65115.50, available: 8230.75, locked: 4450.25, percentage: 51.9, status: 'connected' },
      { exchange: 'Coinbase', total_value: 42344.00, available: 5000.00, locked: 2000.00, percentage: 33.8, status: 'connected' },
      { exchange: 'OKX', total_value: 17721.00, available: 2000.00, locked: 2000.00, percentage: 14.1, status: 'connected' },
      { exchange: 'Bybit', total_value: 250.00, available: 0.00, locked: 0.00, percentage: 0.2, status: 'disconnected' }
    ],
    performance_metrics: {
      sharpe_ratio: 1.85,
      sortino_ratio: 2.12,
      max_drawdown: 15.8,
      volatility: 28.5,
      beta: 1.12,
      alpha: 3.8,
      win_rate: 68.5,
      profit_factor: 2.15
    },
    risk_metrics: {
      var_1d: 2850.50,
      var_7d: 8420.75,
      portfolio_correlation: 0.78,
      concentration_risk: 65.2,
      liquidity_risk: 15.8,
      risk_score: 72
    },
    tax_implications: {
      short_term_gains: 5420.80,
      long_term_gains: 15689.20,
      unrealized_gains: 2340.80,
      tax_loss_harvesting_opportunities: 1253.00,
      estimated_tax_liability: 4250.75
    },
    rebalancing_suggestions: [
      { symbol: 'BTC', current_allocation: 43.1, target_allocation: 40.0, action: 'sell', amount: 3890.45, reason: 'Overweight position' },
      { symbol: 'ETH', current_allocation: 33.8, target_allocation: 35.0, action: 'buy', amount: 1505.16, reason: 'Underweight position' },
      { symbol: 'BNB', current_allocation: 8.8, target_allocation: 10.0, action: 'buy', amount: 1504.37, reason: 'Underweight position' }
    ],
    benchmarks: [
      { name: 'Bitcoin', symbol: 'BTC', portfolio_return: 18.7, benchmark_return: 15.2, outperformance: 3.5, correlation: 0.85 },
      { name: 'S&P 500', symbol: 'SPY', portfolio_return: 18.7, benchmark_return: 12.8, outperformance: 5.9, correlation: 0.42 },
      { name: 'Crypto Total Market', symbol: 'TOTAL', portfolio_return: 18.7, benchmark_return: 22.1, outperformance: -3.4, correlation: 0.92 }
    ]
  };

  setTimeout(() => {
    setPortfolioData(mockData);
    setLoading(false);
  }, 1000);

  // Simulate real-time updates
  const interval = setInterval(() => {
    if (portfolioData) {
      setPortfolioData(prev => prev ? {
        ...prev,
        total_value: prev.total_value * (1 + (Math.random() - 0.5) * 0.02),
        daily_change: prev.daily_change + (Math.random() - 0.5) * 100,
        positions: prev.positions.map(pos => ({
          ...pos,
          current_price: pos.current_price * (1 + (Math.random() - 0.5) * 0.02),
          market_value: pos.quantity * pos.current_price * (1 + (Math.random() - 0.5) * 0.02)
        }))
      } : null);
    }
  }, 10000);

  return () => clearInterval(interval);
}, [portfolioData]);

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

const formatPercent = (percent: number) => {
  return `${percent >= 0 ? '+' : ''}${percent.toFixed(2)}%`;
};

if (loading || !portfolioData) {
  return (
    <div className="h-full flex items-center justify-center">
      <div className="spinner h-8 w-8"></div>
    </div>
  );
}

// Performance Tab Component
const PerformanceTab = () => (
  <div className="space-y-4">
    {/* Performance Metrics */}
    <div className="grid grid-cols-2 gap-3">
      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <BarChart3 className="h-4 w-4 text-primary-400" />
          <span className="text-xs text-gray-400">Sharpe Ratio</span>
        </div>
        <div className="text-lg font-semibold text-white">
          {portfolioData.performance_metrics.sharpe_ratio.toFixed(2)}
        </div>
        <div className="text-xs text-success-400">Excellent</div>
      </div>

      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <TrendingDown className="h-4 w-4 text-danger-400" />
          <span className="text-xs text-gray-400">Max Drawdown</span>
        </div>
        <div className="text-lg font-semibold text-danger-400">
          -{portfolioData.performance_metrics.max_drawdown.toFixed(1)}%
        </div>
        <div className="text-xs text-gray-400">Recovered</div>
      </div>

      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <Activity className="h-4 w-4 text-warning-400" />
          <span className="text-xs text-gray-400">Volatility</span>
        </div>
        <div className="text-lg font-semibold text-white">
          {portfolioData.performance_metrics.volatility.toFixed(1)}%
        </div>
        <div className="text-xs text-gray-400">Annualized</div>
      </div>

      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <Target className="h-4 w-4 text-success-400" />
          <span className="text-xs text-gray-400">Win Rate</span>
        </div>
        <div className="text-lg font-semibold text-success-400">
          {portfolioData.performance_metrics.win_rate.toFixed(1)}%
        </div>
        <div className="text-xs text-gray-400">Trades</div>
      </div>
    </div>

    {/* Benchmark Comparison */}
    <div className="bg-dark-700 rounded-lg p-3">
      <h4 className="text-sm font-medium text-white mb-3">Benchmark Comparison</h4>
      <div className="space-y-2">
        {portfolioData.benchmarks.map((benchmark, index) => (
          <div key={index} className="flex items-center justify-between">
            <span className="text-sm text-gray-300">{benchmark.name}</span>
            <div className="flex items-center space-x-4">
              <div className="text-sm">
                <span className="text-gray-400">Portfolio: </span>
                <span className="text-white">{benchmark.portfolio_return.toFixed(1)}%</span>
              </div>
              <div className="text-sm">
                <span className="text-gray-400">vs </span>
                <span className={benchmark.outperformance >= 0 ? 'text-success-400' : 'text-danger-400'}>
                  {benchmark.outperformance >= 0 ? '+' : ''}{benchmark.outperformance.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// Risk Tab Component
const RiskTab = () => (
  <div className="space-y-4">
    <div className="grid grid-cols-2 gap-3">
      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <AlertTriangle className="h-4 w-4 text-warning-400" />
          <span className="text-xs text-gray-400">VaR (1D)</span>
        </div>
        <div className="text-lg font-semibold text-white">
          {formatCurrency(portfolioData.risk_metrics.var_1d)}
        </div>
        <div className="text-xs text-gray-400">95% confidence</div>
      </div>

      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <AlertTriangle className="h-4 w-4 text-danger-400" />
          <span className="text-xs text-gray-400">Risk Score</span>
        </div>
        <div className="text-lg font-semibold text-warning-400">
          {portfolioData.risk_metrics.risk_score}/100
        </div>
        <div className="text-xs text-gray-400">Moderate Risk</div>
      </div>
    </div>

    <div className="bg-dark-700 rounded-lg p-3">
      <h4 className="text-sm font-medium text-white mb-3">Risk Breakdown</h4>
      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Concentration Risk</span>
            <span className="text-warning-400">{portfolioData.risk_metrics.concentration_risk.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-dark-600 rounded-full h-2">
            <div className="bg-warning-500 h-2 rounded-full" style={{ width: `${portfolioData.risk_metrics.concentration_risk}%` }}></div>
          </div>
        </div>
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Liquidity Risk</span>
            <span className="text-success-400">{portfolioData.risk_metrics.liquidity_risk.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-dark-600 rounded-full h-2">
            <div className="bg-success-500 h-2 rounded-full" style={{ width: `${portfolioData.risk_metrics.liquidity_risk}%` }}></div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Tax Tab Component
const TaxTab = () => (
  <div className="space-y-4">
    <div className="grid grid-cols-2 gap-3">
      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <FileText className="h-4 w-4 text-success-400" />
          <span className="text-xs text-gray-400">Long-term Gains</span>
        </div>
        <div className="text-lg font-semibold text-success-400">
          {formatCurrency(portfolioData.tax_implications.long_term_gains)}
        </div>
        <div className="text-xs text-gray-400">Favorable tax rate</div>
      </div>

      <div className="bg-dark-700 rounded-lg p-3">
        <div className="flex items-center space-x-2 mb-1">
          <FileText className="h-4 w-4 text-warning-400" />
          <span className="text-xs text-gray-400">Short-term Gains</span>
        </div>
        <div className="text-lg font-semibold text-warning-400">
          {formatCurrency(portfolioData.tax_implications.short_term_gains)}
        </div>
        <div className="text-xs text-gray-400">Regular tax rate</div>
      </div>
    </div>

    <div className="bg-dark-700 rounded-lg p-3">
      <h4 className="text-sm font-medium text-white mb-3">Tax Summary</h4>
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Unrealized Gains</span>
          <span className="text-white">{formatCurrency(portfolioData.tax_implications.unrealized_gains)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Tax Loss Harvesting</span>
          <span className="text-success-400">{formatCurrency(portfolioData.tax_implications.tax_loss_harvesting_opportunities)}</span>
        </div>
        <div className="flex justify-between text-sm border-t border-dark-600 pt-2">
          <span className="text-gray-400">Estimated Tax Liability</span>
          <span className="text-danger-400 font-medium">{formatCurrency(portfolioData.tax_implications.estimated_tax_liability)}</span>
        </div>
      </div>
    </div>
  </div>
);

// Rebalance Tab Component
const RebalanceTab = () => (
  <div className="space-y-4">
    <div className="bg-dark-700 rounded-lg p-3">
      <h4 className="text-sm font-medium text-white mb-3">Rebalancing Suggestions</h4>
      <div className="space-y-3">
        {portfolioData.rebalancing_suggestions.map((suggestion, index) => (
          <div key={index} className="border border-dark-600 rounded p-2">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-white">{suggestion.symbol}</span>
              <span className={`text-sm px-2 py-1 rounded ${suggestion.action === 'buy' ? 'bg-success-900/30 text-success-400' : 'bg-danger-900/30 text-danger-400'
                }`}>
                {suggestion.action.toUpperCase()} {formatCurrency(suggestion.amount)}
              </span>
            </div>
            <div className="flex justify-between text-xs text-gray-400 mb-1">
              <span>Current: {suggestion.current_allocation.toFixed(1)}%</span>
              <span>Target: {suggestion.target_allocation.toFixed(1)}%</span>
            </div>
            <div className="text-xs text-gray-300">{suggestion.reason}</div>
          </div>
        ))}
      </div>
      <button className="w-full mt-3 bg-primary-600 hover:bg-primary-700 text-white py-2 rounded text-sm transition-colors">
        Execute Rebalancing
      </button>
    </div>
  </div>
);

return (
  <div className="h-full flex flex-col">
    {/* Enhanced Header with Tab Navigation */}
    <div className="flex items-center justify-between mb-4">
      <h3 className="text-lg font-semibold text-white flex items-center">
        <Wallet className="h-5 w-5 mr-2 text-primary-500" />
        Advanced Portfolio
      </h3>
      <div className="flex items-center space-x-2">
        <div className="text-xs bg-success-900/30 text-success-400 px-2 py-1 rounded">
          {formatPercent(portfolioData.performance_metrics.sharpe_ratio * 10)} YTD
        </div>
        <button className="p-1 text-gray-400 hover:text-white transition-colors">
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>
    </div>

    {/* Tab Navigation */}
    <div className="flex space-x-1 mb-4">
      {[
        { key: 'overview', label: 'Overview', icon: PieChart },
        { key: 'performance', label: 'Performance', icon: BarChart3 },
        { key: 'risk', label: 'Risk', icon: AlertTriangle },
        { key: 'tax', label: 'Tax', icon: FileText },
        { key: 'rebalance', label: 'Rebalance', icon: Target }
      ].map(({ key, label, icon: Icon }) => (
        <button
          key={key}
          onClick={() => setActiveTab(key as any)}
          className={`flex items-center space-x-1 px-2 py-1 rounded text-xs transition-colors ${activeTab === key
            ? 'bg-primary-600 text-white'
            : 'bg-dark-700 text-gray-400 hover:text-white hover:bg-dark-600'
            }`}
        >
          <Icon className="h-3 w-3" />
          <span>{label}</span>
        </button>
      ))}
    </div>

    {/* Tab Content */}
    <div className="flex-1 overflow-auto">
      {activeTab === 'performance' && <PerformanceTab />}
      {activeTab === 'risk' && <RiskTab />}
      {activeTab === 'tax' && <TaxTab />}
      {activeTab === 'rebalance' && <RebalanceTab />}
      {activeTab === 'overview' && (
        <div className="space-y-4">

          {/* Portfolio Summary */}
          <div className="bg-dark-700 rounded-lg p-4 mb-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-2xl font-bold text-white">
                  {formatCurrency(portfolioData.total_value)}
                </div>
                <div className="text-sm text-gray-400">Total Portfolio Value</div>
              </div>
              <div className="text-right">
                <div className={`text-lg font-semibold flex items-center justify-end ${portfolioData.daily_change >= 0 ? 'text-success-400' : 'text-danger-400'
                  }`}>
                  {portfolioData.daily_change >= 0 ? (
                    <TrendingUp className="h-4 w-4 mr-1" />
                  ) : (
                    <TrendingDown className="h-4 w-4 mr-1" />
                  )}
                  {formatCurrency(Math.abs(portfolioData.daily_change))}
                </div>
                <div className={`text-sm ${portfolioData.daily_change_percent >= 0 ? 'text-success-400' : 'text-danger-400'
                  }`}>
                  {formatPercent(portfolioData.daily_change_percent)} (24h)
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-dark-600">
              <div>
                <div className="text-sm text-gray-400">Available</div>
                <div className="text-white font-medium">
                  {formatCurrency(portfolioData.available_balance)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400">Locked</div>
                <div className="text-white font-medium">
                  {formatCurrency(portfolioData.locked_balance)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400">Total P&L</div>
                <div className={`font-medium ${portfolioData.total_pnl >= 0 ? 'text-success-400' : 'text-danger-400'
                  }`}>
                  {formatCurrency(portfolioData.total_pnl)}
                </div>
              </div>
            </div>
          </div>

          {/* Positions */}
          <div className="flex-1 overflow-auto">
            <div className="flex items-center space-x-2 mb-3">
              <PieChart className="h-4 w-4 text-gray-400" />
              <span className="text-sm font-medium text-white">Positions</span>
            </div>

            <div className="space-y-2">
              {portfolioData.positions.map((position) => (
                <div key={position.symbol} className="bg-dark-700 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-white">{position.symbol}</span>
                      <span className="text-xs text-gray-400">
                        {position.allocation_percent.toFixed(1)}%
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-white">
                        {formatCurrency(position.market_value)}
                      </div>
                      <div className={`text-xs ${position.unrealized_pnl >= 0 ? 'text-success-400' : 'text-danger-400'
                        }`}>
                        {formatCurrency(position.unrealized_pnl)} ({formatPercent(position.unrealized_pnl_percent)})
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs text-gray-400">
                    <div>
                      <div>Quantity</div>
                      <div className="text-white">{position.quantity}</div>
                    </div>
                    <div>
                      <div>Avg Price</div>
                      <div className="text-white">${position.average_price.toLocaleString()}</div>
                    </div>
                    <div>
                      <div>Current</div>
                      <div className="text-white">${position.current_price.toLocaleString()}</div>
                    </div>
                  </div>

                  {/* Allocation bar */}
                  <div className="mt-2">
                    <div className="w-full bg-dark-600 rounded-full h-1">
                      <div
                        className="bg-primary-500 h-1 rounded-full"
                        style={{ width: `${position.allocation_percent}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  </div>
);
}
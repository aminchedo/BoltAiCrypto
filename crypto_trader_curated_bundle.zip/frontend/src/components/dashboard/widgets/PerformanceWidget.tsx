'use client';

import { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Award, Calendar } from 'lucide-react';

interface PerformanceMetrics {
  total_return: number;
  total_return_percent: number;
  sharpe_ratio: number;
  max_drawdown: number;
  win_rate: number;
  profit_factor: number;
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  avg_win: number;
  avg_loss: number;
  best_trade: number;
  worst_trade: number;
  monthly_returns: number[];
}

export function PerformanceWidget() {
  const [performance, setPerformance] = useState<PerformanceMetrics | null>(null);
  const [timeframe, setTimeframe] = useState<'1M' | '3M' | '6M' | '1Y'>('3M');

  useEffect(() => {
    // Mock performance data
    const mockPerformance: PerformanceMetrics = {
      total_return: 23450.80,
      total_return_percent: 23.8,
      sharpe_ratio: 1.85,
      max_drawdown: 8.5,
      win_rate: 68.5,
      profit_factor: 2.15,
      total_trades: 147,
      winning_trades: 101,
      losing_trades: 46,
      avg_win: 485.20,
      avg_loss: -225.80,
      best_trade: 2850.50,
      worst_trade: -1250.30,
      monthly_returns: [5.2, -2.1, 8.7, 3.4, -1.8, 12.5, 4.2, 6.8, -3.2, 9.1, 7.3, 2.9]
    };

    setPerformance(mockPerformance);
  }, [timeframe]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatPercent = (percent: number) => {
    return `${percent >= 0 ? '+' : ''}${percent.toFixed(2)}%`;
  };

  if (!performance) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="spinner h-8 w-8"></div>
      </div>
    );
  }

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <BarChart3 className="h-5 w-5 mr-2 text-primary-500" />
          Performance
        </h3>
        <select
          value={timeframe}
          onChange={(e) => setTimeframe(e.target.value as any)}
          className="bg-dark-700 border border-dark-600 rounded px-2 py-1 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
        >
          <option value="1M">1 Month</option>
          <option value="3M">3 Months</option>
          <option value="6M">6 Months</option>
          <option value="1Y">1 Year</option>
        </select>
      </div>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <TrendingUp className="h-4 w-4 text-success-400" />
            <span className="text-xs text-gray-400">Total Return</span>
          </div>
          <div className="text-lg font-semibold text-success-400">
            {formatCurrency(performance.total_return)}
          </div>
          <div className="text-sm text-success-400">
            {formatPercent(performance.total_return_percent)}
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Award className="h-4 w-4 text-primary-400" />
            <span className="text-xs text-gray-400">Sharpe Ratio</span>
          </div>
          <div className="text-lg font-semibold text-white">
            {performance.sharpe_ratio.toFixed(2)}
          </div>
          <div className="text-sm text-success-400">
            Excellent
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs text-gray-400">Win Rate</span>
          </div>
          <div className="text-lg font-semibold text-white">
            {performance.win_rate.toFixed(1)}%
          </div>
          <div className="text-sm text-gray-400">
            {performance.winning_trades}/{performance.total_trades} trades
          </div>
        </div>

        <div className="bg-dark-700 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs text-gray-400">Max Drawdown</span>
          </div>
          <div className="text-lg font-semibold text-danger-400">
            -{performance.max_drawdown.toFixed(1)}%
          </div>
          <div className="text-sm text-gray-400">
            Recovered
          </div>
        </div>
      </div>

      {/* Trading Statistics */}
      <div className="bg-dark-700 rounded-lg p-3 mb-4">
        <h4 className="text-sm font-medium text-white mb-3">Trading Statistics</h4>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-gray-400">Profit Factor</div>
            <div className="text-white font-medium">{performance.profit_factor.toFixed(2)}</div>
          </div>
          <div>
            <div className="text-gray-400">Total Trades</div>
            <div className="text-white font-medium">{performance.total_trades}</div>
          </div>
          <div>
            <div className="text-gray-400">Avg Win</div>
            <div className="text-success-400 font-medium">{formatCurrency(performance.avg_win)}</div>
          </div>
          <div>
            <div className="text-gray-400">Avg Loss</div>
            <div className="text-danger-400 font-medium">{formatCurrency(performance.avg_loss)}</div>
          </div>
          <div>
            <div className="text-gray-400">Best Trade</div>
            <div className="text-success-400 font-medium">{formatCurrency(performance.best_trade)}</div>
          </div>
          <div>
            <div className="text-gray-400">Worst Trade</div>
            <div className="text-danger-400 font-medium">{formatCurrency(performance.worst_trade)}</div>
          </div>
        </div>
      </div>

      {/* Monthly Returns Chart */}
      <div className="flex-1">
        <div className="flex items-center space-x-2 mb-3">
          <Calendar className="h-4 w-4 text-gray-400" />
          <span className="text-sm font-medium text-white">Monthly Returns</span>
        </div>
        
        <div className="space-y-2">
          {performance.monthly_returns.slice(-6).map((returnPercent, index) => {
            const monthIndex = (new Date().getMonth() - 5 + index + 12) % 12;
            const monthName = monthNames[monthIndex];
            const isPositive = returnPercent >= 0;
            
            return (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-8 text-xs text-gray-400">{monthName}</div>
                <div className="flex-1 flex items-center">
                  <div className="w-full bg-dark-600 rounded-full h-2 relative">
                    <div
                      className={`h-2 rounded-full ${
                        isPositive ? 'bg-success-500' : 'bg-danger-500'
                      }`}
                      style={{ 
                        width: `${Math.min(Math.abs(returnPercent) * 2, 100)}%`,
                        marginLeft: !isPositive ? `${100 - Math.min(Math.abs(returnPercent) * 2, 100)}%` : '0'
                      }}
                    ></div>
                  </div>
                  <div className={`ml-2 text-xs font-medium w-12 text-right ${
                    isPositive ? 'text-success-400' : 'text-danger-400'
                  }`}>
                    {formatPercent(returnPercent)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Performance Actions */}
      <div className="mt-4 pt-4 border-t border-dark-700">
        <div className="grid grid-cols-2 gap-2">
          <button className="bg-dark-700 hover:bg-dark-600 text-gray-400 hover:text-white py-2 rounded text-sm transition-colors">
            Detailed Report
          </button>
          <button className="bg-primary-600 hover:bg-primary-700 text-white py-2 rounded text-sm transition-colors">
            Export Data
          </button>
        </div>
      </div>
    </div>
  );
}
'use client';

import { useState, useEffect } from 'react';
import { Newspaper, TrendingUp, TrendingDown, Clock } from 'lucide-react';

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  sentiment_score: number;
  source: string;
  published_at: string;
  impact_symbols: string[];
  url: string;
}

export function NewsWidget() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'positive' | 'negative'>('all');

  useEffect(() => {
    // Mock news data
    const mockNews: NewsItem[] = [
      {
        id: '1',
        title: 'Bitcoin ETF Sees Record Inflows as Institutional Adoption Grows',
        summary: 'Major institutional investors continue to pour money into Bitcoin ETFs, with record-breaking inflows reported this week.',
        sentiment: 'positive',
        sentiment_score: 0.85,
        source: 'CoinDesk',
        published_at: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        impact_symbols: ['BTC', 'ETH'],
        url: '#'
      },
      {
        id: '2',
        title: 'Regulatory Concerns Mount as SEC Increases Crypto Scrutiny',
        summary: 'The Securities and Exchange Commission announces new guidelines that could impact several major cryptocurrency projects.',
        sentiment: 'negative',
        sentiment_score: -0.72,
        source: 'CoinTelegraph',
        published_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        impact_symbols: ['BTC', 'ETH', 'ADA', 'SOL'],
        url: '#'
      },
      {
        id: '3',
        title: 'Ethereum Layer 2 Solutions Show Massive Growth in TVL',
        summary: 'Total Value Locked in Ethereum Layer 2 networks reaches new all-time highs, signaling strong ecosystem growth.',
        sentiment: 'positive',
        sentiment_score: 0.68,
        source: 'The Block',
        published_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        impact_symbols: ['ETH'],
        url: '#'
      },
      {
        id: '4',
        title: 'Major Exchange Reports Security Breach, User Funds Safe',
        summary: 'A leading cryptocurrency exchange confirms a security incident but assures users that all funds remain secure.',
        sentiment: 'negative',
        sentiment_score: -0.45,
        source: 'Decrypt',
        published_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
        impact_symbols: ['BTC', 'ETH', 'BNB'],
        url: '#'
      },
      {
        id: '5',
        title: 'DeFi Protocol Launches Revolutionary Yield Farming Mechanism',
        summary: 'New decentralized finance protocol introduces innovative yield farming strategies with enhanced security features.',
        sentiment: 'positive',
        sentiment_score: 0.55,
        source: 'DeFi Pulse',
        published_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        impact_symbols: ['ETH', 'UNI', 'AAVE'],
        url: '#'
      }
    ];

    setNews(mockNews);
  }, []);

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    }
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return <TrendingUp className="h-4 w-4 text-success-400" />;
      case 'negative':
        return <TrendingDown className="h-4 w-4 text-danger-400" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'border-l-success-500 bg-success-900/10';
      case 'negative':
        return 'border-l-danger-500 bg-danger-900/10';
      default:
        return 'border-l-gray-500 bg-gray-900/10';
    }
  };

  const filteredNews = news.filter(item => {
    if (filter === 'positive') return item.sentiment === 'positive';
    if (filter === 'negative') return item.sentiment === 'negative';
    return true;
  });

  const averageSentiment = news.reduce((sum, item) => sum + item.sentiment_score, 0) / news.length;

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Newspaper className="h-5 w-5 mr-2 text-primary-500" />
          News & Sentiment
        </h3>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="bg-dark-700 border border-dark-600 rounded px-2 py-1 text-sm text-white focus:outline-none focus:ring-1 focus:ring-primary-500"
        >
          <option value="all">All News</option>
          <option value="positive">Positive</option>
          <option value="negative">Negative</option>
        </select>
      </div>

      {/* Sentiment Summary */}
      <div className="bg-dark-700 rounded-lg p-3 mb-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-400">Market Sentiment</div>
            <div className={`text-lg font-semibold ${
              averageSentiment > 0.2 
                ? 'text-success-400' 
                : averageSentiment < -0.2 
                ? 'text-danger-400' 
                : 'text-warning-400'
            }`}>
              {averageSentiment > 0.2 ? 'Bullish' : averageSentiment < -0.2 ? 'Bearish' : 'Neutral'}
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-400">Score</div>
            <div className={`text-lg font-semibold ${
              averageSentiment >= 0 ? 'text-success-400' : 'text-danger-400'
            }`}>
              {averageSentiment >= 0 ? '+' : ''}{(averageSentiment * 100).toFixed(0)}
            </div>
          </div>
        </div>
        
        <div className="mt-2">
          <div className="w-full bg-dark-600 rounded-full h-2">
            <div
              className={`h-2 rounded-full ${
                averageSentiment >= 0 ? 'bg-success-500' : 'bg-danger-500'
              }`}
              style={{ 
                width: `${Math.min(Math.abs(averageSentiment) * 100, 100)}%`,
                marginLeft: averageSentiment < 0 ? `${100 - Math.abs(averageSentiment) * 100}%` : '0'
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* News List */}
      <div className="flex-1 overflow-auto space-y-3">
        {filteredNews.map((item) => (
          <div
            key={item.id}
            className={`border-l-4 rounded-r-lg p-3 cursor-pointer hover:bg-dark-600/50 transition-colors ${getSentimentColor(item.sentiment)}`}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-2">
                {getSentimentIcon(item.sentiment)}
                <span className="text-xs text-gray-400">{item.source}</span>
                <span className="text-xs text-gray-500">•</span>
                <span className="text-xs text-gray-500">{formatTimeAgo(item.published_at)}</span>
              </div>
              <div className={`text-xs px-2 py-1 rounded ${
                item.sentiment === 'positive' 
                  ? 'bg-success-900/30 text-success-400'
                  : item.sentiment === 'negative'
                  ? 'bg-danger-900/30 text-danger-400'
                  : 'bg-gray-900/30 text-gray-400'
              }`}>
                {Math.abs(item.sentiment_score * 100).toFixed(0)}%
              </div>
            </div>
            
            <h4 className="text-sm font-medium text-white mb-2 line-clamp-2">
              {item.title}
            </h4>
            
            <p className="text-xs text-gray-400 mb-2 line-clamp-2">
              {item.summary}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex space-x-1">
                {item.impact_symbols.slice(0, 3).map(symbol => (
                  <span
                    key={symbol}
                    className="text-xs px-2 py-1 bg-dark-600 text-gray-300 rounded"
                  >
                    {symbol}
                  </span>
                ))}
                {item.impact_symbols.length > 3 && (
                  <span className="text-xs text-gray-500">
                    +{item.impact_symbols.length - 3} more
                  </span>
                )}
              </div>
              
              <button className="text-xs text-primary-400 hover:text-primary-300">
                Read More
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* News Sources */}
      <div className="mt-4 pt-4 border-t border-dark-700">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span>Sources: CoinDesk, CoinTelegraph, The Block, Decrypt</span>
          <button className="text-primary-400 hover:text-primary-300">
            Configure
          </button>
        </div>
      </div>
    </div>
  );
}
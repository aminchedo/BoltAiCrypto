import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Activity, TrendingUp, TrendingDown, BarChart3, Target, Zap } from 'lucide-react';
import { realDataService } from '@/services/realDataService';

interface AIModelPerformanceWidgetProps {
  className?: string;
}

interface ModelPerformance {
  name: string;
  accuracy: number;
  signals: number;
  profit: number;
  change: number;
}

export function AIModelPerformanceWidget({ className }: AIModelPerformanceWidgetProps) {
  const [models, setModels] = useState<ModelPerformance[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeframe, setTimeframe] = useState<'day' | 'week' | 'month'>('week');

  useEffect(() => {
    const fetchModelPerformance = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Try to fetch real data
        const dashboardData = await realDataService.getDashboardData();
        
        // If we have real model data, use it
        if (dashboardData && dashboardData.aiModels) {
          setModels(dashboardData.aiModels);
        } else {
          // Fallback to mock data
          setModels([
            {
              name: 'SpeedTrader_v2.1',
              accuracy: 91.2,
              signals: 247,
              profit: 1234,
              change: 5.6
            },
            {
              name: 'SwingMaster_v1.5',
              accuracy: 88.7,
              signals: 156,
              profit: 987,
              change: -2.3
            },
            {
              name: 'DeepAnalyzer_v3.0',
              accuracy: 94.1,
              signals: 89,
              profit: 626,
              change: 8.2
            }
          ]);
        }
      } catch (err) {
        console.error('Error fetching model performance:', err);
        setError('Failed to load model data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchModelPerformance();
    
    // Set up interval for real-time updates
    const interval = setInterval(fetchModelPerformance, 300000); // Update every 5 minutes
    return () => clearInterval(interval);
  }, [timeframe]);

  if (isLoading) {
    return (
      <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center">
            <Activity className="w-4 h-4 mr-2 text-blue-400" />
            AI Model Performance
          </h3>
          <div className="text-xs text-gray-400">Loading...</div>
        </div>
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse p-2 bg-gray-700/30 rounded">
              <div className="h-4 w-32 bg-gray-600 rounded mb-2"></div>
              <div className="h-3 w-20 bg-gray-600 rounded"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white flex items-center">
          <Activity className="w-4 h-4 mr-2 text-blue-400" />
          AI Model Performance
        </h3>
        
        <div className="flex text-xs bg-gray-700/50 rounded overflow-hidden">
          <button 
            onClick={() => setTimeframe('day')}
            className={`px-2 py-1 ${timeframe === 'day' ? 'bg-blue-600 text-white' : 'text-gray-400'}`}
          >
            24h
          </button>
          <button 
            onClick={() => setTimeframe('week')}
            className={`px-2 py-1 ${timeframe === 'week' ? 'bg-blue-600 text-white' : 'text-gray-400'}`}
          >
            7d
          </button>
          <button 
            onClick={() => setTimeframe('month')}
            className={`px-2 py-1 ${timeframe === 'month' ? 'bg-blue-600 text-white' : 'text-gray-400'}`}
          >
            30d
          </button>
        </div>
      </div>
      
      {error && (
        <div className="p-2 bg-red-500/20 text-red-400 text-xs rounded mb-2">
          {error}
        </div>
      )}
      
      <div className="space-y-3">
        {models.map((model) => (
          <div key={model.name} className="p-3 bg-gray-700/30 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="font-medium text-sm">{model.name}</div>
              <div className={`text-xs flex items-center ${
                model.change >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {model.change >= 0 ? (
                  <TrendingUp className="w-3 h-3 mr-1" />
                ) : (
                  <TrendingDown className="w-3 h-3 mr-1" />
                )}
                {Math.abs(model.change)}%
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-gray-800/50 rounded p-1">
                <div className="text-xs text-gray-400">Accuracy</div>
                <div className="text-sm font-medium text-green-400">{model.accuracy}%</div>
              </div>
              <div className="bg-gray-800/50 rounded p-1">
                <div className="text-xs text-gray-400">Signals</div>
                <div className="text-sm font-medium text-blue-400">{model.signals}</div>
              </div>
              <div className="bg-gray-800/50 rounded p-1">
                <div className="text-xs text-gray-400">Profit</div>
                <div className="text-sm font-medium text-green-400">
                  ${model.profit.toLocaleString()}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <button 
        className="w-full mt-3 bg-blue-600/30 hover:bg-blue-600/50 text-blue-400 py-1.5 rounded text-xs font-medium transition-colors"
        onClick={() => window.dispatchEvent(new CustomEvent('open-ai-lab', { detail: { tab: 'main' } }))}
      >
        View Full Analytics
      </button>
    </div>
  );
}
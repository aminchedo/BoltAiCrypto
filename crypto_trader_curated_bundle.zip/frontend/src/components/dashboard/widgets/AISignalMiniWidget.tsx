import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Brain, TrendingUp, TrendingDown, AlertTriangle, Zap, Clock } from 'lucide-react';
import { signalService } from '@/services/signalService';
import { marketService } from '@/services/marketService';

interface AISignalMiniWidgetProps {
  className?: string;
  onSignalClick?: (signal: any) => void;
}

export function AISignalMiniWidget({ className, onSignalClick }: AISignalMiniWidgetProps) {
  const [signals, setSignals] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSignals = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Fetch real signals from service
        const liveSignals = await signalService.getLiveSignals();
        setSignals(liveSignals.slice(0, 3)); // Show top 3 signals
      } catch (err) {
        console.error('Error fetching signals:', err);
        setError('Failed to load signals');
        
        // Fallback to mock data
        setSignals([
          {
            id: '1',
            symbol: 'BTC/USDT',
            signal: 'BUY',
            confidence: 87,
            entry_price: 43250,
            created_at: new Date().toISOString(),
            algorithm_breakdown: {
              technical_analysis: { score: 0.8, weight: 0.35, contribution: 0.28 },
              final_score: 0.78
            }
          },
          {
            id: '2',
            symbol: 'ETH/USDT',
            signal: 'SELL',
            confidence: 72,
            entry_price: 2680,
            created_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
            algorithm_breakdown: {
              technical_analysis: { score: -0.6, weight: 0.35, contribution: -0.21 },
              final_score: -0.67
            }
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSignals();
    
    // Set up interval for real-time updates
    const interval = setInterval(fetchSignals, 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  const getSignalIcon = (signal: string) => {
    switch (signal) {
      case 'BUY': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'SELL': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  if (isLoading) {
    return (
      <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center">
            <Brain className="w-4 h-4 mr-2 text-purple-400" />
            AI Signals
          </h3>
          <div className="text-xs text-gray-400">Loading...</div>
        </div>
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse flex items-center justify-between p-2 bg-gray-700/30 rounded">
              <div className="h-4 w-20 bg-gray-600 rounded"></div>
              <div className="h-4 w-12 bg-gray-600 rounded"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-gray-800/30 p-4 rounded-xl border border-gray-700 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white flex items-center">
          <Brain className="w-4 h-4 mr-2 text-purple-400" />
          AI Signals
        </h3>
        <div className="text-xs bg-purple-500/20 text-purple-400 px-2 py-1 rounded-full flex items-center">
          <Zap className="w-3 h-3 mr-1" />
          Live
        </div>
      </div>
      
      {error && (
        <div className="p-2 bg-red-500/20 text-red-400 text-xs rounded mb-2">
          {error}
        </div>
      )}
      
      <div className="space-y-2">
        {signals.map((signal) => (
          <motion.div
            key={signal.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSignalClick?.(signal)}
            className={`flex items-center justify-between p-2 rounded cursor-pointer ${
              signal.signal === 'BUY' ? 'bg-green-500/10 border border-green-500/20' :
              signal.signal === 'SELL' ? 'bg-red-500/10 border border-red-500/20' :
              'bg-yellow-500/10 border border-yellow-500/20'
            }`}
          >
            <div className="flex items-center space-x-2">
              {getSignalIcon(signal.signal)}
              <div>
                <div className="text-sm font-medium">{signal.symbol}</div>
                <div className="text-xs text-gray-400 flex items-center">
                  <Clock className="w-3 h-3 mr-1" />
                  {formatTimeAgo(signal.created_at)}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className={`text-sm font-medium ${
                signal.signal === 'BUY' ? 'text-green-400' :
                signal.signal === 'SELL' ? 'text-red-400' :
                'text-yellow-400'
              }`}>
                {signal.signal}
              </div>
              <div className="text-xs text-gray-400">{signal.confidence}%</div>
            </div>
          </motion.div>
        ))}
      </div>
      
      <button 
        className="w-full mt-3 bg-purple-600/30 hover:bg-purple-600/50 text-purple-400 py-1.5 rounded text-xs font-medium transition-colors"
        onClick={() => window.dispatchEvent(new CustomEvent('open-ai-lab', { detail: { tab: 'predictions' } }))}
      >
        View All Signals
      </button>
    </div>
  );
}
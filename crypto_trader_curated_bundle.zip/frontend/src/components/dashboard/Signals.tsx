import React, { useEffect, useState } from 'react';
import { 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  Play, 
  AlertCircle, 
  Activity,
  Target,
  Zap
} from 'lucide-react';
import { useMLStore } from '@/store/mlStore';
import clsx from 'clsx';
import toast from 'react-hot-toast';

export function Signals() {
  const {
    latestPrice,
    setLatestPrice,
    prediction,
    status,
    error,
    trainResult,
    train,
    predict,
    clearError,
  } = useMLStore();

  const handleTrain = async () => {
    clearError();
    await train();
    if (trainResult && trainResult.status === 'trained') {
      toast.success('Model trained successfully!');
    }
  };

  const handlePredict = async () => {
    clearError();
    await predict();
    if (prediction && !prediction.error) {
      toast.success('Prediction completed!');
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const formatPercent = (percent: number) => {
    const sign = percent >= 0 ? '+' : '';
    return `${sign}${percent.toFixed(2)}%`;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Brain className="w-8 h-8 text-purple-600 dark:text-purple-400 mr-3" />
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              AI Trading Signals
            </h1>
          </div>
          <p className="text-gray-600 dark:text-gray-400">
            Machine learning powered cryptocurrency price predictions
          </p>
        </div>

        {/* Training Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Model Training
          </h2>

          <div className="flex items-center space-x-4 mb-4">
            <button
              onClick={handleTrain}
              disabled={status === 'training'}
              className={clsx(
                'flex items-center px-6 py-3 rounded-lg font-medium transition-colors',
                status === 'training'
                  ? 'bg-gray-400 text-white cursor-not-allowed'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              )}
            >
              {status === 'training' ? (
                <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
              ) : (
                <Play className="w-5 h-5 mr-2" />
              )}
              {status === 'training' ? 'Training...' : 'Train Model'}
            </button>

            {trainResult && (
              <div className="text-sm text-green-600 dark:text-green-400">
                ✓ Training completed successfully
              </div>
            )}
          </div>

          {trainResult && trainResult.r2 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {(trainResult.r2 * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">R² Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {trainResult.samples || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Samples</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {trainResult.improved ? '✓' : '✗'}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Improved</div>
              </div>
            </div>
          )}
        </div>

        {/* Prediction Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Price Prediction
          </h2>

          {/* Input Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Current BTC Price (USD)
              </label>
              <input
                type="number"
                value={latestPrice}
                onChange={(e) => setLatestPrice(Number(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500"
                placeholder="Enter current BTC price"
                step="0.01"
              />
            </div>
          </div>

          {/* Predict Button */}
          <div className="flex items-center space-x-4 mb-6">
            <button
              onClick={handlePredict}
              disabled={status === 'predicting'}
              className={clsx(
                'flex items-center px-6 py-3 rounded-lg font-medium transition-colors',
                status === 'predicting'
                  ? 'bg-gray-400 text-white cursor-not-allowed'
                  : 'bg-purple-600 hover:bg-purple-700 text-white'
              )}
            >
              {status === 'predicting' ? (
                <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
              ) : (
                <Zap className="w-5 h-5 mr-2" />
              )}
              {status === 'predicting' ? 'Predicting...' : 'Make Prediction'}
            </button>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900 border border-red-200 dark:border-red-700 rounded-lg">
              <p className="text-red-800 dark:text-red-200 text-sm">
                Prediction Error: {error}
              </p>
            </div>
          )}

          {/* Prediction Results */}
          {prediction && !prediction.error && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Current Price */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Activity className="w-5 h-5 text-blue-500 mr-2" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Current Price
                  </span>
                </div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {formatPrice(prediction.latest || 0)}
                </div>
              </div>

              {/* Predicted Price */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Target className="w-5 h-5 text-purple-500 mr-2" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Predicted Price
                  </span>
                </div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {formatPrice(prediction.predicted || 0)}
                </div>
              </div>

              {/* Direction & Change */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  {prediction.direction === 'LONG' ? (
                    <TrendingUp className="w-5 h-5 text-green-500 mr-2" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-red-500 mr-2" />
                  )}
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Direction
                  </span>
                </div>
                <div className={clsx(
                  'text-2xl font-bold',
                  prediction.direction === 'LONG' 
                    ? 'text-green-600 dark:text-green-400' 
                    : 'text-red-600 dark:text-red-400'
                )}>
                  {prediction.direction}
                </div>
                <div className={clsx(
                  'text-sm',
                  prediction.direction === 'LONG' 
                    ? 'text-green-600 dark:text-green-400' 
                    : 'text-red-600 dark:text-red-400'
                )}>
                  {formatPercent(prediction.change_percent || 0)}
                </div>
              </div>

              {/* Confidence */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Brain className="w-5 h-5 text-indigo-500 mr-2" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Confidence
                  </span>
                </div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {(prediction.confidence * 100).toFixed(0)}%
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2 mt-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${prediction.confidence * 100}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Prediction Timestamp */}
          {prediction && (
            <div className="mt-4 text-sm text-gray-500 dark:text-gray-400 text-center">
              Last prediction: {new Date(prediction.timestamp).toLocaleString()}
            </div>
          )}
        </div>

        {/* Info Panel */}
        <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-3">
            How It Works
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-800 dark:text-blue-200">
            <div>
              <h4 className="font-medium mb-2">Machine Learning Model</h4>
              <ul className="space-y-1">
                <li>• Random Forest Regression algorithm</li>
                <li>• Technical indicators as features</li>
                <li>• Historical price data training</li>
                <li>• Real-time prediction capability</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Features Used</h4>
              <ul className="space-y-1">
                <li>• Price lags (1, 2, 3 periods)</li>
                <li>• Moving averages (5, 10 periods)</li>
                <li>• Price volatility indicators</li>
                <li>• Confidence scoring</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
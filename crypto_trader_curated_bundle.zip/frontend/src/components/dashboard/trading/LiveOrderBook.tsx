import React, { useEffect, useRef, useState } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { OrderBook, OrderBookLevel } from '@/types';
import clsx from 'clsx';

interface LiveOrderBookProps {
  symbol: string;
}

export function LiveOrderBook({ symbol }: LiveOrderBookProps) {
  const [orderBook, setOrderBook] = useState<OrderBook>({
    bids: [],
    asks: [],
  });
  const [flashedRows, setFlashedRows] = useState<Set<string>>(new Set());
  const bidsRef = useRef<HTMLDivElement>(null);
  const asksRef = useRef<HTMLDivElement>(null);

  const wsUrl = __API_BASE__.replace(/^http/, 'ws') + `/v1/orderbook/${symbol}`;
  const { status, lastMessage } = useWebSocket(wsUrl, [symbol]);

  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage.data);
        if (data.type === 'orderbook') {
          const newOrderBook: OrderBook = {
            bids: data.bids || [],
            asks: data.asks || [],
          };

          // Flash changed rows
          const newFlashedRows = new Set<string>();
          
          newOrderBook.bids.forEach((bid, index) => {
            const oldBid = orderBook.bids[index];
            if (oldBid && (oldBid.price !== bid.price || oldBid.size !== bid.size)) {
              newFlashedRows.add(`bid-${index}`);
            }
          });

          newOrderBook.asks.forEach((ask, index) => {
            const oldAsk = orderBook.asks[index];
            if (oldAsk && (oldAsk.price !== ask.price || oldAsk.size !== ask.size)) {
              newFlashedRows.add(`ask-${index}`);
            }
          });

          setOrderBook(newOrderBook);
          setFlashedRows(newFlashedRows);

          // Clear flash after animation
          setTimeout(() => {
            setFlashedRows(new Set());
          }, 500);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    }
  }, [lastMessage, orderBook]);

  // Synchronized scroll
  const handleScroll = (event: React.UIEvent<HTMLDivElement>) => {
    const target = event.target as HTMLDivElement;
    const scrollTop = target.scrollTop;
    
    if (target === bidsRef.current && asksRef.current) {
      asksRef.current.scrollTop = scrollTop;
    } else if (target === asksRef.current && bidsRef.current) {
      bidsRef.current.scrollTop = scrollTop;
    }
  };

  const formatPrice = (price: number) => price.toFixed(2);
  const formatSize = (size: number) => size.toFixed(4);

  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Order Book - {symbol}
        </h3>
        <div className={clsx(
          'px-2 py-1 rounded-full text-xs font-medium',
          status === 'open' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
          status === 'connecting' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
          'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
        )}>
          {status}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 h-96">
        {/* Bids */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Bids
          </h4>
          <div className="text-xs text-gray-500 dark:text-gray-400 grid grid-cols-3 gap-2 mb-1">
            <span>Price</span>
            <span>Size</span>
            <span>Total</span>
          </div>
          <div
            ref={bidsRef}
            onScroll={handleScroll}
            className="overflow-y-auto h-full border rounded dark:border-gray-700"
          >
            {orderBook.bids.map((bid, index) => (
              <div
                key={`bid-${index}`}
                className={clsx(
                  'grid grid-cols-3 gap-2 p-2 text-xs font-mono transition-colors',
                  'hover:bg-gray-50 dark:hover:bg-gray-800',
                  flashedRows.has(`bid-${index}`) && 'bg-green-100 dark:bg-green-900'
                )}
              >
                <span className="text-green-600 dark:text-green-400">
                  {formatPrice(bid.price)}
                </span>
                <span className="text-gray-700 dark:text-gray-300">
                  {formatSize(bid.size)}
                </span>
                <span className="text-gray-500 dark:text-gray-400">
                  {formatSize(bid.total)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Asks */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Asks
          </h4>
          <div className="text-xs text-gray-500 dark:text-gray-400 grid grid-cols-3 gap-2 mb-1">
            <span>Price</span>
            <span>Size</span>
            <span>Total</span>
          </div>
          <div
            ref={asksRef}
            onScroll={handleScroll}
            className="overflow-y-auto h-full border rounded dark:border-gray-700"
          >
            {orderBook.asks.map((ask, index) => (
              <div
                key={`ask-${index}`}
                className={clsx(
                  'grid grid-cols-3 gap-2 p-2 text-xs font-mono transition-colors',
                  'hover:bg-gray-50 dark:hover:bg-gray-800',
                  flashedRows.has(`ask-${index}`) && 'bg-red-100 dark:bg-red-900'
                )}
              >
                <span className="text-red-600 dark:text-red-400">
                  {formatPrice(ask.price)}
                </span>
                <span className="text-gray-700 dark:text-gray-300">
                  {formatSize(ask.size)}
                </span>
                <span className="text-gray-500 dark:text-gray-400">
                  {formatSize(ask.total)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  HardDrive,
  Cloud,
  Download,
  Upload,
  Trash2,
  Copy,
  Share2,
  Save,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Clock,
  Database,
  Settings,
  FileText,
  Star,
  Play,
  Pause
} from 'lucide-react';

interface ModelStorageItem {
  name: string;
  version: string;
  filename: string;
  created: string;
  size_mb: number;
  model_type: string;
  accuracy?: number;
  status: 'active' | 'saved' | 'backup' | 'training';
}

interface StorageStats {
  local_models: number;
  cloud_backups: number;
  local_size_mb: number;
  local_size_gb: number;
  cloud_enabled: boolean;
  auto_backup: boolean;
}

interface ModelStorageTabProps {
  models: ModelStorageItem[];
  storageStats: StorageStats;
  onModelsUpdate: () => void;
  onStatsUpdate: () => void;
}

const ModelStorageTab: React.FC<ModelStorageTabProps> = ({ 
  models, 
  storageStats, 
  onModelsUpdate, 
  onStatsUpdate 
}) => {
  const [selectedModels, setSelectedModels] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'created' | 'name' | 'size' | 'accuracy'>('created');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'saved' | 'backup'>('all');

  const handleModelSelect = (modelId: string) => {
    setSelectedModels(prev => 
      prev.includes(modelId) 
        ? prev.filter(id => id !== modelId)
        : [...prev, modelId]
    );
  };

  const handleBulkAction = async (action: 'backup' | 'delete' | 'export') => {
    for (const modelId of selectedModels) {
      try {
        if (action === 'backup') {
          await fetch(`/api/models/backup/${modelId}`, { method: 'POST' });
        } else if (action === 'delete') {
          await fetch(`/api/models/delete/${modelId}`, { method: 'DELETE' });
        } else if (action === 'export') {
          await fetch(`/api/models/export/${modelId}`, { method: 'POST' });
        }
      } catch (error) {
        console.error(`Failed to ${action} model ${modelId}:`, error);
      }
    }
    setSelectedModels([]);
    onModelsUpdate();
    onStatsUpdate();
  };

  const filteredModels = models
    .filter(model => filterStatus === 'all' || model.status === filterStatus)
    .sort((a, b) => {
      switch (sortBy) {
        case 'created':
          return new Date(b.created).getTime() - new Date(a.created).getTime();
        case 'name':
          return a.name.localeCompare(b.name);
        case 'size':
          return b.size_mb - a.size_mb;
        case 'accuracy':
          return (b.accuracy || 0) - (a.accuracy || 0);
        default:
          return 0;
      }
    });

  return (
    <div className="space-y-6">
      {/* Storage Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-card p-4 text-center bg-gray-800/30 rounded-lg border border-gray-700">
          <div className="text-3xl mb-2">💾</div>
          <div className="text-2xl font-bold text-blue-400">{storageStats.local_models}</div>
          <div className="text-sm text-gray-400">Local Models</div>
        </div>
        <div className="glass-card p-4 text-center bg-gray-800/30 rounded-lg border border-gray-700">
          <div className="text-3xl mb-2">☁️</div>
          <div className="text-2xl font-bold text-green-400">{storageStats.cloud_backups}</div>
          <div className="text-sm text-gray-400">Cloud Backups</div>
        </div>
        <div className="glass-card p-4 text-center bg-gray-800/30 rounded-lg border border-gray-700">
          <div className="text-3xl mb-2">📊</div>
          <div className="text-2xl font-bold text-purple-400">{storageStats.local_size_gb.toFixed(1)}GB</div>
          <div className="text-sm text-gray-400">Storage Used</div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between bg-gray-800/30 p-4 rounded-lg border border-gray-700">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <label className="text-sm text-gray-400">Sort by:</label>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-gray-700 text-white rounded px-2 py-1 text-sm"
            >
              <option value="created">Date Created</option>
              <option value="name">Name</option>
              <option value="size">Size</option>
              <option value="accuracy">Accuracy</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-gray-400">Filter:</label>
            <select 
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="bg-gray-700 text-white rounded px-2 py-1 text-sm"
            >
              <option value="all">All Models</option>
              <option value="active">Active</option>
              <option value="saved">Saved</option>
              <option value="backup">Backup</option>
            </select>
          </div>
        </div>

        <div className="flex space-x-2">
          <button className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-sm flex items-center">
            <Upload className="w-4 h-4 mr-1" />
            Import Model
          </button>
          <button className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-sm flex items-center">
            <Download className="w-4 h-4 mr-1" />
            Export Selected
          </button>
          {selectedModels.length > 0 && (
            <div className="flex space-x-1">
              <button 
                onClick={() => handleBulkAction('backup')}
                className="bg-purple-600 hover:bg-purple-700 px-3 py-2 rounded text-sm"
              >
                <Cloud className="w-4 h-4" />
              </button>
              <button 
                onClick={() => handleBulkAction('delete')}
                className="bg-red-600 hover:bg-red-700 px-3 py-2 rounded text-sm"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Models List */}
      <div className="glass-card p-6 bg-gray-800/30 rounded-lg border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold flex items-center">
            <HardDrive className="w-5 h-5 mr-2" />
            Local Models ({filteredModels.length})
          </h3>
          <button 
            onClick={onModelsUpdate}
            className="bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded text-sm flex items-center"
          >
            <RefreshCw className="w-4 h-4 mr-1" />
            Refresh
          </button>
        </div>

        <div className="space-y-3">
          {filteredModels.map((model) => (
            <ModelStorageItem
              key={model.filename}
              model={model}
              selected={selectedModels.includes(model.filename)}
              onSelect={() => handleModelSelect(model.filename)}
              onUpdate={onModelsUpdate}
            />
          ))}
          
          {filteredModels.length === 0 && (
            <div className="text-center py-8 text-gray-400">
              <Database className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No models found matching your criteria</p>
            </div>
          )}
        </div>
      </div>

      {/* Cloud Backup Management */}
      <div className="glass-card p-6 bg-gray-800/30 rounded-lg border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold flex items-center">
            <Cloud className="w-5 h-5 mr-2" />
            Cloud Backup
          </h3>
          <div className="flex space-x-2">
            <button className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded text-sm flex items-center">
              <Upload className="w-4 h-4 mr-1" />
              Backup All
            </button>
            <button className="bg-cyan-600 hover:bg-cyan-700 px-4 py-2 rounded text-sm flex items-center">
              <RefreshCw className="w-4 h-4 mr-1" />
              Sync from Cloud
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-800/30 p-4 rounded-lg">
            <h4 className="font-bold mb-3 flex items-center">
              <Settings className="w-4 h-4 mr-2" />
              Auto-Backup Settings
            </h4>
            <div className="space-y-3">
              <label className="flex items-center space-x-2">
                <input type="checkbox" checked={storageStats.auto_backup} className="text-blue-500" />
                <span className="text-sm">Auto-backup after training</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" checked className="text-blue-500" />
                <span className="text-sm">Sync every 6 hours</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="text-blue-500" />
                <span className="text-sm">Compress models before upload</span>
              </label>
            </div>
          </div>

          <div className="bg-gray-800/30 p-4 rounded-lg">
            <h4 className="font-bold mb-3 flex items-center">
              <Database className="w-4 h-4 mr-2" />
              Storage Status
            </h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Used:</span>
                <span>{storageStats.local_size_gb.toFixed(1)}GB / 10GB</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{width: `${Math.min(storageStats.local_size_gb * 10, 100)}%`}}
                ></div>
              </div>
              <div className="text-xs text-gray-400">
                {storageStats.cloud_enabled ? 'Cloud backup: Active' : 'Cloud backup: Disabled'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Individual Model Storage Item Component
const ModelStorageItem: React.FC<{
  model: ModelStorageItem;
  selected: boolean;
  onSelect: () => void;
  onUpdate: () => void;
}> = ({ model, selected, onSelect, onUpdate }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleAction = async (action: 'load' | 'backup' | 'delete' | 'download') => {
    setIsLoading(true);
    try {
      switch (action) {
        case 'load':
          await fetch(`/api/models/load/${model.filename}`, { method: 'POST' });
          break;
        case 'backup':
          await fetch(`/api/models/backup/${model.filename}`, { method: 'POST' });
          break;
        case 'delete':
          await fetch(`/api/models/delete/${model.filename}`, { method: 'DELETE' });
          onUpdate();
          break;
        case 'download':
          window.open(`/api/models/download/${model.filename}`, '_blank');
          break;
      }
    } catch (error) {
      console.error(`Failed to ${action} model:`, error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'training': return 'bg-yellow-500';
      case 'backup': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Play className="w-3 h-3" />;
      case 'training': return <RefreshCw className="w-3 h-3 animate-spin" />;
      case 'backup': return <Cloud className="w-3 h-3" />;
      default: return <Save className="w-3 h-3" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex items-center justify-between bg-gray-800/30 p-4 rounded-lg border-2 transition-all ${
        selected ? 'border-blue-500' : 'border-gray-700'
      }`}
    >
      <div className="flex items-center space-x-4">
        <input
          type="checkbox"
          checked={selected}
          onChange={onSelect}
          className="w-4 h-4 text-blue-500"
        />
        <div className={`w-3 h-3 rounded-full ${getStatusColor(model.status)} flex items-center justify-center`}>
          {getStatusIcon(model.status)}
        </div>
        <div>
          <div className="font-bold flex items-center">
            {model.name}
            <span className="text-xs bg-gray-700 px-2 py-1 rounded ml-2">v{model.version}</span>
            {model.accuracy && (
              <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded ml-2">
                {model.accuracy.toFixed(1)}% accuracy
              </span>
            )}
          </div>
          <div className="text-sm text-gray-400">
            {model.model_type} • {model.size_mb.toFixed(1)}MB • {new Date(model.created).toLocaleDateString()}
          </div>
        </div>
      </div>

      <div className="flex space-x-2">
        <button
          onClick={() => handleAction('load')}
          disabled={isLoading}
          className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 px-3 py-1 rounded text-xs flex items-center"
        >
          <Play className="w-3 h-3 mr-1" />
          Load
        </button>
        <button
          onClick={() => handleAction('backup')}
          disabled={isLoading}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-3 py-1 rounded text-xs flex items-center"
        >
          <Cloud className="w-3 h-3 mr-1" />
          Backup
        </button>
        <button
          onClick={() => handleAction('download')}
          disabled={isLoading}
          className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 px-3 py-1 rounded text-xs flex items-center"
        >
          <Download className="w-3 h-3 mr-1" />
          Download
        </button>
        <button
          onClick={() => handleAction('delete')}
          disabled={isLoading}
          className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600 px-3 py-1 rounded text-xs flex items-center"
        >
          <Trash2 className="w-3 h-3 mr-1" />
          Delete
        </button>
      </div>
    </motion.div>
  );
};

export default ModelStorageTab;
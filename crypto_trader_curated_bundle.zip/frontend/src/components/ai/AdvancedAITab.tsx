import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Brain,
  Zap,
  Target,
  TrendingUp,
  Activity,
  Settings,
  Play,
  Pause,
  RefreshCw,
  BarChart3,
  Cpu,
  Database,
  Star,
  Award,
  Layers,
  Network,
  Code,
  GitBranch
} from 'lucide-react';

const AdvancedAITab: React.FC = () => {
  const [selectedMethod, setSelectedMethod] = useState('ensemble');
  const [isTraining, setIsTraining] = useState(false);

  const aiMethods = [
    {
      id: 'ensemble',
      name: 'Ensemble Learning',
      icon: <Layers className="w-6 h-6" />,
      description: 'Combines multiple models for superior performance',
      complexity: 'Advanced',
      accuracy: '96.3%',
      features: ['Random Forest', 'Gradient Boosting', 'Neural Networks', 'Model Voting'],
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'transformer',
      name: 'Transformer Architecture',
      icon: <Network className="w-6 h-6" />,
      description: 'Attention-based models for sequence prediction',
      complexity: 'Expert',
      accuracy: '94.7%',
      features: ['Self-Attention', 'Multi-Head Attention', 'Positional Encoding', 'Layer Normalization'],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'reinforcement',
      name: 'Reinforcement Learning',
      icon: <Target className="w-6 h-6" />,
      description: 'Learn optimal trading strategies through trial and error',
      complexity: 'Expert',
      accuracy: '93.8%',
      features: ['Q-Learning', 'Policy Gradient', 'Actor-Critic', 'Deep Q-Networks'],
      color: 'from-green-500 to-teal-500'
    },
    {
      id: 'gnn',
      name: 'Graph Neural Networks',
      icon: <GitBranch className="w-6 h-6" />,
      description: 'Model market relationships and correlations',
      complexity: 'Expert',
      accuracy: '92.1%',
      features: ['Graph Convolution', 'Node Embedding', 'Edge Prediction', 'Graph Attention'],
      color: 'from-orange-500 to-red-500'
    }
  ];

  const handleStartTraining = () => {
    setIsTraining(true);
    // Simulate training completion
    setTimeout(() => {
      setIsTraining(false);
    }, 5000);
  };

  return (
    <div className="space-y-6">
      {/* Advanced AI Methods */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h2 className="text-2xl font-bold mb-4 flex items-center">
          <Brain className="w-6 h-6 mr-2 text-purple-400" />
          Advanced AI Methods
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {aiMethods.map((method) => (
            <motion.div
              key={method.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedMethod(method.id)}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedMethod === method.id 
                  ? 'border-blue-500 bg-blue-500/10' 
                  : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
              }`}
            >
              <div className="flex items-center mb-3">
                <div className={`p-2 rounded-lg bg-gradient-to-r ${method.color} mr-3`}>
                  {method.icon}
                </div>
                <div>
                  <h3 className="font-bold text-lg">{method.name}</h3>
                  <p className="text-sm text-gray-400">{method.description}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="text-center">
                  <div className="text-sm text-gray-400">Complexity</div>
                  <div className="font-bold text-orange-400">{method.complexity}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-400">Accuracy</div>
                  <div className="font-bold text-green-400">{method.accuracy}</div>
                </div>
              </div>
              
              <div className="space-y-1">
                <div className="text-sm text-gray-400 mb-2">Key Features:</div>
                <div className="grid grid-cols-2 gap-1">
                  {method.features.map((feature, idx) => (
                    <div key={idx} className="text-xs bg-gray-700/50 px-2 py-1 rounded">
                      {feature}
                    </div>
                  ))}
                </div>
              </div>
              
              {selectedMethod === method.id && (
                <div className="mt-3 bg-blue-500 text-white text-center py-2 rounded font-bold">
                  ✓ Selected for Training
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Hyperparameter Tuning */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Settings className="w-5 h-5 mr-2" />
          Hyperparameter Tuning
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1">Learning Rate</label>
              <input
                type="range"
                min="0.0001"
                max="0.1"
                step="0.0001"
                defaultValue="0.001"
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>0.0001</span>
                <span>0.001</span>
                <span>0.1</span>
              </div>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-1">Batch Size</label>
              <select className="w-full bg-gray-700 text-white rounded p-2 text-sm">
                <option>32</option>
                <option>64</option>
                <option>128</option>
                <option>256</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-1">Epochs</label>
              <input
                type="number"
                min="10"
                max="1000"
                defaultValue="100"
                className="w-full bg-gray-700 text-white rounded p-2 text-sm"
              />
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1">Dropout Rate</label>
              <input
                type="range"
                min="0"
                max="0.5"
                step="0.05"
                defaultValue="0.2"
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>0.0</span>
                <span>0.2</span>
                <span>0.5</span>
              </div>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-1">Optimizer</label>
              <select className="w-full bg-gray-700 text-white rounded p-2 text-sm">
                <option>Adam</option>
                <option>SGD</option>
                <option>RMSprop</option>
                <option>AdaGrad</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-1">Regularization</label>
              <select className="w-full bg-gray-700 text-white rounded p-2 text-sm">
                <option>L1</option>
                <option>L2</option>
                <option>Elastic Net</option>
                <option>None</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Training Control */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Activity className="w-5 h-5 mr-2" />
          Advanced Training Control
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Cross-Validation</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Early Stopping</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Learning Rate Scheduling</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
          
          <div className="space-y-4">
            <button
              onClick={handleStartTraining}
              disabled={isTraining}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-gray-600 disabled:to-gray-700 p-3 rounded font-bold flex items-center justify-center"
            >
              {isTraining ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Training Advanced Model...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start Advanced Training
                </>
              )}
            </button>
            
            <div className="p-3 bg-gray-700/50 rounded">
              <div className="text-sm text-gray-400 mb-1">Estimated Training Time</div>
              <div className="font-bold text-yellow-400">45-90 minutes</div>
            </div>
            
            <div className="p-3 bg-gray-700/50 rounded">
              <div className="text-sm text-gray-400 mb-1">GPU Memory Required</div>
              <div className="font-bold text-blue-400">4.2 GB</div>
            </div>
          </div>
        </div>
      </div>

      {/* Model Performance Metrics */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <BarChart3 className="w-5 h-5 mr-2" />
          Advanced Performance Metrics
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 bg-gray-700/50 rounded">
            <div className="text-2xl font-bold text-green-400">96.3%</div>
            <div className="text-sm text-gray-400">Accuracy</div>
          </div>
          <div className="text-center p-3 bg-gray-700/50 rounded">
            <div className="text-2xl font-bold text-blue-400">4.2</div>
            <div className="text-sm text-gray-400">Sharpe Ratio</div>
          </div>
          <div className="text-center p-3 bg-gray-700/50 rounded">
            <div className="text-2xl font-bold text-purple-400">12.3%</div>
            <div className="text-sm text-gray-400">Max Drawdown</div>
          </div>
          <div className="text-center p-3 bg-gray-700/50 rounded">
            <div className="text-2xl font-bold text-orange-400">2.1</div>
            <div className="text-sm text-gray-400">Information Ratio</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedAITab;
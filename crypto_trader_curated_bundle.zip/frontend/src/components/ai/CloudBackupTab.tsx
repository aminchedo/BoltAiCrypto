import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Cloud,
  Upload,
  Download,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Settings,
  Database,
  Shield,
  Clock,
  Wifi,
  WifiOff
} from 'lucide-react';

interface CloudBackupTabProps {
  storageStats: {
    local_models: number;
    cloud_backups: number;
    local_size_mb: number;
    local_size_gb: number;
    cloud_enabled: boolean;
    auto_backup: boolean;
  };
  onStatsUpdate: () => void;
}

const CloudBackupTab: React.FC<CloudBackupTabProps> = ({ storageStats, onStatsUpdate }) => {
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'success' | 'error'>('idle');
  const [lastSync, setLastSync] = useState<Date>(new Date());
  const [cloudStatus, setCloudStatus] = useState<'connected' | 'disconnected' | 'checking'>('connected');

  const handleSync = async () => {
    setSyncStatus('syncing');
    try {
      const response = await fetch('/api/models/sync', { method: 'POST' });
      const result = await response.json();
      
      if (result.status === 'success') {
        setSyncStatus('success');
        setLastSync(new Date());
        onStatsUpdate();
      } else {
        setSyncStatus('error');
      }
    } catch (error) {
      setSyncStatus('error');
    }
    
    setTimeout(() => setSyncStatus('idle'), 3000);
  };

  const handleBackupAll = async () => {
    try {
      const response = await fetch('/api/models/backup/all', { method: 'POST' });
      const result = await response.json();
      onStatsUpdate();
    } catch (error) {
      console.error('Failed to backup all models:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Cloud Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700 text-center">
          <div className="flex items-center justify-center mb-2">
            {cloudStatus === 'connected' ? (
              <Wifi className="w-8 h-8 text-green-400" />
            ) : (
              <WifiOff className="w-8 h-8 text-red-400" />
            )}
          </div>
          <div className="text-lg font-bold">
            {cloudStatus === 'connected' ? 'Connected' : 'Disconnected'}
          </div>
          <div className="text-sm text-gray-400">Cloud Status</div>
        </div>
        
        <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700 text-center">
          <div className="flex items-center justify-center mb-2">
            <Cloud className="w-8 h-8 text-blue-400" />
          </div>
          <div className="text-lg font-bold text-blue-400">{storageStats.cloud_backups}</div>
          <div className="text-sm text-gray-400">Models Backed Up</div>
        </div>
        
        <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-700 text-center">
          <div className="flex items-center justify-center mb-2">
            <Clock className="w-8 h-8 text-purple-400" />
          </div>
          <div className="text-lg font-bold text-purple-400">
            {Math.floor((Date.now() - lastSync.getTime()) / (1000 * 60))}m ago
          </div>
          <div className="text-sm text-gray-400">Last Sync</div>
        </div>
      </div>

      {/* Sync Controls */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <RefreshCw className="w-5 h-5 mr-2" />
          Cloud Synchronization
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Local Models:</span>
              <span className="font-bold">{storageStats.local_models}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Cloud Backups:</span>
              <span className="font-bold">{storageStats.cloud_backups}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Sync Status:</span>
              <span className={`font-bold ${
                syncStatus === 'success' ? 'text-green-400' :
                syncStatus === 'error' ? 'text-red-400' :
                syncStatus === 'syncing' ? 'text-yellow-400' : 'text-gray-400'
              }`}>
                {syncStatus === 'syncing' ? 'Syncing...' : 
                 syncStatus === 'success' ? 'Success' :
                 syncStatus === 'error' ? 'Error' : 'Ready'}
              </span>
            </div>
          </div>
          
          <div className="space-y-3">
            <button
              onClick={handleSync}
              disabled={syncStatus === 'syncing'}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 p-3 rounded font-bold flex items-center justify-center"
            >
              {syncStatus === 'syncing' ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Sync Now
                </>
              )}
            </button>
            
            <button
              onClick={handleBackupAll}
              className="w-full bg-purple-600 hover:bg-purple-700 p-3 rounded font-bold flex items-center justify-center"
            >
              <Upload className="w-4 h-4 mr-2" />
              Backup All Models
            </button>
          </div>
        </div>
      </div>

      {/* Cloud Settings */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Settings className="w-5 h-5 mr-2" />
          Cloud Settings
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h4 className="font-bold text-sm text-gray-300">Backup Configuration</h4>
            <div className="space-y-3">
              <label className="flex items-center space-x-2">
                <input type="checkbox" checked={storageStats.auto_backup} className="text-blue-500" />
                <span className="text-sm">Auto-backup after training</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" checked className="text-blue-500" />
                <span className="text-sm">Sync every 6 hours</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" className="text-blue-500" />
                <span className="text-sm">Compress before upload</span>
              </label>
              <label className="flex items-center space-x-2">
                <input type="checkbox" checked className="text-blue-500" />
                <span className="text-sm">Encrypt cloud storage</span>
              </label>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4 className="font-bold text-sm text-gray-300">Storage Provider</h4>
            <select className="w-full bg-gray-700 text-white rounded p-2 text-sm">
              <option>AWS S3</option>
              <option>Google Cloud Storage</option>
              <option>Azure Blob Storage</option>
              <option>Custom Provider</option>
            </select>
            
            <div className="space-y-2">
              <label className="text-sm text-gray-400">Bucket/Container:</label>
              <input
                type="text"
                placeholder="hts-model-storage"
                className="w-full bg-gray-700 text-white rounded p-2 text-sm"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm text-gray-400">Region:</label>
              <input
                type="text"
                placeholder="us-west-2"
                className="w-full bg-gray-700 text-white rounded p-2 text-sm"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Security & Monitoring */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2" />
          Security & Monitoring
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Encryption Status:</span>
              <span className="text-green-400 flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                Enabled
              </span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Access Control:</span>
              <span className="text-green-400 flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                Active
              </span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Audit Logging:</span>
              <span className="text-green-400 flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                Enabled
              </span>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="p-3 bg-gray-700/50 rounded">
              <div className="text-sm text-gray-400 mb-1">Storage Usage</div>
              <div className="w-full bg-gray-600 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{width: `${Math.min(storageStats.local_size_gb * 2, 100)}%`}}
                ></div>
              </div>
              <div className="text-xs text-gray-400 mt-1">
                {storageStats.local_size_gb.toFixed(1)}GB / 50GB Used
              </div>
            </div>
            
            <div className="p-3 bg-gray-700/50 rounded">
              <div className="text-sm text-gray-400 mb-1">Monthly Transfer</div>
              <div className="w-full bg-gray-600 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{width: '23%'}}></div>
              </div>
              <div className="text-xs text-gray-400 mt-1">2.3GB / 10GB Used</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Database className="w-5 h-5 mr-2" />
          Recent Activity
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
            <div className="flex items-center">
              <Upload className="w-4 h-4 mr-2 text-blue-400" />
              <span className="text-sm">SpeedTrader_v2.1 backed up</span>
            </div>
            <span className="text-xs text-gray-400">2 hours ago</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
            <div className="flex items-center">
              <RefreshCw className="w-4 h-4 mr-2 text-green-400" />
              <span className="text-sm">Sync completed successfully</span>
            </div>
            <span className="text-xs text-gray-400">6 hours ago</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
            <div className="flex items-center">
              <Download className="w-4 h-4 mr-2 text-purple-400" />
              <span className="text-sm">SwingMaster_v1.5 downloaded</span>
            </div>
            <span className="text-xs text-gray-400">1 day ago</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CloudBackupTab;
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Target,
  Zap,
  RefreshCw,
  Play,
  Pause,
  BarChart3,
  Eye,
  Brain,
  Clock,
  AlertCircle,
  CheckCircle,
  DollarSign,
  Percent
} from 'lucide-react';

interface Prediction {
  id: string;
  symbol: string;
  prediction: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  target: number;
  change: number;
  timeframe: string;
  model: string;
  timestamp: Date;
}

const LivePredictionsTab: React.FC = () => {
  const [isLive, setIsLive] = useState(false);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState('1h');

  useEffect(() => {
    // Simulate live predictions
    const mockPredictions: Prediction[] = [
      {
        id: '1',
        symbol: 'BTC/USDT',
        prediction: 'BUY',
        confidence: 87.3,
        price: 43520.50,
        target: 45200.00,
        change: 3.86,
        timeframe: '1h',
        model: 'SpeedTrader_v2.1',
        timestamp: new Date()
      },
      {
        id: '2',
        symbol: 'ETH/USDT',
        prediction: 'SELL',
        confidence: 92.1,
        price: 2640.75,
        target: 2580.00,
        change: -2.3,
        timeframe: '4h',
        model: 'SwingMaster_v1.5',
        timestamp: new Date()
      },
      {
        id: '3',
        symbol: 'BNB/USDT',
        prediction: 'HOLD',
        confidence: 75.8,
        price: 312.45,
        target: 315.00,
        change: 0.82,
        timeframe: '1d',
        model: 'DeepAnalyzer_v3.0',
        timestamp: new Date()
      }
    ];

    setPredictions(mockPredictions);
  }, []);

  const handleToggleLive = () => {
    setIsLive(!isLive);
  };

  const getPredictionColor = (prediction: string) => {
    switch (prediction) {
      case 'BUY': return 'text-green-400';
      case 'SELL': return 'text-red-400';
      case 'HOLD': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getPredictionIcon = (prediction: string) => {
    switch (prediction) {
      case 'BUY': return <TrendingUp className="w-4 h-4" />;
      case 'SELL': return <TrendingDown className="w-4 h-4" />;
      case 'HOLD': return <Activity className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Live Predictions Header */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold flex items-center">
            <Brain className="w-6 h-6 mr-2 text-purple-400" />
            Live AI Predictions
          </h2>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Timeframe:</span>
              <select 
                value={selectedTimeframe}
                onChange={(e) => setSelectedTimeframe(e.target.value)}
                className="bg-gray-700 text-white rounded px-2 py-1 text-sm"
              >
                <option value="1m">1 minute</option>
                <option value="5m">5 minutes</option>
                <option value="15m">15 minutes</option>
                <option value="1h">1 hour</option>
                <option value="4h">4 hours</option>
                <option value="1d">1 day</option>
              </select>
            </div>
            
            <button
              onClick={handleToggleLive}
              className={`px-4 py-2 rounded font-bold flex items-center ${
                isLive 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : 'bg-green-600 hover:bg-green-700'
              }`}
            >
              {isLive ? (
                <>
                  <Pause className="w-4 h-4 mr-2" />
                  Stop Live Feed
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start Live Feed
                </>
              )}
            </button>
          </div>
        </div>
        
        {/* Status Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`}></div>
            <span className="text-sm">
              {isLive ? 'Live Predictions Active' : 'Predictions Paused'}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-sm">3 Models Running</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span className="text-sm">Updated 2s ago</span>
          </div>
          <div className="flex items-center space-x-2">
            <Target className="w-4 h-4 text-purple-400" />
            <span className="text-sm">85.2% Avg Confidence</span>
          </div>
        </div>
      </div>

      {/* Predictions List */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Eye className="w-5 h-5 mr-2" />
          Current Predictions
        </h3>
        
        <div className="space-y-3">
          {predictions.map((prediction) => (
            <motion.div
              key={prediction.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg border border-gray-600 hover:border-gray-500 transition-colors"
            >
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-lg ${
                  prediction.prediction === 'BUY' ? 'bg-green-500/20' :
                  prediction.prediction === 'SELL' ? 'bg-red-500/20' : 'bg-yellow-500/20'
                }`}>
                  {getPredictionIcon(prediction.prediction)}
                </div>
                
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-lg">{prediction.symbol}</span>
                    <span className={`font-bold ${getPredictionColor(prediction.prediction)}`}>
                      {prediction.prediction}
                    </span>
                  </div>
                  <div className="text-sm text-gray-400">
                    Model: {prediction.model} • {prediction.timeframe}
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="flex items-center space-x-4">
                  <div className="text-center">
                    <div className="text-sm text-gray-400">Current</div>
                    <div className="font-bold">${prediction.price.toFixed(2)}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-gray-400">Target</div>
                    <div className="font-bold">${prediction.target.toFixed(2)}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-gray-400">Change</div>
                    <div className={`font-bold ${
                      prediction.change > 0 ? 'text-green-400' : 
                      prediction.change < 0 ? 'text-red-400' : 'text-yellow-400'
                    }`}>
                      {prediction.change > 0 ? '+' : ''}{prediction.change.toFixed(2)}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-gray-400">Confidence</div>
                    <div className="font-bold text-blue-400">{prediction.confidence.toFixed(1)}%</div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Prediction Accuracy
          </h3>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm">Today</span>
              <span className="font-bold text-green-400">89.3%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-green-500 h-2 rounded-full" style={{width: '89.3%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">This Week</span>
              <span className="font-bold text-blue-400">85.7%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{width: '85.7%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">This Month</span>
              <span className="font-bold text-purple-400">82.4%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-purple-500 h-2 rounded-full" style={{width: '82.4%'}}></div>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <DollarSign className="w-5 h-5 mr-2" />
            Profit/Loss Tracking
          </h3>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Total Profit</span>
              <span className="font-bold text-green-400">+$2,847.50</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Win Rate</span>
              <span className="font-bold text-blue-400">74.2%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Max Drawdown</span>
              <span className="font-bold text-red-400">-$423.10</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-700/50 rounded">
              <span className="text-sm">Sharpe Ratio</span>
              <span className="font-bold text-purple-400">2.34</span>
            </div>
          </div>
        </div>
      </div>

      {/* Model Performance Comparison */}
      <div className="bg-gray-800/30 p-6 rounded-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Zap className="w-5 h-5 mr-2" />
          Model Performance Comparison
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-700/30 rounded-lg">
            <h4 className="font-bold mb-2">SpeedTrader_v2.1</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Accuracy:</span>
                <span className="font-bold text-green-400">91.2%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Signals:</span>
                <span className="font-bold">247</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Profit:</span>
                <span className="font-bold text-green-400">+$1,234</span>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-gray-700/30 rounded-lg">
            <h4 className="font-bold mb-2">SwingMaster_v1.5</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Accuracy:</span>
                <span className="font-bold text-green-400">88.7%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Signals:</span>
                <span className="font-bold">156</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Profit:</span>
                <span className="font-bold text-green-400">+$987</span>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-gray-700/30 rounded-lg">
            <h4 className="font-bold mb-2">DeepAnalyzer_v3.0</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Accuracy:</span>
                <span className="font-bold text-green-400">94.1%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Signals:</span>
                <span className="font-bold">89</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Profit:</span>
                <span className="font-bold text-green-400">+$626</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LivePredictionsTab;
/**
 * AI Smart Trader - AI Components Export
 * 
 * Advanced AI components for trading analysis, model management,
 * and real-time predictions with sophisticated animations.
 * 
 * @version 1.0.0
 * @license MIT
 */

// Export all AI components
// Export all AI components with proper default exports
import AIAnalyticsModule from './AIAnalyticsModule';
import AdvancedAITab from './AdvancedAITab';
import LivePredictionsTab from './LivePredictionsTab';
import ModelStorageTab from './ModelStorageTab';
import CloudBackupTab from './CloudBackupTab';

export {
  AIAnalyticsModule,
  AdvancedAITab,
  LivePredictionsTab,
  ModelStorageTab,
  CloudBackupTab
};

// Export types
export interface AIModelStats {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  trainingTime: number;
  lastUpdated: Date;
}

export interface AISignal {
  id: string;
  symbol: string;
  direction: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  timestamp: Date;
  source: string;
  reasoning: string[];
}

export interface ModelStorageItem {
  id: string;
  name: string;
  description: string;
  version: string;
  size_mb: number;
  created: string;
  updated: string;
  accuracy?: number;
  status: 'active' | 'saved' | 'backup';
  type: 'classification' | 'regression' | 'reinforcement' | 'ensemble';
  hasCloudBackup: boolean;
}

export interface StorageStats {
  local_models: number;
  cloud_backups: number;
  local_size_mb: number;
  local_size_gb: number;
  cloud_enabled: boolean;
  auto_backup: boolean;
}
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain,
  Save,
  Upload,
  Download,
  Cloud,
  HardDrive,
  Settings,
  Play,
  Pause,
  RefreshCw,
  Trash2,
  Copy,
  CheckCircle,
  AlertCircle,
  Clock,
  Loader2,
  Database,
  Zap,
  Star,
  TrendingUp,
  Activity,
  FileText,
  Share2
} from 'lucide-react';

// Import AI module components
import ModelStorageTab from './ModelStorageTab';
import AdvancedAITab from './AdvancedAITab';
import CloudBackupTab from './CloudBackupTab';
import LivePredictionsTab from './LivePredictionsTab';

interface AIAnalyticsModuleProps { }

interface ModelStorageItem {
  name: string;
  version: string;
  filename: string;
  created: string;
  size_mb: number;
  model_type: string;
  accuracy?: number;
  status: 'active' | 'saved' | 'backup' | 'training';
}

interface StorageStats {
  local_models: number;
  cloud_backups: number;
  local_size_mb: number;
  local_size_gb: number;
  cloud_enabled: boolean;
  auto_backup: boolean;
}

const AIAnalyticsModule: React.FC<AIAnalyticsModuleProps> = () => {
  const [activeTab, setActiveTab] = useState('learning');
  const [models, setModels] = useState<ModelStorageItem[]>([]);
  const [storageStats, setStorageStats] = useState<StorageStats>({
    local_models: 12,
    cloud_backups: 8,
    local_size_mb: 2400,
    local_size_gb: 2.4,
    cloud_enabled: true,
    auto_backup: true
  });
  const [trainingProgress, setTrainingProgress] = useState({
    isTraining: false,
    progress: 0,
    epoch: 0,
    loss: 0,
    accuracy: 0
  });

  useEffect(() => {
    // Load models and stats on component mount
    loadModels();
    loadStorageStats();
  }, []);

  const loadModels = async () => {
    try {
      const response = await fetch('/api/models/list');
      const data = await response.json();
      setModels(data.models || []);
    } catch (error) {
      console.error('Failed to load models:', error);
    }
  };

  const loadStorageStats = async () => {
    try {
      const response = await fetch('/api/models/storage/stats');
      const data = await response.json();
      setStorageStats(data);
    } catch (error) {
      console.error('Failed to load storage stats:', error);
    }
  };

  return (
    <div className="ai-analytics-module h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="ai-header p-6 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              🤖 AI Analytics Laboratory
            </h1>
            <p className="text-gray-400 mt-1">Modern ML • Model Storage • Cloud Backup</p>
          </div>

          {/* Model Storage Status */}
          <div className="flex items-center space-x-3">
            <div className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm flex items-center space-x-1">
              <HardDrive className="w-4 h-4" />
              <span>{storageStats.local_models} Local Models</span>
            </div>
            <div className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-full text-sm flex items-center space-x-1">
              <Cloud className="w-4 h-4" />
              <span>{storageStats.cloud_backups} Cloud Backups</span>
            </div>
            <div className="bg-purple-500/20 text-purple-400 px-3 py-1 rounded-full text-sm flex items-center space-x-1">
              <Activity className="w-4 h-4" />
              <span>{trainingProgress.isTraining ? 'Training Active' : 'Ready'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="sub-tabs-navigation bg-gray-800/50 px-6 py-4 border-b border-gray-700">
        <div className="flex space-x-2 overflow-x-auto">
          <AISubTab
            active={activeTab === 'learning'}
            onClick={() => setActiveTab('learning')}
            icon="🧠" title="Smart Learning" desc="One-Click Training"
          />
          <AISubTab
            active={activeTab === 'models'}
            onClick={() => setActiveTab('models')}
            icon="💾" title="Model Storage" desc="Save & Load Models"
          />
          <AISubTab
            active={activeTab === 'advanced'}
            onClick={() => setActiveTab('advanced')}
            icon="🔬" title="Advanced AI" desc="Cutting-Edge Methods"
          />
          <AISubTab
            active={activeTab === 'cloud'}
            onClick={() => setActiveTab('cloud')}
            icon="☁️" title="Cloud Backup" desc="Remote Storage"
          />
          <AISubTab
            active={activeTab === 'predictions'}
            onClick={() => setActiveTab('predictions')}
            icon="🔮" title="Live Predictions" desc="Real-Time AI"
          />
        </div>
      </div>

      {/* Tab Content Area */}
      <div className="ai-content p-6 overflow-y-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'learning' && (
            <motion.div
              key="learning"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <UserFriendlyLearningTab
                trainingProgress={trainingProgress}
                setTrainingProgress={setTrainingProgress}
                onModelSaved={loadModels}
              />
            </motion.div>
          )}
          {activeTab === 'models' && (
            <motion.div
              key="models"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <ModelStorageTab
                models={models}
                storageStats={storageStats}
                onModelsUpdate={loadModels}
                onStatsUpdate={loadStorageStats}
              />
            </motion.div>
          )}
          {activeTab === 'advanced' && (
            <motion.div
              key="advanced"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <AdvancedAITab />
            </motion.div>
          )}
          {activeTab === 'cloud' && (
            <motion.div
              key="cloud"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <CloudBackupTab
                storageStats={storageStats}
                onStatsUpdate={loadStorageStats}
              />
            </motion.div>
          )}
          {activeTab === 'predictions' && (
            <motion.div
              key="predictions"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <LivePredictionsTab />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

// AI Sub-Tab Component
const AISubTab: React.FC<{ active: boolean; onClick: () => void; icon: string; title: string; desc: string }> = ({
  active, onClick, icon, title, desc
}) => (
  <motion.button
    onClick={onClick}
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
    className={`flex flex-col items-center p-3 rounded-lg min-w-[120px] transition-all duration-300 ${active
      ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 shadow-lg'
      : 'bg-gray-800/30 border border-gray-700/50 hover:bg-gray-700/40'
      }`}
  >
    <div className="text-xl mb-1">{icon}</div>
    <div className="font-semibold text-sm">{title}</div>
    <div className="text-xs text-gray-400">{desc}</div>
  </motion.button>
);

// User-Friendly Learning Tab
const UserFriendlyLearningTab: React.FC<{
  trainingProgress: any;
  setTrainingProgress: (progress: any) => void;
  onModelSaved: () => void;
}> = ({ trainingProgress, setTrainingProgress, onModelSaved }) => {
  const [selectedStrategy, setSelectedStrategy] = useState('speed');
  const [modelName, setModelName] = useState('SpeedTrader_v1');
  const [autoSave, setAutoSave] = useState(true);

  const startTraining = async () => {
    setTrainingProgress({
      isTraining: true,
      progress: 0,
      epoch: 0,
      loss: 0.1,
      accuracy: 0
    });

    // Simulate training progress
    const interval = setInterval(() => {
      setTrainingProgress((prev: any) => {
        const newProgress = prev.progress + 2;
        if (newProgress >= 100) {
          clearInterval(interval);
          onModelSaved();
          return { ...prev, progress: 100, isTraining: false };
        }
        return {
          ...prev,
          progress: newProgress,
          epoch: Math.floor(newProgress),
          loss: 0.1 - (newProgress * 0.0008),
          accuracy: newProgress * 0.9
        };
      });
    }, 200);
  };

  return (
    <div className="space-y-6">
      {/* Quick AI Training */}
      <div className="glass-card p-6 bg-gray-800/30 rounded-lg border border-gray-700">
        <h2 className="text-2xl font-bold mb-4 flex items-center">
          <Zap className="w-6 h-6 mr-2 text-yellow-400" />
          Quick AI Training
        </h2>

        {/* Strategy Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <QuickStrategyCard
            id="speed"
            title="⚡ Speed Trader"
            description="Ultra-fast 1-minute scalping"
            method="LSTM + Attention"
            difficulty="Beginner"
            accuracy="92%"
            trainTime="10 minutes"
            selected={selectedStrategy === 'speed'}
            onClick={() => setSelectedStrategy('speed')}
          />
          <QuickStrategyCard
            id="swing"
            title="🎯 Smart Swing"
            description="4-hour intelligent swing trading"
            method="Transformer"
            difficulty="Intermediate"
            accuracy="88%"
            trainTime="25 minutes"
            selected={selectedStrategy === 'swing'}
            onClick={() => setSelectedStrategy('swing')}
          />
          <QuickStrategyCard
            id="deep"
            title="🧠 Deep Analysis"
            description="Multi-timeframe analysis"
            method="Ensemble + RL"
            difficulty="Advanced"
            accuracy="95%"
            trainTime="60 minutes"
            selected={selectedStrategy === 'deep'}
            onClick={() => setSelectedStrategy('deep')}
          />
        </div>

        {/* Training Configuration */}
        <div className="bg-gray-800/30 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold">⚡ Speed Trader Model</h3>
              <p className="text-gray-400">LSTM with Multi-Head Attention (2024 Method)</p>
            </div>
            <div className="text-right">
              <div className="text-green-400 font-bold">Ready to Train</div>
              <div className="text-sm text-gray-400">Estimated: 10 minutes</div>
            </div>
          </div>

          {/* Training Options */}
          <div className="grid grid-cols-4 gap-3 mb-4">
            <div className="bg-gray-700/50 p-3 rounded text-center">
              <div className="text-sm text-gray-400 mb-1">Data Period</div>
              <select className="bg-transparent text-white font-bold w-full">
                <option>📅 30 Days</option>
                <option>📅 90 Days</option>
                <option>📅 6 Months</option>
              </select>
            </div>
            <div className="bg-gray-700/50 p-3 rounded text-center">
              <div className="text-sm text-gray-400 mb-1">Market Type</div>
              <select className="bg-transparent text-white font-bold w-full">
                <option>📈 Bull Market</option>
                <option>📉 Bear Market</option>
                <option>🔄 All Conditions</option>
              </select>
            </div>
            <div className="bg-gray-700/50 p-3 rounded text-center">
              <div className="text-sm text-gray-400 mb-1">Auto-Save</div>
              <select
                className="bg-transparent text-white font-bold w-full"
                value={autoSave ? 'local-cloud' : 'local-only'}
                onChange={(e) => setAutoSave(e.target.value === 'local-cloud')}
              >
                <option value="local-cloud">💾 Local + Cloud</option>
                <option value="local-only">💾 Local Only</option>
                <option value="cloud-only">☁️ Cloud Only</option>
              </select>
            </div>
            <div className="bg-gray-700/50 p-3 rounded text-center">
              <div className="text-sm text-gray-400 mb-1">Model Name</div>
              <input
                type="text"
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                className="bg-transparent text-white font-bold w-full text-center"
              />
            </div>
          </div>

          {/* Training Button */}
          <button
            onClick={startTraining}
            disabled={trainingProgress.isTraining}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-gray-600 disabled:to-gray-700 p-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg disabled:cursor-not-allowed"
          >
            {trainingProgress.isTraining ? (
              <div className="flex items-center justify-center">
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                Training in Progress...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <Play className="w-5 h-5 mr-2" />
                🚀 Start Training & Auto-Save Model
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Training Progress */}
      {trainingProgress.isTraining && (
        <TrainingProgressCard trainingProgress={trainingProgress} autoSave={autoSave} />
      )}
    </div>
  );
};

// Quick Strategy Card
const QuickStrategyCard: React.FC<{
  id: string;
  title: string;
  description: string;
  method: string;
  difficulty: string;
  accuracy: string;
  trainTime: string;
  selected: boolean;
  onClick: () => void;
}> = ({ id, title, description, method, difficulty, accuracy, trainTime, selected, onClick }) => (
  <motion.div
    onClick={onClick}
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${selected
      ? 'border-green-500 bg-green-500/10 shadow-lg'
      : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
      }`}
  >
    <h4 className="font-bold text-lg mb-2">{title}</h4>
    <p className="text-sm text-gray-400 mb-3">{description}</p>

    <div className="space-y-2 text-xs">
      <div className="flex justify-between">
        <span className="text-gray-500">Method:</span>
        <span className="font-bold text-purple-400">{method}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">Difficulty:</span>
        <span className="font-bold">{difficulty}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">Accuracy:</span>
        <span className="font-bold text-green-400">{accuracy}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">Train Time:</span>
        <span className="font-bold text-yellow-400">{trainTime}</span>
      </div>
    </div>

    {selected && (
      <div className="mt-3 bg-green-500 text-white text-center py-1 rounded text-sm font-bold">
        ✓ Selected for Training
      </div>
    )}
  </motion.div>
);

// Training Progress Card
const TrainingProgressCard: React.FC<{
  trainingProgress: any;
  autoSave: boolean;
}> = ({ trainingProgress, autoSave }) => (
  <div className="glass-card p-6 bg-gray-800/30 rounded-lg border border-gray-700">
    <h3 className="text-xl font-bold mb-4 flex items-center">
      <Activity className="w-5 h-5 mr-2 text-green-400" />
      Training Progress & Auto-Save
    </h3>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Progress Visualization */}
      <div className="bg-gray-800/30 p-4 rounded-lg">
        <div className="flex items-center space-x-4 mb-4">
          {/* Animated Progress Circle */}
          <div className="relative w-20 h-20">
            <svg className="w-20 h-20 transform -rotate-90">
              <circle cx="40" cy="40" r="32" stroke="rgba(255,255,255,0.1)" strokeWidth="6" fill="none" />
              <circle
                cx="40" cy="40" r="32"
                stroke="url(#progressGradient)" strokeWidth="6" fill="none"
                strokeDasharray={`${trainingProgress.progress * 2.01} 201`}
                className="transition-all duration-1000"
              />
              <defs>
                <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#10B981" />
                  <stop offset="100%" stopColor="#3B82F6" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-lg font-bold">{trainingProgress.progress}%</span>
            </div>
          </div>

          <div>
            <div className="text-lg font-bold">🧠 Neural Network Training...</div>
            <div className="text-sm text-gray-400">
              Epoch {trainingProgress.epoch}/100 • Loss: ↘ {trainingProgress.loss.toFixed(4)}
            </div>
            <div className="text-sm text-green-400">
              Accuracy: ↗ {trainingProgress.accuracy.toFixed(1)}% • ETA: {Math.max(0, 10 - Math.floor(trainingProgress.progress / 10))} min
            </div>
          </div>
        </div>

        {/* Real-time Metrics */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-green-500/20 p-2 rounded text-center">
            <div className="text-green-400 font-bold text-sm">{trainingProgress.accuracy.toFixed(1)}%</div>
            <div className="text-xs text-gray-400">Accuracy</div>
          </div>
          <div className="bg-blue-500/20 p-2 rounded text-center">
            <div className="text-blue-400 font-bold text-sm">{trainingProgress.loss.toFixed(3)}</div>
            <div className="text-xs text-gray-400">Loss</div>
          </div>
          <div className="bg-purple-500/20 p-2 rounded text-center">
            <div className="text-purple-400 font-bold text-sm">3.2</div>
            <div className="text-xs text-gray-400">Sharpe</div>
          </div>
        </div>
      </div>

      {/* Auto-Save Status */}
      <div className="bg-gray-800/30 p-4 rounded-lg">
        <h4 className="font-bold mb-3 flex items-center">
          <Save className="w-4 h-4 mr-2 text-green-400" />
          Auto-Save Status
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm">Local Checkpoint:</span>
            <span className="text-green-400 text-sm flex items-center">
              <CheckCircle className="w-3 h-3 mr-1" />
              Saved (Epoch {Math.floor(trainingProgress.epoch * 0.9)})
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Cloud Backup:</span>
            <span className="text-blue-400 text-sm flex items-center">
              {autoSave ? (
                <>
                  <Upload className="w-3 h-3 mr-1" />
                  Uploading...
                </>
              ) : (
                <>
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Disabled
                </>
              )}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Model Version:</span>
            <span className="text-purple-400 text-sm">SpeedTrader_v1.3</span>
          </div>
          <div className="bg-gray-700/50 p-2 rounded">
            <div className="text-xs text-gray-400 mb-1">Storage Usage:</div>
            <div className="w-full bg-gray-600 rounded-full h-1">
              <div
                className="bg-blue-500 h-1 rounded-full transition-all duration-1000"
                style={{ width: `${Math.min(34 + trainingProgress.progress * 0.1, 50)}%` }}
              ></div>
            </div>
            <div className="text-xs text-gray-400 mt-1">
              {(1.2 + trainingProgress.progress * 0.01).toFixed(1)}GB / 5GB Used
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default AIAnalyticsModule;
'use client';

import { TradingSignal } from '@/types';
import { formatCryptoPrice, formatRelativeTime } from '@/lib/utils';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ArrowDown, ArrowUp, BarChart2, Clock, Target } from 'lucide-react';

interface SignalCardProps {
  signal: TradingSignal;
  onTrade?: (signal: TradingSignal) => void;
  onViewDetails?: (signal: TradingSignal) => void;
}

export function SignalCard({ signal, onTrade, onViewDetails }: SignalCardProps) {
  // Determine signal color based on type
  const getSignalColor = () => {
    switch (signal.type) {
      case 'BUY':
        return 'success';
      case 'SELL':
        return 'destructive';
      default:
        return 'warning';
    }
  };
  
  // Format confidence as percentage
  const confidencePercentage = `${signal.confidence.toFixed(0)}%`;
  
  // Calculate potential profit/loss
  const calculatePotential = () => {
    if (!signal.stopLoss || !signal.takeProfit) return null;
    
    const entryPrice = signal.entryPrice;
    const stopLoss = signal.stopLoss;
    const takeProfit = signal.takeProfit;
    
    if (signal.type === 'BUY') {
      const potentialLoss = ((stopLoss - entryPrice) / entryPrice) * 100;
      const potentialGain = ((takeProfit - entryPrice) / entryPrice) * 100;
      return { loss: potentialLoss, gain: potentialGain };
    } else {
      const potentialLoss = ((entryPrice - stopLoss) / entryPrice) * 100;
      const potentialGain = ((entryPrice - takeProfit) / entryPrice) * 100;
      return { loss: potentialLoss, gain: potentialGain };
    }
  };
  
  const potential = calculatePotential();
  
  return (
    <Card variant="bordered" className={`border-l-4 border-l-${getSignalColor()}-500`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Badge variant={getSignalColor() as any}>
              {signal.type}
            </Badge>
            <h3 className="text-base font-medium text-white">{signal.symbol}</h3>
            <Badge variant="secondary">{signal.timeframe}</Badge>
          </div>
          <div className="flex items-center space-x-1">
            <Badge variant="outline" className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>{formatRelativeTime(signal.createdAt)}</span>
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-3 gap-2 mb-3">
          <div className="bg-dark-700 rounded p-2">
            <div className="text-xs text-gray-400 mb-1">Entry Price</div>
            <div className="text-sm font-mono font-medium text-white">
              {formatCryptoPrice(signal.entryPrice)}
            </div>
          </div>
          
          {signal.stopLoss && (
            <div className="bg-dark-700 rounded p-2">
              <div className="text-xs text-gray-400 mb-1">Stop Loss</div>
              <div className="text-sm font-mono font-medium text-danger-400">
                {formatCryptoPrice(signal.stopLoss)}
              </div>
            </div>
          )}
          
          {signal.takeProfit && (
            <div className="bg-dark-700 rounded p-2">
              <div className="text-xs text-gray-400 mb-1">Take Profit</div>
              <div className="text-sm font-mono font-medium text-success-400">
                {formatCryptoPrice(signal.takeProfit)}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className="text-xs text-gray-400">Confidence:</div>
            <div className="w-32 h-2 bg-dark-700 rounded-full overflow-hidden">
              <div
                className={`h-full bg-${getSignalColor()}-500`}
                style={{ width: `${signal.confidence}%` }}
              />
            </div>
            <div className="text-xs font-medium text-white">{confidencePercentage}</div>
          </div>
          
          {potential && (
            <div className="flex items-center space-x-2 text-xs">
              <div className="flex items-center text-danger-400">
                <ArrowDown className="h-3 w-3 mr-1" />
                {Math.abs(potential.loss).toFixed(2)}%
              </div>
              <div className="text-gray-400">/</div>
              <div className="flex items-center text-success-400">
                <ArrowUp className="h-3 w-3 mr-1" />
                {potential.gain.toFixed(2)}%
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant={signal.type === 'BUY' ? 'success' : 'destructive'}
            fullWidth
            onClick={() => onTrade && onTrade(signal)}
          >
            Trade Now
          </Button>
          
          <Button
            size="sm"
            variant="outline"
            onClick={() => onViewDetails && onViewDetails(signal)}
          >
            <BarChart2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
'use client';

import { Portfolio, Position } from '@/types';
import { formatCurrency, formatPercentage } from '@/lib/utils';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/Tabs';
import { PriceDisplay } from '@/components/trading/PriceDisplay';
import { Spinner } from '@/components/ui/Spinner';
import { ArrowDown, ArrowUp, Wallet } from 'lucide-react';

interface PortfolioSummaryProps {
  portfolio: Portfolio | null;
  isLoading?: boolean;
  onPositionSelect?: (position: Position) => void;
}

export function PortfolioSummary({
  portfolio,
  isLoading = false,
  onPositionSelect,
}: PortfolioSummaryProps) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <Spinner size="md" />
        </CardContent>
      </Card>
    );
  }
  
  if (!portfolio) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center p-8 text-center">
          <Wallet className="h-12 w-12 text-gray-500 mb-2" />
          <h3 className="text-lg font-medium text-white mb-1">No Portfolio Data</h3>
          <p className="text-sm text-gray-400">
            Connect your exchange API keys to view your portfolio.
          </p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-white">Portfolio Summary</h3>
          <div className="text-sm text-gray-400">
            {new Date().toLocaleDateString()}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-dark-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Total Value</div>
            <div className="text-xl font-semibold text-white">
              {formatCurrency(portfolio.totalValue)}
            </div>
            <div className="flex items-center text-xs mt-1">
              {portfolio.performance.daily >= 0 ? (
                <ArrowUp className="h-3 w-3 text-success-400 mr-1" />
              ) : (
                <ArrowDown className="h-3 w-3 text-danger-400 mr-1" />
              )}
              <span
                className={
                  portfolio.performance.daily >= 0
                    ? 'text-success-400'
                    : 'text-danger-400'
                }
              >
                {portfolio.performance.daily > 0 ? '+' : ''}
                {formatCurrency(portfolio.performance.daily)} (
                {((portfolio.performance.daily / portfolio.totalValue) * 100).toFixed(2)}
                %)
              </span>
            </div>
          </div>
          
          <div className="bg-dark-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Available Balance</div>
            <div className="text-xl font-semibold text-white">
              {formatCurrency(portfolio.availableBalance)}
            </div>
            <div className="text-xs text-gray-400 mt-1">
              {formatCurrency(portfolio.lockedBalance)} locked
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-dark-700 rounded p-2">
            <div className="text-xs text-gray-400 mb-1">Total P&L</div>
            <div
              className={`text-sm font-medium ${
                portfolio.pnl.total >= 0 ? 'text-success-400' : 'text-danger-400'
              }`}
            >
              {portfolio.pnl.total > 0 ? '+' : ''}
              {formatCurrency(portfolio.pnl.total)}
            </div>
          </div>
          
          <div className="bg-dark-700 rounded p-2">
            <div className="text-xs text-gray-400 mb-1">Realized</div>
            <div
              className={`text-sm font-medium ${
                portfolio.pnl.realized >= 0 ? 'text-success-400' : 'text-danger-400'
              }`}
            >
              {portfolio.pnl.realized > 0 ? '+' : ''}
              {formatCurrency(portfolio.pnl.realized)}
            </div>
          </div>
          
          <div className="bg-dark-700 rounded p-2">
            <div className="text-xs text-gray-400 mb-1">Unrealized</div>
            <div
              className={`text-sm font-medium ${
                portfolio.pnl.unrealized >= 0 ? 'text-success-400' : 'text-danger-400'
              }`}
            >
              {portfolio.pnl.unrealized > 0 ? '+' : ''}
              {formatCurrency(portfolio.pnl.unrealized)}
            </div>
          </div>
        </div>
        
        <div className="mb-2">
          <h4 className="text-sm font-medium text-white mb-2">Positions</h4>
          
          {portfolio.positions.length > 0 ? (
            <div className="max-h-[200px] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="bg-dark-700">
                  <tr className="text-xs text-gray-400">
                    <th className="text-left p-2">Symbol</th>
                    <th className="text-right p-2">Size</th>
                    <th className="text-right p-2">Entry</th>
                    <th className="text-right p-2">Current</th>
                    <th className="text-right p-2">P&L</th>
                  </tr>
                </thead>
                <tbody>
                  {portfolio.positions.map((position) => (
                    <tr
                      key={position.id}
                      className="border-b border-dark-700 hover:bg-dark-700 cursor-pointer"
                      onClick={() => onPositionSelect && onPositionSelect(position)}
                    >
                      <td className="p-2">
                        <div className="flex items-center">
                          <span
                            className={`w-2 h-2 rounded-full mr-2 ${
                              position.type === 'LONG'
                                ? 'bg-success-400'
                                : 'bg-danger-400'
                            }`}
                          />
                          <span className="font-medium text-white">
                            {position.symbol}
                          </span>
                        </div>
                      </td>
                      <td className="p-2 text-right text-gray-400">
                        {position.quantity.toFixed(6)}
                      </td>
                      <td className="p-2 text-right text-gray-400">
                        {position.entryPrice.toFixed(2)}
                      </td>
                      <td className="p-2 text-right">
                        <PriceDisplay
                          price={position.currentPrice}
                          previousPrice={position.entryPrice}
                          size="sm"
                          showChangeIndicator={false}
                        />
                      </td>
                      <td className="p-2 text-right">
                        <span
                          className={
                            position.pnl >= 0 ? 'text-success-400' : 'text-danger-400'
                          }
                        >
                          {position.pnl > 0 ? '+' : ''}
                          {position.pnlPercentage.toFixed(2)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-dark-700 rounded-lg p-4 text-center">
              <p className="text-sm text-gray-400">No open positions</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
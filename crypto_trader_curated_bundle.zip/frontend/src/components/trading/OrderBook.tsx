'use client';

import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils/cn';
import { formatCryptoPrice } from '@/lib/utils';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/Tabs';
import { Spinner } from '@/components/ui/Spinner';

interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
  percentage: number;
}

interface OrderBookProps {
  symbol: string;
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  spread?: number;
  isLoading?: boolean;
  depth?: number;
  onPriceClick?: (price: number) => void;
}

export function OrderBook({
  symbol,
  bids = [],
  asks = [],
  spread = 0,
  isLoading = false,
  depth = 10,
  onPriceClick,
}: OrderBookProps) {
  const [view, setView] = useState<'both' | 'bids' | 'asks'>('both');
  const [displayBids, setDisplayBids] = useState<OrderBookEntry[]>([]);
  const [displayAsks, setDisplayAsks] = useState<OrderBookEntry[]>([]);
  
  // Process order book data
  useEffect(() => {
    // Limit to specified depth
    const limitedBids = bids.slice(0, depth);
    const limitedAsks = asks.slice(0, depth).reverse(); // Reverse asks for display
    
    setDisplayBids(limitedBids);
    setDisplayAsks(limitedAsks);
  }, [bids, asks, depth]);
  
  // Handle price click
  const handlePriceClick = (price: number) => {
    if (onPriceClick) {
      onPriceClick(price);
    }
  };
  
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 overflow-hidden">
      <div className="p-3 border-b border-dark-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-white">Order Book</h3>
          <span className="text-xs text-gray-400">{symbol}</span>
        </div>
        
        <div className="flex items-center justify-between mt-1">
          <Tabs defaultValue="both" onValueChange={(v) => setView(v as any)}>
            <TabsList className="h-7 p-0.5">
              <TabsTrigger value="both" className="text-xs h-6 px-2">
                Both
              </TabsTrigger>
              <TabsTrigger value="bids" className="text-xs h-6 px-2">
                Bids
              </TabsTrigger>
              <TabsTrigger value="asks" className="text-xs h-6 px-2">
                Asks
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          <div className="text-xs">
            <span className="text-gray-400">Spread: </span>
            <span className="text-white">{spread.toFixed(2)}%</span>
          </div>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center p-8">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="relative">
          <div className="grid grid-cols-3 text-xs text-gray-400 px-3 py-2 border-b border-dark-700">
            <div>Price</div>
            <div className="text-right">Amount</div>
            <div className="text-right">Total</div>
          </div>
          
          {(view === 'both' || view === 'asks') && (
            <div className="max-h-[200px] overflow-y-auto">
              {displayAsks.map((ask, index) => (
                <div
                  key={`ask-${index}`}
                  className="grid grid-cols-3 text-xs px-3 py-1.5 hover:bg-dark-700 cursor-pointer relative"
                  onClick={() => handlePriceClick(ask.price)}
                >
                  <div
                    className="absolute top-0 bottom-0 right-0 bg-danger-500 bg-opacity-10"
                    style={{ width: `${ask.percentage}%` }}
                  />
                  <div className="relative z-10 text-danger-400">
                    {formatCryptoPrice(ask.price)}
                  </div>
                  <div className="relative z-10 text-right">{ask.amount.toFixed(6)}</div>
                  <div className="relative z-10 text-right">{ask.total.toFixed(6)}</div>
                </div>
              ))}
            </div>
          )}
          
          {view === 'both' && (
            <div className="grid grid-cols-3 text-xs px-3 py-2 bg-dark-700 border-y border-dark-600">
              <div className="font-medium text-white">
                {formatCryptoPrice((bids[0]?.price || 0) + (asks[0]?.price || 0) / 2)}
              </div>
              <div className="text-right text-gray-400">Mid Price</div>
              <div></div>
            </div>
          )}
          
          {(view === 'both' || view === 'bids') && (
            <div className="max-h-[200px] overflow-y-auto">
              {displayBids.map((bid, index) => (
                <div
                  key={`bid-${index}`}
                  className="grid grid-cols-3 text-xs px-3 py-1.5 hover:bg-dark-700 cursor-pointer relative"
                  onClick={() => handlePriceClick(bid.price)}
                >
                  <div
                    className="absolute top-0 bottom-0 right-0 bg-success-500 bg-opacity-10"
                    style={{ width: `${bid.percentage}%` }}
                  />
                  <div className="relative z-10 text-success-400">
                    {formatCryptoPrice(bid.price)}
                  </div>
                  <div className="relative z-10 text-right">{bid.amount.toFixed(6)}</div>
                  <div className="relative z-10 text-right">{bid.total.toFixed(6)}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
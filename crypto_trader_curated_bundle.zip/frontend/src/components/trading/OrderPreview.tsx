import React from 'react';

interface OrderPreviewProps {
  symbol: string;
  orderType: 'market' | 'limit';
  side: 'buy' | 'sell';
  amount: number;
  price?: number;
  total?: number;
  estimatedFee?: number;
  estimatedPrice?: number | null; // For market orders
  onConfirm: () => void;
  onCancel: () => void;
  isSubmitting?: boolean;
}

export const OrderPreview: React.FC<OrderPreviewProps> = ({
  symbol,
  orderType,
  side,
  amount,
  price,
  total,
  estimatedFee = 0,
  estimatedPrice,
  onConfirm,
  onCancel,
  isSubmitting = false,
}) => {
  // Extract base and quote currency from symbol (e.g., "BTC/USDT" -> "BTC", "USDT")
  const [baseCurrency, quoteCurrency] = symbol.split('/');
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4">Order Preview</h2>
      
      <div className="space-y-3 mb-6">
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">Order Type:</span>
          <span className="font-medium">
            {side === 'buy' ? 'Buy' : 'Sell'} {orderType === 'market' ? 'Market' : 'Limit'}
          </span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">Symbol:</span>
          <span className="font-medium">{symbol}</span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">Amount:</span>
          <span className="font-medium">
            {amount.toFixed(8)} {baseCurrency}
          </span>
        </div>
        
        {orderType === 'limit' ? (
          <>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Price:</span>
              <span className="font-medium">
                {price?.toFixed(2)} {quoteCurrency}
              </span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Total:</span>
              <span className="font-medium">
                {total?.toFixed(2)} {quoteCurrency}
              </span>
            </div>
          </>
        ) : (
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">Estimated Price:</span>
            <span className="font-medium">
              {estimatedPrice?.toFixed(2)} {quoteCurrency}
            </span>
          </div>
        )}
        
        <div className="flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">Estimated Fee:</span>
          <span className="font-medium">
            {estimatedFee.toFixed(2)} {quoteCurrency}
          </span>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-3 flex justify-between">
          <span className="text-gray-600 dark:text-gray-400">Total {side === 'buy' ? 'Cost' : 'Received'}:</span>
          <span className="font-medium">
            {orderType === 'limit'
              ? `${(total! + (side === 'buy' ? estimatedFee : -estimatedFee)).toFixed(2)} ${quoteCurrency}`
              : `≈ ${((estimatedPrice || 0) * amount + (side === 'buy' ? estimatedFee : -estimatedFee)).toFixed(2)} ${quoteCurrency}`}
          </span>
        </div>
      </div>
      
      <div className="flex space-x-3">
        <button
          onClick={onCancel}
          className="flex-1 py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300"
          disabled={isSubmitting}
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          className={`flex-1 py-2 px-4 rounded-md text-white font-medium ${
            side === 'buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'
          }`}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </span>
          ) : (
            `Confirm ${side === 'buy' ? 'Buy' : 'Sell'}`
          )}
        </button>
      </div>
    </div>
  );
};

export default OrderPreview;
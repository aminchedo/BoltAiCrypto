'use client';

import { useState } from 'react';
import { Search } from 'lucide-react';
import { MarketData } from '@/types';
import { formatCryptoPrice, formatPercentage } from '@/lib/utils';
import { Input } from '@/components/ui/Input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/Tabs';
import { PriceDisplay } from '@/components/trading/PriceDisplay';
import { Spinner } from '@/components/ui/Spinner';

interface MarketOverviewProps {
  markets: MarketData[];
  isLoading?: boolean;
  onSelectMarket?: (symbol: string) => void;
}

export function MarketOverview({
  markets = [],
  isLoading = false,
  onSelectMarket,
}: MarketOverviewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  
  // Filter markets based on search query and active tab
  const filteredMarkets = markets.filter((market) => {
    const matchesSearch = market.symbol.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === 'all') return matchesSearch;
    if (activeTab === 'gainers') return matchesSearch && market.change24h > 0;
    if (activeTab === 'losers') return matchesSearch && market.change24h < 0;
    
    return matchesSearch;
  });
  
  // Sort markets based on active tab
  const sortedMarkets = [...filteredMarkets].sort((a, b) => {
    if (activeTab === 'gainers') return b.change24h - a.change24h;
    if (activeTab === 'losers') return a.change24h - b.change24h;
    if (activeTab === 'volume') return b.volume24h - a.volume24h;
    
    // Default sort by market cap
    return b.marketCap - a.marketCap;
  });
  
  // Handle market selection
  const handleMarketClick = (symbol: string) => {
    if (onSelectMarket) {
      onSelectMarket(symbol);
    }
  };
  
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 overflow-hidden">
      <div className="p-3 border-b border-dark-700">
        <h3 className="text-sm font-medium text-white mb-2">Market Overview</h3>
        
        <Input
          placeholder="Search markets..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          leftIcon={<Search className="h-4 w-4" />}
          className="mb-2"
        />
        
        <Tabs defaultValue="all" onValueChange={setActiveTab}>
          <TabsList className="w-full">
            <TabsTrigger value="all" className="flex-1 text-xs">
              All
            </TabsTrigger>
            <TabsTrigger value="gainers" className="flex-1 text-xs">
              Gainers
            </TabsTrigger>
            <TabsTrigger value="losers" className="flex-1 text-xs">
              Losers
            </TabsTrigger>
            <TabsTrigger value="volume" className="flex-1 text-xs">
              Volume
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center p-8">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="max-h-[400px] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-dark-700">
              <tr className="text-xs text-gray-400">
                <th className="text-left p-2">Symbol</th>
                <th className="text-right p-2">Price</th>
                <th className="text-right p-2">24h Change</th>
                <th className="text-right p-2">24h Volume</th>
              </tr>
            </thead>
            <tbody>
              {sortedMarkets.map((market) => (
                <tr
                  key={market.symbol}
                  className="border-b border-dark-700 hover:bg-dark-700 cursor-pointer"
                  onClick={() => handleMarketClick(market.symbol)}
                >
                  <td className="p-2">
                    <div className="font-medium text-white">{market.symbol}</div>
                  </td>
                  <td className="p-2 text-right">
                    <PriceDisplay price={market.price} size="sm" />
                  </td>
                  <td className="p-2 text-right">
                    <span
                      className={
                        market.change24h > 0
                          ? 'text-success-400'
                          : market.change24h < 0
                          ? 'text-danger-400'
                          : 'text-gray-400'
                      }
                    >
                      {market.change24h > 0 ? '+' : ''}
                      {market.change24h.toFixed(2)}%
                    </span>
                  </td>
                  <td className="p-2 text-right text-gray-400">
                    ${(market.volume24h / 1000000).toFixed(2)}M
                  </td>
                </tr>
              ))}
              
              {sortedMarkets.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-4 text-center text-gray-400">
                    No markets found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'react-hot-toast';
import {
  ChartBarSquareIcon,
  BanknotesIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  CogIcon,
  BellIcon,
  UserIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  PlayIcon,
  PauseIcon
} from '@heroicons/react/24/outline';

// Import services and hooks
import { useTrading } from '@/contexts/TradingContext';
import { useSettings } from '@/contexts/SettingsContext';
import { useTheme } from '@/contexts/ThemeContext';
import { useRealTimeData } from '@/hooks/useRealTimeData';
import { useWebSocket } from '@/hooks/useWebSocket';

// Import types
import { Ticker, Position, Order, TradingSignal } from '@/types';

// Mock data for demonstration
const mockTickers: Ticker[] = [
  { symbol: 'BTC', price: 43250.50, change24h: 2.45, volume24h: 28450000000, marketCap: 850000000000, lastUpdated: new Date() },
  { symbol: 'ETH', price: 2650.75, change24h: -1.23, volume24h: 15800000000, marketCap: 320000000000, lastUpdated: new Date() },
  { symbol: 'ADA', price: 0.485, change24h: 5.67, volume24h: 1200000000, marketCap: 17000000000, lastUpdated: new Date() },
  { symbol: 'DOT', price: 6.85, change24h: -0.89, volume24h: 850000000, marketCap: 8500000000, lastUpdated: new Date() },
  { symbol: 'LINK', price: 14.25, change24h: 3.12, volume24h: 950000000, marketCap: 8500000000, lastUpdated: new Date() },
];

const mockPositions: Position[] = [
  { symbol: 'BTC', qty: 0.5, entry: 42000, pnl: 625.25, side: 'LONG', timestamp: new Date() },
  { symbol: 'ETH', qty: 2.0, entry: 2700, pnl: -98.50, side: 'SHORT', timestamp: new Date() },
];

const mockOrders: Order[] = [
  { id: '1', symbol: 'BTC', side: 'BUY', type: 'LIMIT', status: 'OPEN', quantity: 0.1, price: 43000, timestamp: new Date() },
  { id: '2', symbol: 'ETH', side: 'SELL', type: 'MARKET', status: 'FILLED', quantity: 1.5, timestamp: new Date() },
];

const mockSignals: TradingSignal[] = [
  { id: '1', symbol: 'BTC', signal: 'BUY', confidence: 0.85, reasoning: 'Strong bullish momentum with RSI oversold', timestamp: new Date(), source: 'AI', priority: 'HIGH' },
  { id: '2', symbol: 'ETH', signal: 'SELL', confidence: 0.72, reasoning: 'Resistance level reached, potential reversal', timestamp: new Date(), source: 'TECHNICAL', priority: 'MEDIUM' },
];

const CryptoTradingDashboard: React.FC = () => {
  // State management
  const [selectedAsset, setSelectedAsset] = useState('BTC');
  const [isRealTrading, setIsRealTrading] = useState(false);
  const [currentPrice, setCurrentPrice] = useState(43250.50);
  const [priceChange, setPriceChange] = useState(2.45);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  // Context hooks
  const { state: tradingState, dispatch: tradingDispatch } = useTrading();
  const { settings } = useSettings();
  const { state: themeState } = useTheme();

  // Custom hooks
  const { data: realTimeData, isLoading: dataLoading } = useRealTimeData(selectedAsset);
  const { isConnected, lastMessage } = useWebSocket('wss://stream.binance.com:9443/ws/btcusdt@ticker');

  // Update current price from real-time data
  useEffect(() => {
    if (realTimeData?.price) {
      setCurrentPrice(realTimeData.price);
      setPriceChange(realTimeData.change24h);
    }
  }, [realTimeData]);

  // WebSocket message handler
  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage);
        if (data.s === selectedAsset + 'USDT') {
          setCurrentPrice(parseFloat(data.c));
          setPriceChange(parseFloat(data.P));
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    }
  }, [lastMessage, selectedAsset]);

  // Trading functions
  const executeTrade = useCallback(async (side: 'BUY' | 'SELL', quantity: number) => {
    setIsLoading(true);
    try {
      // Simulate trade execution
      await new Promise(resolve => setTimeout(resolve, 1000));

      const order: Order = {
        id: Date.now().toString(),
        symbol: selectedAsset,
        side,
        type: 'MARKET',
        status: 'FILLED',
        quantity,
        timestamp: new Date(),
        averagePrice: currentPrice,
      };

      tradingDispatch({ type: 'ADD_ORDER', payload: order });

      toast.success(`${side} order placed for ${quantity} ${selectedAsset}`);
    } catch (error) {
      toast.error('Failed to execute trade');
      console.error('Trade execution error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedAsset, currentPrice, tradingDispatch]);

  const toggleRealTrading = useCallback(() => {
    setIsRealTrading(!isRealTrading);
    toast.success(`${!isRealTrading ? 'Real' : 'Demo'} trading mode activated`);
  }, [isRealTrading]);

  // Computed values
  const totalPnL = useMemo(() => {
    return mockPositions.reduce((sum, pos) => sum + pos.pnl, 0);
  }, []);

  const portfolioValue = useMemo(() => {
    return mockPositions.reduce((sum, pos) => {
      const currentPrice = mockTickers.find(t => t.symbol === pos.symbol)?.price || 0;
      return sum + (pos.qty * currentPrice);
    }, 0);
  }, []);

  // Navigation items
  const navigationItems = [
    { name: 'Overview', id: 'overview', icon: ChartBarSquareIcon },
    { name: 'Trading', id: 'trading', icon: BanknotesIcon },
    { name: 'Portfolio', id: 'portfolio', icon: ArrowTrendingUpIcon },
    { name: 'Signals', id: 'signals', icon: ArrowTrendingDownIcon },
    { name: 'Settings', id: 'settings', icon: CogIcon },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-900 text-white">
      {/* Header */}
      <header className="glass-effect border-b border-white/10 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold gradient-text">AI Smart Trader</h1>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-sm text-gray-400">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button className="trading-button px-4 py-2 text-white">
              <BellIcon className="w-5 h-5" />
            </button>
            <button className="trading-button px-4 py-2 text-white">
              <UserIcon className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 glass-effect border-r border-white/10 p-4">
          <nav className="space-y-2">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`sidebar-item w-full p-3 text-left flex items-center space-x-3 transition-all duration-300 ${activeTab === item.id ? 'active' : 'hover:bg-white/5'
                  }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.name}</span>
              </button>
            ))}
          </nav>

          {/* Trading Mode Toggle */}
          <div className="mt-8 p-4 glass-effect rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Trading Mode</span>
              <button
                onClick={toggleRealTrading}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${isRealTrading ? 'bg-green-500' : 'bg-gray-600'
                  }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isRealTrading ? 'translate-x-6' : 'translate-x-1'
                    }`}
                />
              </button>
            </div>
            <span className="text-xs text-gray-400">
              {isRealTrading ? 'Real Trading' : 'Demo Mode'}
            </span>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Market Overview */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="dashboard-card">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-400">Portfolio Value</p>
                        <p className="text-2xl font-bold">${portfolioValue.toLocaleString()}</p>
                      </div>
                      <BanknotesIcon className="w-8 h-8 text-primary-500" />
                    </div>
                    <div className="mt-2">
                      <span className={`text-sm ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="dashboard-card">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-400">Total P&L</p>
                        <p className={`text-2xl font-bold ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                          {totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)}
                        </p>
                      </div>
                      <ArrowTrendingUpIcon className="w-8 h-8 text-primary-500" />
                    </div>
                  </div>

                  <div className="dashboard-card">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-400">Active Positions</p>
                        <p className="text-2xl font-bold">{mockPositions.length}</p>
                      </div>
                      <ChartBarSquareIcon className="w-8 h-8 text-primary-500" />
                    </div>
                  </div>

                  <div className="dashboard-card">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-400">Open Orders</p>
                        <p className="text-2xl font-bold">{mockOrders.filter(o => o.status === 'OPEN').length}</p>
                      </div>
                      <ArrowTrendingDownIcon className="w-8 h-8 text-primary-500" />
                    </div>
                  </div>
                </div>

                {/* Current Asset */}
                <div className="dashboard-card">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">{selectedAsset}/USD</h2>
                    <div className="flex items-center space-x-2">
                      <select
                        value={selectedAsset}
                        onChange={(e) => setSelectedAsset(e.target.value)}
                        className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-1 text-white"
                      >
                        {mockTickers.map(ticker => (
                          <option key={ticker.symbol} value={ticker.symbol}>
                            {ticker.symbol}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <p className="text-sm text-gray-400">Current Price</p>
                      <p className="text-3xl font-bold">${currentPrice.toLocaleString()}</p>
                      <p className={`text-sm ${priceChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)}%
                      </p>
                    </div>

                    <div className="flex space-x-2">
                      <button
                        onClick={() => executeTrade('BUY', 0.1)}
                        disabled={isLoading}
                        className="trading-button flex-1 py-3 text-white disabled:opacity-50"
                      >
                        {isLoading ? 'Processing...' : 'Buy'}
                      </button>
                      <button
                        onClick={() => executeTrade('SELL', 0.1)}
                        disabled={isLoading}
                        className="trading-button flex-1 py-3 text-white disabled:opacity-50"
                      >
                        {isLoading ? 'Processing...' : 'Sell'}
                      </button>
                    </div>

                    <div>
                      <p className="text-sm text-gray-400">24h Volume</p>
                      <p className="text-lg font-semibold">
                        ${mockTickers.find(t => t.symbol === selectedAsset)?.volume24h.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Recent Signals */}
                <div className="dashboard-card">
                  <h3 className="text-lg font-bold mb-4">Recent Signals</h3>
                  <div className="space-y-3">
                    {mockSignals.map((signal) => (
                      <div key={signal.id} className="flex items-center justify-between p-3 glass-effect rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${signal.signal === 'BUY' ? 'bg-green-500' :
                            signal.signal === 'SELL' ? 'bg-red-500' : 'bg-yellow-500'
                            }`} />
                          <div>
                            <p className="font-medium">{signal.symbol}</p>
                            <p className="text-sm text-gray-400">{signal.reasoning}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${signal.signal === 'BUY' ? 'text-green-500' :
                            signal.signal === 'SELL' ? 'text-red-500' : 'text-yellow-500'
                            }`}>
                            {signal.signal}
                          </p>
                          <p className="text-sm text-gray-400">{signal.confidence * 100}%</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'trading' && (
              <motion.div
                key="trading"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="dashboard-card">
                  <h2 className="text-xl font-bold mb-4">Trading Console</h2>
                  <p className="text-gray-400">Advanced trading features coming soon...</p>
                </div>
              </motion.div>
            )}

            {activeTab === 'portfolio' && (
              <motion.div
                key="portfolio"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="dashboard-card">
                  <h2 className="text-xl font-bold mb-4">Portfolio</h2>
                  <div className="space-y-4">
                    {mockPositions.map((position, index) => (
                      <div key={index} className="flex items-center justify-between p-4 glass-effect rounded-lg">
                        <div>
                          <p className="font-medium">{position.symbol}</p>
                          <p className="text-sm text-gray-400">
                            {position.qty} @ ${position.entry.toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${position.pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                            {position.pnl >= 0 ? '+' : ''}${position.pnl.toFixed(2)}
                          </p>
                          <p className="text-sm text-gray-400">{position.side}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'signals' && (
              <motion.div
                key="signals"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="dashboard-card">
                  <h2 className="text-xl font-bold mb-4">Trading Signals</h2>
                  <p className="text-gray-400">AI-powered signals coming soon...</p>
                </div>
              </motion.div>
            )}

            {activeTab === 'settings' && (
              <motion.div
                key="settings"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="dashboard-card">
                  <h2 className="text-xl font-bold mb-4">Settings</h2>
                  <p className="text-gray-400">Application settings coming soon...</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

export default CryptoTradingDashboard; 
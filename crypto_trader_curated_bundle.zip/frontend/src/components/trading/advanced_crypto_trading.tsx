import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, TrendingDown, BarChart3, Settings, Wallet, Target, 
  Zap, DollarSign, Percent, Activity, Filter, Search, Bell, 
  User, Shield, Eye, EyeOff, Calculator, BarChart, AlertTriangle,
  ArrowUp, ArrowDown, X, ChevronDown, CandlestickChart
} from 'lucide-react';

// SVG Icons for cryptocurrencies
const CryptoIcons = {
  BTC: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="12" fill="#F7931A"/>
      <path d="M17.154 8.681c.24-1.602-.98-2.464-2.647-3.04l.541-2.17-1.32-.329-.527 2.115c-.347-.087-.703-.168-1.058-.248l.531-2.13-1.32-.329-.541 2.169c-.287-.065-.569-.13-.843-.196v-.007l-1.82-.454-.35 1.407s.98.225.959.239c.535.133.632.487.615.768l-.615 2.47c.037.009.085.022.138.042l-.14-.035-.863 3.463c-.066.162-.23.406-.602.314.013.019-.959-.239-.959-.239l-.654 1.51 1.72.428c.32.08.634.164.943.242l-.547 2.19 1.32.329.541-2.17c.36.098.708.188 1.05.276l-.54 2.165 1.32.329.546-2.19c2.253.426 3.946.254 4.66-1.78.576-1.639-.028-2.585-1.212-3.202.862-.199 1.51-.765 1.684-1.934zm-3.01 4.22c-.408 1.64-3.174.753-4.071.53l.726-2.908c.897.223 3.781.664 3.345 2.378zm.408-4.24c-.372 1.49-2.662.733-3.405.547l.657-2.64c.743.186 3.139.533 2.748 2.093z" fill="white"/>
    </svg>
  ),
  ETH: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="12" fill="#627EEA"/>
      <path d="M12.373 3v6.652l5.623 2.513L12.373 3z" fill="white" fillOpacity="0.602"/>
      <path d="M12.373 3L6.75 12.165l5.623-2.513V3z" fill="white"/>
      <path d="M12.373 16.103v4.896l5.627-7.954-5.627 3.058z" fill="white" fillOpacity="0.602"/>
      <path d="M12.373 20.999v-4.896L6.75 13.045l5.623 7.954z" fill="white"/>
      <path d="M12.373 15.165l5.623-3.058-5.623-2.513v5.571z" fill="white" fillOpacity="0.2"/>
      <path d="M6.75 12.107l5.623 3.058V9.594L6.75 12.107z" fill="white" fillOpacity="0.602"/>
    </svg>
  ),
  BNB: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="12" fill="#F3BA2F"/>
      <path d="M8.48 11.64l2.88-2.88 2.88 2.88L16.32 9.6 12 5.28 7.68 9.6l.8.8zm-2.88 2.88l.8-.8.8.8-.8.8-.8-.8zm2.88 2.88l2.88 2.88 2.88-2.88.8.8L12 21.12 7.68 16.8l.8-.8zm8.64-2.88l-.8.8-.8-.8.8-.8.8.8zm-3.76-2.88L12 10.24l-1.36 1.36 1.36 1.36 1.36-1.36z" fill="white"/>
    </svg>
  ),
  ADA: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="12" fill="#0033AD"/>
      <path d="M12 4.8c-3.97 0-7.2 3.23-7.2 7.2s3.23 7.2 7.2 7.2 7.2-3.23 7.2-7.2-3.23-7.2-7.2-7.2zm0 13.2c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z" fill="white"/>
      <circle cx="12" cy="12" r="3" fill="white"/>
    </svg>
  ),
  SOL: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="12" fill="#9945FF"/>
      <path d="M6.5 15.5h11c.28 0 .5.22.5.5v1c0 .28-.22.5-.5.5h-11c-.28 0-.5-.22-.5-.5v-1c0-.28.22-.5.5-.5zm0-7h11c.28 0 .5.22.5.5v1c0 .28-.22.5-.5.5h-11c-.28 0-.5-.22-.5-.5v-1c0-.28.22-.5.5-.5zm0 3.5h11c.28 0 .5.22.5.5v1c0 .28-.22.5-.5.5h-11c-.28 0-.5-.22-.5-.5v-1c0-.28.22-.5.5-.5z" fill="white"/>
    </svg>
  )
};

interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume: number;
  marketCap: number;
}

interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
}

const TradingConsole: React.FC = () => {
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [selectedPair, setSelectedPair] = useState('BTC/USDT');
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy');
  const [orderMode, setOrderMode] = useState<'market' | 'limit' | 'stop'>('limit');
  const [price, setPrice] = useState<string>('45230.50');
  const [amount, setAmount] = useState<string>('');
  const [leverage, setLeverage] = useState<number>(1);
  const [stopLoss, setStopLoss] = useState<string>('');
  const [takeProfit, setTakeProfit] = useState<string>('');
  const [balance, setBalance] = useState({
    USDT: 12450.67,
    BTC: 0.27485
  });
  const [volumeFilter, setVolumeFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isOrderBookExpanded, setIsOrderBookExpanded] = useState(true);
  const [isChartExpanded, setIsChartExpanded] = useState(true);
  const [activeTimeframe, setActiveTimeframe] = useState('1h');
  const [showSettings, setShowSettings] = useState(false);
  const [showAlerts, setShowAlerts] = useState(false);
  const [alerts, setAlerts] = useState([
    { id: 1, symbol: 'BTC/USDT', condition: 'above', price: 46000, active: true },
    { id: 2, symbol: 'ETH/USDT', condition: 'below', price: 3000, active: false }
  ]);
  const [chartTools, setChartTools] = useState({
    trendLine: false,
    fibonacci: false,
    rsi: false,
    macd: false,
    volume: false,
    ma20: true,
    ma50: true,
    bollinger: false,
    stochastic: false,
    ema: false,
    support: false,
    resistance: false
  });
  const [rsiValue, setRsiValue] = useState(67.3);
  const [macdValues, setMacdValues] = useState({ macd: 0.5, signal: 0.3, histogram: 0.2 });

  const [marketData] = useState<MarketData[]>([
    {
      symbol: 'BTC/USDT',
      name: 'Bitcoin',
      price: 45230.50,
      change24h: 2.45,
      volume: 1200000000,
      marketCap: 890000000000
    },
    {
      symbol: 'ETH/USDT',
      name: 'Ethereum',
      price: 3125.80,
      change24h: 1.78,
      volume: 890000000,
      marketCap: 375000000000
    },
    {
      symbol: 'BNB/USDT',
      name: 'Binance Coin',
      price: 245.67,
      change24h: -0.85,
      volume: 156000000,
      marketCap: 38000000000
    },
    {
      symbol: 'ADA/USDT',
      name: 'Cardano',
      price: 0.4521,
      change24h: 3.21,
      volume: 95000000,
      marketCap: 15000000000
    },
    {
      symbol: 'SOL/USDT',
      name: 'Solana',
      price: 98.45,
      change24h: 5.67,
      volume: 234000000,
      marketCap: 42000000000
    }
  ]);

  const [orderBook] = useState({
    asks: [
      { price: 45245.30, amount: 0.0245, total: 1108.51 },
      { price: 45240.80, amount: 0.1230, total: 5564.62 },
      { price: 45235.60, amount: 0.0890, total: 4025.97 },
      { price: 45232.10, amount: 0.2150, total: 9724.90 },
      { price: 45230.50, amount: 0.1680, total: 7598.72 }
    ] as OrderBookEntry[],
    bids: [
      { price: 45228.90, amount: 0.1450, total: 6558.19 },
      { price: 45225.40, amount: 0.0980, total: 4432.09 },
      { price: 45220.30, amount: 0.2340, total: 10581.55 },
      { price: 45215.80, amount: 0.1120, total: 5064.17 },
      { price: 45210.60, amount: 0.1890, total: 8544.84 }
    ] as OrderBookEntry[]
  });

  const getCurrentPrice = () => {
    const market = marketData.find(m => m.symbol === selectedPair);
    return market?.price || 0;
  };

  const getCurrentBalance = () => {
    const baseCurrency = selectedPair.split('/')[0];
    const quoteCurrency = selectedPair.split('/')[1];
    return {
      base: balance[baseCurrency as keyof typeof balance] || 0,
      quote: balance[quoteCurrency as keyof typeof balance] || 0
    };
  };

  const calculateTotal = () => {
    const priceValue = parseFloat(price) || 0;
    const amountValue = parseFloat(amount) || 0;
    return (priceValue * amountValue).toFixed(2);
  };

  const calculateProfitLoss = () => {
    const entryPrice = parseFloat(price) || 0;
    const amountValue = parseFloat(amount) || 0;
    const takeProfitPrice = parseFloat(takeProfit) || 0;
    const stopLossPrice = parseFloat(stopLoss) || 0;
    
    if (!entryPrice || !amountValue) return { profit: 0, loss: 0, profitROI: 0, lossROI: 0 };
    
    const investment = entryPrice * amountValue * leverage;
    
    const profit = takeProfitPrice > 0 ? 
      (orderType === 'buy' ? 
        (takeProfitPrice - entryPrice) * amountValue * leverage :
        (entryPrice - takeProfitPrice) * amountValue * leverage) : 0;
    
    const loss = stopLossPrice > 0 ? 
      (orderType === 'buy' ? 
        (entryPrice - stopLossPrice) * amountValue * leverage :
        (stopLossPrice - entryPrice) * amountValue * leverage) : 0;
    
    const profitROI = investment > 0 ? (profit / investment) * 100 : 0;
    const lossROI = investment > 0 ? (loss / investment) * 100 : 0;
    
    return { profit, loss, profitROI, lossROI };
  };

  const calculateMaxAmount = () => {
    const currentBalance = getCurrentBalance();
    const priceValue = parseFloat(price) || 1;
    
    if (orderType === 'buy') {
      return ((currentBalance.quote * leverage) / priceValue).toFixed(6);
    } else {
      return (currentBalance.base * leverage).toFixed(6);
    }
  };

  const handlePercentageClick = (percentage: number) => {
    const maxAmount = parseFloat(calculateMaxAmount());
    const newAmount = ((maxAmount * percentage) / 100).toFixed(6);
    setAmount(newAmount);
  };

  const filteredMarkets = marketData.filter(market => {
    const matchesSearch = market.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         market.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesVolume = true;
    if (volumeFilter === 'high') matchesVolume = market.volume > 500000000;
    else if (volumeFilter === 'medium') matchesVolume = market.volume > 100000000 && market.volume <= 500000000;
    else if (volumeFilter === 'low') matchesVolume = market.volume <= 100000000;
    
    return matchesSearch && matchesVolume;
  });

  const toggleChartTool = (tool: keyof typeof chartTools) => {
    setChartTools(prev => ({
      ...prev,
      [tool]: !prev[tool]
    }));
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    }).format(num);
  };

  const formatVolume = (volume: number) => {
    if (volume >= 1000000000) return `${(volume / 1000000000).toFixed(1)}B`;
    if (volume >= 1000000) return `${(volume / 1000000).toFixed(1)}M`;
    if (volume >= 1000) return `${(volume / 1000).toFixed(1)}K`;
    return volume.toString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900 text-white">
      {/* Header */}
      <div className="border-b border-slate-700/50 backdrop-blur-sm bg-gray-900/80">
        <div className="w-full px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Crypto Trader Pro
                </h1>
              </div>
              
              {/* Demo/Live Toggle */}
              <div className="flex items-center gap-3 bg-slate-800/70 rounded-full p-1 border border-slate-700">
                <button
                  onClick={() => setIsDemoMode(true)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center ${
                    isDemoMode 
                      ? 'bg-gradient-to-r from-orange-500 to-orange-700 text-white shadow-lg' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Demo
                </button>
                <button
                  onClick={() => setIsDemoMode(false)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center ${
                    !isDemoMode 
                      ? 'bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Live
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-4 bg-slate-800/70 rounded-xl px-4 py-2 border border-slate-700">
                <Wallet className="w-5 h-5 text-blue-400" />
                <span className="text-sm">Balance:</span>
                <span className="font-bold text-green-400">
                  ${formatNumber(balance.USDT)}
                </span>
              </div>
              <button 
                className="p-2 hover:bg-slate-800/50 rounded-xl transition-colors border border-slate-700 relative"
                onClick={() => setShowAlerts(!showAlerts)}
              >
                <Bell className="w-5 h-5" />
                {alerts.filter(a => a.active).length > 0 && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white">{alerts.filter(a => a.active).length}</span>
                  </div>
                )}
              </button>
              <button className="p-2 hover:bg-slate-800/50 rounded-xl transition-colors border border-slate-700">
                <User className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Settings className="w-6 h-6 text-blue-400" />
                Settings
              </h3>
              <button 
                onClick={() => setShowSettings(false)}
                className="p-2 hover:bg-slate-700/50 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Theme</label>
                <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm">
                  <option>Dark Mode</option>
                  <option>Light Mode</option>
                  <option>Auto</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">Default Leverage</label>
                <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm">
                  <option>1x</option>
                  <option>2x</option>
                  <option>5x</option>
                  <option>10x</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">Sound Notifications</label>
                <div className="flex items-center gap-3">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="text-sm">Enable sound alerts</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">Auto-refresh Interval</label>
                <select className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm">
                  <option>1 second</option>
                  <option>3 seconds</option>
                  <option>5 seconds</option>
                  <option>10 seconds</option>
                </select>
              </div>
              
              <button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-2 rounded-lg font-medium hover:scale-[1.02] transition-all">
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Alerts Panel */}
      {showAlerts && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-slate-800 rounded-2xl border border-slate-700 p-6 w-full max-w-lg mx-4">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Bell className="w-6 h-6 text-yellow-400" />
                Price Alerts
              </h3>
              <button 
                onClick={() => setShowAlerts(false)}
                className="p-2 hover:bg-slate-700/50 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-4 mb-6">
              {alerts.map((alert) => (
                <div key={alert.id} className="bg-slate-700/30 rounded-lg p-4 border border-slate-600">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">{alert.symbol}</div>
                      <div className="text-sm text-gray-400">
                        Alert when price goes {alert.condition} ${formatNumber(alert.price)}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${alert.active ? 'bg-green-400' : 'bg-gray-400'}`}></div>
                      <button className="text-red-400 hover:text-red-300">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="border-t border-slate-600 pt-4">
              <h4 className="font-medium mb-3">Create New Alert</h4>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <select className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm">
                  <option>BTC/USDT</option>
                  <option>ETH/USDT</option>
                  <option>BNB/USDT</option>
                </select>
                <select className="bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm">
                  <option>Above</option>
                  <option>Below</option>
                </select>
              </div>
              <input 
                type="number" 
                placeholder="Target price"
                className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-sm mb-3"
              />
              <button className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 text-white py-2 rounded-lg font-medium hover:scale-[1.02] transition-all">
                Create Alert
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Enhanced Responsive Grid */}
      <div className="block sm:hidden">
        {/* Mobile layout adjustments */}
      </div>

      <div className="w-full px-4 py-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 xl:grid-cols-12 gap-4 min-h-[calc(100vh-100px)]">
          {/* Market List - Responsive */}
          <div className="lg:col-span-3 xl:col-span-3 2xl:col-span-2 bg-slate-800/30 backdrop-blur-sm rounded-2xl border border-slate-700 p-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-400" />
                Markets
              </h2>
              <button className="p-1.5 hover:bg-slate-700/50 rounded-lg">
                <Settings 
                  className="w-5 h-5 text-gray-400 hover:text-white transition-colors" 
                  onClick={() => setShowSettings(!showSettings)}
                />
              </button>
            </div>

            {/* Search and Filter */}
            <div className="space-y-3 mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search markets..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30"
                />
              </div>

              <div className="flex gap-2">
                <select
                  value={volumeFilter}
                  onChange={(e) => setVolumeFilter(e.target.value)}
                  className="flex-1 bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30"
                >
                  <option value="all">All Volume</option>
                  <option value="high">High Volume</option>
                  <option value="medium">Medium Volume</option>
                  <option value="low">Low Volume</option>
                </select>
                <button className="p-2.5 bg-slate-700/50 border border-slate-600 rounded-xl hover:bg-slate-600/50 transition-colors">
                  <Filter className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Market List */}
            <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar">
              {filteredMarkets.map((market) => {
                const IconComponent = CryptoIcons[market.symbol.split('/')[0] as keyof typeof CryptoIcons];
                return (
                  <div
                    key={market.symbol}
                    onClick={() => setSelectedPair(market.symbol)}
                    className={`p-3 rounded-xl cursor-pointer transition-all hover:bg-slate-700/50 border ${
                      selectedPair === market.symbol 
                        ? 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/50' 
                        : 'border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {IconComponent && <IconComponent />}
                        <div>
                          <div className="font-medium">{market.symbol}</div>
                          <div className="text-xs text-gray-400">{market.name}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">${formatNumber(market.price)}</div>
                        <div className={`text-xs flex items-center justify-end ${market.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {market.change24h >= 0 ? <ArrowUp className="w-3 h-3 mr-1" /> : <ArrowDown className="w-3 h-3 mr-1" />}
                          {Math.abs(market.change24h)}%
                        </div>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-gray-400 flex justify-between">
                      <span>Vol: {formatVolume(market.volume)}</span>
                      <span>Cap: {formatVolume(market.marketCap)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Main Chart Area - Responsive */}
          <div className="lg:col-span-6 xl:col-span-6 2xl:col-span-7 bg-slate-800/30 backdrop-blur-sm rounded-2xl border border-slate-700 p-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <h2 className="text-xl font-bold">{selectedPair}</h2>
                <div className="text-2xl font-bold text-green-400">
                  ${formatNumber(getCurrentPrice())}
                </div>
                <div className="flex items-center gap-2 text-sm bg-slate-700/50 px-2 py-1 rounded-lg">
                  <TrendingUp className="w-4 h-4 text-green-400" />
                  <span className="text-green-400">+2.45%</span>
                </div>
              </div>
              <div className="flex gap-1 flex-wrap">
                {['1m', '5m', '15m', '30m', '1h', '4h', '12h', '24h', '2d'].map((timeframe) => (
                  <button 
                    key={timeframe}
                    onClick={() => setActiveTimeframe(timeframe)}
                    className={`px-2 py-1 rounded-lg text-xs transition-all ${
                      activeTimeframe === timeframe
                        ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg'
                        : 'bg-slate-700/50 hover:bg-slate-600/50 text-gray-300'
                    }`}
                  >
                    {timeframe}
                  </button>
                ))}
              </div>
            </div>

            {/* Enhanced Chart Placeholder */}
            <div className="bg-slate-900/50 rounded-xl p-4 h-[500px] relative overflow-hidden border border-slate-700/30">
              {/* Chart Grid */}
              <div className="absolute inset-0">
                {/* Horizontal grid lines */}
                {[...Array(10)].map((_, i) => (
                  <div 
                    key={`h-${i}`} 
                    className="absolute w-full h-px bg-slate-700/20" 
                    style={{top: `${10 * (i + 1)}%`}}
                  ></div>
                ))}
                {/* Vertical grid lines */}
                {[...Array(8)].map((_, i) => (
                  <div 
                    key={`v-${i}`} 
                    className="absolute h-full w-px bg-slate-700/20" 
                    style={{left: `${12.5 * (i + 1)}%`}}
                  ></div>
                ))}
              </div>
              
              {/* Price Scale (Right side) */}
              <div className="absolute right-2 top-4 bottom-20 flex flex-col justify-between text-xs text-gray-400">
                <span>46,800</span>
                <span>46,400</span>
                <span>46,000</span>
                <span>45,600</span>
                <span>45,200</span>
                <span>44,800</span>
                <span>44,400</span>
                <span>44,000</span>
              </div>
              
              {/* Time Scale (Bottom) */}
              <div className="absolute bottom-2 left-4 right-4 flex justify-between text-xs text-gray-400">
                <span>09:00</span>
                <span>11:00</span>
                <span>13:00</span>
                <span>15:00</span>
                <span>17:00</span>
                <span>19:00</span>
                <span>21:00</span>
              </div>
              
              {/* Main Chart Area - Upper 70% */}
              <div className="absolute inset-0 top-0 h-[70%]">
                {/* Enhanced Candlesticks with more realistic patterns */}
                <div className="absolute inset-0">
                  {[...Array(25)].map((_, i) => {
                    const isGreen = Math.random() > 0.4;
                    const height = Math.random() * 20 + 8;
                    const bottom = Math.random() * 40 + 20;
                    const left = 8 + (i * 3.2);
                    return (
                      <div key={i} className="absolute">
                        {/* Candlestick wick */}
                        <div 
                          className={`absolute w-px ${isGreen ? 'bg-green-400' : 'bg-red-400'}`}
                          style={{
                            left: `${left + 0.4}%`,
                            bottom: `${bottom - 5}%`,
                            height: `${height + 10}px`
                          }}
                        />
                        {/* Candlestick body */}
                        <div 
                          className={`absolute w-2 ${isGreen ? 'bg-green-500/90' : 'bg-red-500/90'} rounded-sm shadow-sm`}
                          style={{
                            left: `${left}%`,
                            bottom: `${bottom}%`,
                            height: `${height}px`
                          }}
                        />
                      </div>
                    );
                  })}
                </div>
                
                {/* Moving Averages */}
                {chartTools.ma20 && (
                  <div className="absolute inset-0">
                    <svg className="w-full h-full">
                      <path
                        d="M 40 180 Q 80 170, 120 175 T 200 165 T 280 155 T 360 145 T 440 140 T 520 135"
                        stroke="#10b981"
                        strokeWidth="2"
                        fill="none"
                        className="opacity-80"
                      />
                    </svg>
                  </div>
                )}
                
                {chartTools.ma50 && (
                  <div className="absolute inset-0">
                    <svg className="w-full h-full">
                      <path
                        d="M 40 200 Q 80 190, 120 195 T 200 185 T 280 175 T 360 165 T 440 160 T 520 155"
                        stroke="#3b82f6"
                        strokeWidth="2"
                        fill="none"
                        className="opacity-80"
                      />
                    </svg>
                  </div>
                )}
                
                {/* EMA */}
                {chartTools.ema && (
                  <div className="absolute inset-0">
                    <svg className="w-full h-full">
                      <path
                        d="M 40 190 Q 80 180, 120 185 T 200 175 T 280 165 T 360 155 T 440 150 T 520 145"
                        stroke="#f59e0b"
                        strokeWidth="2"
                        fill="none"
                        className="opacity-80"
                        strokeDasharray="5,5"
                      />
                    </svg>
                  </div>
                )}
                
                {/* Bollinger Bands */}
                {chartTools.bollinger && (
                  <div className="absolute inset-0">
                    <svg className="w-full h-full">
                      {/* Upper Band */}
                      <path
                        d="M 40 160 Q 80 150, 120 155 T 200 145 T 280 135 T 360 125 T 440 120 T 520 115"
                        stroke="#8b5cf6"
                        strokeWidth="1"
                        fill="none"
                        className="opacity-60"
                        strokeDasharray="3,3"
                      />
                      {/* Lower Band */}
                      <path
                        d="M 40 220 Q 80 210, 120 215 T 200 205 T 280 195 T 360 185 T 440 180 T 520 175"
                        stroke="#8b5cf6"
                        strokeWidth="1"
                        fill="none"
                        className="opacity-60"
                        strokeDasharray="3,3"
                      />
                    </svg>
                  </div>
                )}
                
                {/* Fibonacci Retracement */}
                {chartTools.fibonacci && (
                  <div className="absolute inset-0">
                    {[23.6, 38.2, 50, 61.8, 78.6].map((level, i) => (
                      <div 
                        key={level}
                        className="absolute w-full h-px bg-yellow-400/40"
                        style={{ bottom: `${20 + level * 0.5}%` }}
                      >
                        <span className="absolute right-2 -top-2 text-xs text-yellow-400">
                          {level}%
                        </span>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Support and Resistance Lines */}
                {chartTools.support && (
                  <div className="absolute w-full h-px bg-green-400/60 bottom-[25%]">
                    <span className="absolute right-2 -top-2 text-xs text-green-400">Support</span>
                  </div>
                )}
                
                {chartTools.resistance && (
                  <div className="absolute w-full h-px bg-red-400/60 bottom-[65%]">
                    <span className="absolute right-2 -top-2 text-xs text-red-400">Resistance</span>
                  </div>
                )}
                
                {/* Trend Lines */}
                {chartTools.trendLine && (
                  <div className="absolute inset-0">
                    <svg className="w-full h-full">
                      <line
                        x1="10%"
                        y1="80%"
                        x2="90%"
                        y2="40%"
                        stroke="#06d6a0"
                        strokeWidth="2"
                        className="opacity-70"
                        strokeDasharray="5,5"
                      />
                    </svg>
                  </div>
                )}
              </div>
              
              {/* RSI Indicator - Bottom panel */}
              {chartTools.rsi && (
                <div className="absolute bottom-16 left-4 right-16 h-16 bg-slate-800/50 rounded border border-slate-600/50">
                  <div className="p-2">
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>RSI (14)</span>
                      <span className={rsiValue > 70 ? 'text-red-400' : rsiValue < 30 ? 'text-green-400' : 'text-blue-400'}>
                        {rsiValue.toFixed(1)}
                      </span>
                    </div>
                    <div className="h-8 bg-slate-700/50 rounded relative">
                      {/* RSI Overbought/Oversold levels */}
                      <div className="absolute top-0 w-full h-px bg-red-400/50" style={{top: '20%'}}></div>
                      <div className="absolute top-0 w-full h-px bg-green-400/50" style={{top: '80%'}}></div>
                      
                      {/* RSI Line */}
                      <div className="absolute inset-0">
                        <svg className="w-full h-full">
                          <path
                            d="M 20 25 Q 60 20, 100 22 T 180 18 T 260 25 T 340 30 T 420 20 T 500 22"
                            stroke="#06d6a0"
                            strokeWidth="2"
                            fill="none"
                          />
                        </svg>
                      </div>
                      
                      <div className="absolute right-2 top-1 text-xs text-gray-400">
                        <div>70</div>
                        <div className="mt-1">30</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* MACD Indicator */}
              {chartTools.macd && (
                <div className="absolute bottom-16 left-4 right-16 h-20 bg-slate-800/50 rounded border border-slate-600/50">
                  <div className="p-2">
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>MACD (12,26,9)</span>
                      <div className="flex gap-3">
                        <span className="text-blue-400">MACD: {macdValues.macd.toFixed(3)}</span>
                        <span className="text-orange-400">Signal: {macdValues.signal.toFixed(3)}</span>
                        <span className="text-purple-400">Hist: {macdValues.histogram.toFixed(3)}</span>
                      </div>
                    </div>
                    <div className="h-12 bg-slate-700/50 rounded relative">
                      {/* Zero line */}
                      <div className="absolute top-1/2 w-full h-px bg-gray-500/50"></div>
                      
                      {/* MACD Histogram */}
                      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-around h-full">
                        {[...Array(15)].map((_, i) => {
                          const height = Math.random() * 60 + 20;
                          const isPositive = Math.random() > 0.5;
                          return (
                            <div 
                              key={i}
                              className={`w-1 ${isPositive ? 'bg-green-400/60' : 'bg-red-400/60'}`}
                              style={{ height: `${height}%` }}
                            />
                          );
                        })}
                      </div>
                      
                      {/* MACD and Signal lines */}
                      <div className="absolute inset-0">
                        <svg className="w-full h-full">
                          <path
                            d="M 20 30 Q 60 25, 100 28 T 180 22 T 260 30 T 340 35 T 420 25 T 500 28"
                            stroke="#3b82f6"
                            strokeWidth="1.5"
                            fill="none"
                          />
                          <path
                            d="M 20 35 Q 60 30, 100 33 T 180 27 T 260 35 T 340 40 T 420 30 T 500 33"
                            stroke="#f59e0b"
                            strokeWidth="1.5"
                            fill="none"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Stochastic Oscillator */}
              {chartTools.stochastic && (
                <div className="absolute bottom-16 left-4 right-16 h-16 bg-slate-800/50 rounded border border-slate-600/50">
                  <div className="p-2">
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>Stochastic (14,3,3)</span>
                      <div className="flex gap-2">
                        <span className="text-cyan-400">%K: 73.2</span>
                        <span className="text-pink-400">%D: 71.8</span>
                      </div>
                    </div>
                    <div className="h-8 bg-slate-700/50 rounded relative">
                      <div className="absolute top-0 w-full h-px bg-red-400/50" style={{top: '20%'}}></div>
                      <div className="absolute top-0 w-full h-px bg-green-400/50" style={{top: '80%'}}></div>
                      
                      <div className="absolute inset-0">
                        <svg className="w-full h-full">
                          <path
                            d="M 20 18 Q 60 15, 100 17 T 180 12 T 260 20 T 340 25 T 420 15 T 500 17"
                            stroke="#06b6d4"
                            strokeWidth="1.5"
                            fill="none"
                          />
                          <path
                            d="M 20 20 Q 60 17, 100 19 T 180 14 T 260 22 T 340 27 T 420 17 T 500 19"
                            stroke="#ec4899"
                            strokeWidth="1.5"
                            fill="none"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Volume bars at bottom */}
              {chartTools.volume && (
                <div className="absolute bottom-8 left-[8%] right-[8%] flex items-end gap-px h-8">
                  {[...Array(25)].map((_, i) => (
                    <div 
                      key={i} 
                      className="flex-1 bg-blue-400/40 rounded-t-sm" 
                      style={{height: `${Math.random() * 80 + 20}%`}}
                    ></div>
                  ))}
                </div>
              )}
              
              {/* Enhanced Chart indicators overlay */}
              <div className="absolute top-4 left-4 flex flex-wrap gap-2 text-xs max-w-2xl">
                {chartTools.ma20 && (
                  <div className="bg-slate-800/70 px-2 py-1 rounded border border-green-500/30">
                    <span className="text-green-400">MA20: </span>
                    <span className="text-white">45,156</span>
                  </div>
                )}
                {chartTools.ma50 && (
                  <div className="bg-slate-800/70 px-2 py-1 rounded border border-blue-500/30">
                    <span className="text-blue-400">MA50: </span>
                    <span className="text-white">44,892</span>
                  </div>
                )}
                {chartTools.ema && (
                  <div className="bg-slate-800/70 px-2 py-1 rounded border border-yellow-500/30">
                    <span className="text-yellow-400">EMA20: </span>
                    <span className="text-white">45,234</span>
                  </div>
                )}
                {chartTools.bollinger && (
                  <div className="bg-slate-800/70 px-2 py-1 rounded border border-purple-500/30">
                    <span className="text-purple-400">BB: </span>
                    <span className="text-white">46,100/44,800</span>
                  </div>
                )}
              </div>
              
              <div className="relative z-10 h-full flex items-center justify-center opacity-10">
                <div className="text-center">
                  <CandlestickChart className="w-20 h-20 mx-auto mb-4 text-purple-400" />
                  <h3 className="text-xl font-bold mb-2">Advanced TradingView Pro</h3>
                  <p className="text-gray-400">Professional Technical Analysis • {activeTimeframe}</p>
                </div>
              </div>
            </div>

            {/* Trading Tools */}
            <div className="mt-4 flex gap-2 flex-wrap">
              <button className="px-3 py-2 bg-slate-700/50 rounded-xl text-sm hover:bg-slate-600/50 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Trend Line
              </button>
              <button className="px-3 py-2 bg-slate-700/50 rounded-xl text-sm hover:bg-slate-600/50 flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Fibonacci
              </button>
              <button className="px-3 py-2 bg-slate-700/50 rounded-xl text-sm hover:bg-slate-600/50 flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                RSI
              </button>
              <button className="px-3 py-2 bg-slate-700/50 rounded-xl text-sm hover:bg-slate-600/50 flex items-center gap-2">
                <Percent className="w-4 h-4" />
                MACD
              </button>
              <button className="px-3 py-2 bg-slate-700/50 rounded-xl text-sm hover:bg-slate-600/50 flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Volume
              </button>
            </div>
          </div>

          {/* Trading Console - Responsive */}
          <div className="lg:col-span-3 xl:col-span-3 2xl:col-span-3 bg-slate-800/30 backdrop-blur-sm rounded-2xl border border-slate-700 p-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                Trading Console
              </h3>
              <div className="flex items-center gap-3">
                {/* Miniature Balance Display */}
                <div className="bg-slate-700/30 rounded-lg px-2 py-1 text-xs border border-slate-600">
                  <div className="flex items-center gap-2">
                    <Wallet className="w-3 h-3 text-blue-400" />
                    <span className="text-gray-400">
                      {orderType === 'buy' 
                        ? `${formatNumber(getCurrentBalance().quote)} USDT`
                        : `${getCurrentBalance().base.toFixed(6)} ${selectedPair.split('/')[0]}`
                      }
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-400">Leverage:</span>
                  <select
                    value={leverage}
                    onChange={(e) => setLeverage(Number(e.target.value))}
                    className="bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30"
                  >
                    <option value={1}>1x</option>
                    <option value={2}>2x</option>
                    <option value={5}>5x</option>
                    <option value={10}>10x</option>
                    <option value={20}>20x</option>
                    <option value={50}>50x</option>
                    <option value={100}>100x</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Buy/Sell Toggle */}
            <div className="grid grid-cols-2 gap-1 bg-slate-700/30 rounded-xl p-1 mb-4">
              <button
                onClick={() => setOrderType('buy')}
                className={`py-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                  orderType === 'buy'
                    ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <TrendingUp className="w-5 h-5" />
                Buy
              </button>
              <button
                onClick={() => setOrderType('sell')}
                className={`py-2.5 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                  orderType === 'sell'
                    ? 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <TrendingDown className="w-5 h-5" />
                Sell
              </button>
            </div>

            {/* Order Type */}
            <div className="flex gap-1 bg-slate-700/30 rounded-xl p-1 mb-4">
              {['market', 'limit', 'stop'].map((mode) => (
                <button
                  key={mode}
                  onClick={() => setOrderMode(mode as typeof orderMode)}
                  className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${
                    orderMode === mode
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {mode === 'market' ? 'Market' : mode === 'limit' ? 'Limit' : 'Stop'}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {orderMode !== 'market' && (
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Price (USDT)</label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2.5 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Amount ({selectedPair.split('/')[0]})
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2.5 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30"
                />
                <div className="flex gap-1 mt-2">
                  {[25, 50, 75, 100].map((percent) => (
                    <button
                      key={percent}
                      onClick={() => handlePercentageClick(percent)}
                      className="flex-1 py-1.5 bg-slate-700/50 hover:bg-slate-600/50 rounded-lg text-xs transition-colors"
                    >
                      {percent}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Stop Loss and Take Profit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm text-gray-400 mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                    Stop Loss
                  </label>
                  <input
                    type="number"
                    value={stopLoss}
                    onChange={(e) => setStopLoss(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2.5 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500/30"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2 flex items-center gap-2">
                    <Target className="w-4 h-4 text-green-400" />
                    Take Profit
                  </label>
                  <input
                    type="number"
                    value={takeProfit}
                    onChange={(e) => setTakeProfit(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-700/50 border border-slate-600 rounded-xl px-3 py-2.5 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500/30"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2">Total (USDT)</label>
                <input
                  type="text"
                  value={calculateTotal()}
                  readOnly
                  className="w-full bg-slate-700/30 border border-slate-600 rounded-xl px-3 py-2.5 text-gray-400"
                />
              </div>

              {/* Profit/Loss Calculator */}
              {(stopLoss || takeProfit) && (
                <div className="bg-slate-700/30 rounded-xl p-3 border border-slate-600">
                  <div className="flex items-center gap-2 mb-2">
                    <Calculator className="w-4 h-4 text-purple-400" />
                    <span className="text-sm font-medium">P&L Calculator</span>
                  </div>
                  {(() => {
                    const { profit, loss, profitROI, lossROI } = calculateProfitLoss();
                    return (
                      <div className="space-y-2 text-sm">
                        {takeProfit && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Potential Profit:</span>
                            <span className="text-green-400 font-medium">
                              ${profit.toFixed(2)} ({profitROI.toFixed(2)}%)
                            </span>
                          </div>
                        )}
                        {stopLoss && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Potential Loss:</span>
                            <span className="text-red-400 font-medium">
                              ${loss.toFixed(2)} ({lossROI.toFixed(2)}%)
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* Enhanced Balance Info */}
              <div className="bg-slate-700/30 rounded-xl p-3 border border-slate-600">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-gray-400 text-xs">Available Balance</div>
                    <div className="font-medium">
                      {orderType === 'buy' 
                        ? `${formatNumber(getCurrentBalance().quote)} USDT`
                        : `${getCurrentBalance().base.toFixed(6)} ${selectedPair.split('/')[0]}`
                      }
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400 text-xs">Max {orderType === 'buy' ? 'Buy' : 'Sell'}</div>
                    <div className="font-medium">{calculateMaxAmount()}</div>
                  </div>
                  {leverage > 1 && (
                    <>
                      <div>
                        <div className="text-gray-400 text-xs">Buying Power</div>
                        <div className="text-purple-400 font-medium">{leverage}x</div>
                      </div>
                      <div>
                        <div className="text-gray-400 text-xs">Margin Used</div>
                        <div className="text-orange-400 font-medium">
                          ${(parseFloat(calculateTotal()) / leverage).toFixed(2)}
                        </div>
                      </div>
                    </>
                  )}
                </div>
                
                {/* Portfolio Summary */}
                <div className="mt-3 pt-3 border-t border-slate-600/50">
                  <div className="text-xs text-gray-400 mb-2">Portfolio Summary</div>
                  <div className="flex justify-between text-xs">
                    <span>Total Balance:</span>
                    <span className="text-green-400 font-medium">
                      ${(balance.USDT + (balance.BTC * getCurrentPrice())).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs mt-1">
                    <span>P&L Today:</span>
                    <span className="text-green-400 font-medium">+$247.32 (+2.1%)</span>
                  </div>
                </div>
              </div>

              <button
                className={`w-full py-3 rounded-xl font-bold transition-all hover:scale-[1.02] flex items-center justify-center gap-2 shadow-lg ${
                  orderType === 'buy'
                    ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700'
                    : 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700'
                }`}
              >
                {orderType === 'buy' ? (
                  <>
                    <DollarSign className="w-5 h-5" />
                    Buy {selectedPair.split('/')[0]}
                  </>
                ) : (
                  <>
                    <TrendingDown className="w-5 h-5" />
                    Sell {selectedPair.split('/')[0]}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Order Book & Market Stats - Enhanced Responsive */}
        <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-4 mt-4">
          {/* Enhanced Order Book - Responsive */}
          <div className="lg:col-span-2 xl:col-span-2 2xl:col-span-3 bg-slate-800/30 backdrop-blur-sm rounded-2xl border border-slate-700 p-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <BarChart className="w-5 h-5 text-blue-400" />
                Order Book
              </h3>
              <div className="flex gap-2">
                <button 
                  onClick={() => setIsOrderBookExpanded(!isOrderBookExpanded)}
                  className="p-1.5 hover:bg-slate-700/50 rounded-xl"
                >
                  {isOrderBookExpanded ? <ChevronDown className="w-5 h-5" /> : <X className="w-5 h-5" />}
                </button>
              </div>
            </div>
            
            {isOrderBookExpanded && (
              <div className="space-y-4">
                <div>
                  <div className="grid grid-cols-3 text-xs text-gray-400 mb-2 px-2">
                    <span>Price (USDT)</span>
                    <span className="text-center">Amount</span>
                    <span className="text-right">Total</span>
                  </div>
                  
                  {/* Asks */}
                  <div className="space-y-1 mb-3">
                    {orderBook.asks.slice().reverse().map((ask, index) => (
                      <div
                        key={index}
                        className="grid grid-cols-3 items-center text-xs py-2 px-2 hover:bg-red-500/10 rounded-xl cursor-pointer group relative"
                      >
                        <div 
                          className="absolute inset-y-0 right-0 bg-red-500/10 rounded-xl"
                          style={{ width: `${(index+1) * 15}%` }}
                        ></div>
                        <span className="text-red-400 group-hover:text-red-300 z-10">{formatNumber(ask.price)}</span>
                        <span className="text-center z-10 group-hover:text-white">{ask.amount}</span>
                        <span className="text-right text-gray-400 group-hover:text-gray-300 z-10">{formatNumber(ask.total)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Spread */}
                  <div className="text-center py-3 border-y border-slate-600/50 my-2 bg-slate-700/20 rounded-xl">
                    <div className="text-lg font-bold text-purple-400">
                      ${formatNumber(getCurrentPrice())}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">
                      Spread: $15.40 (0.034%)
                    </div>
                  </div>

                  {/* Bids */}
                  <div className="space-y-1">
                    {orderBook.bids.map((bid, index) => (
                      <div
                        key={index}
                        className="grid grid-cols-3 items-center text-xs py-2 px-2 hover:bg-green-500/10 rounded-xl cursor-pointer group relative"
                      >
                        <div 
                          className="absolute inset-y-0 right-0 bg-green-500/10 rounded-xl"
                          style={{ width: `${(index+1) * 15}%` }}
                        ></div>
                        <span className="text-green-400 group-hover:text-green-300 z-10">{formatNumber(bid.price)}</span>
                        <span className="text-center z-10 group-hover:text-white">{bid.amount}</span>
                        <span className="text-right text-gray-400 group-hover:text-gray-300 z-10">{formatNumber(bid.total)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Market Stats - Enhanced Responsive */}
          <div className="lg:col-span-1 xl:col-span-1 2xl:col-span-1 bg-slate-800/30 backdrop-blur-sm rounded-2xl border border-slate-700 p-4 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-400" />
                <span className="hidden sm:inline">Market Statistics</span>
                <span className="sm:hidden">Stats</span>
              </h3>
            </div>
            
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
                  <div className="text-gray-400 text-sm">24h Change</div>
                  <div className="text-2xl font-bold text-green-400 mt-1">+2.45%</div>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
                  <div className="text-gray-400 text-sm">24h Volume</div>
                  <div className="text-2xl font-bold text-blue-400 mt-1">1.2B USDT</div>
                </div>
              </div>
              
              <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">24h High:</span>
                    <span className="text-green-400">$46,100.00</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">24h Low:</span>
                    <span className="text-red-400">$44,200.00</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Market Cap:</span>
                    <span className="text-purple-400">$890.32B</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Liquidity:</span>
                    <span className="text-blue-400">$1.8B</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-slate-700/30 rounded-xl p-4 border border-slate-600">
                <div className="text-sm text-gray-400 mb-2">Market Sentiment</div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-slate-800/50 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-green-500 h-full" 
                      style={{ width: '72%' }}
                    ></div>
                  </div>
                  <div className="text-green-400 font-medium">72%</div>
                </div>
                <div className="text-xs text-gray-400 mt-2">Bullish sentiment dominates the market</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Enhanced Custom Styles */}
      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(30, 41, 59, 0.3);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(99, 102, 241, 0.5);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(79, 70, 229, 0.8);
        }
        
        /* Enhanced Mobile Responsiveness */
        @media (max-width: 768px) {
          .mobile-stack {
            grid-template-columns: 1fr;
          }
          .mobile-hide {
            display: none;
          }
          .mobile-full {
            grid-column: 1 / -1;
          }
        }
        
        /* Trading animations */
        @keyframes pulse-green {
          0%, 100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4); }
          50% { box-shadow: 0 0 0 10px rgba(34, 197, 94, 0); }
        }
        
        @keyframes pulse-red {
          0%, 100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
          50% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
        }
        
        .pulse-green {
          animation: pulse-green 2s infinite;
        }
        
        .pulse-red {
          animation: pulse-red 2s infinite;
        }
        
        /* Chart hover effects */
        .chart-indicator:hover {
          transform: scale(1.05);
          transition: transform 0.2s ease;
        }
        
        /* Enhanced gradient animations */
        @keyframes gradient-shift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        .animated-gradient {
          background: linear-gradient(-45deg, #1e293b, #334155, #475569, #64748b);
          background-size: 400% 400%;
          animation: gradient-shift 15s ease infinite;
        }
      `}</style>
    </div>
  );
};

export default TradingConsole;
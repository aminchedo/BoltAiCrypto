import React, { useState, useEffect } from 'react';
import { apiService } from '@/services/apiService';
import { useToast } from '@/hooks/useToast';

interface Order {
  id: string;
  symbol: string;
  side: 'buy' | 'sell';
  type: 'market' | 'limit';
  status: 'new' | 'filled' | 'partially_filled' | 'canceled' | 'rejected';
  amount: number;
  filled: number;
  price?: number;
  executedPrice?: number;
  timestamp: number;
}

interface OrderHistoryProps {
  symbol?: string;
  limit?: number;
  onOrderCancel?: () => void;
}

export const OrderHistory: React.FC<OrderHistoryProps> = ({
  symbol,
  limit = 10,
  onOrderCancel,
}) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const { showToast } = useToast();
  
  // Fetch order history
  const fetchOrders = async () => {
    try {
      setIsLoading(true);
      const status = filter !== 'all' ? filter : undefined;
      const response = await apiService.getOrderHistory(symbol, status, limit);
      setOrders(response.data);
    } catch (error) {
      console.error('Error fetching order history:', error);
      showToast({
        title: 'Error',
        description: 'Failed to fetch order history',
        type: 'error',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Fetch orders on mount and when filter changes
  useEffect(() => {
    fetchOrders();
    
    // Set up polling for order updates
    const intervalId = setInterval(fetchOrders, 10000);
    
    return () => {
      clearInterval(intervalId);
    };
  }, [symbol, filter, limit]);
  
  // Handle order cancellation
  const handleCancelOrder = async (orderId: string) => {
    try {
      await apiService.cancelOrder(orderId);
      showToast({
        title: 'Order Canceled',
        description: 'Your order has been canceled successfully',
        type: 'success',
      });
      fetchOrders();
      if (onOrderCancel) {
        onOrderCancel();
      }
    } catch (error) {
      console.error('Error canceling order:', error);
      showToast({
        title: 'Error',
        description: 'Failed to cancel order',
        type: 'error',
      });
    }
  };
  
  // Format timestamp to readable date
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };
  
  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'filled':
        return 'bg-green-100 text-green-800';
      case 'partially_filled':
        return 'bg-blue-100 text-blue-800';
      case 'new':
        return 'bg-yellow-100 text-yellow-800';
      case 'canceled':
        return 'bg-gray-100 text-gray-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Order History</h2>
        
        {/* Filter controls */}
        <div className="flex space-x-2">
          <select
            className="px-2 py-1 border border-gray-300 dark:border-gray-600 rounded-md text-sm"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Orders</option>
            <option value="new">Open</option>
            <option value="filled">Filled</option>
            <option value="partially_filled">Partially Filled</option>
            <option value="canceled">Canceled</option>
          </select>
          
          <button
            onClick={fetchOrders}
            className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            title="Refresh"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center py-8">
          <svg className="animate-spin h-8 w-8 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No orders found
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900">
              <tr>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Symbol
                </th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Type
                </th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Side
                </th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Price
                </th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Amount
                </th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-3 py-2 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {orders.map((order) => (
                <tr key={order.id}>
                  <td className="px-3 py-2 whitespace-nowrap text-xs text-gray-500 dark:text-gray-400">
                    {formatDate(order.timestamp)}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs">
                    {order.symbol}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs">
                    {order.type.charAt(0).toUpperCase() + order.type.slice(1)}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs">
                    <span className={order.side === 'buy' ? 'text-green-600' : 'text-red-600'}>
                      {order.side.charAt(0).toUpperCase() + order.side.slice(1)}
                    </span>
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs">
                    {order.executedPrice || order.price || 'Market'}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs">
                    {order.filled > 0 && order.filled < order.amount
                      ? `${order.filled}/${order.amount}`
                      : order.amount}
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(order.status)}`}>
                      {order.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap text-xs text-right">
                    {order.status === 'new' && (
                      <button
                        onClick={() => handleCancelOrder(order.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Cancel
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default OrderHistory;
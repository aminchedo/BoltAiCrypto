'use client';

import { useEffect, useRef, useState } from 'react';
import { 
  createChart, 
  IChartApi, 
  ISeriesApi, 
  LineStyle, 
  CrosshairMode,
  PriceScaleMode,
  ColorType
} from 'lightweight-charts';
import { ChevronDown, Maximize2, Minimize2, Settings, BarChart2, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { Spinner } from '@/components/ui/Spinner';
import { Switch } from '@/components/ui/Switch';
import { config } from '@/lib/config';
import { useChartData, CandlestickData, IndicatorData } from '@/hooks/useChartData';

interface TradingViewChartProps {
  symbol: string;
  data?: CandlestickData[];
  isLoading?: boolean;
  onTimeframeChange?: (timeframe: string) => void;
  onSymbolChange?: (symbol: string) => void;
  height?: number;
  availableSymbols?: { value: string; label: string }[];
}

export function TradingViewChart({
  symbol,
  data,
  isLoading: externalLoading = false,
  onTimeframeChange,
  onSymbolChange,
  height = 400,
  availableSymbols = [],
}: TradingViewChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const indicatorContainerRef = useRef<HTMLDivElement>(null);
  const [chartInstance, setChartInstance] = useState<IChartApi | null>(null);
  const [indicatorChartInstance, setIndicatorChartInstance] = useState<IChartApi | null>(null);
  const [candleSeries, setCandleSeries] = useState<ISeriesApi<'Candlestick'> | null>(null);
  const [timeframe, setTimeframe] = useState(config.chart.defaultTimeframe);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showRSI, setShowRSI] = useState(true);
  const [showMACD, setShowMACD] = useState(true);
  const [showBollingerBands, setShowBollingerBands] = useState(false);
  
  // Fetch chart data if not provided externally
  const { 
    candlestickData: fetchedData, 
    indicatorData, 
    isLoading: dataLoading, 
    error 
  } = useChartData(symbol, timeframe);
  
  const chartData = data || fetchedData;
  const isLoading = externalLoading || dataLoading;
  
  // Initialize main chart
  useEffect(() => {
    if (!chartContainerRef.current) return;
    
    // Create chart
    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: height * 0.7, // Main chart takes 70% of total height
      layout: {
        background: { color: '#1e293b' },
        textColor: '#94a3b8',
      },
      grid: {
        vertLines: { color: '#334155' },
        horzLines: { color: '#334155' },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          width: 1,
          color: '#64748b',
          style: LineStyle.Dashed,
        },
        horzLine: {
          width: 1,
          color: '#64748b',
          style: LineStyle.Dashed,
        },
      },
      timeScale: {
        borderColor: '#334155',
        timeVisible: true,
        secondsVisible: false,
      },
      rightPriceScale: {
        borderColor: '#334155',
      },
      handleScroll: {
        vertTouchDrag: false,
      },
    });
    
    // Create candlestick series
    const series = chart.addCandlestickSeries({
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderVisible: false,
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    });
    
    // Handle resize
    const handleResize = () => {
      if (chartContainerRef.current && chart) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
        });
      }
      
      if (indicatorContainerRef.current && indicatorChartInstance) {
        indicatorChartInstance.applyOptions({
          width: indicatorContainerRef.current.clientWidth,
        });
      }
    };
    
    window.addEventListener('resize', handleResize);
    
    // Save instances
    setChartInstance(chart);
    setCandleSeries(series);
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      chart.remove();
      setChartInstance(null);
      setCandleSeries(null);
    };
  }, [height]);
  
  // Initialize indicator chart
  useEffect(() => {
    if (!indicatorContainerRef.current) return;
    
    // Create indicator chart
    const chart = createChart(indicatorContainerRef.current, {
      width: indicatorContainerRef.current.clientWidth,
      height: height * 0.3, // Indicator chart takes 30% of total height
      layout: {
        background: { color: '#1e293b' },
        textColor: '#94a3b8',
      },
      grid: {
        vertLines: { color: '#334155' },
        horzLines: { color: '#334155' },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          width: 1,
          color: '#64748b',
          style: LineStyle.Dashed,
        },
        horzLine: {
          width: 1,
          color: '#64748b',
          style: LineStyle.Dashed,
        },
      },
      timeScale: {
        borderColor: '#334155',
        timeVisible: true,
        secondsVisible: false,
        visible: false, // Hide time scale on indicator chart
      },
      rightPriceScale: {
        borderColor: '#334155',
      },
      handleScroll: false,
      handleScale: false,
    });
    
    setIndicatorChartInstance(chart);
    
    // Cleanup
    return () => {
      chart.remove();
      setIndicatorChartInstance(null);
    };
  }, [height]);
  
  // Sync charts' time scales
  useEffect(() => {
    if (chartInstance && indicatorChartInstance) {
      // Sync time scales
      chartInstance.timeScale().subscribeVisibleTimeRangeChange(timeRange => {
        if (timeRange) {
          indicatorChartInstance.timeScale().setVisibleRange(timeRange);
        }
      });
      
      chartInstance.timeScale().subscribeCrosshairMove(param => {
        indicatorChartInstance.setCrosshairPosition(
          param.point?.x,
          param.point?.y,
          param.paneIndex
        );
      });
    }
  }, [chartInstance, indicatorChartInstance]);
  
  // Update chart data
  useEffect(() => {
    if (candleSeries && chartData && chartData.length > 0) {
      candleSeries.setData(chartData);
      
      // Add Bollinger Bands if enabled
      if (showBollingerBands && chartInstance && indicatorData) {
        // Remove existing BB lines if any
        chartInstance.series().forEach(series => {
          if (series.options().id?.toString().includes('bb-')) {
            chartInstance.removeSeries(series);
          }
        });
        
        // Add upper band
        const upperBandSeries = chartInstance.addLineSeries({
          id: 'bb-upper',
          color: '#64748b',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          priceScaleId: 'right',
        });
        upperBandSeries.setData(indicatorData.bollingerBands.upper);
        
        // Add middle band
        const middleBandSeries = chartInstance.addLineSeries({
          id: 'bb-middle',
          color: '#94a3b8',
          lineWidth: 1,
          lineStyle: LineStyle.Solid,
          priceScaleId: 'right',
        });
        middleBandSeries.setData(indicatorData.bollingerBands.middle);
        
        // Add lower band
        const lowerBandSeries = chartInstance.addLineSeries({
          id: 'bb-lower',
          color: '#64748b',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          priceScaleId: 'right',
        });
        lowerBandSeries.setData(indicatorData.bollingerBands.lower);
      } else if (!showBollingerBands && chartInstance) {
        // Remove BB lines if disabled
        chartInstance.series().forEach(series => {
          if (series.options().id?.toString().includes('bb-')) {
            chartInstance.removeSeries(series);
          }
        });
      }
      
      // Fit content
      if (chartInstance) {
        chartInstance.timeScale().fitContent();
      }
    }
  }, [candleSeries, chartInstance, chartData, showBollingerBands, indicatorData]);
  
  // Update indicator data
  useEffect(() => {
    if (indicatorChartInstance && indicatorData) {
      // Clear existing series
      indicatorChartInstance.series().forEach(series => {
        indicatorChartInstance.removeSeries(series);
      });
      
      // Add RSI if enabled
      if (showRSI) {
        const rsiSeries = indicatorChartInstance.addLineSeries({
          color: '#0ea5e9',
          lineWidth: 2,
          priceScaleId: 'right',
          title: 'RSI (14)',
          pane: 0,
        });
        
        // Add RSI overbought/oversold levels
        const overboughtSeries = indicatorChartInstance.addLineSeries({
          color: '#64748b',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          priceScaleId: 'right',
          pane: 0,
        });
        
        const oversoldSeries = indicatorChartInstance.addLineSeries({
          color: '#64748b',
          lineWidth: 1,
          lineStyle: LineStyle.Dashed,
          priceScaleId: 'right',
          pane: 0,
        });
        
        // Set RSI data
        rsiSeries.setData(indicatorData.rsi);
        
        // Set overbought/oversold levels (70/30)
        const overboughtData = indicatorData.rsi.map(item => ({ time: item.time, value: 70 }));
        const oversoldData = indicatorData.rsi.map(item => ({ time: item.time, value: 30 }));
        overboughtSeries.setData(overboughtData);
        oversoldSeries.setData(oversoldData);
        
        // Set visible range for RSI (0-100)
        rsiSeries.priceScale().applyOptions({
          autoScale: false,
          scaleMargins: {
            top: 0.1,
            bottom: 0.1,
          },
          minValue: 0,
          maxValue: 100,
        });
      }
      
      // Add MACD if enabled
      if (showMACD) {
        // MACD Line
        const macdLineSeries = indicatorChartInstance.addLineSeries({
          color: '#0ea5e9',
          lineWidth: 2,
          priceScaleId: 'right',
          title: 'MACD',
          pane: 0,
        });
        
        // Signal Line
        const signalLineSeries = indicatorChartInstance.addLineSeries({
          color: '#f59e0b',
          lineWidth: 2,
          priceScaleId: 'right',
          title: 'Signal',
          pane: 0,
        });
        
        // Histogram
        const histogramSeries = indicatorChartInstance.addHistogramSeries({
          color: '#64748b',
          priceScaleId: 'right',
          pane: 0,
        });
        
        // Set data
        macdLineSeries.setData(indicatorData.macd.line);
        signalLineSeries.setData(indicatorData.macd.signal);
        
        // Set histogram data with colors
        const histogramData = indicatorData.macd.histogram.map(item => {
          if (item.value === null) return item;
          return {
            time: item.time,
            value: item.value,
            color: item.value >= 0 ? '#22c55e' : '#ef4444',
          };
        });
        histogramSeries.setData(histogramData);
        
        // Auto-scale the price scale
        macdLineSeries.priceScale().applyOptions({
          autoScale: true,
          scaleMargins: {
            top: 0.1,
            bottom: 0.1,
          },
        });
      }
      
      // Fit content
      indicatorChartInstance.timeScale().fitContent();
    }
  }, [indicatorChartInstance, indicatorData, showRSI, showMACD]);
  
  // Handle timeframe change
  const handleTimeframeChange = (value: string) => {
    setTimeframe(value);
    if (onTimeframeChange) {
      onTimeframeChange(value);
    }
  };
  
  // Handle symbol change
  const handleSymbolChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (onSymbolChange) {
      onSymbolChange(e.target.value);
    }
  };
  
  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!chartContainerRef.current || !chartInstance || !indicatorContainerRef.current || !indicatorChartInstance) return;
    
    setIsFullscreen(!isFullscreen);
    
    if (!isFullscreen) {
      // Enter fullscreen
      chartInstance.applyOptions({
        height: (window.innerHeight - 100) * 0.7,
      });
      indicatorChartInstance.applyOptions({
        height: (window.innerHeight - 100) * 0.3,
      });
    } else {
      // Exit fullscreen
      chartInstance.applyOptions({
        height: height * 0.7,
      });
      indicatorChartInstance.applyOptions({
        height: height * 0.3,
      });
    }
  };
  
  // Toggle indicators
  const toggleRSI = () => {
    setShowRSI(!showRSI);
    if (showMACD && !showRSI) {
      setShowMACD(false); // If turning on RSI and MACD is on, turn off MACD
    }
  };
  
  const toggleMACD = () => {
    setShowMACD(!showMACD);
    if (showRSI && !showMACD) {
      setShowRSI(false); // If turning on MACD and RSI is on, turn off RSI
    }
  };
  
  const toggleBollingerBands = () => {
    setShowBollingerBands(!showBollingerBands);
  };
  
  return (
    <div className={`relative ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-900 p-4' : ''}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <Select
            value={symbol}
            onChange={handleSymbolChange}
            options={availableSymbols.length > 0 ? availableSymbols : [{ value: symbol, label: symbol }]}
            className="w-32"
          />
          
          <div className="flex items-center space-x-1">
            {config.chart.availableTimeframes.map((tf) => (
              <Button
                key={tf}
                size="sm"
                variant={timeframe === tf ? 'default' : 'subtle'}
                onClick={() => handleTimeframeChange(tf)}
              >
                {tf}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <span className="text-xs text-slate-400">BB</span>
              <Switch checked={showBollingerBands} onCheckedChange={toggleBollingerBands} />
            </div>
            
            <div className="flex items-center space-x-1">
              <span className="text-xs text-slate-400">RSI</span>
              <Switch checked={showRSI} onCheckedChange={toggleRSI} />
            </div>
            
            <div className="flex items-center space-x-1">
              <span className="text-xs text-slate-400">MACD</span>
              <Switch checked={showMACD} onCheckedChange={toggleMACD} />
            </div>
          </div>
          
          <div className="flex items-center space-x-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {}}
              title="Chart Settings"
            >
              <Settings className="h-4 w-4" />
            </Button>
            
            <Button
              size="sm"
              variant="ghost"
              onClick={toggleFullscreen}
              title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
            >
              {isFullscreen ? (
                <Minimize2 className="h-4 w-4" />
              ) : (
                <Maximize2 className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>
      
      <div className="relative w-full rounded-lg overflow-hidden bg-slate-800">
        <div
          ref={chartContainerRef}
          className="w-full"
          style={{ height: isFullscreen ? `${(window.innerHeight - 100) * 0.7}px` : `${height * 0.7}px` }}
        />
        
        <div
          ref={indicatorContainerRef}
          className="w-full border-t border-slate-700"
          style={{ height: isFullscreen ? `${(window.innerHeight - 100) * 0.3}px` : `${height * 0.3}px` }}
        />
        
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-800 bg-opacity-75 z-10">
            <Spinner size="lg" />
          </div>
        )}
        
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-800 bg-opacity-75 z-10">
            <div className="text-red-500 text-center p-4">
              <p className="font-bold">Error loading chart data</p>
              <p className="text-sm">{error.message}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
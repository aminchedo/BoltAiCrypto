import React, { useState, useEffect } from 'react';
import hybridSignalService from '@/services/hybridSignalService';
import { HybridSignal } from '@/services/hybridTradingService';

interface HybridSignalWidgetProps {
  symbols?: string[];
  refreshInterval?: number; // in milliseconds
}

const HybridSignalWidget: React.FC<HybridSignalWidgetProps> = ({ 
  symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT'],
  refreshInterval = 60000 // 1 minute
}) => {
  const [signals, setSignals] = useState<HybridSignal[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedSignal, setSelectedSignal] = useState<HybridSignal | null>(null);

  // Fetch signals on component mount and at regular intervals
  useEffect(() => {
    const fetchSignals = async () => {
      try {
        setLoading(true);
        const data = await hybridSignalService.getLiveSignals(symbols);
        setSignals(data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch signals. Please try again later.');
        console.error('Error fetching signals:', err);
      } finally {
        setLoading(false);
      }
    };

    // Initial fetch
    fetchSignals();

    // Set up interval for regular updates
    const intervalId = setInterval(fetchSignals, refreshInterval);

    // Clean up interval on component unmount
    return () => clearInterval(intervalId);
  }, [symbols, refreshInterval]);

  // Format price with appropriate decimal places
  const formatPrice = (price: number, symbol: string) => {
    // BTC and ETH typically use 2 decimal places, others may use more
    const decimals = symbol.includes('BTC') || symbol.includes('ETH') ? 2 : 4;
    return price.toFixed(decimals);
  };

  // Get color based on signal direction
  const getDirectionColor = (direction: string) => {
    switch (direction) {
      case 'BUY':
        return 'text-green-500';
      case 'SELL':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  // Get color based on confidence level
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'bg-green-500';
    if (confidence >= 70) return 'bg-green-400';
    if (confidence >= 60) return 'bg-yellow-500';
    return 'bg-gray-400';
  };

  // Format percentage
  const formatPercentage = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  // Handle signal click to show details
  const handleSignalClick = (signal: HybridSignal) => {
    setSelectedSignal(signal === selectedSignal ? null : signal);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4">
      <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-white flex items-center">
        <span className="mr-2">🤖</span> AI Hybrid Trading Signals
      </h2>
      
      {loading && signals.length === 0 && (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {signals.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Symbol</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Signal</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Confidence</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Entry</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Target</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Stop Loss</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">R:R</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {signals.map((signal) => (
                <React.Fragment key={signal.id}>
                  <tr 
                    className={`hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer ${selectedSignal?.id === signal.id ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                    onClick={() => handleSignalClick(signal)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{signal.symbol}</td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm font-bold ${getDirectionColor(signal.direction)}`}>{signal.direction}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className={`h-2.5 rounded-full ${getConfidenceColor(signal.confidence)}`} 
                            style={{ width: `${signal.confidence}%` }}
                          ></div>
                        </div>
                        <span className="ml-2 text-sm text-gray-600 dark:text-gray-300">{signal.confidence}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{formatPrice(signal.entryPrice, signal.symbol)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-green-500">{formatPrice(signal.takeProfit, signal.symbol)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-red-500">{formatPrice(signal.stopLoss, signal.symbol)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{signal.riskRewardRatio.toFixed(2)}</td>
                  </tr>
                  
                  {selectedSignal?.id === signal.id && (
                    <tr className="bg-gray-50 dark:bg-gray-700/50">
                      <td colSpan={7} className="px-6 py-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h3 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Algorithm Breakdown</h3>
                            <div className="space-y-2">
                              {Object.entries(signal.algorithmBreakdown).map(([key, value]) => {
                                if (key === 'finalScore') return null;
                                const typedValue = value as { score: number; weight: number; contribution: number };
                                return (
                                  <div key={key} className="flex items-center">
                                    <div className="w-40 text-sm text-gray-600 dark:text-gray-300">
                                      {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:
                                    </div>
                                    <div className="flex-1">
                                      <div className="w-full bg-gray-200 rounded-full h-2">
                                        <div 
                                          className={`h-2 rounded-full ${typedValue.score >= 0 ? 'bg-green-500' : 'bg-red-500'}`} 
                                          style={{ width: `${Math.abs(typedValue.score) * 100}%` }}
                                        ></div>
                                      </div>
                                    </div>
                                    <div className="ml-2 text-xs text-gray-500 dark:text-gray-400 w-16">
                                      {(typedValue.weight * 100).toFixed(0)}%
                                    </div>
                                  </div>
                                );
                              })}
                              <div className="flex items-center font-bold">
                                <div className="w-40 text-sm text-gray-800 dark:text-white">
                                  Final Score:
                                </div>
                                <div className="flex-1">
                                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                                    <div 
                                      className={`h-2.5 rounded-full ${signal.algorithmBreakdown.finalScore >= 0 ? 'bg-green-600' : 'bg-red-600'}`} 
                                      style={{ width: `${Math.abs(signal.algorithmBreakdown.finalScore) * 100}%` }}
                                    ></div>
                                  </div>
                                </div>
                                <div className="ml-2 text-xs font-bold text-gray-800 dark:text-white w-16">
                                  {(signal.algorithmBreakdown.finalScore * 100).toFixed(1)}%
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div>
                            <h3 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Risk Assessment</h3>
                            <div className="grid grid-cols-2 gap-2">
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Risk Score</div>
                                <div className="text-lg font-bold text-gray-800 dark:text-white">{signal.riskAssessment.riskScore.toFixed(0)}/100</div>
                              </div>
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Position Size</div>
                                <div className="text-lg font-bold text-gray-800 dark:text-white">{signal.riskAssessment.positionSizeRecommendation.toFixed(1)}%</div>
                              </div>
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Market Impact</div>
                                <div className="text-lg font-bold text-gray-800 dark:text-white">{signal.riskAssessment.marketImpact}</div>
                              </div>
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Max Loss</div>
                                <div className="text-lg font-bold text-red-500">{formatPrice(signal.riskAssessment.maxLossAmount, signal.symbol)}</div>
                              </div>
                            </div>
                            
                            <h3 className="text-lg font-semibold mt-4 mb-2 text-gray-800 dark:text-white">Market Conditions</h3>
                            <div className="grid grid-cols-2 gap-2">
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Volatility</div>
                                <div className="text-lg font-bold text-gray-800 dark:text-white">{signal.marketConditions.volatility.toFixed(1)}%</div>
                              </div>
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Volume Profile</div>
                                <div className="text-lg font-bold text-gray-800 dark:text-white">{signal.marketConditions.volumeProfile}</div>
                              </div>
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Trend Strength</div>
                                <div className="text-lg font-bold text-gray-800 dark:text-white">{signal.marketConditions.trendStrength.toFixed(1)}%</div>
                              </div>
                              <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Support/Resistance</div>
                                <div className="text-xs font-medium text-gray-800 dark:text-white">
                                  S: {formatPrice(signal.marketConditions.supportResistance.support, signal.symbol)}
                                  <br />
                                  R: {formatPrice(signal.marketConditions.supportResistance.resistance, signal.symbol)}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex justify-end space-x-2">
                          <button className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                            Add to Watchlist
                          </button>
                          <button className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">
                            Execute Trade
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {!loading && signals.length === 0 && !error && (
        <div className="text-center py-10 text-gray-500 dark:text-gray-400">
          No signals available at this time. Please check back later.
        </div>
      )}
      
      <div className="mt-4 text-xs text-gray-500 dark:text-gray-400 flex justify-between items-center">
        <div>
          Last updated: {new Date().toLocaleTimeString()}
        </div>
        <div className="flex items-center">
          <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-1"></span>
          <span>Live</span>
        </div>
      </div>
    </div>
  );
};

export default HybridSignalWidget;
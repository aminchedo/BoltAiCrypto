import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { apiService } from '@/services/apiService';
import OrderPreview from './OrderPreview';
import { useToast } from '@/hooks/useToast';
import useMarketData from '@/hooks/useMarketData';

// Order type definitions
export type OrderType = 'market' | 'limit';
export type OrderSide = 'buy' | 'sell';

// Form schema validation
const orderFormSchema = z.object({
  symbol: z.string().min(1, 'Symbol is required'),
  orderType: z.enum(['market', 'limit']),
  side: z.enum(['buy', 'sell']),
  amount: z.number().positive('Amount must be positive'),
  price: z.number().positive('Price must be positive').optional(),
  total: z.number().positive('Total must be positive').optional(),
  slippage: z.number().min(0).max(5).optional(),
});

type OrderFormValues = z.infer<typeof orderFormSchema>;

interface OrderEntryFormProps {
  defaultSymbol?: string;
  onSubmit?: (values: OrderFormValues) => void;
  onOrderSubmitted?: () => void;
}

export const OrderEntryForm: React.FC<OrderEntryFormProps> = ({
  defaultSymbol = 'BTC/USDT',
  onSubmit,
  onOrderSubmitted,
}) => {
  const [orderType, setOrderType] = useState<OrderType>('market');
  const [orderSide, setOrderSide] = useState<OrderSide>('buy');
  const [isPreviewVisible, setIsPreviewVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [availableBalance, setAvailableBalance] = useState({
    base: 0,
    quote: 0,
  });
  const [isLoadingBalance, setIsLoadingBalance] = useState(true);
  const [orderData, setOrderData] = useState<any>(null);
  const { showToast } = useToast();
  
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
    reset,
  } = useForm<OrderFormValues>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      symbol: defaultSymbol,
      orderType: 'market',
      side: 'buy',
      amount: undefined,
      price: undefined,
      slippage: 1,
    },
  });
  
  // Watch form values for calculations
  const watchAmount = watch('amount');
  const watchPrice = watch('price');
  const watchSymbol = watch('symbol');
  
  // Use the market data hook for real-time price updates
  const { 
    marketData, 
    isLoading: isLoadingPrice, 
    isRealTime 
  } = useMarketData(watchSymbol);
  
  // Update price when market data changes
  useEffect(() => {
    if (marketData) {
      // If limit order and no price set, use current price
      if (orderType === 'limit' && !watchPrice) {
        setValue('price', marketData.price);
      }
    }
  }, [marketData, orderType, watchPrice, setValue]);
  
  // Fetch user balance
  useEffect(() => {
    const fetchBalance = async () => {
      try {
        setIsLoadingBalance(true);
        const portfolio = await apiService.getPortfolio();
        
        // Extract base and quote currency from symbol (e.g., "BTC/USDT" -> "BTC", "USDT")
        const [baseCurrency, quoteCurrency] = watchSymbol.split('/');
        
        // Find balances for the currencies
        const baseBalance = portfolio.balances.find(
          (b: any) => b.currency === baseCurrency
        )?.available || 0;
        
        const quoteBalance = portfolio.balances.find(
          (b: any) => b.currency === quoteCurrency
        )?.available || 0;
        
        setAvailableBalance({
          base: baseBalance,
          quote: quoteBalance,
        });
      } catch (error) {
        console.error('Error fetching portfolio:', error);
        showToast({
          title: 'Error',
          description: 'Failed to fetch available balance',
          type: 'error',
        });
      } finally {
        setIsLoadingBalance(false);
      }
    };
    
    fetchBalance();
  }, [watchSymbol, showToast]);
  
  // Calculate total based on amount and price
  useEffect(() => {
    if (watchAmount && watchPrice) {
      setValue('total', watchAmount * watchPrice);
    }
  }, [watchAmount, watchPrice, setValue]);
  
  // Handle form submission
  const processSubmit = (data: OrderFormValues) => {
    const price = marketData?.price || 0;
    
    // Calculate estimated fee (0.1% in this example)
    const estimatedFee = data.orderType === 'limit' && data.price
      ? data.amount * data.price * 0.001
      : data.amount * price * 0.001;
    
    // Store order data for preview
    setOrderData({
      ...data,
      estimatedFee,
      estimatedPrice: price,
    });
    
    // Show preview
    setIsPreviewVisible(true);
    
    // Call onSubmit prop if provided
    if (onSubmit) {
      onSubmit(data);
    }
  };
  
  // Handle order confirmation
  const handleConfirmOrder = async () => {
    try {
      setIsSubmitting(true);
      
      // Extract base and quote currency from symbol
      const [baseCurrency, quoteCurrency] = orderData.symbol.split('/');
      
      // Prepare order data for API
      const apiOrderData = {
        symbol: orderData.symbol,
        side: orderData.side,
        type: orderData.orderType,
        amount: orderData.amount,
        price: orderData.orderType === 'limit' ? orderData.price : undefined,
        slippage: orderData.orderType === 'market' ? orderData.slippage : undefined,
      };
      
      // Submit order to API
      const response = await apiService.submitOrder(apiOrderData);
      
      // Show success message
      showToast({
        title: 'Order Submitted',
        description: `Your ${orderData.side} order has been submitted successfully.`,
        type: 'success',
      });
      
      // Reset form and state
      reset({
        symbol: watchSymbol,
        orderType: 'market',
        side: 'buy',
        amount: undefined,
        price: undefined,
        slippage: 1,
      });
      setIsPreviewVisible(false);
      setOrderData(null);
      
      // Notify parent component
      if (onOrderSubmitted) {
        onOrderSubmitted();
      }
    } catch (error) {
      console.error('Error submitting order:', error);
      
      // Show error message
      showToast({
        title: 'Order Failed',
        description: 'There was an error submitting your order. Please try again.',
        type: 'error',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle preview cancellation
  const handleCancelPreview = () => {
    setIsPreviewVisible(false);
  };
  
  // Extract base and quote currency from symbol
  const [baseCurrency, quoteCurrency] = watchSymbol.split('/');
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      {isPreviewVisible ? (
        <OrderPreview
          symbol={orderData.symbol}
          orderType={orderData.orderType}
          side={orderData.side}
          amount={orderData.amount}
          price={orderData.price}
          total={orderData.orderType === 'limit' ? orderData.amount * orderData.price : undefined}
          estimatedFee={orderData.estimatedFee}
          estimatedPrice={orderData.estimatedPrice}
          onConfirm={handleConfirmOrder}
          onCancel={handleCancelPreview}
          isSubmitting={isSubmitting}
        />
      ) : (
        <>
          <h2 className="text-lg font-semibold mb-4">Place Order</h2>
          
          {/* Current price display */}
          <div className="mb-4 text-center">
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Current Price {isRealTime && <span className="text-green-500 text-xs ml-1">(Live)</span>}
            </div>
            {isLoadingPrice ? (
              <div className="h-6 w-24 mx-auto bg-gray-200 dark:bg-gray-700 animate-pulse rounded"></div>
            ) : (
              <div className="text-xl font-semibold">
                {marketData?.price ? `${marketData.price.toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })} ${quoteCurrency}` : 'N/A'}
              </div>
            )}
          </div>
          
          {/* Order type selector */}
          <div className="flex mb-4">
            <button
              type="button"
              className={`flex-1 py-2 px-4 rounded-l-md ${
                orderType === 'market'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
              }`}
              onClick={() => {
                setOrderType('market');
                setValue('orderType', 'market');
              }}
            >
              Market
            </button>
            <button
              type="button"
              className={`flex-1 py-2 px-4 rounded-r-md ${
                orderType === 'limit'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
              }`}
              onClick={() => {
                setOrderType('limit');
                setValue('orderType', 'limit');
                if (marketData?.price) {
                  setValue('price', marketData.price);
                }
              }}
            >
              Limit
            </button>
          </div>
          
          {/* Buy/Sell selector */}
          <div className="flex mb-4">
            <button
              type="button"
              className={`flex-1 py-2 px-4 rounded-l-md ${
                orderSide === 'buy'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
              }`}
              onClick={() => {
                setOrderSide('buy');
                setValue('side', 'buy');
              }}
            >
              Buy
            </button>
            <button
              type="button"
              className={`flex-1 py-2 px-4 rounded-r-md ${
                orderSide === 'sell'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
              }`}
              onClick={() => {
                setOrderSide('sell');
                setValue('side', 'sell');
              }}
            >
              Sell
            </button>
          </div>
          
          <form onSubmit={handleSubmit(processSubmit)}>
            {/* Symbol input */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Symbol
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md"
                {...register('symbol')}
              />
              {errors.symbol && (
                <p className="mt-1 text-sm text-red-600">{errors.symbol.message}</p>
              )}
            </div>
            
            {/* Price input (for limit orders) */}
            {orderType === 'limit' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Price
                </label>
                <input
                  type="number"
                  step="any"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md"
                  {...register('price', { valueAsNumber: true })}
                />
                {errors.price && (
                  <p className="mt-1 text-sm text-red-600">{errors.price.message}</p>
                )}
              </div>
            )}
            
            {/* Amount input */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Amount
              </label>
              <div className="flex items-center">
                <input
                  type="number"
                  step="any"
                  className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-l-md"
                  {...register('amount', { valueAsNumber: true })}
                />
                <button
                  type="button"
                  className="px-3 py-2 bg-gray-200 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-r-md"
                  onClick={() => {
                    // Set max amount based on available balance
                    if (orderSide === 'buy') {
                      const price = orderType === 'limit' ? watchPrice : marketData?.price;
                      if (price && price > 0) {
                        setValue('amount', availableBalance.quote / price * 0.99); // 99% to account for fees
                      }
                    } else {
                      setValue('amount', availableBalance.base * 0.99); // 99% to account for fees
                    }
                  }}
                >
                  Max
                </button>
              </div>
              {errors.amount && (
                <p className="mt-1 text-sm text-red-600">{errors.amount.message}</p>
              )}
            </div>
            
            {/* Total calculation */}
            {orderType === 'limit' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Total
                </label>
                <input
                  type="number"
                  step="any"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-100 dark:bg-gray-900"
                  value={watchAmount && watchPrice ? watchAmount * watchPrice : ''}
                />
              </div>
            )}
            
            {/* Slippage tolerance (for market orders) */}
            {orderType === 'market' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Slippage Tolerance (%)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="5"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md"
                  {...register('slippage', { valueAsNumber: true })}
                />
                {errors.slippage && (
                  <p className="mt-1 text-sm text-red-600">{errors.slippage.message}</p>
                )}
              </div>
            )}
            
            {/* Available balance display */}
            <div className="mb-4 text-sm text-gray-600 dark:text-gray-400">
              {isLoadingBalance ? (
                <div className="h-4 w-32 bg-gray-200 dark:bg-gray-700 animate-pulse rounded"></div>
              ) : (
                <p>
                  Available: {orderSide === 'buy' 
                    ? `${availableBalance.quote.toFixed(2)} ${quoteCurrency}` 
                    : `${availableBalance.base.toFixed(8)} ${baseCurrency}`}
                </p>
              )}
            </div>
            
            {/* Submit button */}
            <button
              type="submit"
              className={`w-full py-2 px-4 rounded-md ${
                orderSide === 'buy'
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-red-600 hover:bg-red-700'
              } text-white font-medium`}
              disabled={isLoadingPrice || isLoadingBalance}
            >
              {isLoadingPrice || isLoadingBalance ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Loading...
                </span>
              ) : (
                <>
                  {orderSide === 'buy' ? 'Buy' : 'Sell'} {orderType === 'market' ? 'at market price' : 'at limit price'}
                </>
              )}
            </button>
          </form>
        </>
      )}
    </div>
  );
};

export default OrderEntryForm;
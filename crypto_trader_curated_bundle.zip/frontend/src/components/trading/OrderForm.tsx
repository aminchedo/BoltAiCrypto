'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowDown, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/Tabs';
import { Alert } from '@/components/ui/Alert';
import { PriceDisplay } from '@/components/trading/PriceDisplay';
import { formatCryptoPrice, formatCurrency } from '@/lib/utils';
import { config } from '@/lib/config';

// Order form schema
const orderSchema = z.object({
  symbol: z.string().min(1, 'Symbol is required'),
  type: z.enum(['MARKET', 'LIMIT', 'STOP', 'STOP_LIMIT', 'TAKE_PROFIT', 'OCO']),
  side: z.enum(['BUY', 'SELL']),
  quantity: z.number().positive('Quantity must be positive'),
  price: z.number().positive('Price must be positive').optional(),
  stopPrice: z.number().positive('Stop price must be positive').optional(),
  takeProfitPrice: z.number().positive('Take profit price must be positive').optional(),
  leverage: z.number().min(1).max(config.trading.maxLeverage).optional(),
});

type OrderFormValues = z.infer<typeof orderSchema>;

interface OrderFormProps {
  symbol: string;
  currentPrice: number;
  onSubmit: (values: OrderFormValues) => void;
  isSubmitting?: boolean;
}

export function OrderForm({
  symbol,
  currentPrice,
  onSubmit,
  isSubmitting = false,
}: OrderFormProps) {
  const [orderSide, setOrderSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT'>('MARKET');
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<OrderFormValues>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      symbol,
      type: 'MARKET',
      side: 'BUY',
      quantity: config.trading.defaultOrderSize / currentPrice,
      price: currentPrice,
      leverage: 1,
    },
  });
  
  // Watch form values for calculations
  const quantity = watch('quantity');
  const price = watch('price') || currentPrice;
  const leverage = watch('leverage') || 1;
  
  // Calculate order cost
  const orderCost = quantity * price;
  const leveragedCost = orderCost / leverage;
  
  // Handle order type change
  const handleOrderTypeChange = (value: string) => {
    setOrderType(value as 'MARKET' | 'LIMIT');
    setValue('type', value as any);
  };
  
  // Handle order side change
  const handleOrderSideChange = (value: 'BUY' | 'SELL') => {
    setOrderSide(value);
    setValue('side', value);
  };
  
  // Handle form submission
  const handleFormSubmit = (data: OrderFormValues) => {
    onSubmit(data);
  };
  
  return (
    <div className="bg-dark-800 rounded-lg border border-dark-700 p-4">
      <h3 className="text-lg font-semibold text-white mb-4">Place Order</h3>
      
      <form onSubmit={handleSubmit(handleFormSubmit)}>
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">Symbol</span>
            <PriceDisplay
              price={currentPrice}
              size="sm"
            />
          </div>
          
          <Select
            {...register('symbol')}
            options={[
              { value: symbol, label: symbol },
              // Add more symbols as needed
            ]}
            error={!!errors.symbol}
            helperText={errors.symbol?.message}
          />
        </div>
        
        <div className="mb-4">
          <span className="text-sm text-gray-400 mb-2 block">Order Side</span>
          <div className="grid grid-cols-2 gap-2">
            <Button
              type="button"
              variant={orderSide === 'BUY' ? 'success' : 'outline'}
              fullWidth
              onClick={() => handleOrderSideChange('BUY')}
              leftIcon={<ArrowUp className="h-4 w-4" />}
            >
              Buy
            </Button>
            <Button
              type="button"
              variant={orderSide === 'SELL' ? 'destructive' : 'outline'}
              fullWidth
              onClick={() => handleOrderSideChange('SELL')}
              leftIcon={<ArrowDown className="h-4 w-4" />}
            >
              Sell
            </Button>
          </div>
        </div>
        
        <div className="mb-4">
          <span className="text-sm text-gray-400 mb-2 block">Order Type</span>
          <Tabs defaultValue="MARKET" onValueChange={handleOrderTypeChange}>
            <TabsList className="w-full">
              <TabsTrigger value="MARKET" className="flex-1">Market</TabsTrigger>
              <TabsTrigger value="LIMIT" className="flex-1">Limit</TabsTrigger>
            </TabsList>
            
            <TabsContent value="MARKET">
              <div className="mt-4">
                <div className="mb-4">
                  <label className="text-sm text-gray-400 mb-1 block">Quantity</label>
                  <Input
                    type="number"
                    step="any"
                    {...register('quantity', { valueAsNumber: true })}
                    error={!!errors.quantity}
                    helperText={errors.quantity?.message}
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="LIMIT">
              <div className="mt-4 space-y-4">
                <div>
                  <label className="text-sm text-gray-400 mb-1 block">Quantity</label>
                  <Input
                    type="number"
                    step="any"
                    {...register('quantity', { valueAsNumber: true })}
                    error={!!errors.quantity}
                    helperText={errors.quantity?.message}
                  />
                </div>
                
                <div>
                  <label className="text-sm text-gray-400 mb-1 block">Limit Price</label>
                  <Input
                    type="number"
                    step="any"
                    {...register('price', { valueAsNumber: true })}
                    error={!!errors.price}
                    helperText={errors.price?.message}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="mb-4">
          <button
            type="button"
            className="text-sm text-primary-500 hover:text-primary-400 transition-colors"
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            {showAdvanced ? 'Hide Advanced Options' : 'Show Advanced Options'}
          </button>
          
          {showAdvanced && (
            <div className="mt-2 space-y-4">
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Leverage (x)</label>
                <Input
                  type="number"
                  min="1"
                  max={config.trading.maxLeverage}
                  step="1"
                  {...register('leverage', { valueAsNumber: true })}
                  error={!!errors.leverage}
                  helperText={errors.leverage?.message}
                />
              </div>
              
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Stop Loss</label>
                <Input
                  type="number"
                  step="any"
                  {...register('stopPrice', { valueAsNumber: true })}
                  error={!!errors.stopPrice}
                  helperText={errors.stopPrice?.message}
                />
              </div>
              
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Take Profit</label>
                <Input
                  type="number"
                  step="any"
                  {...register('takeProfitPrice', { valueAsNumber: true })}
                  error={!!errors.takeProfitPrice}
                  helperText={errors.takeProfitPrice?.message}
                />
              </div>
            </div>
          )}
        </div>
        
        <div className="mb-4 p-3 bg-dark-700 rounded-md">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Order Value:</span>
            <span className="text-white">{formatCurrency(orderCost)}</span>
          </div>
          
          {leverage > 1 && (
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Required Margin:</span>
              <span className="text-white">{formatCurrency(leveragedCost)}</span>
            </div>
          )}
          
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Estimated Fee:</span>
            <span className="text-white">{formatCurrency(orderCost * 0.001)}</span>
          </div>
        </div>
        
        <Button
          type="submit"
          variant={orderSide === 'BUY' ? 'success' : 'destructive'}
          fullWidth
          isLoading={isSubmitting}
        >
          {orderSide === 'BUY' ? 'Buy' : 'Sell'} {symbol}
        </Button>
        
        <Alert
          variant="info"
          className="mt-4 text-xs"
          title="Trading Disclaimer"
        >
          Cryptocurrency trading involves significant risk. Only trade with funds you can afford to lose.
        </Alert>
      </form>
    </div>
  );
}
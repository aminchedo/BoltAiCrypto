'use client';

import { formatCryptoPrice } from '@/lib/utils';
import { cn } from '@/lib/utils/cn';
import { ArrowDown, ArrowUp, Minus } from 'lucide-react';

interface PriceDisplayProps {
  price: number;
  previousPrice?: number;
  change?: number;
  showChangeIndicator?: boolean;
  showChangePercentage?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function PriceDisplay({
  price,
  previousPrice,
  change,
  showChangeIndicator = true,
  showChangePercentage = false,
  size = 'md',
  className,
}: PriceDisplayProps) {
  // Calculate change if not provided but previousPrice is available
  const calculatedChange = change ?? (previousPrice ? ((price - previousPrice) / previousPrice) * 100 : 0);
  
  // Determine if price is positive, negative, or neutral
  const direction = calculatedChange > 0 ? 'up' : calculatedChange < 0 ? 'down' : 'neutral';
  
  // Format the price
  const formattedPrice = formatCryptoPrice(price);
  
  // Format the change percentage
  const formattedChange = Math.abs(calculatedChange).toFixed(2) + '%';
  
  return (
    <div className={cn('flex items-center', className)}>
      <span
        className={cn(
          'font-mono',
          {
            'text-sm': size === 'sm',
            'text-base': size === 'md',
            'text-lg font-semibold': size === 'lg',
            'text-success-400': direction === 'up',
            'text-danger-400': direction === 'down',
            'text-gray-400': direction === 'neutral',
          }
        )}
      >
        {formattedPrice}
      </span>
      
      {showChangeIndicator && (
        <span
          className={cn(
            'ml-2 flex items-center',
            {
              'text-xs': size === 'sm',
              'text-sm': size === 'md',
              'text-base': size === 'lg',
              'text-success-400': direction === 'up',
              'text-danger-400': direction === 'down',
              'text-gray-400': direction === 'neutral',
            }
          )}
        >
          {direction === 'up' && <ArrowUp className="h-3 w-3 mr-1" />}
          {direction === 'down' && <ArrowDown className="h-3 w-3 mr-1" />}
          {direction === 'neutral' && <Minus className="h-3 w-3 mr-1" />}
          
          {showChangePercentage && formattedChange}
        </span>
      )}
    </div>
  );
}
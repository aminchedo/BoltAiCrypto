import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain,
  BarChart3,
  DollarSign,
  TrendingUp,
  Settings,
  Menu,
  ChevronLeft,
  ChevronRight,
  Activity,
  Zap,
  Target,
  History,
  Users,
  Bell,
  Shield,
  Globe,
  BookOpen,
  Award,
  Layers,
  PieChart,
  LineChart,
  CandlestickChart,
  Wallet,
  CreditCard,
  Briefcase,
  Monitor,
  TrendingDown,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

interface SidebarProps {
  collapsed?: boolean;
  onToggle?: () => void;
  currentTheme?: 'dark' | 'blue' | 'green';
  onThemeChange?: (theme: 'dark' | 'blue' | 'green') => void;
  connectionStatus?: 'connected' | 'connecting' | 'disconnected';
}

interface NavigationItem {
  id: string;
  name: string;
  icon: any;
  color: string;
  badge?: number;
  subItems?: NavigationItem[];
  isActive?: boolean;
  description?: string;
}

interface PerformanceMetric {
  label: string;
  value: string;
  change: number;
  color: string;
  icon: any;
}

interface AiStatus {
  engine: 'online' | 'offline' | 'learning';
  accuracy: number;
  signals: number;
  lastTrained: Date;
}

const Sidebar: React.FC<SidebarProps> = ({
  collapsed = false,
  onToggle,
  currentTheme = 'dark',
  onThemeChange,
  connectionStatus = 'connected'
}) => {
  const [activeItem, setActiveItem] = useState('dashboard');
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [aiStatus, setAiStatus] = useState<AiStatus>({
    engine: 'online',
    accuracy: 87.4,
    signals: 23,
    lastTrained: new Date(Date.now() - 3600000) // 1 hour ago
  });

  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetric[]>([
    { label: 'Total P&L', value: '+$12,341', change: 5.67, color: 'text-green-400', icon: TrendingUp },
    { label: 'Win Rate', value: '68.4%', change: 2.1, color: 'text-blue-400', icon: Target },
    { label: 'Active Signals', value: '23', change: 0, color: 'text-purple-400', icon: Zap },
    { label: 'Portfolio', value: '$127.8K', change: 1.87, color: 'text-yellow-400', icon: Wallet }
  ]);

  const navigationItems: NavigationItem[] = [
    {
      id: 'dashboard',
      name: 'Dashboard',
      icon: BarChart3,
      color: 'text-blue-400',
      description: 'Overview and analytics'
    },
    {
      id: 'trading',
      name: 'Trading',
      icon: DollarSign,
      color: 'text-green-400',
      description: 'Execute trades and manage positions'
    },
    {
      id: 'signals',
      name: 'AI Signals',
      icon: Brain,
      color: 'text-purple-400',
      badge: 5,
      description: 'AI-powered trading signals'
    },
    {
      id: 'portfolio',
      name: 'Portfolio',
      icon: Briefcase,
      color: 'text-yellow-400',
      description: 'Portfolio management and analysis'
    },
    {
      id: 'analytics',
      name: 'Analytics',
      icon: TrendingUp,
      color: 'text-cyan-400',
      description: 'Advanced analytics and insights'
    },
    {
      id: 'strategy',
      name: 'Strategy Builder',
      icon: Target,
      color: 'text-orange-400',
      description: 'Build and test trading strategies'
    },
    {
      id: 'history',
      name: 'History',
      icon: History,
      color: 'text-gray-400',
      description: 'Trading history and performance'
    },
    {
      id: 'settings',
      name: 'Settings',
      icon: Settings,
      color: 'text-gray-400',
      description: 'Platform configuration'
    }
  ];

  const handleItemClick = (itemId: string, hasSubItems: boolean = false) => {
    if (hasSubItems) {
      setExpandedItems(prev =>
        prev.includes(itemId)
          ? prev.filter(id => id !== itemId)
          : [...prev, itemId]
      );
    } else {
      setActiveItem(itemId);
    }
  };

  const getThemeClasses = () => {
    switch (currentTheme) {
      case 'blue': return 'from-blue-500 to-purple-500';
      case 'green': return 'from-green-500 to-blue-500';
      default: return 'from-gray-800 to-gray-900';
    }
  };

  const getAiStatusColor = () => {
    switch (aiStatus.engine) {
      case 'online': return 'text-green-400';
      case 'learning': return 'text-yellow-400';
      default: return 'text-red-400';
    }
  };

  const getAiStatusIcon = () => {
    switch (aiStatus.engine) {
      case 'online': return <CheckCircle size={10} />;
      case 'learning': return <Activity size={10} />;
      default: return <AlertCircle size={10} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -10 }}
      transition={{ duration: 0.5 }}
      className={`h-full bg-gradient-to-br ${getThemeClasses()} border-r border-white/10 relative`}
    >
      <AnimatePresence mode="wait">
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            className="w-64 h-full flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                  <Brain size={20} className="text-white" />
                </div>
                <span className="text-white font-bold text-sm">AiSmart Pro</span>
              </div>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onToggle}
                className="p-1 hover:bg-white/10 rounded transition-colors"
              >
                <ChevronLeft size={16} className="text-white" />
              </motion.button>
            </div>

            {/* User Profile */}
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                  <span className="text-white font-bold text-sm">JT</span>
                </div>
                <div className="flex-1">
                  <div className="text-white font-medium text-sm">John Trader</div>
                  <div className="text-gray-400 text-xs">Premium Account</div>
                </div>
              </div>
            </div>

            {/* Connection Status */}
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white text-sm font-medium">Connection Status</span>
                <div className={`flex items-center space-x-1 ${getAiStatusColor()}`}>
                  {getAiStatusIcon()}
                  <span className="text-xs">
                    {connectionStatus === 'connected' ? 'Connected' :
                      connectionStatus === 'connecting' ? 'Connecting...' : 'Disconnected'}
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-gray-700 rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: connectionStatus === 'connected' ? '100%' : '75%' }}
                  transition={{ duration: 1 }}
                  className={`h-2 rounded-full ${connectionStatus === 'connected' ? 'bg-green-500' :
                      connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                />
              </div>
            </div>

            {/* AI Engine Status */}
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white text-sm font-medium">AI Engine Status</span>
                <div className={`flex items-center space-x-1 ${getAiStatusColor()}`}>
                  {getAiStatusIcon()}
                  <span className="text-xs">{aiStatus.engine}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Accuracy</span>
                  <span className="text-white">{aiStatus.accuracy}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-1">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${aiStatus.accuracy}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="h-1 bg-green-500 rounded-full"
                  />
                </div>
              </div>
            </div>

            {/* Performance Stats */}
            <div className="p-4 border-b border-white/10">
              <h3 className="text-white text-sm font-medium mb-3">Performance Stats</h3>
              <div className="space-y-3">
                {performanceMetrics.map((metric, index) => (
                  <motion.div
                    key={metric.label}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2">
                      <metric.icon className={`h-4 w-4 ${metric.color}`} />
                      <span className="text-gray-400 text-xs">{metric.label}</span>
                    </div>
                    <div className="text-right">
                      <div className={`text-white text-sm font-medium ${metric.color}`}>
                        {metric.value}
                      </div>
                      <div className={`text-xs ${metric.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {metric.change >= 0 ? '+' : ''}{metric.change}%
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex-1 overflow-auto p-4">
              <nav className="space-y-1">
                {navigationItems.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <button
                      onClick={() => handleItemClick(item.id, !!item.subItems)}
                      className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${activeItem === item.id
                          ? 'bg-white/10 text-white'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                    >
                      <item.icon className={`h-4 w-4 ${item.color}`} />
                      <span className="flex-1 text-left">{item.name}</span>
                      {item.badge && (
                        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                          {item.badge}
                        </span>
                      )}
                      {item.subItems && (
                        <ChevronRight
                          size={12}
                          className={`transition-transform ${expandedItems.includes(item.id) ? 'rotate-90' : ''
                            }`}
                        />
                      )}
                    </button>

                    {item.subItems && expandedItems.includes(item.id) && (
                      <div className="ml-6 mt-1 space-y-1">
                        {item.subItems.map((subItem) => (
                          <button
                            key={subItem.id}
                            onClick={() => handleItemClick(subItem.id)}
                            className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${activeItem === subItem.id
                                ? 'bg-white/10 text-white'
                                : 'text-gray-400 hover:text-white hover:bg-white/5'
                              }`}
                          >
                            <subItem.icon className={`h-4 w-4 ${subItem.color}`} />
                            <span>{subItem.name}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </motion.div>
                ))}
              </nav>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-white/10">
              <div className="flex items-center justify-between text-xs text-gray-400">
                <span>v1.0.0</span>
                <span>© 2024 AiSmart</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Collapsed State */}
      {collapsed && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="w-16 h-full flex flex-col items-center py-4"
        >
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onToggle}
            className="mb-6 p-2 hover:bg-white/10 rounded transition-colors"
          >
            <ChevronRight size={16} className="text-white" />
          </motion.button>

          <div className="space-y-4">
            {navigationItems.slice(0, 6).map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleItemClick(item.id)}
                className={`p-2 rounded-lg transition-all ${activeItem === item.id
                    ? 'bg-white/10 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                title={item.name}
              >
                <item.icon className={`h-5 w-5 ${item.color}`} />
                {item.badge && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </motion.button>
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default Sidebar;
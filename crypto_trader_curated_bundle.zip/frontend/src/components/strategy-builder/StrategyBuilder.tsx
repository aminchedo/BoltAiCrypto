'use client';

import React, { useState, useCallback, useRef, useEffect } from 'react';
import ReactFlow, {
  ReactFlowProvider,
  Background,
  Controls,
  MiniMap,
  addEdge,
  Connection,
  Edge,
  Node,
  useNodesState,
  useEdgesState,
  NodeTypes,
  EdgeTypes,
  Panel
} from 'reactflow';
import 'reactflow/dist/style.css';
import { v4 as uuidv4 } from 'uuid';
import { 
  Strategy, 
  StrategyComponent, 
  ComponentType, 
  componentTemplates,
  Connection as StrategyConnection
} from '@/services/strategyBuilderService';
import ComponentNode from './nodes/ComponentNode';
import ConditionNode from './nodes/ConditionNode';
import OperatorNode from './nodes/OperatorNode';
import ActionNode from './nodes/ActionNode';
import ComponentPanel from './panels/ComponentPanel';
import StrategyControls from './controls/StrategyControls';
import BacktestPanel from './panels/BacktestPanel';
import SaveStrategyModal from './modals/SaveStrategyModal';
import LoadStrategyModal from './modals/LoadStrategyModal';
import strategyBuilderService from '@/services/strategyBuilderService';
import strategyApiService from '@/services/strategyApiService';

// Define custom node types
const nodeTypes: NodeTypes = {
  componentNode: ComponentNode,
  conditionNode: ConditionNode,
  operatorNode: OperatorNode,
  actionNode: ActionNode,
};

// Convert strategy components to ReactFlow nodes
const componentsToNodes = (components: StrategyComponent[]): Node[] => {
  return components.map((component) => {
    let nodeType = 'componentNode';
    
    switch (component.type) {
      case ComponentType.CONDITION:
        nodeType = 'conditionNode';
        break;
      case ComponentType.OPERATOR:
        nodeType = 'operatorNode';
        break;
      case ComponentType.ACTION:
        nodeType = 'actionNode';
        break;
    }
    
    return {
      id: component.id,
      type: nodeType,
      position: component.position,
      data: {
        ...component.data,
        label: component.name,
        description: component.description,
        componentType: component.type,
      },
    };
  });
};

// Convert strategy connections to ReactFlow edges
const connectionsToEdges = (connections: StrategyConnection[]): Edge[] => {
  return connections.map((connection) => ({
    id: connection.id,
    source: connection.sourceId,
    target: connection.targetId,
    sourceHandle: connection.sourceHandle,
    targetHandle: connection.targetHandle,
    animated: true,
    style: { stroke: '#2563eb' },
  }));
};

interface StrategyBuilderProps {
  initialStrategy?: Strategy;
}

const StrategyBuilder: React.FC<StrategyBuilderProps> = ({ initialStrategy }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showLoadModal, setShowLoadModal] = useState(false);
  const [currentStrategy, setCurrentStrategy] = useState<Strategy | null>(null);
  const [showBacktestPanel, setShowBacktestPanel] = useState(false);
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null);

  // Initialize with strategy if provided
  useEffect(() => {
    if (initialStrategy) {
      setCurrentStrategy(initialStrategy);
      setNodes(componentsToNodes(initialStrategy.components));
      setEdges(connectionsToEdges(initialStrategy.connections));
    }
  }, [initialStrategy, setNodes, setEdges]);

  // Handle node selection
  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  // Handle edge connections
  const onConnect = useCallback(
    (params: Connection) => {
      // Create a unique ID for the new edge
      const edgeId = uuidv4();
      setEdges((eds) => addEdge({ ...params, id: edgeId, animated: true }, eds));
      
      // If we have a current strategy, update its connections
      if (currentStrategy) {
        const newConnection: StrategyConnection = {
          id: edgeId,
          sourceId: params.source || '',
          targetId: params.target || '',
          sourceHandle: params.sourceHandle || 'output',
          targetHandle: params.targetHandle || 'input',
        };
        
        setCurrentStrategy({
          ...currentStrategy,
          connections: [...currentStrategy.connections, newConnection],
        });
      }
    },
    [setEdges, currentStrategy]
  );

  // Handle drag and drop from component panel
  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      if (!reactFlowWrapper.current || !reactFlowInstance) return;

      const reactFlowBounds = reactFlowWrapper.current.getBoundingClientRect();
      const componentType = event.dataTransfer.getData('application/componentType') as ComponentType;
      const componentId = event.dataTransfer.getData('application/componentId');
      
      // Find the component template
      const componentTemplate = componentTemplates[componentType].find(
        (template) => template.id === componentId
      );
      
      if (!componentTemplate) return;

      // Get position from drop coordinates
      const position = reactFlowInstance.project({
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      });

      // Create a new component with a unique ID
      const newComponentId = uuidv4();
      const newComponent: StrategyComponent = {
        ...componentTemplate,
        id: newComponentId,
        position,
      };

      // Create a new node
      const newNode = componentsToNodes([newComponent])[0];
      setNodes((nds) => nds.concat(newNode));

      // Update current strategy if it exists
      if (currentStrategy) {
        setCurrentStrategy({
          ...currentStrategy,
          components: [...currentStrategy.components, newComponent],
        });
      }
    },
    [reactFlowInstance, setNodes, currentStrategy]
  );

  // Save current strategy
  const saveStrategy = useCallback(async (name: string, description: string) => {
    try {
      if (!currentStrategy) {
        // Create new strategy
        // Prepare strategy data
        const components: StrategyComponent[] = nodes.map((node) => ({
          id: node.id,
          type: node.data.componentType,
          name: node.data.label,
          description: node.data.description || '',
          position: node.position,
          data: node.data,
        }));
        
        const connections: StrategyConnection[] = edges.map((edge) => ({
          id: edge.id,
          sourceId: edge.source,
          targetId: edge.target,
          sourceHandle: edge.sourceHandle || 'output',
          targetHandle: edge.targetHandle || 'input',
        }));
        
        // Create new strategy via API
        const newStrategy = await strategyApiService.createStrategy({
          name,
          description,
          components,
          connections,
          isActive: false,
          symbol: 'BTCUSDT', // Default symbol
          timeframe: '1h', // Default timeframe
        });
        
        if (newStrategy) {
          setCurrentStrategy(newStrategy);
        }
      } else {
        // Update existing strategy via API
        const updatedStrategy = await strategyApiService.updateStrategy(currentStrategy.id, {
          name,
          description,
          components: nodes.map((node) => ({
            id: node.id,
            type: node.data.componentType,
            name: node.data.label,
            description: node.data.description || '',
            position: node.position,
            data: node.data,
          })),
          connections: edges.map((edge) => ({
            id: edge.id,
            sourceId: edge.source,
            targetId: edge.target,
            sourceHandle: edge.sourceHandle || 'output',
            targetHandle: edge.targetHandle || 'input',
          })),
        });
        
        if (updatedStrategy) {
          setCurrentStrategy(updatedStrategy);
        }
      }
    } catch (error) {
      console.error('Failed to save strategy:', error);
      // Here you could add error handling UI feedback
    }
    
    setShowSaveModal(false);
  }, [currentStrategy, nodes, edges]);

  // Load a strategy
  const loadStrategy = useCallback(async (strategy: Strategy) => {
    try {
      // If we need to fetch the full strategy details
      const fullStrategy = await strategyApiService.getStrategy(strategy.id);
      if (fullStrategy) {
        setCurrentStrategy(fullStrategy);
        setNodes(componentsToNodes(fullStrategy.components));
        setEdges(connectionsToEdges(fullStrategy.connections));
      } else {
        // Fallback to using the provided strategy
        setCurrentStrategy(strategy);
        setNodes(componentsToNodes(strategy.components));
        setEdges(connectionsToEdges(strategy.connections));
      }
    } catch (error) {
      console.error('Failed to load strategy details:', error);
      // Fallback to using the provided strategy
      setCurrentStrategy(strategy);
      setNodes(componentsToNodes(strategy.components));
      setEdges(connectionsToEdges(strategy.connections));
    }
    setShowLoadModal(false);
  }, [setNodes, setEdges]);

  // Run backtest
  const runBacktest = useCallback(async (symbol: string, timeframe: string, startDate: Date, endDate: Date) => {
    if (!currentStrategy) return;
    
    try {
      const backtestResult = await strategyApiService.runBacktest(
        currentStrategy.id,
        symbol,
        timeframe,
        startDate,
        endDate
      );
      
      if (backtestResult) {
        setCurrentStrategy({
          ...currentStrategy,
          backtestResults: backtestResult,
        });
      }
    } catch (error) {
      console.error('Failed to run backtest:', error);
      // Here you could add error handling UI feedback
    }
  }, [currentStrategy]);

  // Deploy strategy
  const deployStrategy = useCallback(async () => {
    if (!currentStrategy) return;
    
    try {
      const success = await strategyApiService.deployStrategy(currentStrategy.id);
      
      if (success) {
        setCurrentStrategy({
          ...currentStrategy,
          isActive: true,
        });
      }
    } catch (error) {
      console.error('Failed to deploy strategy:', error);
      // Here you could add error handling UI feedback
    }
  }, [currentStrategy]);

  // Stop strategy
  const stopStrategy = useCallback(async () => {
    if (!currentStrategy) return;
    
    try {
      const success = await strategyApiService.stopStrategy(currentStrategy.id);
      
      if (success) {
        setCurrentStrategy({
          ...currentStrategy,
          isActive: false,
        });
      }
    } catch (error) {
      console.error('Failed to stop strategy:', error);
      // Here you could add error handling UI feedback
    }
  }, [currentStrategy]);

  return (
    <div className="h-full w-full flex flex-col">
      <div className="h-16 bg-gray-800 text-white p-4 flex justify-between items-center">
        <div className="text-xl font-bold">
          {currentStrategy ? currentStrategy.name : 'New Strategy'}
        </div>
        <StrategyControls
          onSave={() => setShowSaveModal(true)}
          onLoad={() => setShowLoadModal(true)}
          onBacktest={() => setShowBacktestPanel(true)}
          onDeploy={deployStrategy}
          onStop={stopStrategy}
          isActive={currentStrategy?.isActive || false}
          hasBacktestResults={!!currentStrategy?.backtestResults}
        />
      </div>
      
      <div className="flex-grow flex" style={{ height: 'calc(100% - 4rem)' }}>
        <div className="w-64 bg-gray-100 p-4 overflow-y-auto">
          <ComponentPanel />
        </div>
        
        <div className="flex-grow relative" ref={reactFlowWrapper}>
          <ReactFlowProvider>
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              onNodeClick={onNodeClick}
              onDragOver={onDragOver}
              onDrop={onDrop}
              onInit={setReactFlowInstance}
              nodeTypes={nodeTypes}
              fitView
            >
              <Background />
              <Controls />
              <MiniMap />
              
              {selectedNode && (
                <Panel position="top-right" className="bg-white p-4 rounded shadow-lg">
                  <h3 className="text-lg font-bold mb-2">{selectedNode.data.label}</h3>
                  <p className="text-sm text-gray-600 mb-4">{selectedNode.data.description}</p>
                  
                  {/* Render component-specific settings */}
                  {/* This would be expanded based on component type */}
                  <div className="space-y-2">
                    {Object.entries(selectedNode.data.parameters || {}).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="text-sm font-medium">{key}:</span>
                        <span className="text-sm">{value as string}</span>
                      </div>
                    ))}
                  </div>
                  
                  <button
                    className="mt-4 px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                    onClick={() => {
                      setNodes((nds) => nds.filter((n) => n.id !== selectedNode.id));
                      setEdges((eds) => eds.filter(
                        (e) => e.source !== selectedNode.id && e.target !== selectedNode.id
                      ));
                      setSelectedNode(null);
                      
                      // Update current strategy if it exists
                      if (currentStrategy) {
                        setCurrentStrategy({
                          ...currentStrategy,
                          components: currentStrategy.components.filter(
                            (c) => c.id !== selectedNode.id
                          ),
                          connections: currentStrategy.connections.filter(
                            (c) => c.sourceId !== selectedNode.id && c.targetId !== selectedNode.id
                          ),
                        });
                      }
                    }}
                  >
                    Remove
                  </button>
                </Panel>
              )}
            </ReactFlow>
          </ReactFlowProvider>
        </div>
        
        {showBacktestPanel && currentStrategy && (
          <div className="w-80 bg-gray-100 p-4 overflow-y-auto">
            <BacktestPanel
              strategy={currentStrategy}
              onClose={() => setShowBacktestPanel(false)}
              onRunBacktest={runBacktest}
            />
          </div>
        )}
      </div>
      
      {showSaveModal && (
        <SaveStrategyModal
          strategy={currentStrategy}
          onSave={saveStrategy}
          onCancel={() => setShowSaveModal(false)}
        />
      )}
      
      {showLoadModal && (
        <LoadStrategyModal
          onLoad={loadStrategy}
          onCancel={() => setShowLoadModal(false)}
        />
      )}
    </div>
  );
};

export default StrategyBuilder;
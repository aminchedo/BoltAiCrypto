import React, { useState, useEffect } from 'react';
import { Strategy } from '@/services/strategyBuilderService';
import strategyBuilderService from '@/services/strategyBuilderService';

interface LoadStrategyModalProps {
  onLoad: (strategy: Strategy) => void;
  onCancel: () => void;
}

const LoadStrategyModal: React.FC<LoadStrategyModalProps> = ({ onLoad, onCancel }) => {
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [selectedStrategyId, setSelectedStrategyId] = useState<string | null>(null);
  const [importMode, setImportMode] = useState(false);
  const [importJson, setImportJson] = useState('');
  const [importError, setImportError] = useState('');

  // Load strategies on mount
  useEffect(() => {
    const allStrategies = strategyBuilderService.getAllStrategies();
    setStrategies(allStrategies);
    
    if (allStrategies.length > 0) {
      setSelectedStrategyId(allStrategies[0].id);
    }
  }, []);

  const handleLoad = () => {
    if (!selectedStrategyId) return;
    
    const strategy = strategyBuilderService.getStrategyById(selectedStrategyId);
    if (strategy) {
      onLoad(strategy);
    }
  };

  const handleImport = () => {
    try {
      setImportError('');
      const importedStrategy = strategyBuilderService.importStrategy(importJson);
      
      if (importedStrategy) {
        onLoad(importedStrategy);
      } else {
        setImportError('Failed to import strategy');
      }
    } catch (error) {
      setImportError('Invalid strategy JSON format');
    }
  };

  const handleExport = () => {
    if (!selectedStrategyId) return;
    
    const strategyJson = strategyBuilderService.exportStrategy(selectedStrategyId);
    if (strategyJson) {
      // Create a download link
      const blob = new Blob([strategyJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `strategy_${selectedStrategyId}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-[500px]">
        <h2 className="text-xl font-bold mb-4">Load Strategy</h2>
        
        <div className="mb-4">
          <div className="flex space-x-2 mb-4">
            <button
              className={`px-3 py-1 rounded ${!importMode ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
              onClick={() => setImportMode(false)}
            >
              My Strategies
            </button>
            <button
              className={`px-3 py-1 rounded ${importMode ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
              onClick={() => setImportMode(true)}
            >
              Import/Export
            </button>
          </div>
          
          {!importMode ? (
            <>
              {strategies.length > 0 ? (
                <div className="max-h-60 overflow-y-auto border border-gray-300 rounded-md">
                  {strategies.map((strategy) => (
                    <div
                      key={strategy.id}
                      className={`p-3 cursor-pointer hover:bg-gray-100 ${
                        selectedStrategyId === strategy.id ? 'bg-blue-50 border-l-4 border-blue-500' : ''
                      }`}
                      onClick={() => setSelectedStrategyId(strategy.id)}
                    >
                      <div className="font-medium">{strategy.name}</div>
                      <div className="text-sm text-gray-500">{strategy.description}</div>
                      <div className="text-xs text-gray-400 mt-1">
                        Last updated: {new Date(strategy.updatedAt).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No saved strategies found
                </div>
              )}
            </>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Import Strategy (JSON)
                </label>
                <textarea
                  value={importJson}
                  onChange={(e) => setImportJson(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  rows={6}
                  placeholder="Paste strategy JSON here..."
                />
                {importError && (
                  <div className="text-red-500 text-sm mt-1">{importError}</div>
                )}
              </div>
              
              <div>
                <button
                  onClick={handleImport}
                  className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 w-full"
                  disabled={!importJson}
                >
                  Import
                </button>
              </div>
              
              <div className="border-t border-gray-300 pt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Export Strategy
                </label>
                
                <div className="flex space-x-2">
                  <select
                    value={selectedStrategyId || ''}
                    onChange={(e) => setSelectedStrategyId(e.target.value)}
                    className="flex-grow px-3 py-2 border border-gray-300 rounded-md"
                    disabled={strategies.length === 0}
                  >
                    {strategies.map((strategy) => (
                      <option key={strategy.id} value={strategy.id}>
                        {strategy.name}
                      </option>
                    ))}
                  </select>
                  
                  <button
                    onClick={handleExport}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                    disabled={!selectedStrategyId}
                  >
                    Export
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex justify-end space-x-2 mt-6">
          <button
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100"
          >
            Cancel
          </button>
          
          {!importMode && (
            <button
              onClick={handleLoad}
              className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              disabled={!selectedStrategyId}
            >
              Load
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoadStrategyModal;
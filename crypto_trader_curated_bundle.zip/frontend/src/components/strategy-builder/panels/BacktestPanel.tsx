import React, { useState } from 'react';
import { Strategy, BacktestResult } from '@/services/strategyBuilderService';

interface BacktestPanelProps {
  strategy: Strategy;
  onClose: () => void;
  onRunBacktest: (symbol: string, timeframe: string, startDate: Date, endDate: Date) => void;
}

const BacktestPanel: React.FC<BacktestPanelProps> = ({ strategy, onClose, onRunBacktest }) => {
  const [symbol, setSymbol] = useState(strategy.symbol || 'BTCUSDT');
  const [timeframe, setTimeframe] = useState(strategy.timeframe || '1h');
  const [startDate, setStartDate] = useState<string>(
    new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [isLoading, setIsLoading] = useState(false);

  const handleRunBacktest = async () => {
    setIsLoading(true);
    await onRunBacktest(
      symbol,
      timeframe,
      new Date(startDate),
      new Date(endDate)
    );
    setIsLoading(false);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Backtest Strategy</h2>
        <button
          className="text-gray-500 hover:text-gray-700"
          onClick={onClose}
        >
          ✕
        </button>
      </div>

      <div className="space-y-4 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Symbol
          </label>
          <input
            type="text"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Timeframe
          </label>
          <select
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="1m">1 minute</option>
            <option value="5m">5 minutes</option>
            <option value="15m">15 minutes</option>
            <option value="30m">30 minutes</option>
            <option value="1h">1 hour</option>
            <option value="4h">4 hours</option>
            <option value="1d">1 day</option>
            <option value="1w">1 week</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Start Date
          </label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            End Date
          </label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>

        <button
          className="w-full px-4 py-2 bg-purple-500 text-white rounded-md hover:bg-purple-600 disabled:bg-gray-400"
          onClick={handleRunBacktest}
          disabled={isLoading}
        >
          {isLoading ? 'Running...' : 'Run Backtest'}
        </button>
      </div>

      {strategy.backtestResults && (
        <div className="flex-grow overflow-y-auto">
          <h3 className="text-md font-bold mb-2">Results</h3>
          <BacktestResults results={strategy.backtestResults} />
        </div>
      )}
    </div>
  );
};

interface BacktestResultsProps {
  results: BacktestResult;
}

const BacktestResults: React.FC<BacktestResultsProps> = ({ results }) => {
  const { metrics, trades } = results;

  return (
    <div className="space-y-4">
      <div className="bg-white p-3 rounded-md shadow-sm">
        <h4 className="font-bold text-sm mb-2">Performance Metrics</h4>
        
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Net Profit:</span>
            <span className={metrics.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}>
              ${metrics.netProfit.toFixed(2)}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Win Rate:</span>
            <span>{metrics.winRate.toFixed(2)}%</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Profit Factor:</span>
            <span>{metrics.profitFactor.toFixed(2)}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Max Drawdown:</span>
            <span className="text-red-600">{metrics.maxDrawdown.toFixed(2)}%</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Total Trades:</span>
            <span>{metrics.totalTrades}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Winning Trades:</span>
            <span className="text-green-600">{metrics.winningTrades}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Losing Trades:</span>
            <span className="text-red-600">{metrics.losingTrades}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Sharpe Ratio:</span>
            <span>{metrics.sharpeRatio.toFixed(2)}</span>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-3 rounded-md shadow-sm">
        <h4 className="font-bold text-sm mb-2">Trade Statistics</h4>
        
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Avg. Win:</span>
            <span className="text-green-600">${metrics.averageWin.toFixed(2)}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Avg. Loss:</span>
            <span className="text-red-600">${metrics.averageLoss.toFixed(2)}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Largest Win:</span>
            <span className="text-green-600">${metrics.largestWin.toFixed(2)}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Largest Loss:</span>
            <span className="text-red-600">${metrics.largestLoss.toFixed(2)}</span>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-3 rounded-md shadow-sm">
        <h4 className="font-bold text-sm mb-2">Recent Trades</h4>
        
        <div className="overflow-x-auto">
          <table className="min-w-full text-xs">
            <thead>
              <tr className="bg-gray-100">
                <th className="px-2 py-1 text-left">Direction</th>
                <th className="px-2 py-1 text-left">Entry</th>
                <th className="px-2 py-1 text-left">Exit</th>
                <th className="px-2 py-1 text-right">Profit</th>
              </tr>
            </thead>
            <tbody>
              {trades.slice(0, 10).map((trade) => (
                <tr key={trade.id} className="border-t border-gray-200">
                  <td className="px-2 py-1">
                    <span className={trade.direction === 'LONG' ? 'text-green-600' : 'text-red-600'}>
                      {trade.direction}
                    </span>
                  </td>
                  <td className="px-2 py-1">
                    ${trade.entryPrice.toFixed(2)}
                    <div className="text-gray-500 text-xs">
                      {new Date(trade.entryTime).toLocaleString()}
                    </div>
                  </td>
                  <td className="px-2 py-1">
                    ${trade.exitPrice.toFixed(2)}
                    <div className="text-gray-500 text-xs">
                      {new Date(trade.exitTime).toLocaleString()}
                    </div>
                  </td>
                  <td className={`px-2 py-1 text-right ${trade.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    ${trade.profit.toFixed(2)}
                    <div className="text-xs">
                      {trade.profitPercentage.toFixed(2)}%
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {trades.length > 10 && (
            <div className="text-center text-xs text-gray-500 mt-2">
              Showing 10 of {trades.length} trades
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BacktestPanel;
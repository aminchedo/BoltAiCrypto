import React, { useState } from 'react';
import { ComponentType, componentTemplates } from '@/services/strategyBuilderService';

// Component category labels
const categoryLabels: Record<ComponentType, string> = {
  [ComponentType.INDICATOR]: 'Technical Indicators',
  [ComponentType.PATTERN]: 'Chart Patterns',
  [ComponentType.SMART_MONEY]: 'Smart Money Concepts',
  [ComponentType.SENTIMENT]: 'Sentiment Analysis',
  [ComponentType.WHALE]: 'Whale Activity',
  [ComponentType.ML]: 'ML Predictions',
  [ComponentType.CONDITION]: 'Conditions',
  [ComponentType.OPERATOR]: 'Operators',
  [ComponentType.ACTION]: 'Actions',
  [ComponentType.RISK]: 'Risk Management',
};

// Component category icons
const categoryIcons: Record<ComponentType, string> = {
  [ComponentType.INDICATOR]: '📊',
  [ComponentType.PATTERN]: '📈',
  [ComponentType.SMART_MONEY]: '💰',
  [ComponentType.SENTIMENT]: '😀',
  [ComponentType.WHALE]: '🐋',
  [ComponentType.ML]: '🤖',
  [ComponentType.CONDITION]: '❓',
  [ComponentType.OPERATOR]: '🔄',
  [ComponentType.ACTION]: '⚡',
  [ComponentType.RISK]: '⚠️',
};

const ComponentPanel: React.FC = () => {
  const [expandedCategories, setExpandedCategories] = useState<Record<ComponentType, boolean>>({
    [ComponentType.INDICATOR]: true,
    [ComponentType.PATTERN]: false,
    [ComponentType.SMART_MONEY]: false,
    [ComponentType.SENTIMENT]: false,
    [ComponentType.WHALE]: false,
    [ComponentType.ML]: false,
    [ComponentType.CONDITION]: true,
    [ComponentType.OPERATOR]: true,
    [ComponentType.ACTION]: true,
    [ComponentType.RISK]: false,
  });

  // Toggle category expansion
  const toggleCategory = (category: ComponentType) => {
    setExpandedCategories({
      ...expandedCategories,
      [category]: !expandedCategories[category],
    });
  };

  // Handle drag start
  const onDragStart = (event: React.DragEvent, componentType: ComponentType, componentId: string) => {
    event.dataTransfer.setData('application/componentType', componentType);
    event.dataTransfer.setData('application/componentId', componentId);
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div className="h-full overflow-y-auto">
      <h2 className="text-lg font-bold mb-4">Components</h2>
      
      {Object.values(ComponentType).map((category) => (
        <div key={category} className="mb-2">
          <div
            className="flex items-center justify-between p-2 bg-gray-200 rounded cursor-pointer hover:bg-gray-300"
            onClick={() => toggleCategory(category)}
          >
            <div className="flex items-center">
              <span className="mr-2">{categoryIcons[category]}</span>
              <span className="font-medium">{categoryLabels[category]}</span>
            </div>
            <span>{expandedCategories[category] ? '▼' : '►'}</span>
          </div>
          
          {expandedCategories[category] && (
            <div className="pl-2 mt-1 space-y-1">
              {componentTemplates[category].map((component) => (
                <div
                  key={component.id}
                  className="p-2 bg-white rounded border border-gray-300 cursor-grab hover:bg-gray-50"
                  draggable
                  onDragStart={(event) => onDragStart(event, category, component.id)}
                >
                  <div className="font-medium">{component.name}</div>
                  <div className="text-xs text-gray-500">{component.description}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ComponentPanel;
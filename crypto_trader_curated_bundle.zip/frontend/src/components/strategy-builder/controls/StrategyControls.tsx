import React from 'react';

interface StrategyControlsProps {
  onSave: () => void;
  onLoad: () => void;
  onBacktest: () => void;
  onDeploy: () => void;
  onStop: () => void;
  isActive: boolean;
  hasBacktestResults: boolean;
}

const StrategyControls: React.FC<StrategyControlsProps> = ({
  onSave,
  onLoad,
  onBacktest,
  onDeploy,
  onStop,
  isActive,
  hasBacktestResults,
}) => {
  return (
    <div className="flex space-x-2">
      <button
        className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
        onClick={onSave}
      >
        Save
      </button>
      
      <button
        className="px-3 py-1 bg-gray-500 text-white rounded hover:bg-gray-600"
        onClick={onLoad}
      >
        Load
      </button>
      
      <button
        className="px-3 py-1 bg-purple-500 text-white rounded hover:bg-purple-600"
        onClick={onBacktest}
      >
        Backtest
      </button>
      
      {isActive ? (
        <button
          className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
          onClick={onStop}
        >
          Stop
        </button>
      ) : (
        <button
          className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed"
          onClick={onDeploy}
          disabled={!hasBacktestResults}
          title={!hasBacktestResults ? 'Run backtest before deploying' : ''}
        >
          Deploy
        </button>
      )}
    </div>
  );
};

export default StrategyControls;
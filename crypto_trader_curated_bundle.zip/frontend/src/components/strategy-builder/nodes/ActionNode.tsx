import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';

interface ActionNodeData {
  label: string;
  description: string;
  action: 'BUY' | 'SELL' | 'ALERT';
  parameters: Record<string, any>;
}

const ActionNode: React.FC<NodeProps<ActionNodeData>> = ({ data, isConnectable }) => {
  const { label, description, action, parameters } = data;
  
  // Set color based on action type
  const bgColor = action === 'BUY' 
    ? 'bg-green-600' 
    : action === 'SELL' 
      ? 'bg-red-600' 
      : 'bg-yellow-600';
  
  return (
    <div className={`px-4 py-2 rounded-md shadow-md border border-gray-200 ${bgColor} text-white`}>
      <Handle
        type="target"
        position={Position.Left}
        id="input"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800"
      />
      
      <div className="flex items-center">
        <span className="mr-2 text-xl">⚡</span>
        <div>
          <div className="font-bold">{label}</div>
          <div className="text-xs opacity-80">{description}</div>
          
          <div className="mt-2 text-xs bg-opacity-30 bg-black p-1 rounded">
            {parameters && Object.entries(parameters).map(([key, value]) => (
              <div key={key} className="font-mono">
                {key}: {value as string}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default memo(ActionNode);
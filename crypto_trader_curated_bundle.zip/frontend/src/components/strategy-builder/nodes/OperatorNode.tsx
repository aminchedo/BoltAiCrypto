import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';

interface OperatorNodeData {
  label: string;
  description: string;
  operator: 'AND' | 'OR' | 'NOT';
}

const OperatorNode: React.FC<NodeProps<OperatorNodeData>> = ({ data, isConnectable }) => {
  const { label, description, operator } = data;
  
  return (
    <div className="px-4 py-2 rounded-md shadow-md border border-gray-200 bg-gray-700 text-white">
      <Handle
        type="target"
        position={Position.Left}
        id="input1"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800 -translate-y-3"
      />
      
      <Handle
        type="target"
        position={Position.Left}
        id="input2"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800 translate-y-3"
      />
      
      <div className="flex items-center">
        <span className="mr-2 text-xl">🔄</span>
        <div>
          <div className="font-bold">{label}</div>
          <div className="text-xs opacity-80">{description}</div>
          
          <div className="mt-2 text-center font-mono text-lg font-bold">
            {operator}
          </div>
        </div>
      </div>
      
      <Handle
        type="source"
        position={Position.Right}
        id="output"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800"
      />
    </div>
  );
};

export default memo(OperatorNode);
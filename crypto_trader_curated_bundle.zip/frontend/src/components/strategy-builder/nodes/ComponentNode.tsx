import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { ComponentType } from '@/services/strategyBuilderService';

// Map component types to colors
const typeColors: Record<ComponentType, string> = {
  [ComponentType.INDICATOR]: 'bg-blue-500',
  [ComponentType.PATTERN]: 'bg-purple-500',
  [ComponentType.SMART_MONEY]: 'bg-green-500',
  [ComponentType.SENTIMENT]: 'bg-yellow-500',
  [ComponentType.WHALE]: 'bg-orange-500',
  [ComponentType.ML]: 'bg-pink-500',
  [ComponentType.CONDITION]: 'bg-indigo-500',
  [ComponentType.OPERATOR]: 'bg-gray-500',
  [ComponentType.ACTION]: 'bg-red-500',
  [ComponentType.RISK]: 'bg-teal-500',
};

// Map component types to icons
const typeIcons: Record<ComponentType, string> = {
  [ComponentType.INDICATOR]: '📊',
  [ComponentType.PATTERN]: '📈',
  [ComponentType.SMART_MONEY]: '💰',
  [ComponentType.SENTIMENT]: '😀',
  [ComponentType.WHALE]: '🐋',
  [ComponentType.ML]: '🤖',
  [ComponentType.CONDITION]: '❓',
  [ComponentType.OPERATOR]: '🔄',
  [ComponentType.ACTION]: '⚡',
  [ComponentType.RISK]: '⚠️',
};

interface ComponentNodeData {
  label: string;
  description: string;
  componentType: ComponentType;
  [key: string]: any;
}

const ComponentNode: React.FC<NodeProps<ComponentNodeData>> = ({ data, isConnectable }) => {
  const { label, description, componentType } = data;
  
  return (
    <div className={`px-4 py-2 rounded-md shadow-md border border-gray-200 ${typeColors[componentType]} text-white`}>
      <Handle
        type="target"
        position={Position.Left}
        id="input"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800"
      />
      
      <div className="flex items-center">
        <span className="mr-2 text-xl">{typeIcons[componentType]}</span>
        <div>
          <div className="font-bold">{label}</div>
          <div className="text-xs opacity-80">{description}</div>
        </div>
      </div>
      
      <Handle
        type="source"
        position={Position.Right}
        id="output"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800"
      />
    </div>
  );
};

export default memo(ComponentNode);
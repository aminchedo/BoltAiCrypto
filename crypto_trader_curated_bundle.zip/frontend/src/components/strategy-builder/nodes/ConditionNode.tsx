import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';

interface ConditionNodeData {
  label: string;
  description: string;
  condition: string;
  parameters: Record<string, any>;
}

const ConditionNode: React.FC<NodeProps<ConditionNodeData>> = ({ data, isConnectable }) => {
  const { label, description, condition, parameters } = data;
  
  return (
    <div className="px-4 py-2 rounded-md shadow-md border border-gray-200 bg-indigo-500 text-white">
      <Handle
        type="target"
        position={Position.Left}
        id="input"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800"
      />
      
      <div className="flex items-center">
        <span className="mr-2 text-xl">❓</span>
        <div>
          <div className="font-bold">{label}</div>
          <div className="text-xs opacity-80">{description}</div>
          
          <div className="mt-2 text-xs bg-indigo-600 p-1 rounded">
            {condition && (
              <div className="font-mono">
                {condition}
                {parameters && Object.entries(parameters).map(([key, value]) => (
                  <span key={key}> {key}={value as string}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      
      <Handle
        type="source"
        position={Position.Right}
        id="output"
        isConnectable={isConnectable}
        className="w-3 h-3 bg-gray-800"
      />
    </div>
  );
};

export default memo(ConditionNode);
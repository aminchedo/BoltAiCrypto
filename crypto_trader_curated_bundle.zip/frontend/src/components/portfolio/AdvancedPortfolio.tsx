import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  PieChart,
  BarChart3,
  RefreshCw,
  Plus,
  Minus,
  Download,
  Search,
  Target,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowUpDown,
  Settings,
  Edit,
  Trash2,
  X,
  Bell,
  Moon,
  Sun,
  Zap,
  Activity,
  Bookmark,
  Filter,
  Eye,
  EyeOff,
  Calendar,
  Share,
  Maximize2,
  Minimize2,
  Globe,
  Smartphone,
  Wifi,
  WifiOff,
  Battery,
  Signal,
  AlertCircle,
  Info,
  ChevronDown,
  ChevronUp,
  MoreHorizontal,
  ExternalLink,
  Copy,
  Percent,
  PlusCircle,
  MinusCircle,
  Shield
} from 'lucide-react';

// API Keys - Replace with your actual keys
const CMC_KEY = ('04cf4b5b-9868-465c-8ba0-9f2e78c92eb1');
const ND_KEY = ('pub_0541f8b03d49486285f479c3b9a41fd8');

// Enhanced Types
interface Position {
  id: string;
  symbol: string;
  name: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  marketValue: number;
  unrealizedPL: number;
  unrealizedPLPercent: number;
  side: 'LONG' | 'SHORT';
  openDate: string;
  lastUpdate: string;
  dayChange: number;
  dayChangePercent: number;
  weekChange: number;
  monthChange: number;
  volume24h: number;
  marketCap?: number;
  sector?: string;
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  alerts: Alert[];
}

interface Alert {
  id: string;
  type: 'PRICE_TARGET' | 'STOP_LOSS' | 'TAKE_PROFIT' | 'NEWS';
  message: string;
  targetPrice?: number;
  isActive: boolean;
  createdAt: string;
}

interface Portfolio {
  id: string;
  name: string;
  totalValue: number;
  totalInvested: number;
  totalPL: number;
  totalPLPercent: number;
  cash: number;
  positions: Position[];
  performance: PerformanceMetrics;
  risk: RiskMetrics;
  createdAt: string;
  updatedAt: string;
}

interface PerformanceMetrics {
  totalReturn: number;
  totalReturnPercent: number;
  dayChange: number;
  dayChangePercent: number;
  weekChange: number;
  weekChangePercent: number;
  monthChange: number;
  monthChangePercent: number;
  yearChange: number;
  yearChangePercent: number;
  sharpeRatio: number;
  maxDrawdown: number;
  winRate: number;
  volatility: number;
}

interface RiskMetrics {
  portfolioRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  diversificationScore: number;
  concentrationRisk: number;
  betaValue: number;
  valueAtRisk: number;
}

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  symbol?: string;
  sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  timestamp: string;
  source: string;
  url?: string;
}

interface PriceData {
  src: string;
  price: number;
  symbol: string;
  mcap?: number;
  change_24h?: number;
  volume_24h?: number;
}

interface FundamentalData {
  src: string;
  name: string;
  rank?: number;
  mcap?: number;
  supply?: number;
  total_supply?: number;
  max_supply?: number;
  volume_24h?: number;
  dominance?: number;
}

interface SentimentData {
  src: string;
  score?: number;
  class?: string;
  timestamp?: string;
  bull?: number;
  bear?: number;
}

// API Service Classes
class PriceSourceSwitcher {
  private sources = ['binance', 'coinmarketcap', 'coinpaprika', 'coingecko'];
  private currentIndex = 0;
  private usageCount = { binance: 0, coinmarketcap: 0, coinpaprika: 0, coingecko: 0 };

  private getNextSource(): string {
    const source = this.sources[this.currentIndex];
    this.currentIndex = (this.currentIndex + 1) % this.sources.length;
    return source;
  }

  private async fetchJson(url: string, options?: RequestInit): Promise<any> {
    try {
      const response = await fetch(url, { ...options, timeout: 8000 } as any);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`Error fetching ${url}:`, error);
      return null;
    }
  }

  private async getPriceBinance(symbol: string, fiat: string = "USDT"): Promise<PriceData | null> {
    const url = "https://data-api.binance.vision/api/v3/ticker/price";
    const data = await this.fetchJson(`${url}?symbol=${symbol}${fiat}`);
    if (data) {
      this.usageCount.binance++;
      return { src: "binance", price: parseFloat(data.price), symbol };
    }
    return null;
  }

  private async getPriceCoinMarketCap(symbol: string, fiat: string = "USD"): Promise<PriceData | null> {
    if (!CMC_KEY) return null;
    const url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest";
    const data = await this.fetchJson(`${url}?symbol=${symbol}&convert=${fiat}`, {
      headers: { "X-CMC_PRO_API_KEY": CMC_KEY }
    });
    if (data?.data?.[symbol]) {
      this.usageCount.coinmarketcap++;
      const quote = data.data[symbol].quote[fiat];
      return {
        src: "coinmarketcap",
        price: quote.price,
        symbol,
        mcap: quote.market_cap,
        change_24h: quote.percent_change_24h,
        volume_24h: quote.volume_24h
      };
    }
    return null;
  }

  private async getPriceCoinPaprika(symbol: string, fiat: string = "USD"): Promise<PriceData | null> {
    const symbolMap: { [key: string]: string } = {
      'BTC': 'btc-bitcoin',
      'ETH': 'eth-ethereum',
      'ADA': 'ada-cardano',
      'SOL': 'sol-solana',
      'BNB': 'bnb-binance-coin'
    };
    const coinId = symbolMap[symbol] || `${symbol.toLowerCase()}-${symbol.toLowerCase()}`;
    const url = `https://api.coinpaprika.com/v1/tickers/${coinId}`;
    const data = await this.fetchJson(url);
    if (data?.quotes?.[fiat]) {
      this.usageCount.coinpaprika++;
      const quote = data.quotes[fiat];
      return {
        src: "coinpaprika",
        price: quote.price,
        symbol,
        mcap: quote.market_cap,
        change_24h: quote.percent_change_24h,
        volume_24h: quote.volume_24h
      };
    }
    return null;
  }

  private async getPriceCoinGecko(symbol: string, fiat: string = "USD"): Promise<PriceData | null> {
    const symbolMap: { [key: string]: string } = {
      'BTC': 'bitcoin',
      'ETH': 'ethereum',
      'ADA': 'cardano',
      'BNB': 'binancecoin',
      'SOL': 'solana',
      'XRP': 'ripple'
    };
    const coinId = symbolMap[symbol] || symbol.toLowerCase();
    const url = "https://api.coingecko.com/api/v3/simple/price";
    const params = new URLSearchParams({
      ids: coinId,
      vs_currencies: fiat.toLowerCase(),
      include_24hr_change: 'true',
      include_market_cap: 'true',
      include_24hr_vol: 'true'
    });
    const data = await this.fetchJson(`${url}?${params}`);
    if (data?.[coinId]) {
      this.usageCount.coingecko++;
      const coinData = data[coinId];
      return {
        src: "coingecko",
        price: coinData[fiat.toLowerCase()],
        symbol,
        mcap: coinData[`${fiat.toLowerCase()}_market_cap`],
        change_24h: coinData[`${fiat.toLowerCase()}_24h_change`],
        volume_24h: coinData[`${fiat.toLowerCase()}_24h_vol`]
      };
    }
    return null;
  }

  async getPrice(symbol: string = "BTC", fiat: string = "USD"): Promise<PriceData | { error: string }> {
    for (let attempt = 0; attempt < this.sources.length; attempt++) {
      const source = this.getNextSource();
      console.log(`💰 Trying ${source} for ${symbol}...`);
      
      try {
        let result: PriceData | null = null;
        
        switch (source) {
          case 'binance':
            result = await this.getPriceBinance(symbol, fiat === "USD" ? "USDT" : fiat);
            break;
          case 'coinmarketcap':
            result = await this.getPriceCoinMarketCap(symbol, fiat);
            break;
          case 'coinpaprika':
            result = await this.getPriceCoinPaprika(symbol, fiat);
            break;
          case 'coingecko':
            result = await this.getPriceCoinGecko(symbol, fiat);
            break;
        }
        
        if (result) {
          console.log(`✅ Got price from ${source}`);
          return result;
        }
      } catch (error) {
        console.error(`❌ ${source} failed:`, error);
      }
      
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    return { error: "All price sources failed!" };
  }
}

// API Service Functions
const priceService = new PriceSourceSwitcher();

const getPrice = async (symbol: string = "BTC", fiat: string = "USD"): Promise<PriceData | { error: string }> => {
  return await priceService.getPrice(symbol, fiat);
};

const getSentiment = async (): Promise<SentimentData | { error: string }> => {
  try {
    // Alternative.me Fear & Greed Index
    console.log("😱 Getting sentiment from Alternative.me...");
    const response = await fetch("https://api.alternative.me/fng/?limit=1");
    if (response.ok) {
      const data = await response.json();
      if (data?.data?.[0]) {
        const item = data.data[0];
        return {
          src: "alternative_me",
          score: parseInt(item.value),
          class: item.value_classification,
          timestamp: item.timestamp
        };
      }
    }
  } catch (error) {
    console.error("Sentiment API error:", error);
  }
  
  return { error: "Sentiment sources unavailable" };
};

const getFundamental = async (symbol: string = "BTC", fiat: string = "USD"): Promise<FundamentalData | { error: string }> => {
  try {
    // Try CoinMarketCap first
    if (CMC_KEY) {
      console.log(`📊 Getting fundamentals for ${symbol} from CMC...`);
      const response = await fetch(
        `https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?symbol=${symbol}&convert=${fiat}`,
        { headers: { "X-CMC_PRO_API_KEY": CMC_KEY } }
      );
      
      if (response.ok) {
        const data = await response.json();
        if (data?.data?.[symbol]) {
          const coinData = data.data[symbol];
          const quote = coinData.quote[fiat];
          return {
            src: "coinmarketcap",
            name: coinData.name,
            rank: coinData.cmc_rank,
            mcap: quote.market_cap,
            supply: coinData.circulating_supply,
            total_supply: coinData.total_supply,
            max_supply: coinData.max_supply,
            volume_24h: quote.volume_24h,
            dominance: quote.market_cap_dominance || 0
          };
        }
      }
    }

    // Fallback to CoinPaprika
    console.log(`📊 Trying CoinPaprika for ${symbol}...`);
    const symbolMap: { [key: string]: string } = {
      'BTC': 'btc-bitcoin',
      'ETH': 'eth-ethereum',
      'ADA': 'ada-cardano'
    };
    const coinId = symbolMap[symbol] || `${symbol.toLowerCase()}-${symbol.toLowerCase()}`;
    
    const response = await fetch(`https://api.coinpaprika.com/v1/tickers/${coinId}`);
    if (response.ok) {
      const data = await response.json();
      if (data?.quotes?.[fiat]) {
        const quote = data.quotes[fiat];
        return {
          src: "coinpaprika",
          name: data.name,
          rank: data.rank,
          mcap: quote.market_cap,
          supply: data.circulating_supply,
          total_supply: data.total_supply,
          max_supply: data.max_supply,
          volume_24h: quote.volume_24h
        };
      }
    }
  } catch (error) {
    console.error("Fundamental data error:", error);
  }
  
  return { error: "Fundamental data unavailable" };
};

const getNews = async (coin: string = "btc", n: number = 10): Promise<NewsItem[]> => {
  try {
    // NewsData.io
    if (ND_KEY) {
      console.log(`📰 Getting news from NewsData.io for ${coin}...`);
      const params = new URLSearchParams({
        apikey: ND_KEY,
        coin: coin,
        size: Math.min(n, 10).toString(),
        language: "en",
        removeduplicate: "1"
      });
      
      const response = await fetch(`https://newsdata.io/api/1/crypto?${params}`);
      if (response.ok) {
        const data = await response.json();
        if (data?.results) {
          return data.results.map((item: any) => ({
            id: Math.random().toString(36).substr(2, 9),
            title: item.title || "",
            summary: item.description || "",
            url: item.link || "",
            timestamp: item.pubDate || new Date().toISOString(),
            source: "newsdata_io",
            sentiment: 'NEUTRAL' as const
          }));
        }
      }
    }

    // Fallback: Generate some sample news
    return [
      {
        id: '1',
        title: `${coin.toUpperCase()} Market Analysis: Strong Technical Indicators`,
        summary: `Recent analysis shows ${coin.toUpperCase()} displaying bullish momentum with key support levels holding...`,
        timestamp: new Date(Date.now() - 1800000).toISOString(),
        source: 'CryptoNews',
        sentiment: 'POSITIVE'
      },
      {
        id: '2',
        title: `Institutional Interest in ${coin.toUpperCase()} Continues to Grow`,
        summary: `Major financial institutions are showing increased interest in ${coin.toUpperCase()} as adoption accelerates...`,
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        source: 'BlockchainDaily',
        sentiment: 'POSITIVE'
      }
    ];
  } catch (error) {
    console.error("News API error:", error);
    return [];
  }
};

const comprehensiveCryptoAnalysis = async (symbols: string[] = ["BTC", "ETH", "ADA"]) => {
  console.log(`🚀 Starting comprehensive analysis for: ${symbols.join(', ')}`);
  
  const analysis = {
    timestamp: new Date().toISOString(),
    symbols_analyzed: symbols,
    prices: {} as { [key: string]: any },
    fundamentals: {} as any,
    sentiment: {} as any,
    news: [] as NewsItem[],
    sources_used: new Set<string>()
  };

  // Fetch prices
  console.log("\n💰 FETCHING PRICES...");
  for (const symbol of symbols) {
    const priceData = await getPrice(symbol);
    analysis.prices[symbol] = priceData;
    if ('src' in priceData) {
      analysis.sources_used.add(priceData.src);
    }
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  // Fetch fundamentals for first symbol
  console.log(`\n📊 FETCHING FUNDAMENTALS FOR ${symbols[0]}...`);
  const fundData = await getFundamental(symbols[0]);
  analysis.fundamentals = fundData;
  if ('src' in fundData) {
    analysis.sources_used.add(fundData.src);
  }

  // Fetch sentiment
  console.log("\n😱 FETCHING MARKET SENTIMENT...");
  const sentimentData = await getSentiment();
  analysis.sentiment = sentimentData;
  if ('src' in sentimentData) {
    analysis.sources_used.add(sentimentData.src);
  }

  // Fetch news
  console.log("\n📰 FETCHING NEWS...");
  for (const coin of symbols.slice(0, 3)) {
    const coinNews = await getNews(coin.toLowerCase(), 3);
    analysis.news.push(...coinNews);
    coinNews.forEach(item => analysis.sources_used.add(item.source));
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  return {
    ...analysis,
    sources_used: Array.from(analysis.sources_used)
  };
};

// Main Component
const AdvancedPortfolio: React.FC = () => {
  // State Management
  const [portfolioData, setPortfolioData] = useState<Portfolio>(() => {
    // Initialize with sample data
    const positions: Position[] = [
      {
        id: '1',
        symbol: 'BTC',
        name: 'Bitcoin',
        quantity: 2.5,
        averagePrice: 42000,
        currentPrice: 43250,
        marketValue: 0,
        unrealizedPL: 0,
        unrealizedPLPercent: 0,
        side: 'LONG',
        openDate: '2024-01-15T10:00:00Z',
        lastUpdate: new Date().toISOString(),
        dayChange: 1200,
        dayChangePercent: 2.8,
        weekChange: 3200,
        monthChange: 5800,
        volume24h: 28500000000,
        marketCap: 850000000000,
        sector: 'Cryptocurrency',
        risk: 'HIGH',
        alerts: []
      },
      {
        id: '2',
        symbol: 'ETH',
        name: 'Ethereum',
        quantity: 15,
        averagePrice: 2450,
        currentPrice: 2520,
        marketValue: 0,
        unrealizedPL: 0,
        unrealizedPLPercent: 0,
        side: 'LONG',
        openDate: '2024-01-20T14:30:00Z',
        lastUpdate: new Date().toISOString(),
        dayChange: 80,
        dayChangePercent: 3.2,
        weekChange: 180,
        monthChange: 320,
        volume24h: 15200000000,
        marketCap: 300000000000,
        sector: 'Cryptocurrency',
        risk: 'HIGH',
        alerts: []
      }
    ];

    // Calculate market values and P&L
    positions.forEach(pos => {
      pos.marketValue = pos.quantity * pos.currentPrice;
      pos.unrealizedPL = pos.marketValue - (pos.quantity * pos.averagePrice);
      pos.unrealizedPLPercent = (pos.unrealizedPL / (pos.quantity * pos.averagePrice)) * 100;
    });

    const totalValue = positions.reduce((sum, pos) => sum + pos.marketValue, 0) + 15230.75;
    const totalInvested = positions.reduce((sum, pos) => sum + (pos.quantity * pos.averagePrice), 0);
    const totalPL = positions.reduce((sum, pos) => sum + pos.unrealizedPL, 0);

    return {
      id: 'portfolio-1',
      name: 'My Crypto Portfolio',
      totalValue,
      totalInvested,
      totalPL,
      totalPLPercent: (totalPL / totalInvested) * 100,
      cash: 15230.75,
      positions,
      performance: {
        totalReturn: totalPL,
        totalReturnPercent: (totalPL / totalInvested) * 100,
        dayChange: 1250.75,
        dayChangePercent: 1.01,
        weekChange: 2840.30,
        weekChangePercent: 2.35,
        monthChange: 5620.80,
        monthChangePercent: 4.82,
        yearChange: 18750.25,
        yearChangePercent: 15.6,
        sharpeRatio: 1.45,
        maxDrawdown: -8.2,
        winRate: 72.5,
        volatility: 18.7
      },
      risk: {
        portfolioRisk: 'MEDIUM',
        diversificationScore: 7.2,
        concentrationRisk: 65.8,
        betaValue: 1.25,
        valueAtRisk: -2850.50
      },
      createdAt: '2024-01-01T00:00:00Z',
      updatedAt: new Date().toISOString(),
    };
  });

  const [news, setNews] = useState<NewsItem[]>([]);
  const [sentiment, setSentiment] = useState<SentimentData | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());
  const [selectedTimeframe, setSelectedTimeframe] = useState<'1h' | '4h' | '1d' | '7d' | '30d' | '90d' | '1y'>('1d');
  const [showAddPosition, setShowAddPosition] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(30);
  const [selectedView, setSelectedView] = useState<'overview' | 'positions' | 'analytics' | 'alerts'>('overview');
  const [isLoading, setIsLoading] = useState(false);
  
  // Filters and Sorting
  const [filters, setFilters] = useState({
    search: '',
    minValue: 0,
    maxValue: 1000000,
    profitFilter: 'all' as 'all' | 'profit' | 'loss',
    riskFilter: 'all' as 'all' | 'LOW' | 'MEDIUM' | 'HIGH',
    sortBy: 'value' as 'symbol' | 'value' | 'pnl' | 'pnlPercent' | 'quantity' | 'risk',
    sortDirection: 'desc' as 'asc' | 'desc',
    showSmallPositions: true,
  });

  // Add Position Form
  const [addPositionData, setAddPositionData] = useState({
    symbol: '',
    name: '',
    quantity: 0,
    averagePrice: 0,
    side: 'LONG' as 'LONG' | 'SHORT',
  });

  // Price change animation effect
  const [priceAnimations, setPriceAnimations] = useState<{[key: string]: 'up' | 'down' | null}>({});

  // Real-time price updates
  const updatePrices = useCallback(async () => {
    if (!portfolioData.positions.length) return;
    
    setIsLoading(true);
    const updatedPositions = [...portfolioData.positions];
    const animations: {[key: string]: 'up' | 'down' | null} = {};
    
    for (const position of updatedPositions) {
      try {
        const priceData = await getPrice(position.symbol);
        if ('price' in priceData) {
          const oldPrice = position.currentPrice;
          const newPrice = priceData.price;
          
          // Update position data
          position.currentPrice = newPrice;
          position.marketValue = position.quantity * newPrice;
          position.unrealizedPL = position.marketValue - (position.quantity * position.averagePrice);
          position.unrealizedPLPercent = (position.unrealizedPL / (position.quantity * position.averagePrice)) * 100;
          position.lastUpdate = new Date().toISOString();
          
          // Set animation
          if (newPrice > oldPrice) {
            animations[position.id] = 'up';
          } else if (newPrice < oldPrice) {
            animations[position.id] = 'down';
          }
          
          // Update additional data if available
          if (priceData.change_24h !== undefined) {
            position.dayChangePercent = priceData.change_24h;
          }
          if (priceData.volume_24h !== undefined) {
            position.volume24h = priceData.volume_24h;
          }
          if (priceData.mcap !== undefined) {
            position.marketCap = priceData.mcap;
          }
        }
      } catch (error) {
        console.error(`Failed to update price for ${position.symbol}:`, error);
      }
      
      // Add delay between requests to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    // Update portfolio totals
    const totalValue = updatedPositions.reduce((sum, pos) => sum + pos.marketValue, 0) + portfolioData.cash;
    const totalInvested = updatedPositions.reduce((sum, pos) => sum + (pos.quantity * pos.averagePrice), 0);
    const totalPL = updatedPositions.reduce((sum, pos) => sum + pos.unrealizedPL, 0);
    
    setPortfolioData(prev => ({
      ...prev,
      positions: updatedPositions,
      totalValue,
      totalPL,
      totalPLPercent: (totalPL / totalInvested) * 100,
      updatedAt: new Date().toISOString()
    }));
    
    setPriceAnimations(animations);
    setLastUpdateTime(new Date());
    setIsLoading(false);
    
    // Clear animations after 1 second
    setTimeout(() => setPriceAnimations({}), 1000);
  }, [portfolioData.positions, portfolioData.cash]);

  // Load market data on component mount
  useEffect(() => {
    const loadMarketData = async () => {
      try {
        // Load sentiment data
        const sentimentData = await getSentiment();
        if ('score' in sentimentData) {
          setSentiment(sentimentData);
        }
        
        // Load news
        const symbols = portfolioData.positions.map(p => p.symbol.toLowerCase());
        const allNews: NewsItem[] = [];
        for (const symbol of symbols.slice(0, 3)) {
          const symbolNews = await getNews(symbol, 2);
          allNews.push(...symbolNews);
          await new Promise(resolve => setTimeout(resolve, 500));
        }
        setNews(allNews);
        
        // Initial price update
        await updatePrices();
      } catch (error) {
        console.error('Failed to load market data:', error);
      }
    };
    
    loadMarketData();
  }, []);

  // Auto-refresh prices
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      updatePrices();
    }, refreshInterval * 1000);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, updatePrices]);

  // Network Status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Utility Functions
  const formatCurrency = useCallback((value: number, compact = false) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: compact ? 'compact' : 'standard',
      minimumFractionDigits: compact ? 1 : 2,
    }).format(value);
  }, []);

  const formatPercentage = useCallback((value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  }, []);

  const formatDate = useCallback((dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }, []);

  const getSymbolColor = useCallback((symbol: string) => {
    const colors: { [key: string]: string } = {
      'BTC': '#F7931A',
      'ETH': '#627EEA',
      'ADA': '#0033AD',
      'SOL': '#66D9EF',
      'BNB': '#F3BA2F',
      'XRP': '#23292F',
    };
    return colors[symbol] || '#8B5CF6';
  }, []);

  const getRiskColor = useCallback((risk: string) => {
    switch (risk) {
      case 'LOW': return 'text-green-600 bg-green-100 dark:bg-green-900/30 dark:text-green-400';
      case 'MEDIUM': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30 dark:text-yellow-400';
      case 'HIGH': return 'text-red-600 bg-red-100 dark:bg-red-900/30 dark:text-red-400';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/30 dark:text-gray-400';
    }
  }, []);

  // Enhanced Performance Chart Data
  const performanceChartData = useMemo(() => {
    const timeFrames = {
      '1h': 24,
      '4h': 24,
      '1d': 7,
      '7d': 7,
      '30d': 30,
      '90d': 90,
      '1y': 365
    };

    const points = timeFrames[selectedTimeframe];
    const labels = Array.from({ length: points }, (_, i) => {
      const date = new Date();
      if (selectedTimeframe === '1h') {
        date.setHours(date.getHours() - (points - 1 - i));
        return date.getHours() + ':00';
      } else if (selectedTimeframe === '4h') {
        date.setHours(date.getHours() - (points - 1 - i) * 4);
        return date.getHours() + ':00';
      } else {
        date.setDate(date.getDate() - (points - 1 - i));
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      }
    });

    const baseValue = portfolioData.totalInvested;
    const data = labels.map((_, i) => {
      const progress = i / (points - 1);
      const trend = portfolioData.totalPL * progress;
      const volatility = (Math.random() - 0.5) * (portfolioData.totalValue * 0.02);
      return Math.max(baseValue + trend + volatility, baseValue * 0.8);
    });

    return { labels, data };
  }, [selectedTimeframe, portfolioData]);

  // Asset Allocation Data
  const allocationChartData = useMemo(() => {
    const totalValue = portfolioData.totalValue;
    return [
      ...portfolioData.positions.map(p => ({
        label: p.name,
        symbol: p.symbol,
        value: (p.marketValue / totalValue) * 100,
        amount: p.marketValue,
        color: getSymbolColor(p.symbol)
      })),
      {
        label: 'Cash',
        symbol: 'CASH',
        value: (portfolioData.cash / totalValue) * 100,
        amount: portfolioData.cash,
        color: '#6B7280'
      }
    ];
  }, [portfolioData, getSymbolColor]);

  // Filtered Positions
  const filteredPositions = useMemo(() => {
    let positions = [...portfolioData.positions];

    if (filters.search) {
      positions = positions.filter(pos =>
        pos.symbol.toLowerCase().includes(filters.search.toLowerCase()) ||
        pos.name.toLowerCase().includes(filters.search.toLowerCase())
      );
    }

    if (filters.profitFilter === 'profit') {
      positions = positions.filter(pos => pos.unrealizedPL > 0);
    } else if (filters.profitFilter === 'loss') {
      positions = positions.filter(pos => pos.unrealizedPL < 0);
    }

    if (filters.riskFilter !== 'all') {
      positions = positions.filter(pos => pos.risk === filters.riskFilter);
    }

    if (!filters.showSmallPositions) {
      positions = positions.filter(pos => pos.marketValue > 100);
    }

    positions.sort((a, b) => {
      let aValue: number, bValue: number;

      switch (filters.sortBy) {
        case 'symbol':
          return filters.sortDirection === 'asc'
            ? a.symbol.localeCompare(b.symbol)
            : b.symbol.localeCompare(a.symbol);
        case 'value':
          aValue = a.marketValue;
          bValue = b.marketValue;
          break;
        case 'pnl':
          aValue = a.unrealizedPL;
          bValue = b.unrealizedPL;
          break;
        case 'pnlPercent':
          aValue = a.unrealizedPLPercent;
          bValue = b.unrealizedPLPercent;
          break;
        case 'quantity':
          aValue = a.quantity;
          bValue = b.quantity;
          break;
        case 'risk':
          const riskValues = { LOW: 1, MEDIUM: 2, HIGH: 3 };
          aValue = riskValues[a.risk];
          bValue = riskValues[b.risk];
          break;
        default:
          aValue = a.marketValue;
          bValue = b.marketValue;
      }

      return filters.sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
    });

    return positions;
  }, [portfolioData.positions, filters]);

  // Active Alerts
  const activeAlerts = useMemo(() => {
    return portfolioData.positions.flatMap(pos => 
      pos.alerts.filter(alert => alert.isActive)
    );
  }, [portfolioData.positions]);

  // Handle Add Position
  const handleAddPosition = useCallback(async () => {
    if (!addPositionData.symbol || addPositionData.quantity <= 0 || addPositionData.averagePrice <= 0) {
      alert('Please fill in all required fields with valid values');
      return;
    }

    setIsLoading(true);
    
    try {
      // Get current price for the new position
      const priceData = await getPrice(addPositionData.symbol.toUpperCase());
      const currentPrice = 'price' in priceData ? priceData.price : addPositionData.averagePrice;

      const newPosition: Position = {
        id: Date.now().toString(),
        symbol: addPositionData.symbol.toUpperCase(),
        name: addPositionData.name || addPositionData.symbol.toUpperCase(),
        quantity: addPositionData.quantity,
        averagePrice: addPositionData.averagePrice,
        currentPrice,
        marketValue: addPositionData.quantity * currentPrice,
        unrealizedPL: (addPositionData.quantity * currentPrice) - (addPositionData.quantity * addPositionData.averagePrice),
        unrealizedPLPercent: ((currentPrice - addPositionData.averagePrice) / addPositionData.averagePrice) * 100,
        side: addPositionData.side,
        openDate: new Date().toISOString(),
        lastUpdate: new Date().toISOString(),
        dayChange: 0,
        dayChangePercent: 0,
        weekChange: 0,
        monthChange: 0,
        volume24h: 'volume_24h' in priceData ? priceData.volume_24h || 0 : 0,
        marketCap: 'mcap' in priceData ? priceData.mcap : undefined,
        sector: 'Cryptocurrency',
        risk: 'MEDIUM',
        alerts: []
      };

      setPortfolioData(prev => {
        const newTotalValue = prev.totalValue + newPosition.marketValue;
        const newTotalInvested = prev.totalInvested + (newPosition.quantity * newPosition.averagePrice);
        const newTotalPL = prev.totalPL + newPosition.unrealizedPL;
        
        return {
          ...prev,
          positions: [...prev.positions, newPosition],
          totalValue: newTotalValue,
          totalInvested: newTotalInvested,
          totalPL: newTotalPL,
          totalPLPercent: (newTotalPL / newTotalInvested) * 100,
          updatedAt: new Date().toISOString()
        };
      });

      setAddPositionData({
        symbol: '',
        name: '',
        quantity: 0,
        averagePrice: 0,
        side: 'LONG',
      });

      setShowAddPosition(false);
      alert('Position added successfully!');
    } catch (error) {
      console.error('Failed to add position:', error);
      alert('Failed to add position. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [addPositionData]);

  // Stats Cards
  const statsCards = [
    {
      title: 'Portfolio Value',
      value: formatCurrency(portfolioData.totalValue),
      change: portfolioData.performance.dayChangePercent,
      changeValue: formatCurrency(portfolioData.performance.dayChange),
      icon: DollarSign,
      color: 'text-blue-600',
      bgColor: isDarkMode ? 'bg-blue-900/20' : 'bg-blue-50',
      trend: portfolioData.performance.dayChange >= 0 ? 'up' : 'down'
    },
    {
      title: 'Total P&L',
      value: formatCurrency(portfolioData.totalPL),
      change: portfolioData.performance.totalReturnPercent,
      changeValue: formatPercentage(portfolioData.performance.totalReturnPercent),
      icon: portfolioData.totalPL >= 0 ? TrendingUp : TrendingDown,
      color: portfolioData.totalPL >= 0 ? 'text-green-600' : 'text-red-600',
      bgColor: portfolioData.totalPL >= 0 
        ? (isDarkMode ? 'bg-green-900/20' : 'bg-green-50') 
        : (isDarkMode ? 'bg-red-900/20' : 'bg-red-50'),
      trend: portfolioData.totalPL >= 0 ? 'up' : 'down'
    },
    {
      title: 'Day Change',
      value: formatCurrency(portfolioData.performance.dayChange),
      change: portfolioData.performance.dayChangePercent,
      changeValue: formatPercentage(portfolioData.performance.dayChangePercent),
      icon: portfolioData.performance.dayChange >= 0 ? TrendingUp : TrendingDown,
      color: portfolioData.performance.dayChange >= 0 ? 'text-green-600' : 'text-red-600',
      bgColor: portfolioData.performance.dayChange >= 0 
        ? (isDarkMode ? 'bg-green-900/20' : 'bg-green-50') 
        : (isDarkMode ? 'bg-red-900/20' : 'bg-red-50'),
      trend: portfolioData.performance.dayChange >= 0 ? 'up' : 'down'
    },
    {
      title: 'Cash Available',
      value: formatCurrency(portfolioData.cash),
      change: 0,
      changeValue: `${((portfolioData.cash / portfolioData.totalValue) * 100).toFixed(1)}% of portfolio`,
      icon: Target,
      color: 'text-purple-600',
      bgColor: isDarkMode ? 'bg-purple-900/20' : 'bg-purple-50',
      trend: 'neutral'
    },
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gray-900 text-white' 
        : 'bg-gray-50 text-gray-900'
    }`}>
      {/* Real-time Market Ticker */}
      <div className={`border-b overflow-hidden ${
        isDarkMode 
          ? 'bg-gray-800 border-gray-700' 
          : 'bg-white border-gray-200'
      }`}>
        <div className="relative h-10 flex items-center">
          <div className="flex items-center space-x-8 animate-pulse">
            {portfolioData.positions.map((position, index) => (
              <div key={position.id} className="flex items-center space-x-2 px-4 whitespace-nowrap">
                <span className="font-medium text-sm">{position.symbol}</span>
                <span className="text-sm">{formatCurrency(position.currentPrice)}</span>
                <span className={`text-sm flex items-center ${
                  position.dayChangePercent >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {position.dayChangePercent >= 0 ? (
                    <TrendingUp className="h-3 w-3 mr-1" />
                  ) : (
                    <TrendingDown className="h-3 w-3 mr-1" />
                  )}
                  {formatPercentage(position.dayChangePercent)}
                </span>
                {index < portfolioData.positions.length - 1 && (
                  <div className={`w-px h-4 ${isDarkMode ? 'bg-gray-600' : 'bg-gray-300'}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Header */}
      <div className={`sticky top-0 z-40 border-b transition-colors duration-300 ${
        isDarkMode 
          ? 'bg-gray-800/95 border-gray-700 backdrop-blur-sm' 
          : 'bg-white/95 border-gray-200 backdrop-blur-sm'
      }`}>
        <div className="px-4 lg:px-6 py-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div className="flex items-center space-x-4">
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold">
                  {portfolioData.name}
                </h1>
                <div className="flex items-center space-x-4 mt-1">
                  <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Last updated: {lastUpdateTime.toLocaleTimeString()}
                  </p>
                  <div className="flex items-center space-x-1">
                    {isOnline ? (
                      <Wifi className="h-4 w-4 text-green-500" />
                    ) : (
                      <WifiOff className="h-4 w-4 text-red-500" />
                    )}
                    <span className={`text-xs ${
                      isOnline ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {isOnline ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  {activeAlerts.length > 0 && (
                    <div className="flex items-center space-x-1">
                      <Bell className="h-4 w-4 text-orange-500" />
                      <span className="text-xs text-orange-500">
                        {activeAlerts.length} alerts
                      </span>
                    </div>
                  )}
                  {sentiment && 'score' in sentiment && typeof sentiment.score === 'number' && (
                    <div className="flex items-center space-x-1">
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        (sentiment.score ?? 0) >= 50 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}>
                        Fear & Greed: {sentiment.score ?? 0}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {/* Manual Refresh */}
              <button
                onClick={updatePrices}
                disabled={isLoading}
                className={`p-2 rounded-lg transition-colors ${
                  isLoading
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : isDarkMode
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
                title="Refresh Prices"
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </button>

              {/* Auto Refresh Toggle */}
              <button
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={`p-2 rounded-lg transition-colors ${
                  autoRefresh
                    ? 'bg-green-100 text-green-600 hover:bg-green-200'
                    : isDarkMode
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
                title={autoRefresh ? 'Auto-refresh ON' : 'Auto-refresh OFF'}
              >
                <Activity className={`h-4 w-4 ${autoRefresh ? 'animate-pulse' : ''}`} />
              </button>

              {/* Notifications */}
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className={`relative p-2 rounded-lg transition-colors ${
                  isDarkMode
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Bell className="h-4 w-4" />
                {activeAlerts.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full text-xs"></span>
                )}
              </button>

              {/* Dark Mode Toggle */}
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`p-2 rounded-lg transition-colors ${
                  isDarkMode
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </button>

              {/* Add Position */}
              <button
                onClick={() => setShowAddPosition(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">Add Position</span>
              </button>

              {/* Export */}
              <button
                onClick={() => alert('Export feature coming soon')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  isDarkMode
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Download className="h-4 w-4" />
                <span className="hidden sm:inline">Export</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center space-x-1 mt-4 overflow-x-auto">
            {[
              { key: 'overview', label: 'Overview', icon: DollarSign },
              { key: 'positions', label: 'Positions', icon: PieChart },
              { key: 'analytics', label: 'Analytics', icon: BarChart3 },
              { key: 'alerts', label: 'Alerts', icon: Bell }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setSelectedView(tab.key as any)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${
                  selectedView === tab.key
                    ? 'bg-blue-600 text-white'
                    : isDarkMode
                    ? 'text-gray-400 hover:text-gray-200 hover:bg-gray-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
                {tab.key === 'alerts' && activeAlerts.length > 0 && (
                  <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                    {activeAlerts.length}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 lg:px-6 py-6">
        {/* Overview Tab */}
        {selectedView === 'overview' && (
          <>
            {/* Enhanced Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {statsCards.map((stat, index) => (
                <div
                  key={stat.title}
                  className={`relative p-4 rounded-xl border transition-all duration-200 hover:scale-105 hover:shadow-lg ${
                    isDarkMode
                      ? 'bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700 hover:border-gray-600'
                      : 'bg-gradient-to-br from-white to-gray-50 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <stat.icon className={`h-5 w-5 ${stat.color}`} />
                        <p className={`text-xs font-medium uppercase tracking-wider ${
                          isDarkMode ? 'text-gray-400' : 'text-gray-500'
                        }`}>
                          {stat.title}
                        </p>
                      </div>
                      <p className="text-xl lg:text-2xl font-bold mb-1">{stat.value}</p>
                      <div className={`flex items-center text-xs ${stat.color}`}>
                        {stat.trend === 'up' && <TrendingUp className="h-3 w-3 mr-1" />}
                        {stat.trend === 'down' && <TrendingDown className="h-3 w-3 mr-1" />}
                        <span className="font-medium">{stat.changeValue}</span>
                      </div>
                    </div>
                    <div className={`p-3 rounded-xl ${stat.bgColor} bg-opacity-80`}>
                      <stat.icon className={`h-6 w-6 ${stat.color}`} />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Performance Chart and Asset Allocation */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              {/* Enhanced Performance Chart */}
              <div className={`lg:col-span-2 p-6 rounded-xl border ${
                isDarkMode
                  ? 'bg-gray-800 border-gray-700'
                  : 'bg-white border-gray-200'
              }`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <h3 className="text-lg font-semibold">Portfolio Performance</h3>
                    <div className="flex items-center space-x-2 text-sm">
                      <div className={`flex items-center space-x-1 px-2 py-1 rounded ${
                        portfolioData.performance.dayChange >= 0 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                          : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                      }`}>
                        {portfolioData.performance.dayChange >= 0 ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                        <span className="font-medium">
                          {formatPercentage(portfolioData.performance.dayChangePercent)}
                        </span>
                        <span className="text-xs">24h</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    {(['1h', '4h', '1d', '7d', '30d'] as const).map((timeframe) => (
                      <button
                        key={timeframe}
                        onClick={() => setSelectedTimeframe(timeframe)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all duration-200 ${
                          selectedTimeframe === timeframe
                            ? 'bg-blue-600 text-white shadow-md'
                            : isDarkMode
                            ? 'text-gray-400 hover:text-gray-200 hover:bg-gray-700'
                            : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        {timeframe}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Chart */}
                <div className="relative h-80">
                  <svg viewBox="0 0 800 320" className="w-full h-full">
                    <defs>
                      <linearGradient id="performanceGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.2"/>
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity="0"/>
                      </linearGradient>
                    </defs>
                    
                    {/* Background Grid */}
                    {Array.from({ length: 9 }, (_, i) => (
                      <line
                        key={`hgrid-${i}`}
                        x1="50"
                        y1={40 + i * 30}
                        x2="750"
                        y2={40 + i * 30}
                        stroke={isDarkMode ? '#374151' : '#f3f4f6'}
                        strokeWidth="1"
                        strokeDasharray="2,2"
                      />
                    ))}
                    
                    {/* Chart Line */}
                    <path
                      d={performanceChartData.data.map((value, index) => {
                        const x = 50 + (index / (performanceChartData.data.length - 1)) * 700;
                        const minVal = Math.min(...performanceChartData.data);
                        const maxVal = Math.max(...performanceChartData.data);
                        const y = 280 - ((value - minVal) / (maxVal - minVal)) * 240;
                        return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
                      }).join(' ')}
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />

                    {/* Area Fill */}
                    <path
                      d={[
                        performanceChartData.data.map((value, index) => {
                          const x = 50 + (index / (performanceChartData.data.length - 1)) * 700;
                          const minVal = Math.min(...performanceChartData.data);
                          const maxVal = Math.max(...performanceChartData.data);
                          const y = 280 - ((value - minVal) / (maxVal - minVal)) * 240;
                          return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
                        }).join(' '),
                        'L 750 280 L 50 280 Z'
                      ].join(' ')}
                      fill="url(#performanceGradient)"
                    />

                    {/* Y-axis labels */}
                    {Array.from({ length: 5 }, (_, i) => {
                      const value = Math.min(...performanceChartData.data) + 
                        (Math.max(...performanceChartData.data) - Math.min(...performanceChartData.data)) * (i / 4);
                      return (
                        <text
                          key={i}
                          x="40"
                          y={285 - (i * 60)}
                          textAnchor="end"
                          className={`text-xs ${isDarkMode ? 'fill-gray-400' : 'fill-gray-500'}`}
                        >
                          {formatCurrency(value, true)}
                        </text>
                      );
                    })}
                  </svg>
                </div>
              </div>

              {/* Asset Allocation */}
              <div className={`p-6 rounded-xl border ${
                isDarkMode
                  ? 'bg-gray-800 border-gray-700'
                  : 'bg-white border-gray-200'
              }`}>
                <h3 className="text-lg font-semibold mb-4">Asset Allocation</h3>
                
                {/* Donut Chart */}
                <div className="flex items-center justify-center mb-4">
                  <div className="relative w-32 h-32">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="35"
                        fill="none"
                        stroke={isDarkMode ? '#374151' : '#f3f4f6'}
                        strokeWidth="10"
                      />
                      
                      {allocationChartData.map((item, index) => {
                        const startAngle = allocationChartData.slice(0, index).reduce((sum, d) => sum + (d.value / 100) * 360, 0);
                        const endAngle = startAngle + (item.value / 100) * 360;
                        const startAngleRad = (startAngle - 90) * Math.PI / 180;
                        const endAngleRad = (endAngle - 90) * Math.PI / 180;
                        
                        const x1 = 50 + 35 * Math.cos(startAngleRad);
                        const y1 = 50 + 35 * Math.sin(startAngleRad);
                        const x2 = 50 + 35 * Math.cos(endAngleRad);
                        const y2 = 50 + 35 * Math.sin(endAngleRad);
                        
                        const largeArcFlag = item.value > 50 ? 1 : 0;
                        
                        return (
                          <path
                            key={item.label}
                            d={`M 50 50 L ${x1} ${y1} A 35 35 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
                            fill={item.color}
                            className="hover:brightness-110 transition-all duration-200"
                          />
                        );
                      })}
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-xs font-medium">Total</div>
                        <div className="text-sm font-bold">{formatCurrency(portfolioData.totalValue, true)}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Asset List */}
                <div className="space-y-2">
                  {allocationChartData
                    .sort((a, b) => b.value - a.value)
                    .map((item) => (
                    <div key={item.label} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-sm font-medium">{item.label}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">{item.value.toFixed(1)}%</div>
                        <div className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          {formatCurrency(item.amount, true)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Market News */}
              <div className={`p-6 rounded-xl border ${
                isDarkMode
                  ? 'bg-gray-800 border-gray-700'
                  : 'bg-white border-gray-200'
              }`}>
                <h3 className="text-lg font-semibold mb-4">Market News</h3>
                <div className="space-y-3">
                  {news.length > 0 ? news.slice(0, 3).map((item) => (
                    <div
                      key={item.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        isDarkMode
                          ? 'bg-gray-700 hover:bg-gray-600'
                          : 'bg-gray-50 hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm mb-1">{item.title}</h4>
                          <p className={`text-xs mb-2 ${
                            isDarkMode ? 'text-gray-400' : 'text-gray-500'
                          }`}>
                            {item.summary}
                          </p>
                          <div className="flex items-center space-x-2">
                            {item.symbol && (
                              <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded">
                                {item.symbol}
                              </span>
                            )}
                            <span className={`text-xs ${
                              item.sentiment === 'POSITIVE'
                                ? 'text-green-600'
                                : item.sentiment === 'NEGATIVE'
                                ? 'text-red-600'
                                : isDarkMode ? 'text-gray-400' : 'text-gray-500'
                            }`}>
                              {item.sentiment}
                            </span>
                            <span className={`text-xs ${
                              isDarkMode ? 'text-gray-400' : 'text-gray-500'
                            }`}>
                              {formatDate(item.timestamp)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )) : (
                    <div className="text-center py-8">
                      <Globe className={`h-8 w-8 mx-auto mb-2 ${
                        isDarkMode ? 'text-gray-600' : 'text-gray-400'
                      }`} />
                      <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                        Loading market news...
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Market Sentiment */}
              <div className={`p-6 rounded-xl border ${
                isDarkMode
                  ? 'bg-gray-800 border-gray-700'
                  : 'bg-white border-gray-200'
              }`}>
                <h3 className="text-lg font-semibold mb-4">Market Sentiment</h3>
                {sentiment && 'score' in sentiment ? (
                  <div className="text-center">
                    <div className="relative w-32 h-32 mx-auto mb-4">
                      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke={isDarkMode ? '#374151' : '#e5e7eb'}
                          strokeWidth="8"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke={(sentiment.score ?? 0) >= 50 ? '#10b981' : '#ef4444'}
                          strokeWidth="8"
                           strokeDasharray={`${((sentiment.score ?? 0) / 100) * 251.2} 251.2`}
                           strokeDasharray={`${((sentiment.score || 0) / 100) * 251.2} 251.2`}
                           strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <div className="text-2xl font-bold">{sentiment.score ?? 0}</div>
                          <div className="text-xs">Fear & Greed</div>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm font-medium mb-1">{sentiment.class}</p>
                    <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      Market sentiment index
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Activity className={`h-8 w-8 mx-auto mb-2 ${
                      isDarkMode ? 'text-gray-600' : 'text-gray-400'
                    }`} />
                    <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                      Loading sentiment data...
                    </p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        {/* Positions Tab */}
        {selectedView === 'positions' && (
          <div className={`rounded-xl border ${
            isDarkMode
              ? 'bg-gray-800 border-gray-700'
              : 'bg-white border-gray-200'
          }`}>
            {/* Filters */}
            <div className={`p-6 border-b ${
              isDarkMode ? 'border-gray-700' : 'border-gray-200'
            }`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <h3 className="text-lg font-semibold">Current Positions</h3>
                
                <div className="flex flex-wrap items-center gap-4">
                  {/* Search */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search positions..."
                      value={filters.search}
                      onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                      className={`pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm ${
                        isDarkMode
                          ? 'bg-gray-700 border-gray-600 text-white'
                          : 'bg-white border-gray-200'
                      }`}
                    />
                  </div>
                  
                  {/* Profit Filter */}
                  <select
                    value={filters.profitFilter}
                    onChange={(e) => setFilters(prev => ({ 
                      ...prev, 
                      profitFilter: e.target.value as 'all' | 'profit' | 'loss' 
                    }))}
                    className={`px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm ${
                      isDarkMode
                        ? 'bg-gray-700 border-gray-600 text-white'
                        : 'bg-white border-gray-200'
                    }`}
                  >
                    <option value="all">All P&L</option>
                    <option value="profit">Profitable</option>
                    <option value="loss">Loss</option>
                  </select>

                  {/* Sort */}
                  <select
                    value={`${filters.sortBy}-${filters.sortDirection}`}
                    onChange={(e) => {
                      const [sortBy, sortDirection] = e.target.value.split('-');
                      setFilters(prev => ({ 
                        ...prev, 
                        sortBy: sortBy as any,
                        sortDirection: sortDirection as 'asc' | 'desc'
                      }));
                    }}
                    className={`px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm ${
                      isDarkMode
                        ? 'bg-gray-700 border-gray-600 text-white'
                        : 'bg-white border-gray-200'
                    }`}
                  >
                    <option value="value-desc">Value (High to Low)</option>
                    <option value="value-asc">Value (Low to High)</option>
                    <option value="pnl-desc">P&L (High to Low)</option>
                    <option value="pnl-asc">P&L (Low to High)</option>
                    <option value="pnlPercent-desc">P&L % (High to Low)</option>
                    <option value="pnlPercent-asc">P&L % (Low to High)</option>
                    <option value="symbol-asc">Symbol (A to Z)</option>
                    <option value="symbol-desc">Symbol (Z to A)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Positions Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className={isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}>
                  <tr>
                    <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Asset
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Quantity
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Avg Price
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Current Price
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Market Value
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Unrealized P&L
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Risk
                    </th>
                    <th className={`px-6 py-3 text-right text-xs font-medium uppercase tracking-wider ${
                      isDarkMode ? 'text-gray-400' : 'text-gray-500'
                    }`}>
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className={`divide-y ${isDarkMode ? 'divide-gray-700' : 'divide-gray-200'}`}>
                  {filteredPositions.map((position) => (
                    <tr
                      key={position.id}
                      className={`transition-colors ${
                        isDarkMode
                          ? 'hover:bg-gray-700'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div
                            className="w-8 h-8 rounded-full mr-3 flex items-center justify-center text-white text-sm font-bold"
                            style={{ backgroundColor: getSymbolColor(position.symbol) }}
                          >
                            {position.symbol.charAt(0)}
                          </div>
                          <div>
                            <div className="font-medium">{position.name}</div>
                            <div className={`text-sm ${
                              isDarkMode ? 'text-gray-400' : 'text-gray-500'
                            }`}>
                              {position.symbol} • {position.side}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className="font-medium">
                          {position.quantity.toLocaleString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className="font-medium">
                          {formatCurrency(position.averagePrice)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className={`transition-all duration-300 ${
                          priceAnimations[position.id] === 'up' ? 'bg-green-100 dark:bg-green-900/30' :
                          priceAnimations[position.id] === 'down' ? 'bg-red-100 dark:bg-red-900/30' : ''
                        } ${priceAnimations[position.id] ? 'px-2 py-1 rounded' : ''}`}>
                          <div className={`font-medium ${
                            priceAnimations[position.id] === 'up' ? 'text-green-700 dark:text-green-300' :
                            priceAnimations[position.id] === 'down' ? 'text-red-700 dark:text-red-300' : ''
                          }`}>
                            {formatCurrency(position.currentPrice)}
                          </div>
                          <div className={`text-sm flex items-center ${
                            position.dayChangePercent >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {position.dayChangePercent >= 0 ? (
                              <TrendingUp className="h-3 w-3 mr-1" />
                            ) : (
                              <TrendingDown className="h-3 w-3 mr-1" />
                            )}
                            {formatPercentage(position.dayChangePercent)}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className="font-medium">
                          {formatCurrency(position.marketValue)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className={`font-medium ${
                          position.unrealizedPL >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatCurrency(position.unrealizedPL)}
                        </div>
                        <div className={`text-sm ${
                          position.unrealizedPL >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatPercentage(position.unrealizedPLPercent)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                          getRiskColor(position.risk)
                        }`}>
                          {position.risk}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => alert(`Viewing chart for ${position.symbol}`)}
                            className={`p-1 rounded transition-colors ${
                              isDarkMode
                                ? 'text-gray-400 hover:text-blue-400'
                                : 'text-gray-400 hover:text-blue-500'
                            }`}
                            title="View Chart"
                          >
                            <BarChart3 className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => alert('Edit position')}
                            className={`p-1 rounded transition-colors ${
                              isDarkMode
                                ? 'text-gray-400 hover:text-yellow-400'
                                : 'text-gray-400 hover:text-yellow-500'
                            }`}
                            title="Edit Position"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => confirm('Close position?') && alert('Position closed')}
                            className={`p-1 rounded transition-colors ${
                              isDarkMode
                                ? 'text-gray-400 hover:text-red-400'
                                : 'text-gray-400 hover:text-red-500'
                            }`}
                            title="Close Position"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredPositions.length === 0 && (
              <div className="p-8 text-center">
                <PieChart className={`h-8 w-8 mx-auto mb-4 ${
                  isDarkMode ? 'text-gray-400' : 'text-gray-400'
                }`} />
                <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                  No positions found matching your criteria
                </p>
              </div>
            )}
          </div>
        )}

        {/* Analytics Tab */}
        {selectedView === 'analytics' && (
          <div className="space-y-6">
            <div className={`p-6 rounded-xl border ${
              isDarkMode
                ? 'bg-gray-800 border-gray-700'
                : 'bg-white border-gray-200'
            }`}>
              <h3 className="text-xl font-semibold mb-4">Portfolio Analytics</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <div className="text-2xl font-bold text-blue-600">{portfolioData.performance.sharpeRatio.toFixed(2)}</div>
                  <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Sharpe Ratio</div>
                </div>
                <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <div className="text-2xl font-bold text-red-600">{portfolioData.performance.maxDrawdown}%</div>
                  <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Max Drawdown</div>
                </div>
                <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <div className="text-2xl font-bold text-green-600">{portfolioData.performance.winRate}%</div>
                  <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Win Rate</div>
                </div>
                <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <div className="text-2xl font-bold text-purple-600">{portfolioData.performance.volatility.toFixed(1)}%</div>
                  <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Volatility</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Alerts Tab */}
        {selectedView === 'alerts' && (
          <div className="space-y-6">
            <div className={`p-6 rounded-xl border ${
              isDarkMode
                ? 'bg-gray-800 border-gray-700'
                : 'bg-white border-gray-200'
            }`}>
              <h3 className="text-xl font-semibold mb-4">Smart Alerts</h3>
              {activeAlerts.length > 0 ? (
                <div className="space-y-4">
                  {activeAlerts.map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-4 rounded-lg border-l-4 ${
                        alert.type === 'PRICE_TARGET'
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                          : alert.type === 'STOP_LOSS'
                          ? 'border-red-500 bg-red-50 dark:bg-red-900/20'
                          : 'border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{alert.message}</p>
                          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            {formatDate(alert.createdAt)}
                          </p>
                        </div>
                        <button
                          className={`p-2 rounded-lg transition-colors ${
                            isDarkMode
                              ? 'text-gray-400 hover:text-gray-200 hover:bg-gray-700'
                              : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
                          }`}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Bell className={`h-12 w-12 mx-auto mb-4 ${
                    isDarkMode ? 'text-gray-600' : 'text-gray-400'
                  }`} />
                  <h3 className="text-lg font-medium mb-2">No Active Alerts</h3>
                  <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-500'} mb-4`}>
                    Create your first alert to monitor price movements
                  </p>
                  <button
                    onClick={() => alert('Create alert feature coming soon')}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Plus className="h-4 w-4 mr-2 inline" />
                    Create Alert
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Add Position Modal */}
      {showAddPosition && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          onClick={() => setShowAddPosition(false)}
        >
          <div
            className={`rounded-xl shadow-xl max-w-md w-full p-6 ${
              isDarkMode ? 'bg-gray-800' : 'bg-white'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">Add New Position</h3>
              <button
                onClick={() => setShowAddPosition(false)}
                className={`p-2 rounded-lg transition-colors ${
                  isDarkMode
                    ? 'text-gray-400 hover:text-gray-200 hover:bg-gray-700'
                    : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
                }`}
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className={`block text-sm font-medium mb-1 ${
                  isDarkMode ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  Symbol
                </label>
                <input
                  type="text"
                  value={addPositionData.symbol}
                  onChange={(e) => setAddPositionData(prev => ({ 
                    ...prev, 
                    symbol: e.target.value.toUpperCase() 
                  }))}
                  placeholder="e.g., BTC"
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isDarkMode
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-200'
                  }`}
                  required
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-1 ${
                  isDarkMode ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  Name
                </label>
                <input
                  type="text"
                  value={addPositionData.name}
                  onChange={(e) => setAddPositionData(prev => ({ 
                    ...prev, 
                    name: e.target.value 
                  }))}
                  placeholder="e.g., Bitcoin"
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isDarkMode
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-200'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={`block text-sm font-medium mb-1 ${
                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                  }`}>
                    Quantity
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={addPositionData.quantity || ''}
                    onChange={(e) => setAddPositionData(prev => ({ 
                      ...prev, 
                      quantity: parseFloat(e.target.value) || 0 
                    }))}
                    className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      isDarkMode
                        ? 'bg-gray-700 border-gray-600 text-white'
                        : 'bg-white border-gray-200'
                    }`}
                    required
                  />
                </div>
                
                <div>
                  <label className={`block text-sm font-medium mb-1 ${
                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                  }`}>
                    Avg Price
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={addPositionData.averagePrice || ''}
                    onChange={(e) => setAddPositionData(prev => ({ 
                      ...prev, 
                      averagePrice: parseFloat(e.target.value) || 0 
                    }))}
                    className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      isDarkMode
                        ? 'bg-gray-700 border-gray-600 text-white'
                        : 'bg-white border-gray-200'
                    }`}
                    required
                  />
                </div>
              </div>

              <div>
                <label className={`block text-sm font-medium mb-1 ${
                  isDarkMode ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  Side
                </label>
                <select
                  value={addPositionData.side}
                  onChange={(e) => setAddPositionData(prev => ({ 
                    ...prev, 
                    side: e.target.value as 'LONG' | 'SHORT' 
                  }))}
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isDarkMode
                      ? 'bg-gray-700 border-gray-600 text-white'
                      : 'bg-white border-gray-200'
                  }`}
                >
                  <option value="LONG">Long</option>
                  <option value="SHORT">Short</option>
                </select>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowAddPosition(false)}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    isDarkMode
                      ? 'text-gray-300 hover:bg-gray-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddPosition}
                  disabled={isLoading}
                  className={`px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors ${
                    isLoading ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {isLoading ? 'Adding...' : 'Add Position'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Notifications Panel */}
      {showNotifications && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-end p-4 z-50"
          onClick={() => setShowNotifications(false)}
        >
          <div
            className={`w-80 mt-16 rounded-xl shadow-xl p-4 ${
              isDarkMode ? 'bg-gray-800' : 'bg-white'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Notifications</h3>
              <button
                onClick={() => setShowNotifications(false)}
                className={`p-1 rounded transition-colors ${
                  isDarkMode
                    ? 'text-gray-400 hover:text-gray-200'
                    : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              {activeAlerts.length > 0 ? (
                activeAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 rounded-lg border-l-4 ${
                      alert.type === 'PRICE_TARGET'
                        ? 'border-blue-500 bg-blue-50'
                        : alert.type === 'STOP_LOSS'
                        ? 'border-red-500 bg-red-50'
                        : 'border-yellow-500 bg-yellow-50'
                    } ${isDarkMode ? 'bg-opacity-20' : ''}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{alert.message}</p>
                        <p className={`text-xs mt-1 ${
                          isDarkMode ? 'text-gray-400' : 'text-gray-500'
                        }`}>
                          {formatDate(alert.createdAt)}
                        </p>
                      </div>
                      <button
                        className={`p-1 rounded transition-colors ${
                          isDarkMode
                            ? 'text-gray-400 hover:text-gray-200'
                            : 'text-gray-400 hover:text-gray-600'
                        }`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <Bell className={`h-8 w-8 mx-auto mb-2 ${
                    isDarkMode ? 'text-gray-600' : 'text-gray-400'
                  }`} />
                  <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                    No active alerts
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedPortfolio;
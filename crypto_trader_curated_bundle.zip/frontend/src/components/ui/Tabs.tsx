'use client';

import * as React from 'react';
import { cn } from '@/lib/utils/cn';

const TabsContext = React.createContext<{
  selectedTab: string;
  setSelectedTab: (id: string) => void;
}>({
  selectedTab: '',
  setSelectedTab: () => {},
});

export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  defaultValue: string;
  onValueChange?: (value: string) => void;
}

function Tabs({ defaultValue, onValueChange, className, children, ...props }: TabsProps) {
  const [selectedTab, setSelectedTab] = React.useState(defaultValue);

  const handleTabChange = React.useCallback(
    (value: string) => {
      setSelectedTab(value);
      onValueChange?.(value);
    },
    [onValueChange]
  );

  return (
    <TabsContext.Provider value={{ selectedTab, setSelectedTab: handleTabChange }}>
      <div className={cn('space-y-2', className)} {...props}>
        {children}
      </div>
    </TabsContext.Provider>
  );
}

export interface TabsListProps extends React.HTMLAttributes<HTMLDivElement> {}

function TabsList({ className, ...props }: TabsListProps) {
  return (
    <div
      className={cn(
        'flex space-x-1 rounded-md bg-dark-700 p-1',
        className
      )}
      {...props}
    />
  );
}

export interface TabsTriggerProps extends React.HTMLAttributes<HTMLButtonElement> {
  value: string;
  disabled?: boolean;
}

function TabsTrigger({ value, disabled, className, ...props }: TabsTriggerProps) {
  const { selectedTab, setSelectedTab } = React.useContext(TabsContext);
  const isSelected = selectedTab === value;

  return (
    <button
      type="button"
      role="tab"
      aria-selected={isSelected}
      disabled={disabled}
      className={cn(
        'inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 disabled:pointer-events-none disabled:opacity-50',
        {
          'bg-dark-800 text-white shadow-sm': isSelected,
          'text-gray-400 hover:text-white': !isSelected,
        },
        className
      )}
      onClick={() => setSelectedTab(value)}
      {...props}
    />
  );
}

export interface TabsContentProps extends React.HTMLAttributes<HTMLDivElement> {
  value: string;
}

function TabsContent({ value, className, ...props }: TabsContentProps) {
  const { selectedTab } = React.useContext(TabsContext);
  const isSelected = selectedTab === value;

  if (!isSelected) return null;

  return (
    <div
      role="tabpanel"
      className={cn(
        'mt-2 rounded-md',
        className
      )}
      {...props}
    />
  );
}

export { Tabs, TabsList, TabsTrigger, TabsContent };
'use client';

import * as React from 'react';
import { cn } from '@/lib/utils/cn';

export interface TooltipProps {
  content: React.ReactNode;
  children: React.ReactNode;
  side?: 'top' | 'right' | 'bottom' | 'left';
  align?: 'start' | 'center' | 'end';
  className?: string;
  contentClassName?: string;
  delayDuration?: number;
}

export function Tooltip({
  content,
  children,
  side = 'top',
  align = 'center',
  className,
  contentClassName,
  delayDuration = 300,
}: TooltipProps) {
  const [isVisible, setIsVisible] = React.useState(false);
  const [position, setPosition] = React.useState({ top: 0, left: 0 });
  const triggerRef = React.useRef<HTMLDivElement>(null);
  const tooltipRef = React.useRef<HTMLDivElement>(null);
  const timeoutRef = React.useRef<NodeJS.Timeout | null>(null);

  const calculatePosition = React.useCallback(() => {
    if (!triggerRef.current || !tooltipRef.current) return;

    const triggerRect = triggerRef.current.getBoundingClientRect();
    const tooltipRect = tooltipRef.current.getBoundingClientRect();
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;

    let top = 0;
    let left = 0;

    switch (side) {
      case 'top':
        top = triggerRect.top - tooltipRect.height - 8 + scrollY;
        break;
      case 'right':
        left = triggerRect.right + 8 + scrollX;
        break;
      case 'bottom':
        top = triggerRect.bottom + 8 + scrollY;
        break;
      case 'left':
        left = triggerRect.left - tooltipRect.width - 8 + scrollX;
        break;
    }

    switch (align) {
      case 'start':
        if (side === 'top' || side === 'bottom') {
          left = triggerRect.left + scrollX;
        } else {
          top = triggerRect.top + scrollY;
        }
        break;
      case 'center':
        if (side === 'top' || side === 'bottom') {
          left = triggerRect.left + triggerRect.width / 2 - tooltipRect.width / 2 + scrollX;
        } else {
          top = triggerRect.top + triggerRect.height / 2 - tooltipRect.height / 2 + scrollY;
        }
        break;
      case 'end':
        if (side === 'top' || side === 'bottom') {
          left = triggerRect.right - tooltipRect.width + scrollX;
        } else {
          top = triggerRect.bottom - tooltipRect.height + scrollY;
        }
        break;
    }

    setPosition({ top, left });
  }, [side, align]);

  const handleMouseEnter = React.useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      setIsVisible(true);
      setTimeout(calculatePosition, 0);
    }, delayDuration);
  }, [calculatePosition, delayDuration]);

  const handleMouseLeave = React.useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    setIsVisible(false);
  }, []);

  React.useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <div
      className={cn('relative inline-block', className)}
      ref={triggerRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onFocus={handleMouseEnter}
      onBlur={handleMouseLeave}
    >
      {children}
      {isVisible && (
        <div
          ref={tooltipRef}
          className={cn(
            'absolute z-50 px-2 py-1 text-xs font-medium text-white bg-dark-900 rounded-md shadow-md border border-dark-700',
            contentClassName
          )}
          style={{
            top: `${position.top}px`,
            left: `${position.left}px`,
          }}
        >
          {content}
        </div>
      )}
    </div>
  );
}
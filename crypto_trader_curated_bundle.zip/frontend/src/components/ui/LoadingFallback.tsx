// src/components/ui/LoadingFallback.tsx
'use client';

import { Loader2 } from 'lucide-react';

interface LoadingFallbackProps {
  message?: string;
}

export default function LoadingFallback({ message = 'Loading...' }: LoadingFallbackProps) {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="flex flex-col items-center space-y-4">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        <p className="text-gray-300 text-sm">{message}</p>
      </div>
    </div>
  );
}
    
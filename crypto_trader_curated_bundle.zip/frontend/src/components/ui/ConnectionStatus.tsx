'use client';

import { useEffect, useState } from 'react';
import { Wifi, WifiOff, AlertCircle } from 'lucide-react';

type ConnectionState = 'connected' | 'disconnected' | 'reconnecting';

export function ConnectionStatus() {
  const [connectionState, setConnectionState] = useState<ConnectionState>('connected');
  const [exchangeStatus, setExchangeStatus] = useState({
    binance: true,
    okx: true,
    coinbase: false,
    bybit: true,
    kraken: true,
  });

  useEffect(() => {
    // Simulate connection monitoring
    const interval = setInterval(() => {
      // Random connection simulation for demo
      const isConnected = Math.random() > 0.1; // 90% uptime
      setConnectionState(isConnected ? 'connected' : 'reconnecting');
      
      // Simulate exchange status
      setExchangeStatus({
        binance: Math.random() > 0.05,
        okx: Math.random() > 0.05,
        coinbase: Math.random() > 0.1,
        bybit: Math.random() > 0.05,
        kraken: Math.random() > 0.05,
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = () => {
    switch (connectionState) {
      case 'connected':
        return <Wifi className="h-4 w-4 text-success-400" />;
      case 'disconnected':
        return <WifiOff className="h-4 w-4 text-danger-400" />;
      case 'reconnecting':
        return <AlertCircle className="h-4 w-4 text-warning-400 animate-pulse" />;
    }
  };

  const getStatusText = () => {
    switch (connectionState) {
      case 'connected':
        return 'Connected';
      case 'disconnected':
        return 'Disconnected';
      case 'reconnecting':
        return 'Reconnecting...';
    }
  };

  const connectedExchanges = Object.values(exchangeStatus).filter(Boolean).length;
  const totalExchanges = Object.keys(exchangeStatus).length;

  return (
    <div className="flex items-center space-x-2 text-sm">
      {getStatusIcon()}
      <span className="text-gray-400">
        {getStatusText()}
      </span>
      <span className="text-xs text-gray-500">
        ({connectedExchanges}/{totalExchanges} exchanges)
      </span>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { Calendar, TrendingUp, TrendingDown, DollarSign, BarChart3 } from 'lucide-react';
import { CandleChart } from './Analytics/__CandleChart';
import { MetricCardSkeleton } from './__skeletons/MetricCardSkeleton';
import marketService from '@/services/marketService';
import signalService from '@/services/signalService';
import { Candle, Backtest } from '@/types';

const STORAGE_KEY = 'analytics-preferences';

interface AnalyticsState {
  symbol: string;
  range: {
    from: Date;
    to: Date;
  };
  candles: Candle[];
  backtest: Backtest | null;
  loading: boolean;
  error: string | null;
}

export function Analytics() {
  const [state, setState] = useState<AnalyticsState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    const defaults = {
      symbol: 'BTCUSD',
      range: {
        from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
        to: new Date(),
      },
      candles: [],
      backtest: null,
      loading: false,
      error: null,
    };

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...defaults,
          symbol: parsed.symbol || defaults.symbol,
          range: {
            from: parsed.range?.from ? new Date(parsed.range.from) : defaults.range.from,
            to: parsed.range?.to ? new Date(parsed.range.to) : defaults.range.to,
          },
        };
      } catch {
        return defaults;
      }
    }

    return defaults;
  });

  const savePreferences = (symbol: string, range: { from: Date; to: Date }) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ symbol, range }));
  };

  const loadData = async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const [candles, backtest] = await Promise.all([
        marketService.getHistoricalPrices(state.symbol, state.range.from, state.range.to),
        signalService.getBacktest(state.symbol),
      ]);

      setState(prev => ({
        ...prev,
        candles,
        backtest,
        loading: false,
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Failed to load data',
        loading: false,
      }));
    }
  };

  useEffect(() => {
    loadData();
  }, [state.symbol, state.range]);

  const handleSymbolChange = (symbol: string) => {
    setState(prev => ({ ...prev, symbol }));
    savePreferences(symbol, state.range);
  };

  const handleRangeChange = (range: { from: Date; to: Date }) => {
    setState(prev => ({ ...prev, range }));
    savePreferences(state.symbol, range);
  };

  const formatDate = (date: Date) => date.toISOString().split('T')[0];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Analytics Dashboard
          </h1>
          
          {/* Controls */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 mb-6">
            <div className="flex flex-wrap gap-4 items-center">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Asset
                </label>
                <select
                  value={state.symbol}
                  onChange={(e) => handleSymbolChange(e.target.value)}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                >
                  <option value="BTCUSD">BTC/USD</option>
                  <option value="ETHUSD">ETH/USD</option>
                  <option value="AAPL">AAPL</option>
                  <option value="GOOGL">GOOGL</option>
                  <option value="TSLA">TSLA</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  From
                </label>
                <input
                  type="date"
                  value={formatDate(state.range.from)}
                  onChange={(e) => handleRangeChange({
                    ...state.range,
                    from: new Date(e.target.value),
                  })}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  To
                </label>
                <input
                  type="date"
                  value={formatDate(state.range.to)}
                  onChange={(e) => handleRangeChange({
                    ...state.range,
                    to: new Date(e.target.value),
                  })}
                  className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Error State */}
          {state.error && (
            <div className="bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
              {state.error}
            </div>
          )}

          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {state.loading ? (
              <>
                <MetricCardSkeleton lines={2} />
                <MetricCardSkeleton lines={2} />
                <MetricCardSkeleton lines={2} />
              </>
            ) : state.backtest ? (
              <>
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <TrendingUp className="w-8 h-8 text-green-500 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">CAGR</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">
                        {(state.backtest.cagr * 100).toFixed(1)}%
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <BarChart3 className="w-8 h-8 text-blue-500 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sharpe Ratio</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">
                        {state.backtest.sharpe.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <DollarSign className="w-8 h-8 text-purple-500 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Return</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">
                        {state.backtest.points.length > 0 ? 
                          ((state.backtest.points[state.backtest.points.length - 1].equity / state.backtest.points[0].equity - 1) * 100).toFixed(1) 
                          : '0.0'}%
                      </p>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <TrendingDown className="w-8 h-8 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">No Data</p>
                      <p className="text-2xl font-bold text-gray-500 dark:text-gray-500">--</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <TrendingDown className="w-8 h-8 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">No Data</p>
                      <p className="text-2xl font-bold text-gray-500 dark:text-gray-500">--</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
                  <div className="flex items-center">
                    <TrendingDown className="w-8 h-8 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">No Data</p>
                      <p className="text-2xl font-bold text-gray-500 dark:text-gray-500">--</p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Candlestick Chart */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Price Chart - {state.symbol}
              </h3>
              <div className="h-80">
                {state.loading ? (
                  <div className="h-full bg-gray-200 dark:bg-gray-700 rounded animate-pulse" />
                ) : state.candles.length > 0 ? (
                  <CandleChart candles={state.candles} />
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                    No chart data available
                  </div>
                )}
              </div>
            </div>

            {/* Equity Curve */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Equity Curve
              </h3>
              <div className="h-80">
                {state.loading ? (
                  <div className="h-full bg-gray-200 dark:bg-gray-700 rounded animate-pulse" />
                ) : state.backtest?.points.length ? (
                  <div className="h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                    Equity curve chart would be rendered here
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                    No backtest data available
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
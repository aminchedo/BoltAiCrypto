import React from 'react';
import {
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { Candle } from '@/types';

interface CandleChartProps {
  candles: Candle[];
  width?: string | number;
  height?: string | number;
}

interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  color: string;
}

export function CandleChart({ candles, width = '100%', height = '100%' }: CandleChartProps) {
  const data: CandleData[] = candles.map((candle) => ({
    time: new Date(candle.t).toLocaleDateString(),
    open: candle.o,
    high: candle.h,
    low: candle.l,
    close: candle.c,
    volume: candle.v,
    color: candle.c >= candle.o ? '#22c55e' : '#ef4444',
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-gray-800 p-3 border border-gray-200 dark:border-gray-700 rounded shadow-lg">
          <p className="text-sm font-medium text-gray-900 dark:text-white">{label}</p>
          <div className="mt-2 space-y-1">
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Open: <span className="font-mono">${data.open.toFixed(2)}</span>
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              High: <span className="font-mono">${data.high.toFixed(2)}</span>
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Low: <span className="font-mono">${data.low.toFixed(2)}</span>
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Close: <span className="font-mono">${data.close.toFixed(2)}</span>
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Volume: <span className="font-mono">{data.volume.toLocaleString()}</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  const CandleShape = (props: any) => {
    const { payload, x, y, width, height } = props;
    if (!payload) return null;

    const { open, high, low, close, color } = payload;
    const candleWidth = width * 0.8;
    const candleX = x + width * 0.1;
    
    // Calculate positions
    const maxPrice = Math.max(open, close);
    const minPrice = Math.min(open, close);
    const bodyHeight = Math.abs(close - open) * (height / (high - low));
    const bodyY = y + ((high - maxPrice) / (high - low)) * height;
    
    return (
      <g>
        {/* Wick */}
        <line
          x1={candleX + candleWidth / 2}
          y1={y}
          x2={candleX + candleWidth / 2}
          y2={y + height}
          stroke={color}
          strokeWidth={1}
        />
        {/* Body */}
        <rect
          x={candleX}
          y={bodyY}
          width={candleWidth}
          height={Math.max(bodyHeight, 1)}
          fill={color}
          stroke={color}
          strokeWidth={1}
        />
      </g>
    );
  };

  return (
    <ResponsiveContainer width={width} height={height}>
      <ComposedChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
        <XAxis
          dataKey="time"
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="text-gray-600 dark:text-gray-400"
        />
        <YAxis
          domain={['dataMin', 'dataMax']}
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12 }}
          className="text-gray-600 dark:text-gray-400"
        />
        <Tooltip content={<CustomTooltip />} />
        <Bar
          dataKey="high"
          fill="transparent"
          shape={<CandleShape />}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
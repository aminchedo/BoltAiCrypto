'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

interface Position {
  id: string;
  symbol: string;
  side: 'long' | 'short';
  size: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
}

interface TradingContextType {
  positions: Position[];
  balance: number;
  isTrading: boolean;
  setPositions: (positions: Position[]) => void;
  setBalance: (balance: number) => void;
  setIsTrading: (isTrading: boolean) => void;
  addPosition: (position: Position) => void;
  removePosition: (id: string) => void;
  updatePosition: (id: string, updates: Partial<Position>) => void;
}

const TradingContext = createContext<TradingContextType | undefined>(undefined);

export const TradingProvider = ({ children }: { children: ReactNode }) => {
  const [positions, setPositions] = useState<Position[]>([]);
  const [balance, setBalance] = useState(10000);
  const [isTrading, setIsTrading] = useState(false);

  const addPosition = (position: Position) => {
    setPositions(prev => [...prev, position]);
  };

  const removePosition = (id: string) => {
    setPositions(prev => prev.filter(pos => pos.id !== id));
  };

  const updatePosition = (id: string, updates: Partial<Position>) => {
    setPositions(prev => prev.map(pos => 
      pos.id === id ? { ...pos, ...updates } : pos
    ));
  };

  const value = {
    positions,
    balance,
    isTrading,
    setPositions,
    setBalance,
    setIsTrading,
    addPosition,
    removePosition,
    updatePosition,
  };

  return <TradingContext.Provider value={value}>{children}</TradingContext.Provider>;
};

export const useTrading = () => {
  const context = useContext(TradingContext);
  if (!context) {
    throw new Error('useTrading must be used within a TradingProvider');
  }
  return context;
};
'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

interface TradingSettings {
  riskPerTrade: number;
  maxPositions: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  autoTrading: boolean;
}

interface NotificationSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  soundAlerts: boolean;
  priceAlerts: boolean;
}

interface DisplaySettings {
  currency: string;
  timeZone: string;
  chartType: 'candlestick' | 'line' | 'area';
  showVolume: boolean;
}

interface Settings {
  trading: TradingSettings;
  notifications: NotificationSettings;
  display: DisplaySettings;
}

interface SettingsContextType {
  settings: Settings;
  updateSettings: (category: keyof Settings, updates: Partial<Settings[keyof Settings]>) => void;
  resetSettings: () => void;
}

const defaultSettings: Settings = {
  trading: {
    riskPerTrade: 2,
    maxPositions: 5,
    stopLossPercent: 5,
    takeProfitPercent: 10,
    autoTrading: false,
  },
  notifications: {
    emailNotifications: true,
    pushNotifications: true,
    soundAlerts: true,
    priceAlerts: true,
  },
  display: {
    currency: 'USD',
    timeZone: 'UTC',
    chartType: 'candlestick',
    showVolume: true,
  },
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider = ({ children }: { children: ReactNode }) => {
  const [settings, setSettings] = useState<Settings>(defaultSettings);

  const updateSettings = (category: keyof Settings, updates: Partial<Settings[keyof Settings]>) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        ...updates,
      },
    }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
  };

  const value = {
    settings,
    updateSettings,
    resetSettings,
  };

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
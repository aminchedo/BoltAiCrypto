'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle, RefreshCw, Home, Bug } from 'lucide-react'
import Link from 'next/link'

interface ErrorProps {
  error: Error & { digest?: string }
  reset: () => void
}

export default function Error({ error, reset }: ErrorProps) {
  useEffect(() => {
    // Log error to external service
    console.error('Application Error:', error)
  }, [error])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(239,68,68,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(249,115,22,0.1),transparent_50%)]" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="text-center relative z-10 max-w-lg mx-auto px-6"
      >
        {/* Error Icon */}
        <motion.div
          animate={{ 
            rotate: [0, 5, -5, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            repeatType: 'reverse'
          }}
          className="mb-8"
        >
          <div className="w-20 h-20 mx-auto bg-gradient-to-br from-red-500 via-orange-500 to-red-600 rounded-full flex items-center justify-center shadow-2xl">
            <AlertTriangle size={40} className="text-white" />
          </div>
        </motion.div>

        {/* Error Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-4 mb-8"
        >
          <h1 className="text-3xl font-bold text-white">
            Oops! Something went wrong
          </h1>
          <p className="text-gray-400 text-lg">
            The trading algorithms encountered an unexpected error.
          </p>
          <p className="text-gray-500 text-sm">
            Don't worry, our AI is already analyzing the issue.
          </p>
        </motion.div>

        {/* Error Details */}
        {process.env.NODE_ENV === 'development' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mb-8 p-4 bg-red-900/20 border border-red-500/30 rounded-lg text-left"
          >
            <div className="flex items-center space-x-2 mb-2">
              <Bug size={16} className="text-red-400" />
              <span className="text-red-400 font-medium text-sm">Debug Info</span>
            </div>
            <pre className="text-xs text-red-300 overflow-x-auto">
              {error.message}
            </pre>
            {error.digest && (
              <p className="text-xs text-red-400 mt-2">
                Error ID: {error.digest}
              </p>
            )}
          </motion.div>
        )}

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="space-y-4"
        >
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={reset}
              className="btn-primary flex items-center justify-center space-x-2 w-full sm:w-auto"
            >
              <RefreshCw size={20} />
              <span>Try Again</span>
            </motion.button>
            
            <Link href="/">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-secondary flex items-center justify-center space-x-2 w-full sm:w-auto"
              >
                <Home size={20} />
                <span>Go Home</span>
              </motion.button>
            </Link>
          </div>

          {/* Help Section */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="border border-gray-700/50 rounded-lg p-4 bg-gray-900/30 backdrop-blur-sm"
          >
            <h3 className="text-white font-medium mb-2">Need Help?</h3>
            <p className="text-gray-400 text-sm mb-3">
              If this error persists, here are some things you can try:
            </p>
            <ul className="text-gray-500 text-sm space-y-1 text-left">
              <li>• Check your internet connection</li>
              <li>• Clear your browser cache</li>
              <li>• Refresh the page</li>
              <li>• Contact support if the issue continues</li>
            </ul>
          </motion.div>
        </motion.div>

        {/* Trading Quote */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-8 p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg"
        >
          <p className="text-blue-400 text-sm">
            💼 <strong>Trading Wisdom:</strong> "In trading and in code, every error is a learning opportunity. Stay calm and adapt."
          </p>
        </motion.div>
      </motion.div>

      {/* Error Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              opacity: 0,
              x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 800),
              y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 600)
            }}
            animate={{
              opacity: [0, 0.6, 0],
              y: [600, -50],
              x: `+=${Math.random() * 100 - 50}`
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              delay: Math.random() * 2
            }}
            className="absolute w-1 h-1 bg-red-400 rounded-full"
          />
        ))}
      </div>
    </div>
  )
}
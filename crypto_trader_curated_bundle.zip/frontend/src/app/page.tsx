// src/app/page.tsx
'use client';

import { Suspense } from 'react';
import dynamic from 'next/dynamic';
import LoadingFallback from '@/components/ui/LoadingFallback';

// Dynamic import Dashboard to avoid SSR issues with complex animations
const Dashboard = dynamic(() => import('@/components/dashboard/Dashboard'), {
  ssr: false,
  loading: () => <LoadingFallback />,
});

export default function HomePage() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Dashboard />
    </Suspense>
  );
}
'use client'

import { Suspense } from 'react'
import dynamic from 'next/dynamic'
import LoadingFallback from '@/components/ui/LoadingFallback'

// Dynamic import to avoid SSR issues
const Dashboard = dynamic(() => import('@/components/dashboard/Dashboard'), {
  ssr: false,
  loading: () => <LoadingFallback />
})

export default function DashboardPage() {
  return (
    <div className="min-h-screen">
      <Suspense fallback={<LoadingFallback />}>
        <Dashboard />
      </Suspense>
    </div>
  )
}

// Metadata removed - client components can't export metadata
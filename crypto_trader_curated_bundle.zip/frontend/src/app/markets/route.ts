import { NextRequest, NextResponse } from 'next/server'

// Mock market data
const mockMarketData = {
  markets: [
    {
      id: 'bitcoin',
      symbol: 'BTC',
      name: 'Bitcoin',
      current_price: 43250.5,
      market_cap: 845123456789,
      market_cap_rank: 1,
      price_change_percentage_24h: 2.45,
      total_volume: 12345678901,
      high_24h: 44100.0,
      low_24h: 42800.0,
      circulating_supply: 19567890,
      last_updated: new Date().toISOString()
    },
    {
      id: 'ethereum',
      symbol: 'ETH',
      name: 'Ethereum',
      current_price: 2650.75,
      market_cap: 318456789012,
      market_cap_rank: 2,
      price_change_percentage_24h: 1.87,
      total_volume: 8901234567,
      high_24h: 2720.0,
      low_24h: 2580.0,
      circulating_supply: 120234567,
      last_updated: new Date().toISOString()
    },
    {
      id: 'binancecoin',
      symbol: 'BNB',
      name: 'BNB',
      current_price: 315.25,
      market_cap: 47123456789,
      market_cap_rank: 4,
      price_change_percentage_24h: -0.95,
      total_volume: 1234567890,
      high_24h: 325.0,
      low_24h: 310.0,
      circulating_supply: 149533652,
      last_updated: new Date().toISOString()
    }
  ],
  total_market_cap: 1650000000000,
  total_volume_24h: 45000000000,
  market_cap_change_percentage_24h: 1.2
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = searchParams.get('limit') || '10'
    const offset = searchParams.get('offset') || '0'

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 100))

    // Add some random price fluctuation for demo
    const markets = mockMarketData.markets.map(market => ({
      ...market,
      current_price: market.current_price * (1 + (Math.random() - 0.5) * 0.02),
      price_change_percentage_24h: market.price_change_percentage_24h + (Math.random() - 0.5) * 2
    }))

    return NextResponse.json({
      success: true,
      data: {
        ...mockMarketData,
        markets: markets.slice(parseInt(offset), parseInt(offset) + parseInt(limit))
      },
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('Market API Error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch market data',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Handle market data subscription or updates
    return NextResponse.json({
      success: true,
      message: 'Market subscription updated',
      data: body,
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    return NextResponse.json(
      { 
        success: false, 
        error: 'Invalid request body',
        timestamp: new Date().toISOString()
      },
      { status: 400 }
    )
  }
}
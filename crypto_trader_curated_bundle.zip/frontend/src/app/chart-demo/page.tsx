// src/app/chart-demo/page.tsx
import { Metadata } from 'next';
import DashboardClient from './dashboard-client';

export const metadata: Metadata = {
  title: 'Dashboard - AiSmart Pro',
  description: 'Professional trading dashboard with real-time market data and AI insights',
};

export default function DashboardPage() {
  return <DashboardClient />;
}
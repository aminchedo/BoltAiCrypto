import { NextResponse } from 'next/server'

export async function GET() {
  const healthCheck = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0',
    services: {
      database: 'healthy',
      market_data: 'healthy',
      websocket: 'healthy',
      ai_engine: 'healthy'
    },
    memory_usage: process.memoryUsage(),
    system_info: {
      node_version: process.version,
      platform: process.platform,
      architecture: process.arch
    }
  }

  return NextResponse.json(healthCheck, {
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  })
}
import { NextResponse } from 'next/server';

// Generate random price data for testing
function generateMockPriceData(symbol: string, timeframe: string, limit: number = 100) {
  const now = new Date();
  const data = [];
  
  // Set base price based on symbol
  let basePrice = 0;
  switch (symbol.toUpperCase()) {
    case 'BTCUSDT':
      basePrice = 50000;
      break;
    case 'ETHUSDT':
      basePrice = 3000;
      break;
    case 'BNBUSDT':
      basePrice = 400;
      break;
    case 'ADAUSDT':
      basePrice = 0.5;
      break;
    case 'SOLUSDT':
      basePrice = 100;
      break;
    default:
      basePrice = 100;
  }
  
  // Set time increment based on timeframe
  let timeIncrement = 0;
  switch (timeframe) {
    case '1m':
      timeIncrement = 60 * 1000;
      break;
    case '5m':
      timeIncrement = 5 * 60 * 1000;
      break;
    case '15m':
      timeIncrement = 15 * 60 * 1000;
      break;
    case '30m':
      timeIncrement = 30 * 60 * 1000;
      break;
    case '1h':
      timeIncrement = 60 * 60 * 1000;
      break;
    case '4h':
      timeIncrement = 4 * 60 * 60 * 1000;
      break;
    case '1d':
      timeIncrement = 24 * 60 * 60 * 1000;
      break;
    default:
      timeIncrement = 60 * 60 * 1000;
  }
  
  // Generate random walk price data
  let price = basePrice;
  let volatility = basePrice * 0.01; // 1% volatility
  
  for (let i = 0; i < limit; i++) {
    const timestamp = new Date(now.getTime() - (limit - i) * timeIncrement);
    
    // Random price movement
    const change = (Math.random() - 0.5) * volatility;
    price += change;
    
    // Generate OHLC data
    const open = price;
    const high = price + Math.random() * volatility * 0.5;
    const low = price - Math.random() * volatility * 0.5;
    const close = price + (Math.random() - 0.5) * volatility;
    
    // Generate volume
    const volume = basePrice * 10 * (0.5 + Math.random());
    
    data.push({
      timestamp: timestamp.toISOString(),
      open,
      high,
      low,
      close,
      volume
    });
  }
  
  return data;
}

export async function GET(
  request: Request,
  { params }: { params: { symbol: string } }
) {
  const { searchParams } = new URL(request.url);
  const timeframe = searchParams.get('timeframe') || '1h';
  const limit = parseInt(searchParams.get('limit') || '100', 10);
  
  // Generate mock data
  const data = generateMockPriceData(params.symbol, timeframe, limit);
  
  return NextResponse.json(data);
}
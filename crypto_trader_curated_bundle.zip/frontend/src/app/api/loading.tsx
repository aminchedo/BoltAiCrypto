// src/app/chart-demo/loading.tsx
import LoadingFallback from '@/components/ui/LoadingFallback';

export default function Loading() {
  return ;
}
    
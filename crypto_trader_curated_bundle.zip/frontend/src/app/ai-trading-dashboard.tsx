import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid,
  Area, AreaChart, PieChart, Pie, Cell, BarChart, Bar, ComposedChart
} from 'recharts';
import {
  Brain, BarChart3, DollarSign, TrendingUp, TrendingDown, Settings, Menu,
  ChevronLeft, ChevronRight, Activity, Zap, Target, History, Users, Bell,
  Shield, Globe, BookOpen, Award, Layers, Wallet, CreditCard,
  Briefcase, Monitor, AlertCircle, CheckCircle, Info, Clock, Search,
  Maximize, Minimize, Wifi, WifiOff, ChevronDown, User, LogOut, Palette,
  Play, Pause, RotateCcw, Filter, Copy, Eye, EyeOff, RefreshCw, Download,
  Upload, Flame, Star, Bookmark, Share, ExternalLink, Newspaper,
  Volume2, ArrowUpRight, ArrowDownRight, Smartphone, Tablet, Grid,
  HelpCircle
} from 'lucide-react';

// Types and Interfaces
interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  rank: number;
  color: string;
}

interface TradingSignal {
  id: string;
  symbol: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  target: number;
  stopLoss: number;
  timestamp: Date;
  status: 'active' | 'executed' | 'expired';
  aiModel: string;
  riskLevel: 'low' | 'medium' | 'high';
  expectedReturn: number;
  reason: string;
}

interface PortfolioAsset {
  symbol: string;
  name: string;
  amount: number;
  value: number;
  change24h: number;
  allocation: number;
  color: string;
}

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  timestamp: Date;
  category: 'breaking' | 'analysis' | 'regulation' | 'technology';
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'high' | 'medium' | 'low';
}

// AI Trading Dashboard Component
const AITradingDashboard: React.FC = () => {
  // State Management
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeView, setActiveView] = useState('dashboard');
  const [currentTheme, setCurrentTheme] = useState<'dark' | 'blue' | 'green'>('dark');
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connected');
  const [isLoading, setIsLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);

  // Portfolio Data
  const [portfolioValue, setPortfolioValue] = useState(127845.32);
  const [portfolioChange, setPortfolioChange] = useState(2341.22);
  const [portfolioChangePercent, setPortfolioChangePercent] = useState(1.87);
  
  // Market Data
  const [fearGreedIndex, setFearGreedIndex] = useState(67);
  const [totalMarketCap, setTotalMarketCap] = useState(2.67);
  const [marketCapChange, setMarketCapChange] = useState(2.34);

  // AI & Trading States
  const [aiStatus, setAiStatus] = useState('online');
  const [activeSignals, setActiveSignals] = useState(23);
  const [successRate, setSuccessRate] = useState(87.3);
  const [isAutoTrading, setIsAutoTrading] = useState(false);

  // Mock Data
  const portfolioAssets: PortfolioAsset[] = [
    { symbol: 'BTC', name: 'Bitcoin', amount: 1.2345, value: 82345.67, change24h: 2.45, allocation: 45, color: '#f7931a' },
    { symbol: 'ETH', name: 'Ethereum', amount: 12.456, value: 34567.89, change24h: -1.23, allocation: 30, color: '#627eea' },
    { symbol: 'SOL', name: 'Solana', amount: 156.78, value: 8934.12, change24h: 5.67, allocation: 15, color: '#9945ff' },
    { symbol: 'USDT', name: 'Tether', amount: 1997.23, value: 1997.23, change24h: 0.01, allocation: 10, color: '#26a17b' }
  ];

  const tradingSignals: TradingSignal[] = [
    {
      id: '1',
      symbol: 'BTC/USDT',
      signal: 'BUY',
      confidence: 87,
      price: 67234.45,
      target: 69500,
      stopLoss: 65800,
      timestamp: new Date(),
      status: 'active',
      aiModel: 'Neural Alpha',
      riskLevel: 'medium',
      expectedReturn: 3.4,
      reason: 'Strong bullish momentum with breakout pattern'
    },
    {
      id: '2',
      symbol: 'ETH/USDT',
      signal: 'SELL',
      confidence: 73,
      price: 3845.67,
      target: 3650,
      stopLoss: 3950,
      timestamp: new Date(Date.now() - 300000),
      status: 'active',
      aiModel: 'Quantum Beta',
      riskLevel: 'low',
      expectedReturn: -5.1,
      reason: 'Resistance level reached, overbought conditions'
    },
    {
      id: '3',
      symbol: 'SOL/USDT',
      signal: 'BUY',
      confidence: 91,
      price: 178.90,
      target: 195,
      stopLoss: 170,
      timestamp: new Date(Date.now() - 600000),
      status: 'executed',
      aiModel: 'Deep Gamma',
      riskLevel: 'high',
      expectedReturn: 9.0,
      reason: 'Technical indicators show strong upward momentum'
    }
  ];

  const topMovers: MarketData[] = [
    { symbol: 'SOL', name: 'Solana', price: 178.90, change: 15.2, changePercent: 9.28, volume: 2450000000, marketCap: 85200000000, rank: 5, color: '#9945ff' },
    { symbol: 'AVAX', name: 'Avalanche', price: 42.30, change: 4.8, changePercent: 12.80, volume: 890000000, marketCap: 17800000000, rank: 12, color: '#e84142' },
    { symbol: 'DOT', name: 'Polkadot', price: 7.85, change: -0.65, changePercent: -7.65, volume: 450000000, marketCap: 9800000000, rank: 15, color: '#e6007a' }
  ];

  const newsItems: NewsItem[] = [
    {
      id: '1',
      title: 'Bitcoin ETF Approval Boosts Market Confidence',
      summary: 'The SEC approval of multiple Bitcoin ETFs has led to increased institutional interest and market momentum.',
      source: 'CoinDesk',
      timestamp: new Date(Date.now() - 1800000),
      category: 'breaking',
      sentiment: 'positive',
      impact: 'high'
    },
    {
      id: '2',
      title: 'Ethereum 2.0 Staking Rewards Increase',
      summary: 'New staking mechanisms offer higher yields, attracting more validators to the network.',
      source: 'CryptoNews',
      timestamp: new Date(Date.now() - 3600000),
      category: 'technology',
      sentiment: 'positive',
      impact: 'medium'
    }
  ];

  const chartData = useMemo(() => {
    const data = [];
    let currentValue = portfolioValue - portfolioChange;
    
    for (let i = 0; i < 24; i++) {
      const timestamp = Date.now() - (24 - i) * 3600000;
      const valueChange = (Math.random() - 0.5) * 5000;
      currentValue = Math.max(currentValue + valueChange, 100000);
      
      data.push({
        time: new Date(timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        timestamp,
        value: currentValue,
        volume: Math.random() * 1000000 + 500000
      });
    }
    return data;
  }, [portfolioValue, portfolioChange]);

  // Loading Simulation
  useEffect(() => {
    const loadingSteps = [
      'Initializing AI engines...',
      'Connecting to market data...',
      'Loading portfolio data...',
      'Synchronizing trading signals...',
      'Dashboard ready!'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      setLoadingProgress(prev => {
        const newProgress = prev + 20;
        if (newProgress >= 100) {
          setTimeout(() => setIsLoading(false), 500);
          clearInterval(interval);
        }
        return newProgress;
      });
      currentStep++;
    }, 800);

    return () => clearInterval(interval);
  }, []);

  // Real-time Updates
  useEffect(() => {
    if (isLoading) return;

    const interval = setInterval(() => {
      // Update portfolio value
      const randomChange = (Math.random() - 0.5) * 1000;
      setPortfolioValue(prev => prev + randomChange);
      setPortfolioChange(prev => prev + randomChange * 0.1);
      setPortfolioChangePercent(prev => prev + (Math.random() - 0.5) * 0.5);
      
      // Update Fear & Greed Index
      setFearGreedIndex(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 5)));
      
      // Update market cap
      setTotalMarketCap(prev => prev + (Math.random() - 0.5) * 0.1);
      setMarketCapChange(prev => prev + (Math.random() - 0.5) * 0.5);
      
      // Simulate connection issues occasionally
      if (Math.random() > 0.98) {
        setConnectionStatus('connecting');
        setTimeout(() => setConnectionStatus('connected'), 2000);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [isLoading]);

  // Theme Configuration
  const getThemeClasses = () => {
    const themes = {
      dark: 'from-gray-950 via-gray-900 to-gray-800',
      blue: 'from-blue-950 via-blue-900 to-indigo-900',
      green: 'from-emerald-950 via-teal-900 to-green-900'
    };
    return themes[currentTheme];
  };

  // Component Functions
  const executeSignal = (signalId: string) => {
    console.log(`Executing signal: ${signalId}`);
  };

  const formatCurrency = (value: number) => {
    return `$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'text-green-400';
      case 'SELL': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-400';
      case 'negative': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Loading Screen
  if (isLoading) {
    return (
      <div className={`flex h-screen bg-gradient-to-br ${getThemeClasses()} items-center justify-center relative overflow-hidden`}>
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(16,185,129,0.1),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.1),transparent_50%)]" />
        </div>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center relative z-10 max-w-md mx-auto px-6"
        >
          <motion.div
            animate={{ rotateY: [0, 360] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            className="mb-8"
          >
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-3xl font-bold text-white shadow-2xl">
              🤖
            </div>
          </motion.div>

          <div>
            <h2 className="text-2xl font-bold text-white mb-2 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
              AI Trading Dashboard
            </h2>
            <p className="text-gray-400 mb-6">Initializing professional trading environment...</p>
          </div>

          <div className="relative">
            <div className="bg-gray-700/50 rounded-full h-3 mb-4 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${loadingProgress}%` }}
                transition={{ type: "spring", stiffness: 100, damping: 15 }}
                className="h-full bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 rounded-full"
              />
            </div>
            <div className="text-right text-sm text-gray-400">
              {loadingProgress}%
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  // Main Dashboard Layout
  return (
    <div className={`flex h-screen bg-gradient-to-br ${getThemeClasses()} overflow-hidden`}>
      {/* Background Effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,rgba(16,185,129,0.05),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_75%,rgba(59,130,246,0.05),transparent_50%)]" />
      </div>

      {/* Advanced Sidebar */}
      <motion.aside
        initial={{ width: sidebarCollapsed ? 80 : 280 }}
        animate={{ width: sidebarCollapsed ? 80 : 280 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="bg-gradient-to-b from-gray-950/95 to-gray-900/95 backdrop-blur-xl border-r border-white/10 text-white flex flex-col relative shadow-2xl z-20"
      >
        {/* Header */}
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center justify-between">
            <AnimatePresence mode="wait">
              {!sidebarCollapsed ? (
                <motion.div
                  key="expanded"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex items-center text-2xl font-bold"
                >
                  <motion.span 
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    className="mr-3 text-3xl"
                  >
                    🤖
                  </motion.span>
                  <div>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-400">
                      AiSmart
                    </span>
                    <span className="ml-1 text-gray-300">Pro</span>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="collapsed"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="text-3xl"
                >
                  🤖
                </motion.div>
              )}
            </AnimatePresence>

            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              {sidebarCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            </motion.button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-transparent">
          {[
            { 
              id: 'dashboard', 
              name: 'Dashboard', 
              icon: BarChart3, 
              color: 'text-blue-400',
              description: 'Overview and analytics'
            },
            { 
              id: 'trading', 
              name: 'Trading', 
              icon: TrendingUp, 
              color: 'text-green-400',
              description: 'Execute trades',
              subItems: [
                { id: 'spot', name: 'Spot Trading', icon: DollarSign, color: 'text-green-400' },
                { id: 'futures', name: 'Futures', icon: Activity, color: 'text-blue-400' },
                { id: 'options', name: 'Options', icon: Target, color: 'text-purple-400' }
              ]
            },
            { 
              id: 'portfolio', 
              name: 'Portfolio', 
              icon: Briefcase, 
              color: 'text-purple-400',
              description: 'Manage assets',
              subItems: [
                { id: 'overview', name: 'Overview', icon: BarChart3, color: 'text-blue-400' },
                { id: 'positions', name: 'Positions', icon: Layers, color: 'text-green-400' },
                { id: 'history', name: 'History', icon: History, color: 'text-gray-400' }
              ]
            },
            { 
              id: 'signals', 
              name: 'AI Signals', 
              icon: Brain, 
              color: 'text-yellow-400',
              badge: activeSignals,
              description: 'AI-powered insights'
            },
            { 
              id: 'analytics', 
              name: 'Analytics', 
              icon: Activity, 
              color: 'text-cyan-400',
              description: 'Performance metrics',
              subItems: [
                { id: 'performance', name: 'Performance', icon: TrendingUp, color: 'text-green-400' },
                { id: 'risk', name: 'Risk Analysis', icon: Shield, color: 'text-red-400' },
                { id: 'reports', name: 'Reports', icon: BookOpen, color: 'text-blue-400' }
              ]
            },
            { 
              id: 'wallet', 
              name: 'Wallet', 
              icon: Wallet, 
              color: 'text-emerald-400',
              description: 'Manage funds',
              subItems: [
                { id: 'deposit', name: 'Deposit', icon: CreditCard, color: 'text-green-400' },
                { id: 'withdraw', name: 'Withdraw', icon: DollarSign, color: 'text-red-400' },
                { id: 'transactions', name: 'Transactions', icon: History, color: 'text-gray-400' }
              ]
            },
            { 
              id: 'social', 
              name: 'Social Trading', 
              icon: Users, 
              color: 'text-pink-400',
              description: 'Follow top traders'
            },
            { 
              id: 'news', 
              name: 'Market News', 
              icon: Globe, 
              color: 'text-orange-400',
              badge: 5,
              description: 'Latest market updates'
            },
            { 
              id: 'settings', 
              name: 'Settings', 
              icon: Settings, 
              color: 'text-gray-400',
              description: 'Configure platform'
            }
          ].map((item) => (
            <div key={item.id}>
              <motion.button
                onClick={() => setActiveView(item.id)}
                whileHover={{ scale: 1.02, x: 4 }}
                whileTap={{ scale: 0.98 }}
                className={`w-full p-3 text-left flex items-center justify-between rounded-xl transition-all duration-200 group ${
                  activeView === item.id
                    ? 'bg-gradient-to-r from-green-600/20 to-blue-600/20 text-green-400 border border-green-500/30 shadow-lg'
                    : 'hover:bg-white/5 text-gray-300 hover:text-white hover:border-white/20 border border-transparent'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <item.icon className={`w-5 h-5 ${item.color} group-hover:scale-110 transition-transform`} />
                  <AnimatePresence mode="wait">
                    {!sidebarCollapsed && (
                      <motion.div
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="flex-1"
                      >
                        <div className="font-medium">{item.name}</div>
                        {item.description && (
                          <div className="text-xs text-gray-400 mt-0.5">{item.description}</div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <AnimatePresence mode="wait">
                  {!sidebarCollapsed && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center space-x-2"
                    >
                      {item.badge && (
                        <motion.span
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold"
                        >
                          {item.badge}
                        </motion.span>
                      )}
                      {item.subItems && (
                        <motion.div
                          animate={{ rotate: 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ChevronRight size={14} />
                        </motion.div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.button>

              {/* Sub Items */}
              <AnimatePresence>
                {!sidebarCollapsed && item.subItems && activeView === item.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="ml-8 mt-2 space-y-1"
                  >
                    {item.subItems.map((subItem) => (
                      <motion.button
                        key={subItem.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        whileHover={{ scale: 1.02, x: 4 }}
                        className="w-full p-2 text-left flex items-center space-x-3 rounded-lg transition-all text-sm hover:bg-white/5 text-gray-400 hover:text-white"
                      >
                        <subItem.icon className={`w-4 h-4 ${subItem.color}`} />
                        <span>{subItem.name}</span>
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </nav>

        {/* Performance Stats */}
        <AnimatePresence mode="wait">
          {!sidebarCollapsed && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="p-4 space-y-4"
            >
              <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                <h3 className="text-sm font-semibold mb-3 text-gray-300">Performance</h3>
                <div className="space-y-3">
                  {[
                    { label: 'Total P&L', value: '+$12,341', change: 5.67, color: 'text-green-400', icon: TrendingUp },
                    { label: 'Win Rate', value: '68.4%', change: 2.1, color: 'text-blue-400', icon: Target },
                    { label: 'Active Signals', value: '23', change: 0, color: 'text-purple-400', icon: Zap },
                    { label: 'Portfolio', value: '$127.8K', change: 1.87, color: 'text-yellow-400', icon: Wallet }
                  ].map((metric, index) => (
                    <motion.div
                      key={metric.label}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ scale: 1.02 }}
                      className="flex justify-between items-center p-2 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="flex items-center space-x-2">
                        <metric.icon size={14} className={metric.color} />
                        <span className="text-xs text-gray-400">{metric.label}</span>
                      </div>
                      <div className="text-right">
                        <div className={`text-sm font-semibold ${metric.color}`}>
                          {metric.value}
                        </div>
                        {metric.change !== 0 && (
                          <div className={`text-xs flex items-center space-x-1 ${
                            metric.change >= 0 ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {metric.change >= 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                            <span>{Math.abs(metric.change).toFixed(1)}%</span>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* AI Engine Status */}
              <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-gray-300">AI Engine</h3>
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="text-green-400"
                  >
                    <CheckCircle size={12} />
                  </motion.div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Status:</span>
                    <span className="font-semibold capitalize text-green-400">
                      {aiStatus}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Accuracy:</span>
                    <span className="text-green-400 font-semibold">
                      {successRate.toFixed(1)}%
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Active Signals:</span>
                    <span className="text-blue-400 font-semibold">
                      {activeSignals}
                    </span>
                  </div>

                  {/* Accuracy Progress Bar */}
                  <div className="mt-3">
                    <div className="bg-gray-700 rounded-full h-2 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${successRate}%` }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-green-500 to-blue-500 rounded-full"
                      />
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Last trained: {new Date().toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Connection Status */}
        <div className="p-4 border-t border-white/10">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="flex items-center space-x-3 p-3 bg-gray-800/30 rounded-xl border border-white/5"
          >
            <motion.span
              animate={{ 
                scale: connectionStatus === 'connected' ? [1, 1.2, 1] : 1,
                opacity: connectionStatus === 'disconnected' ? 0.5 : 1
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="relative flex h-3 w-3"
            >
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                connectionStatus === 'connected' ? 'bg-green-400' :
                connectionStatus === 'connecting' ? 'bg-yellow-400' : 'bg-red-400'
              }`} />
              <span className={`inline-flex rounded-full h-3 w-3 ${
                connectionStatus === 'connected' ? 'bg-green-500' :
                connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
              }`} />
            </motion.span>
            
            <AnimatePresence mode="wait">
              {!sidebarCollapsed && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="flex-1"
                >
                  <div className={`text-sm font-medium ${
                    connectionStatus === 'connected' ? 'text-green-400' :
                    connectionStatus === 'connecting' ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {connectionStatus === 'connected' ? 'AI Engine Online' :
                     connectionStatus === 'connecting' ? 'Connecting...' : 'Connection Lost'}
                  </div>
                  <div className="text-xs text-gray-500">
                    Global trading network
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* User Profile */}
        <div className="p-4 border-t border-white/10">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl border border-blue-500/30"
          >
            <motion.div 
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center"
            >
              <span className="text-sm font-bold text-white">JT</span>
            </motion.div>
            
            <AnimatePresence mode="wait">
              {!sidebarCollapsed && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="flex-1"
                >
                  <div className="text-sm font-medium">John Trader</div>
                  <div className="text-xs text-gray-400 flex items-center space-x-2">
                    <Award size={10} className="text-yellow-400" />
                    <span>Pro Account</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <motion.header
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="h-[80px] border-b border-white/10 flex items-center justify-between px-6 text-white bg-gray-900/50 backdrop-blur-xl relative z-10"
        >
          {/* Left Section */}
          <div className="flex items-center space-x-6">
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                Professional Trading Dashboard
              </h1>
              <p className="text-xs text-gray-400">Real-time AI-powered trading platform</p>
            </div>
          </div>

          {/* Center Section - Trading Controls */}
          <div className="flex items-center space-x-3">
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-green-500/25"
            >
              📈 BUY
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-red-500/25"
            >
              📉 SELL
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsAutoTrading(!isAutoTrading)}
              className={`px-6 py-3 rounded-xl font-bold transition-all duration-200 shadow-lg ${
                isAutoTrading 
                  ? 'bg-gradient-to-r from-purple-600 to-purple-500 hover:shadow-purple-500/25' 
                  : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 hover:shadow-blue-500/25'
              }`}
            >
              ⚡ AI {isAutoTrading ? 'ON' : 'AUTO'}
            </motion.button>
          </div>

          {/* Right Section */}
          <div className="flex items-center space-x-4">
            {/* Connection Status */}
            <motion.div className="flex items-center space-x-2 bg-gray-800/50 rounded-xl px-3 py-2">
              <div className={`w-2 h-2 rounded-full ${
                connectionStatus === 'connected' ? 'bg-green-500' : 
                connectionStatus === 'connecting' ? 'bg-yellow-500 animate-pulse' : 'bg-red-500'
              }`} />
              <span className={`text-sm font-medium ${
                connectionStatus === 'connected' ? 'text-green-400' : 
                connectionStatus === 'connecting' ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {connectionStatus === 'connected' ? 'LIVE' : 
                 connectionStatus === 'connecting' ? 'CONNECTING' : 'OFFLINE'}
              </span>
            </motion.div>

            {/* Balance Display */}
            <motion.div
              key={portfolioValue}
              initial={{ scale: 1.05, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-right bg-gray-800/50 rounded-xl px-4 py-2"
            >
              <div className="text-lg font-mono font-bold">
                {formatCurrency(portfolioValue)}
              </div>
              <div className={`text-xs flex items-center space-x-1 ${
                portfolioChangePercent >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                <span>{portfolioChangePercent >= 0 ? '📈' : '📉'}</span>
                <span>
                  {portfolioChangePercent >= 0 ? '+' : ''}{formatCurrency(Math.abs(portfolioChange))} 
                  ({portfolioChangePercent >= 0 ? '+' : ''}{portfolioChangePercent.toFixed(2)}%)
                </span>
              </div>
            </motion.div>

            {/* Theme Selector */}
            <div className="flex items-center space-x-1 bg-gray-800/50 rounded-lg p-1">
              {[
                { theme: 'dark', color: 'bg-gray-600' },
                { theme: 'blue', color: 'bg-blue-600' },
                { theme: 'green', color: 'bg-green-600' }
              ].map((theme) => (
                <motion.button
                  key={theme.theme}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setCurrentTheme(theme.theme as any)}
                  className={`w-6 h-6 rounded ${theme.color} ${
                    currentTheme === theme.theme ? 'ring-2 ring-white' : ''
                  }`}
                />
              ))}
            </div>

            {/* User Profile */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center cursor-pointer"
            >
              <span className="text-lg">👤</span>
            </motion.div>
          </div>
        </motion.header>

        {/* Dashboard Content */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 overflow-auto"
        >
          {/* Portfolio Summary */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(34,197,94,0.1),transparent_50%)]" />
            </div>

            <div className="flex items-center justify-between mb-4 relative z-10">
              <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                Portfolio Overview
              </h2>
              <Wallet className="text-green-400" size={24} />
            </div>

            <div className="mb-6 relative z-10">
              <div className="text-3xl font-mono font-bold mb-2">
                {formatCurrency(portfolioValue)}
              </div>
              <div className={`flex items-center space-x-2 ${
                portfolioChangePercent >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {portfolioChangePercent >= 0 ? <TrendingUp size={20} /> : <TrendingDown size={20} />}
                <span>
                  {portfolioChangePercent >= 0 ? '+' : ''}{formatCurrency(Math.abs(portfolioChange))} 
                  ({portfolioChangePercent >= 0 ? '+' : ''}{portfolioChangePercent.toFixed(2)}%)
                </span>
              </div>
            </div>

            <div className="h-32 mb-4 relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00ff88" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#00ff88"
                    fill="url(#portfolioGradient)"
                    strokeWidth={2}
                    dot={false}
                  />
                  <Tooltip 
                    formatter={(value: any) => [formatCurrency(value), 'Portfolio Value']}
                    labelFormatter={(label) => `Time: ${label}`}
                    contentStyle={{
                      backgroundColor: 'rgba(31, 41, 55, 0.95)',
                      border: '1px solid rgba(75, 85, 99, 0.5)',
                      borderRadius: '12px',
                      color: 'white'
                    }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-3 relative z-10">
              {portfolioAssets.slice(0, 3).map((asset) => (
                <div key={asset.symbol} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-xl">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs"
                      style={{ backgroundColor: asset.color }}
                    >
                      {asset.symbol}
                    </div>
                    <div>
                      <div className="font-medium">{asset.name}</div>
                      <div className="text-sm text-gray-400">{asset.amount.toFixed(4)} {asset.symbol}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{formatCurrency(asset.value)}</div>
                    <div className={`text-sm ${asset.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 mt-6 relative z-10">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-green-600 hover:bg-green-500 px-4 py-3 rounded-xl font-semibold transition-colors"
              >
                💰 Deposit
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-blue-600 hover:bg-blue-500 px-4 py-3 rounded-xl font-semibold transition-colors"
              >
                📤 Withdraw
              </motion.button>
            </div>
          </motion.div>

          {/* Live Signals */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.01 }}
            className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(59,130,246,0.1),transparent_50%)]" />
            </div>

            <div className="flex items-center justify-between mb-4 relative z-10">
              <div className="flex items-center space-x-3">
                <motion.div
                  animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <Brain size={24} className="text-blue-400" />
                </motion.div>
                <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  AI Live Signals
                </h2>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-green-400 text-sm">🧠 ACTIVE</span>
              </div>
            </div>

            <div className="space-y-3 relative z-10">
              {tradingSignals.map((signal) => (
                <motion.div
                  key={signal.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  whileHover={{ scale: 1.02 }}
                  className="bg-gray-700/40 rounded-xl p-4 border border-white/10 hover:border-white/20 transition-all"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-bold text-lg">{signal.symbol}</span>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => executeSignal(signal.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold ${
                        signal.signal === 'BUY'
                          ? 'bg-green-600 text-white'
                          : signal.signal === 'SELL'
                          ? 'bg-red-600 text-white'
                          : 'bg-yellow-600 text-white'
                      }`}
                    >
                      {signal.signal === 'BUY' ? '📈' : signal.signal === 'SELL' ? '📉' : '⏸️'} {signal.signal}
                    </motion.button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                    <div>Price: <span className="font-mono">{formatCurrency(signal.price)}</span></div>
                    <div>Target: <span className={`font-mono ${getSignalColor(signal.signal)}`}>{formatCurrency(signal.target)}</span></div>
                    <div>Confidence: <span className="text-green-400">{signal.confidence}%</span></div>
                    <div className={`${getRiskColor(signal.riskLevel)}`}>Risk: {signal.riskLevel.toUpperCase()}</div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                    <span>Model: {signal.aiModel}</span>
                    <span>Expected: {signal.expectedReturn >= 0 ? '+' : ''}{signal.expectedReturn.toFixed(1)}%</span>
                  </div>

                  <div className="bg-gray-600 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${signal.confidence}%` }}
                      transition={{ duration: 1 }}
                      className={`h-2 rounded-full ${
                        signal.confidence >= 80 ? 'bg-green-500' :
                        signal.confidence >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                    />
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 relative z-10">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="text-gray-400">Success Rate</div>
                  <div className="text-green-400 font-bold text-lg">{successRate}%</div>
                </div>
                <div className="text-center">
                  <div className="text-gray-400">Active Signals</div>
                  <div className="text-blue-400 font-bold text-lg">{activeSignals}</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Market Overview */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.005 }}
            className="bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,0.1),transparent_50%)]" />
            </div>

            <div className="flex items-center justify-between mb-6 relative z-10">
              <div className="flex items-center space-x-3">
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                >
                  <Globe size={24} className="text-green-400" />
                </motion.div>
                <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                  Market Overview
                </h2>
              </div>
              <span className="text-2xl">🌍</span>
            </div>

            {/* Market Stats */}
            <div className="grid grid-cols-2 gap-4 mb-6 relative z-10">
              <div className="bg-gray-700/30 rounded-xl p-4">
                <h3 className="font-semibold mb-3">Fear & Greed Index</h3>
                <div className={`text-3xl font-bold mb-2 ${
                  fearGreedIndex >= 75 ? 'text-green-400' :
                  fearGreedIndex >= 50 ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  {fearGreedIndex}
                </div>
                <div className="text-sm text-gray-400 mb-3">
                  {fearGreedIndex >= 75 ? 'Extreme Greed' :
                   fearGreedIndex >= 50 ? 'Greed' : 'Fear'}
                </div>
                <div className="bg-gray-600 rounded-full h-2">
                  <motion.div
                    animate={{ width: `${fearGreedIndex}%` }}
                    transition={{ duration: 1 }}
                    className={`h-2 rounded-full ${
                      fearGreedIndex >= 75 ? 'bg-green-500' :
                      fearGreedIndex >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                  />
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="bg-gray-700/30 rounded-xl p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">Total Market Cap</span>
                    <span className="text-xl font-bold text-green-400">
                      ${totalMarketCap.toFixed(2)}T
                    </span>
                  </div>
                </div>
                
                <div className="bg-gray-700/30 rounded-xl p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">24h Volume</span>
                    <span className="text-lg font-bold text-blue-400">$89.2B</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Top Movers */}
            <div className="relative z-10">
              <h3 className="font-semibold mb-3">Top Movers</h3>
              <div className="space-y-2">
                {topMovers.map((coin) => (
                  <motion.div
                    key={coin.symbol}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center justify-between text-sm"
                  >
                    <div className="flex items-center space-x-2">
                      <div 
                        className="w-6 h-6 rounded-full flex items-center justify-center text-white font-bold text-xs"
                        style={{ backgroundColor: coin.color }}
                      >
                        {coin.symbol}
                      </div>
                      <span className="font-medium">{coin.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{formatCurrency(coin.price)}</div>
                      <div className={coin.changePercent >= 0 ? 'text-green-400' : 'text-red-400'}>
                        {coin.changePercent >= 0 ? '+' : ''}{coin.changePercent.toFixed(2)}%
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Latest News */}
            <div className="mt-6 pt-4 border-t border-white/10 relative z-10">
              <h3 className="font-semibold mb-3 flex items-center space-x-2">
                <Newspaper size={16} />
                <span>Latest News</span>
              </h3>
              <div className="space-y-3">
                {newsItems.slice(0, 2).map((news) => (
                  <motion.div
                    key={news.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{ scale: 1.01 }}
                    className="bg-gray-700/30 rounded-lg p-3 hover:bg-gray-700/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-sm leading-tight">{news.title}</h4>
                      <div className={`px-2 py-1 rounded-full text-xs ${
                        news.impact === 'high' ? 'bg-red-500/20 text-red-400' :
                        news.impact === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {news.impact.toUpperCase()}
                      </div>
                    </div>
                    <p className="text-xs text-gray-400 mb-2 line-clamp-2">{news.summary}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{news.source}</span>
                      <span>{news.timestamp.toLocaleTimeString()}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Trading Chart - Full Width */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.005 }}
            className="lg:col-span-3 bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-xl rounded-2xl p-6 text-white border border-white/10 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1),transparent_50%)]" />
            </div>

            <div className="flex items-center justify-between mb-6 relative z-10">
              <div className="flex items-center space-x-3">
                <h2 className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                  BTC/USDT Live Chart
                </h2>
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-green-400 text-sm font-medium">LIVE</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-1 bg-gray-700/50 rounded-lg p-1">
                  {['1H', '4H', '1D', '1W'].map((timeframe) => (
                    <button
                      key={timeframe}
                      className="px-3 py-1 rounded text-xs font-medium transition-colors bg-green-600 text-white"
                    >
                      {timeframe}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mb-4 relative z-10">
              <div className="text-3xl font-mono font-bold mb-2">
                $67,234.45
              </div>
              <div className="text-green-400 flex items-center space-x-2">
                <TrendingUp size={18} />
                <span className="font-semibold">+$1,234.45 (+1.87%)</span>
              </div>
            </div>

            <div className="h-64 relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
                  <XAxis 
                    dataKey="time" 
                    stroke="#6b7280" 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false}
                  />
                  <YAxis 
                    stroke="#6b7280" 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false}
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip 
                    formatter={(value: any) => [formatCurrency(value), 'Price']}
                    labelFormatter={(label) => `Time: ${label}`}
                    contentStyle={{
                      backgroundColor: 'rgba(31, 41, 55, 0.95)',
                      border: '1px solid rgba(75, 85, 99, 0.5)',
                      borderRadius: '12px',
                      color: 'white'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#00ff88" 
                    strokeWidth={3} 
                    dot={false}
                    strokeLinecap="round"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-4 gap-3 mt-6 relative z-10">
              {[
                { label: '24h High', value: '$68,234', color: 'text-green-400' },
                { label: '24h Low', value: '$66,123', color: 'text-red-400' },
                { label: 'Volume', value: '$2.4B', color: 'text-blue-400' },
                { label: 'Market Cap', value: '$1.32T', color: 'text-purple-400' }
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center p-3 bg-gray-700/30 rounded-xl"
                >
                  <div className="text-gray-400 text-xs mb-1">{stat.label}</div>
                  <div className={`font-bold ${stat.color}`}>{stat.value}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default AITradingDashboard;
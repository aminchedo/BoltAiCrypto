import LoadingFallback from '../components/ui/LoadingFallback'

export default function Loading() {
  return <LoadingFallback message="Loading AiSmart Pro..." />
}
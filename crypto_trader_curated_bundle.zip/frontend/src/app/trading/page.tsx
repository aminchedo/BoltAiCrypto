'use client'

import { Suspense } from 'react'
import dynamic from 'next/dynamic'
import LoadingFallback from '../../components/ui/LoadingFallback'

// Dynamic imports to avoid SSR issues
const CryptoTradingDashboard = dynamic(() => import('../../components/trading/CryptoTradingDashboard'), {
  ssr: false,
  loading: () => <LoadingFallback />
})

const Header = dynamic(() => import('../../components/dashboard/Header'), {
  ssr: false,
})

const Sidebar = dynamic(() => import('../../components/dashboard/Sidebar'), {
  ssr: false,
})

export default function TradingPage() {
  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black overflow-hidden">
      {/* Sidebar */}
      <div className="w-80">
        <Suspense fallback={<div className="w-80 bg-gray-900/50 border-r border-gray-700/50" />}>
          <Sidebar
            collapsed={false}
            onToggle={() => {}}
            currentTheme="dark"
            onThemeChange={() => {}}
            connectionStatus="connected"
          />
        </Suspense>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <Suspense fallback={<div className="h-16 bg-gray-900/50 border-b border-gray-700/50" />}>
          <Header
            onMenuClick={() => {}}
            onFullscreenToggle={() => {}}
            connectionStatus="connected"
            currentTheme="dark"
            onThemeChange={() => {}}
            isFullscreen={false}
            lastUpdate={new Date()}
          />
        </Suspense>

        {/* Trading Dashboard */}
        <div className="flex-1 p-4">
          <Suspense fallback={<LoadingFallback />}>
            <CryptoTradingDashboard />
          </Suspense>
        </div>
      </div>
    </div>
  )
}

// Metadata removed - client components can't export metadata
import React from 'react';
import StrategyBuilder from '@/components/strategy-builder/StrategyBuilder';

export const metadata = {
  title: 'AI Smart Trader - Strategy Builder',
  description: 'Create custom trading strategies with a visual drag-and-drop interface',
};

export default function StrategyBuilderPage() {
  return (
    <div className="h-screen w-screen">
      <StrategyBuilder />
    </div>
  );
}
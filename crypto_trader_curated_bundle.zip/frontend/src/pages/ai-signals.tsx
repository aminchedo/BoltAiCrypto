import React from 'react';
import Head from 'next/head';
import HybridSignalWidget from '@/components/trading/HybridSignalWidget';

const AISignalsPage: React.FC = () => {
  return (
    <>
      <Head>
        <title>AI Trading Signals | AiSmart Trader</title>
        <meta name="description" content="Advanced AI-powered trading signals with hybrid algorithm" />
      </Head>

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">
          AI Trading Signals
        </h1>
        
        <div className="mb-6">
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Our advanced AI trading signals are generated using a hybrid algorithm that combines multiple analysis techniques:
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
              <h3 className="font-bold text-lg mb-2 text-gray-800 dark:text-white">Technical Analysis (40%)</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                RSI, MACD, and other technical indicators to identify market trends and momentum.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
              <h3 className="font-bold text-lg mb-2 text-gray-800 dark:text-white">Smart Money Concepts (25%)</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Order blocks, fair value gaps, and market structure analysis to track institutional money flow.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
              <h3 className="font-bold text-lg mb-2 text-gray-800 dark:text-white">Pattern Recognition (20%)</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Harmonic patterns, chart patterns, and candlestick formations to identify high-probability setups.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
              <h3 className="font-bold text-lg mb-2 text-gray-800 dark:text-white">Sentiment Analysis (7%)</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                News and social media sentiment to gauge market psychology and crowd behavior.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
              <h3 className="font-bold text-lg mb-2 text-gray-800 dark:text-white">Whale Movements (3%)</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Large transaction monitoring and exchange flow analysis to track big players.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
              <h3 className="font-bold text-lg mb-2 text-gray-800 dark:text-white">ML Predictions (5%)</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Machine learning models trained on historical data to predict future price movements.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-8">
          <HybridSignalWidget 
            symbols={['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT', 'XRPUSDT', 'DOGEUSDT', 'DOTUSDT']} 
            refreshInterval={60000}
          />
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">How to Use AI Signals</h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-lg mb-1 text-gray-800 dark:text-white">1. Signal Confidence</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Each signal comes with a confidence score (0-100%). We recommend focusing on signals with 70%+ confidence.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-1 text-gray-800 dark:text-white">2. Risk Management</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Always use the recommended position size and stop-loss levels to manage risk effectively.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-1 text-gray-800 dark:text-white">3. Market Conditions</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Pay attention to volatility and volume profiles. High volatility may require wider stop-losses.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-1 text-gray-800 dark:text-white">4. Algorithm Breakdown</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Review the contribution of each component to understand what's driving the signal.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-1 text-gray-800 dark:text-white">5. Confirmation</h3>
              <p className="text-gray-600 dark:text-gray-300">
                For best results, confirm signals with your own analysis or use multiple timeframes.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 p-4 rounded">
          <p className="text-blue-700 dark:text-blue-300">
            <strong>Disclaimer:</strong> Trading signals are provided for informational purposes only and should not be considered as financial advice. Always do your own research and trade at your own risk.
          </p>
        </div>
      </div>
    </>
  );
};

export default AISignalsPage;
import { useState, useEffect, useCallback } from 'react';
import { apiService } from '@/services/apiService';
import useWebSocket from './useWebSocket';

interface MarketData {
  symbol: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  lastUpdated: Date;
}

export const useMarketData = (symbol: string) => {
  const [marketData, setMarketData] = useState<MarketData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Connect to WebSocket for real-time price updates
  const { isConnected, lastMessage } = useWebSocket('ticker', [symbol], {
    onMessage: (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.channel === 'ticker' && data.symbol === symbol) {
          updateMarketData(data);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    },
  });
  
  // Update market data from WebSocket message
  const updateMarketData = useCallback((data: any) => {
    setMarketData(prevData => {
      if (!prevData) return null;
      
      return {
        ...prevData,
        price: data.price,
        lastUpdated: new Date(),
      };
    });
  }, []);
  
  // Fetch initial market data
  const fetchMarketData = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const data = await apiService.getMarketData(symbol);
      
      setMarketData({
        symbol: data.symbol,
        price: data.price,
        change24h: data.change24h,
        changePercent24h: data.changePercent24h,
        high24h: data.high24h,
        low24h: data.low24h,
        volume24h: data.volume24h,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error('Error fetching market data:', error);
      setError('Failed to fetch market data');
    } finally {
      setIsLoading(false);
    }
  }, [symbol]);
  
  // Fetch data on mount and when symbol changes
  useEffect(() => {
    fetchMarketData();
    
    // Fallback polling if WebSocket is not connected
    let intervalId: NodeJS.Timeout;
    
    if (!isConnected) {
      intervalId = setInterval(fetchMarketData, 10000);
    }
    
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [symbol, fetchMarketData, isConnected]);
  
  // Update market data when WebSocket message is received
  useEffect(() => {
    if (lastMessage && lastMessage.channel === 'ticker' && lastMessage.symbol === symbol) {
      updateMarketData(lastMessage);
    }
  }, [lastMessage, symbol, updateMarketData]);
  
  return {
    marketData,
    isLoading,
    error,
    isRealTime: isConnected,
    refetch: fetchMarketData,
  };
};

export default useMarketData;
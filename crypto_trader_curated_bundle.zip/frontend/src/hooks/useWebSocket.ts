import { useState, useEffect, useRef, useCallback } from 'react';
import { apiService } from '@/services/apiService';
import realTimeService, { PriceUpdate, OrderBookUpdate, TradeUpdate, SignalUpdate, WhaleAlert, NewsUpdate } from '@/services/realTimeService';

interface WebSocketOptions {
  onOpen?: (event: WebSocketEventMap['open']) => void;
  onClose?: (event: WebSocketEventMap['close']) => void;
  onError?: (event: WebSocketEventMap['error']) => void;
  onMessage?: (event: WebSocketEventMap['message']) => void;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export const useWebSocket = (
  channel: string,
  symbols: string[],
  options: WebSocketOptions = {}
) => {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const {
    onOpen,
    onClose,
    onError,
    onMessage,
    reconnectInterval = 3000,
    maxReconnectAttempts = 5,
  } = options;
  
  // Connect to WebSocket
  const connect = useCallback(() => {
    try {
      const wsUrl = apiService.getWebSocketUrl();
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = (event) => {
        setIsConnected(true);
        setReconnectAttempts(0);
        
        // Subscribe to the channel with symbols
        const subscriptionMessage = apiService.createSubscriptionMessage(channel, symbols);
        ws.send(subscriptionMessage);
        
        if (onOpen) {
          onOpen(event);
        }
      };
      
      ws.onclose = (event) => {
        setIsConnected(false);
        
        if (onClose) {
          onClose(event);
        }
        
        // Attempt to reconnect if not closed cleanly
        if (event.code !== 1000 && event.code !== 1001) {
          handleReconnect();
        }
      };
      
      ws.onerror = (event) => {
        if (onError) {
          onError(event);
        }
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setLastMessage(data);
          
          if (onMessage) {
            onMessage(event);
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      wsRef.current = ws;
    } catch (error) {
      console.error('Error connecting to WebSocket:', error);
      handleReconnect();
    }
  }, [channel, symbols, onOpen, onClose, onError, onMessage]);
  
  // Handle reconnection
  const handleReconnect = useCallback(() => {
    if (reconnectAttempts < maxReconnectAttempts) {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      reconnectTimeoutRef.current = setTimeout(() => {
        setReconnectAttempts((prev) => prev + 1);
        connect();
      }, reconnectInterval);
    }
  }, [reconnectAttempts, maxReconnectAttempts, reconnectInterval, connect]);
  
  // Send message to WebSocket
  const sendMessage = useCallback((data: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(data));
      return true;
    }
    return false;
  }, []);
  
  // Connect on mount and disconnect on unmount
  useEffect(() => {
    connect();
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connect]);
  
  // Reconnect when symbols change
  useEffect(() => {
    if (isConnected && wsRef.current) {
      const subscriptionMessage = apiService.createSubscriptionMessage(channel, symbols);
      wsRef.current.send(subscriptionMessage);
    }
  }, [channel, symbols, isConnected]);
  
  return {
    isConnected,
    lastMessage,
    sendMessage,
    reconnectAttempts,
  };
};

// Enhanced hook for real-time market data
export function useRealTimeData(symbols: string[] = []) {
  const [priceData, setPriceData] = useState<Map<string, PriceUpdate>>(new Map());
  const [orderBooks, setOrderBooks] = useState<Map<string, OrderBookUpdate>>(new Map());
  const [recentTrades, setRecentTrades] = useState<TradeUpdate[]>([]);
  const [signals, setSignals] = useState<SignalUpdate[]>([]);
  const [whaleAlerts, setWhaleAlerts] = useState<WhaleAlert[]>([]);
  const [news, setNews] = useState<NewsUpdate[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<Record<string, boolean>>({});

  useEffect(() => {
    // Initialize connections
    realTimeService.initializeAll(symbols);

    // Set up event listeners
    const handlePriceUpdate = (update: PriceUpdate) => {
      setPriceData(prev => new Map(prev.set(update.symbol, update)));
    };

    const handleOrderBookUpdate = (update: OrderBookUpdate) => {
      setOrderBooks(prev => new Map(prev.set(update.symbol, update)));
    };

    const handleTradeUpdate = (update: TradeUpdate) => {
      setRecentTrades(prev => [update, ...prev.slice(0, 99)]); // Keep last 100 trades
    };

    const handleSignalUpdate = (update: SignalUpdate) => {
      setSignals(prev => {
        const filtered = prev.filter(s => s.id !== update.id);
        return [update, ...filtered].slice(0, 20); // Keep last 20 signals
      });
    };

    const handleWhaleAlert = (alert: WhaleAlert) => {
      setWhaleAlerts(prev => [alert, ...prev.slice(0, 49)]); // Keep last 50 alerts
    };

    const handleNewsUpdate = (update: NewsUpdate) => {
      setNews(prev => [update, ...prev.slice(0, 99)]); // Keep last 100 news items
    };

    const handleConnectionStatus = (status: { service: string; connected?: boolean }) => {
      setConnectionStatus(prev => ({
        ...prev,
        [status.service]: status.connected ?? true
      }));
    };

    // Subscribe to events
    realTimeService.on('priceUpdate', handlePriceUpdate);
    realTimeService.on('orderBookUpdate', handleOrderBookUpdate);
    realTimeService.on('tradeUpdate', handleTradeUpdate);
    realTimeService.on('signalUpdate', handleSignalUpdate);
    realTimeService.on('whaleAlert', handleWhaleAlert);
    realTimeService.on('newsUpdate', handleNewsUpdate);
    realTimeService.on('connected', handleConnectionStatus);
    realTimeService.on('disconnected', (status) => handleConnectionStatus({ ...status, connected: false }));

    return () => {
      // Clean up event listeners
      realTimeService.off('priceUpdate', handlePriceUpdate);
      realTimeService.off('orderBookUpdate', handleOrderBookUpdate);
      realTimeService.off('tradeUpdate', handleTradeUpdate);
      realTimeService.off('signalUpdate', handleSignalUpdate);
      realTimeService.off('whaleAlert', handleWhaleAlert);
      realTimeService.off('newsUpdate', handleNewsUpdate);
      realTimeService.off('connected', handleConnectionStatus);
      realTimeService.off('disconnected', handleConnectionStatus);
    };
  }, [symbols.join(',')]);

  const subscribeToSymbol = useCallback((symbol: string) => {
    realTimeService.subscribeToSymbol('binance', symbol);
    realTimeService.subscribeToSymbol('coinbase', symbol.replace('USDT', '-USD'));
    realTimeService.subscribeToSymbol('signals', symbol);
  }, []);

  const unsubscribeFromSymbol = useCallback((symbol: string) => {
    realTimeService.unsubscribeFromSymbol('binance', symbol);
    realTimeService.unsubscribeFromSymbol('coinbase', symbol.replace('USDT', '-USD'));
    realTimeService.unsubscribeFromSymbol('signals', symbol);
  }, []);

  const getPrice = useCallback((symbol: string): PriceUpdate | undefined => {
    return priceData.get(symbol);
  }, [priceData]);

  const getOrderBook = useCallback((symbol: string): OrderBookUpdate | undefined => {
    return orderBooks.get(symbol);
  }, [orderBooks]);

  const getHealthStatus = useCallback(() => {
    return realTimeService.healthCheck();
  }, []);

  return {
    priceData: Object.fromEntries(priceData),
    orderBooks: Object.fromEntries(orderBooks),
    recentTrades,
    signals,
    whaleAlerts,
    news,
    connectionStatus,
    subscribeToSymbol,
    unsubscribeFromSymbol,
    getPrice,
    getOrderBook,
    getHealthStatus
  };
}

// Hook for specific symbol data
export function useSymbolData(symbol: string) {
  const [price, setPrice] = useState<PriceUpdate | null>(null);
  const [orderBook, setOrderBook] = useState<OrderBookUpdate | null>(null);
  const [trades, setTrades] = useState<TradeUpdate[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Subscribe to symbol
    realTimeService.subscribeToSymbol('binance', symbol);
    realTimeService.subscribeToSymbol('coinbase', symbol.replace('USDT', '-USD'));

    const handlePriceUpdate = (update: PriceUpdate) => {
      if (update.symbol === symbol) {
        setPrice(update);
      }
    };

    const handleOrderBookUpdate = (update: OrderBookUpdate) => {
      if (update.symbol === symbol) {
        setOrderBook(update);
      }
    };

    const handleTradeUpdate = (update: TradeUpdate) => {
      if (update.symbol === symbol) {
        setTrades(prev => [update, ...prev.slice(0, 19)]); // Keep last 20 trades
      }
    };

    const handleConnection = (status: { service: string }) => {
      setIsConnected(true);
    };

    const handleDisconnection = (status: { service: string }) => {
      setIsConnected(false);
    };

    realTimeService.on('priceUpdate', handlePriceUpdate);
    realTimeService.on('orderBookUpdate', handleOrderBookUpdate);
    realTimeService.on('tradeUpdate', handleTradeUpdate);
    realTimeService.on('connected', handleConnection);
    realTimeService.on('disconnected', handleDisconnection);

    return () => {
      realTimeService.off('priceUpdate', handlePriceUpdate);
      realTimeService.off('orderBookUpdate', handleOrderBookUpdate);
      realTimeService.off('tradeUpdate', handleTradeUpdate);
      realTimeService.off('connected', handleConnection);
      realTimeService.off('disconnected', handleDisconnection);
      
      // Unsubscribe from symbol
      realTimeService.unsubscribeFromSymbol('binance', symbol);
      realTimeService.unsubscribeFromSymbol('coinbase', symbol.replace('USDT', '-USD'));
    };
  }, [symbol]);

  return {
    price,
    orderBook,
    trades,
    isConnected
  };
}

// Hook for AI signals
export function useAISignals(symbols?: string[]) {
  const [signals, setSignals] = useState<SignalUpdate[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Connect to signals service
    realTimeService.connect('signals', symbols);

    const handleSignalUpdate = (update: SignalUpdate) => {
      if (!symbols || symbols.includes(update.symbol)) {
        setSignals(prev => {
          const filtered = prev.filter(s => s.id !== update.id);
          return [update, ...filtered].slice(0, 50); // Keep last 50 signals
        });
      }
    };

    const handleConnection = (status: { service: string }) => {
      if (status.service === 'signals') {
        setIsConnected(true);
      }
    };

    const handleDisconnection = (status: { service: string }) => {
      if (status.service === 'signals') {
        setIsConnected(false);
      }
    };

    realTimeService.on('signalUpdate', handleSignalUpdate);
    realTimeService.on('connected', handleConnection);
    realTimeService.on('disconnected', handleDisconnection);

    return () => {
      realTimeService.off('signalUpdate', handleSignalUpdate);
      realTimeService.off('connected', handleConnection);
      realTimeService.off('disconnected', handleDisconnection);
    };
  }, [symbols?.join(',')]);

  return {
    signals,
    isConnected
  };
}

// Hook for whale alerts
export function useWhaleAlerts() {
  const [alerts, setAlerts] = useState<WhaleAlert[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    realTimeService.connect('signals'); // Whale alerts come through signals service

    const handleWhaleAlert = (alert: WhaleAlert) => {
      setAlerts(prev => [alert, ...prev.slice(0, 99)]); // Keep last 100 alerts
    };

    const handleConnection = (status: { service: string }) => {
      if (status.service === 'signals') {
        setIsConnected(true);
      }
    };

    const handleDisconnection = (status: { service: string }) => {
      if (status.service === 'signals') {
        setIsConnected(false);
      }
    };

    realTimeService.on('whaleAlert', handleWhaleAlert);
    realTimeService.on('connected', handleConnection);
    realTimeService.on('disconnected', handleDisconnection);

    return () => {
      realTimeService.off('whaleAlert', handleWhaleAlert);
      realTimeService.off('connected', handleConnection);
      realTimeService.off('disconnected', handleDisconnection);
    };
  }, []);

  return {
    alerts,
    isConnected
  };
}

// Hook for news updates
export function useNewsUpdates() {
  const [news, setNews] = useState<NewsUpdate[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    realTimeService.connect('news');

    const handleNewsUpdate = (update: NewsUpdate) => {
      setNews(prev => [update, ...prev.slice(0, 199)]); // Keep last 200 news items
    };

    const handleConnection = (status: { service: string }) => {
      if (status.service === 'news') {
        setIsConnected(true);
      }
    };

    const handleDisconnection = (status: { service: string }) => {
      if (status.service === 'news') {
        setIsConnected(false);
      }
    };

    realTimeService.on('newsUpdate', handleNewsUpdate);
    realTimeService.on('connected', handleConnection);
    realTimeService.on('disconnected', handleDisconnection);

    return () => {
      realTimeService.off('newsUpdate', handleNewsUpdate);
      realTimeService.off('connected', handleConnection);
      realTimeService.off('disconnected', handleDisconnection);
    };
  }, []);

  return {
    news,
    isConnected
  };
}

export default useWebSocket;
// Custom hook for responsive design with media queries

import { useState, useEffect } from 'react';

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    // Avoid running on the server
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia(query);
      
      // Set initial value
      setMatches(mediaQuery.matches);
      
      // Create event listener
      const handler = (event: MediaQueryListEvent) => setMatches(event.matches);
      
      // Add event listener
      mediaQuery.addEventListener('change', handler);
      
      // Remove event listener on cleanup
      return () => mediaQuery.removeEventListener('change', handler);
    }
    
    // Default to false on the server
    return () => {};
  }, [query]);

  return matches;
}

// Predefined media queries
export const useIsMobile = () => useMediaQuery('(max-width: 767px)');
export const useIsTablet = () => useMediaQuery('(min-width: 768px) and (max-width: 1023px)');
export const useIsDesktop = () => useMediaQuery('(min-width: 1024px)');
export const useIsLargeDesktop = () => useMediaQuery('(min-width: 1280px)');
export const useIsDarkMode = () => useMediaQuery('(prefers-color-scheme: dark)');
export const useReducedMotion = () => useMediaQuery('(prefers-reduced-motion: reduce)');
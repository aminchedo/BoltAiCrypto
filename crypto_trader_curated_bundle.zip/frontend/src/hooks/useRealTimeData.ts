'use client';

import { useState, useEffect } from 'react';
import { realTimeService, PriceUpdate, OrderBookUpdate, TradeUpdate, SignalUpdate, WhaleAlert, NewsUpdate } from '@/services/realTimeService';

interface RealTimeData {
  prices: PriceUpdate[];
  orderBooks: OrderBookUpdate[];
  trades: TradeUpdate[];
  signals: SignalUpdate[];
  whaleAlerts: WhaleAlert[];
  news: NewsUpdate[];
}

export const useRealTimeData = (symbols: string[] = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']) => {
  const [data, setData] = useState({
    prices: [],
    orderBooks: [],
    trades: [],
    signals: [],
    whaleAlerts: [],
    news: [],
  });

  useEffect(() => {
    realTimeService.initializeAll(symbols);

    const handlePriceUpdate = (update: PriceUpdate) => {
      setData(prev => ({
        ...prev,
        prices: [...prev.prices.filter(p => p.symbol !== update.symbol), update],
      }));
    };

    const handleOrderBookUpdate = (update: OrderBookUpdate) => {
      setData(prev => ({
        ...prev,
        orderBooks: [...prev.orderBooks.filter(ob => ob.symbol !== update.symbol), update],
      }));
    };

    const handleTradeUpdate = (update: TradeUpdate) => {
      setData(prev => ({
        ...prev,
        trades: [...prev.trades.slice(-100), update],
      }));
    };

    const handleSignalUpdate = (update: SignalUpdate) => {
      setData(prev => ({
        ...prev,
        signals: [...prev.signals.filter(s => s.id !== update.id), update],
      }));
    };

    const handleWhaleAlert = (alert: WhaleAlert) => {
      setData(prev => ({
        ...prev,
        whaleAlerts: [...prev.whaleAlerts.slice(-50), alert],
      }));
    };

    const handleNewsUpdate = (update: NewsUpdate) => {
      setData(prev => ({
        ...prev,
        news: [...prev.news.slice(-50), update],
      }));
    };

    realTimeService.on('priceUpdate', handlePriceUpdate);
    realTimeService.on('orderBookUpdate', handleOrderBookUpdate);
    realTimeService.on('tradeUpdate', handleTradeUpdate);
    realTimeService.on('signalUpdate', handleSignalUpdate);
    realTimeService.on('whaleAlert', handleWhaleAlert);
    realTimeService.on('newsUpdate', handleNewsUpdate);

    return () => {
      realTimeService.disconnectAll();
      realTimeService.off('priceUpdate', handlePriceUpdate);
      realTimeService.off('orderBookUpdate', handleOrderBookUpdate);
      realTimeService.off('tradeUpdate', handleTradeUpdate);
      realTimeService.off('signalUpdate', handleSignalUpdate);
      realTimeService.off('whaleAlert', handleWhaleAlert);
      realTimeService.off('newsUpdate', handleNewsUpdate);
    };
  }, [symbols]);

  return data;
};
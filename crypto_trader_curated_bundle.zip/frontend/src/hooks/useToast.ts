import { useState } from 'react';

interface Toast {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'error' | 'info' | 'warning';
  duration?: number;
}

interface ToastOptions {
  title: string;
  description?: string;
  type: 'success' | 'error' | 'info' | 'warning';
  duration?: number;
}

export const useToast = () => {
  const [toasts, setToasts] = useState<Toast[]>([]);
  
  const showToast = (options: ToastOptions) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const toast: Toast = {
      id,
      ...options,
      duration: options.duration || 5000,
    };
    
    setToasts(prev => [...prev, toast]);
    
    // Auto-dismiss after duration
    setTimeout(() => {
      dismissToast(id);
    }, toast.duration);
    
    return id;
  };
  
  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };
  
  return {
    toasts,
    showToast,
    dismissToast,
  };
};

export default useToast;
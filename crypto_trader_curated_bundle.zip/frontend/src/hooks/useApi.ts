// Custom hooks for API integration

import { useState, useEffect, useCallback, useRef } from 'react';
import { 
  marketApi, 
  portfolioApi, 
  signalsApi, 
  tradingApi,
  websocketApi 
} from '@/lib/api';
import { 
  Ticker, 
  Portfolio, 
  Position,
  Signal, 
  HybridSignal,
  Order,
  OrderRequest,
  MarketData,
  Candle,
  NewsItem,
  WhaleActivity,
  ApiResponse,
  ChartTimeframe 
} from '@/types';
import { config } from '@/lib/config';

// Generic API hook
interface UseApiOptions<T> {
  initialData?: T;
  enabled?: boolean;
  refetchInterval?: number;
  onSuccess?: (data: T) => void;
  onError?: (error: string) => void;
}

interface UseApiReturn<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  mutate: (newData: T) => void;
}

export function useApi<T>(
  apiCall: () => Promise<ApiResponse<T>>,
  options: UseApiOptions<T> = {}
): UseApiReturn<T> {
  const [data, setData] = useState<T | null>(options.initialData || null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const mountedRef = useRef(true);

  const fetchData = useCallback(async () => {
    if (!options.enabled && options.enabled !== undefined) return;

    try {
      setLoading(true);
      setError(null);
      
      const response = await apiCall();
      
      if (!mountedRef.current) return;
      
      if (response.success) {
        setData(response.data);
        options.onSuccess?.(response.data);
      } else {
        const errorMessage = response.error || 'API call failed';
        setError(errorMessage);
        options.onError?.(errorMessage);
      }
    } catch (err) {
      if (!mountedRef.current) return;
      
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      options.onError?.(errorMessage);
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }, [apiCall, options]);

  const mutate = useCallback((newData: T) => {
    setData(newData);
  }, []);

  useEffect(() => {
    fetchData();

    // Set up polling if refetchInterval is provided
    if (options.refetchInterval && options.refetchInterval > 0) {
      intervalRef.current = setInterval(fetchData, options.refetchInterval);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [fetchData, options.refetchInterval]);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  return { data, loading, error, refetch: fetchData, mutate };
}

// Market Data Hooks
export function useTickers(options?: UseApiOptions<Ticker[]>) {
  return useApi(() => marketApi.getTickers(), {
    refetchInterval: 10000, // 10 seconds
    ...options
  });
}

export function useTicker(symbol: string, options?: UseApiOptions<Ticker>) {
  return useApi(() => marketApi.getTicker(symbol), {
    enabled: !!symbol,
    refetchInterval: 5000, // 5 seconds
    ...options
  });
}

export function useMarketData(symbol: string, timeFrame?: ChartTimeframe, options?: UseApiOptions<MarketData>) {
  return useApi(() => marketApi.getMarketData(symbol, timeFrame), {
    enabled: !!symbol,
    refetchInterval: 15000, // 15 seconds
    ...options
  });
}

export function useCandles(
  symbol: string, 
  timeFrame: ChartTimeframe = '1h', 
  limit: number = 100,
  options?: UseApiOptions<Candle[]>
) {
  return useApi(() => marketApi.getCandles(symbol, timeFrame, limit), {
    enabled: !!symbol,
    refetchInterval: timeFrame === '1m' ? 60000 : timeFrame === '5m' ? 300000 : 900000,
    ...options
  });
}

// Real-time ticker hook with WebSocket
export function useRealtimeTickers(symbols: string[]) {
  const [tickers, setTickers] = useState<Record<string, Ticker>>({});
  const [connected, setConnected] = useState(false);
  const unsubscribeRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (symbols.length === 0) return;

    // Initial fetch
    const fetchInitialData = async () => {
      try {
        const response = await marketApi.getMultipleTickers(symbols);
        if (response.success) {
          const tickerMap: Record<string, Ticker> = {};
          response.data.forEach(ticker => {
            tickerMap[ticker.symbol] = ticker;
          });
          setTickers(tickerMap);
        }
      } catch (err) {
        console.error('Failed to fetch initial ticker data:', err);
      }
    };

    fetchInitialData();

    // Subscribe to real-time updates
    try {
      setConnected(false);
      unsubscribeRef.current = marketApi.subscribeToTickers(symbols, (ticker) => {
        setTickers(prev => ({
          ...prev,
          [ticker.symbol]: ticker
        }));
        setConnected(true);
      });
    } catch (err) {
      console.error('Failed to subscribe to ticker updates:', err);
    }

    return () => {
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
        unsubscribeRef.current = null;
      }
      setConnected(false);
    };
  }, [symbols]);

  return { 
    tickers, 
    connected,
    getTickerBySymbol: (symbol: string) => tickers[symbol] || null
  };
}

// Portfolio Hooks
export function usePortfolio(options?: UseApiOptions<Portfolio>) {
  return useApi(() => portfolioApi.getPortfolio(), {
    refetchInterval: 30000, // 30 seconds
    ...options
  });
}

export function usePositions(options?: UseApiOptions<Position[]>) {
  return useApi(() => portfolioApi.getPositions(), {
    refetchInterval: 15000, // 15 seconds
    ...options
  });
}

export function usePortfolioPerformance(period: string = '7d', options?: UseApiOptions<any>) {
  return useApi(() => portfolioApi.getPerformance(period), {
    refetchInterval: 60000, // 1 minute
    ...options
  });
}

// Real-time portfolio hook
export function useRealtimePortfolio() {
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [positions, setPositions] = useState<Position[]>([]);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Initial fetch
    const fetchInitialData = async () => {
      try {
        const [portfolioResponse, positionsResponse] = await Promise.all([
          portfolioApi.getPortfolio(),
          portfolioApi.getPositions()
        ]);

        if (portfolioResponse.success) {
          setPortfolio(portfolioResponse.data);
        }

        if (positionsResponse.success) {
          setPositions(positionsResponse.data);
        }
      } catch (err) {
        console.error('Failed to fetch initial portfolio data:', err);
      }
    };

    fetchInitialData();

    // Subscribe to real-time updates
    const unsubscribe = portfolioApi.subscribeToUpdates((data) => {
      setConnected(true);
      
      if ('totalValue' in data) {
        // Portfolio update
        setPortfolio(data as Portfolio);
      } else {
        // Position update
        const position = data as Position;
        setPositions(prev => {
          const existing = prev.find(p => p.id === position.id);
          if (existing) {
            return prev.map(p => p.id === position.id ? position : p);
          } else {
            return [...prev, position];
          }
        });
      }
    });

    return () => {
      unsubscribe();
      setConnected(false);
    };
  }, []);

  return { portfolio, positions, connected };
}

// Signals Hooks
export function useSignals(symbol?: string, options?: UseApiOptions<Signal[]>) {
  return useApi(() => signalsApi.getSignals(symbol), {
    refetchInterval: config.ai.signalRefreshInterval,
    ...options
  });
}

export function useHybridSignals(symbol?: string, options?: UseApiOptions<HybridSignal[]>) {
  return useApi(() => signalsApi.getHybridSignals(symbol), {
    refetchInterval: config.ai.signalRefreshInterval,
    ...options
  });
}

export function useSignalPerformance(period: string = '7d', options?: UseApiOptions<any>) {
  return useApi(() => signalsApi.getSignalPerformance(period), {
    refetchInterval: 300000, // 5 minutes
    ...options
  });
}

// Real-time signals hook
export function useRealtimeSignals(filters?: { symbol?: string; minConfidence?: number }) {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [hybridSignals, setHybridSignals] = useState<HybridSignal[]>([]);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Initial fetch
    const fetchInitialData = async () => {
      try {
        const [signalsResponse, hybridResponse] = await Promise.all([
          signalsApi.getSignals(filters?.symbol),
          signalsApi.getHybridSignals(filters?.symbol, filters?.minConfidence)
        ]);

        if (signalsResponse.success) {
          setSignals(signalsResponse.data);
        }

        if (hybridResponse.success) {
          setHybridSignals(hybridResponse.data);
        }
      } catch (err) {
        console.error('Failed to fetch initial signals data:', err);
      }
    };

    fetchInitialData();

    // Subscribe to real-time updates
    const unsubscribe = signalsApi.subscribeToSignals((signal) => {
      setConnected(true);
      
      if ('algorithmBreakdown' in signal) {
        // Hybrid signal
        setHybridSignals(prev => [signal as HybridSignal, ...prev.slice(0, 19)]);
      } else {
        // Regular signal
        setSignals(prev => [signal, ...prev.slice(0, 19)]);
      }
    }, filters);

    return () => {
      unsubscribe();
      setConnected(false);
    };
  }, [filters?.symbol, filters?.minConfidence]);

  return { signals, hybridSignals, connected };
}

// Trading Hooks
export function useOrders(options?: UseApiOptions<Order[]>) {
  return useApi(() => tradingApi.getOrders(), {
    refetchInterval: 10000, // 10 seconds
    ...options
  });
}

export function useTradeHistory(symbol?: string, limit: number = 100, options?: UseApiOptions<any[]>) {
  return useApi(() => tradingApi.getTradeHistory(symbol, limit), {
    refetchInterval: 30000, // 30 seconds
    ...options
  });
}

export function useTradingPerformance(period: string = '30d', options?: UseApiOptions<any>) {
  return useApi(() => tradingApi.getTradingPerformance(period), {
    refetchInterval: 300000, // 5 minutes
    ...options
  });
}

// Trading operations hook
export function useTrading() {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createOrder = useCallback(async (orderRequest: OrderRequest): Promise<Order | null> => {
    try {
      setSubmitting(true);
      setError(null);
      
      const response = await tradingApi.createOrder(orderRequest);
      
      if (response.success) {
        return response.data;
      } else {
        setError(response.error || 'Failed to create order');
        return null;
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return null;
    } finally {
      setSubmitting(false);
    }
  }, []);

  const cancelOrder = useCallback(async (orderId: string): Promise<boolean> => {
    try {
      setSubmitting(true);
      setError(null);
      
      const response = await tradingApi.cancelOrder(orderId);
      return response.success;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return false;
    } finally {
      setSubmitting(false);
    }
  }, []);

  const cancelAllOrders = useCallback(async (symbol?: string): Promise<boolean> => {
    try {
      setSubmitting(true);
      setError(null);
      
      const response = await tradingApi.cancelAllOrders(symbol);
      return response.success;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return false;
    } finally {
      setSubmitting(false);
    }
  }, []);

  const closePosition = useCallback(async (positionId: string): Promise<boolean> => {
    try {
      setSubmitting(true);
      setError(null);
      
      const response = await portfolioApi.closePosition(positionId);
      return response.success;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return false;
    } finally {
      setSubmitting(false);
    }
  }, []);

  return {
    createOrder,
    cancelOrder,
    cancelAllOrders,
    closePosition,
    submitting,
    error,
    clearError: () => setError(null)
  };
}

// Market search hook
export function useMarketSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Ticker[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  const search = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await marketApi.searchMarkets(searchQuery);
      
      if (response.success) {
        setResults(response.data);
      } else {
        setError(response.error || 'Search failed');
        setResults([]);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Search error';
      setError(errorMessage);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const debouncedSearch = useCallback((searchQuery: string) => {
    setQuery(searchQuery);
    
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
    
    debounceRef.current = setTimeout(() => {
      search(searchQuery);
    }, 300);
  }, [search]);

  useEffect(() => {
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, []);

  return {
    query,
    results,
    loading,
    error,
    search: debouncedSearch,
    clearResults: () => setResults([])
  };
}

// WebSocket connection status hook
export function useConnectionStatus() {
  const [status, setStatus] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const checkConnections = () => {
      const marketUrl = `${config.api.websocketUrl}/market/tickers`;
      const portfolioUrl = `${config.api.websocketUrl}/portfolio`;
      const signalsUrl = `${config.api.websocketUrl}/signals`;

      setStatus({
        market: websocketApi.getConnectionStatus(marketUrl),
        portfolio: websocketApi.getConnectionStatus(portfolioUrl),
        signals: websocketApi.getConnectionStatus(signalsUrl)
      });
    };

    checkConnections();
    const interval = setInterval(checkConnections, 5000);

    return () => clearInterval(interval);
  }, []);

  return status;
}

// Health check hook
export function useHealthCheck() {
  const [status, setStatus] = useState<{
    api: boolean;
    websocket: boolean;
    lastCheck: Date | null;
  }>({
    api: false,
    websocket: false,
    lastCheck: null
  });

  useEffect(() => {
    const checkHealth = async () => {
      try {
        // Check API health
        const response = await fetch(`${config.api.baseUrl}/health`);
        const apiHealthy = response.ok;

        // Check WebSocket health (basic connectivity test)
        const wsHealthy = Object.values(useConnectionStatus()).some(connected => connected);

        setStatus({
          api: apiHealthy,
          websocket: wsHealthy,
          lastCheck: new Date()
        });
      } catch (err) {
        setStatus(prev => ({
          ...prev,
          api: false,
          lastCheck: new Date()
        }));
      }
    };

    checkHealth();
    const interval = setInterval(checkHealth, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return status;
}

// Cache hook for optimistic updates
export function useOptimisticUpdates<T>() {
  const [optimisticData, setOptimisticData] = useState<T | null>(null);
  const [isOptimistic, setIsOptimistic] = useState(false);

  const updateOptimistically = useCallback((data: T, rollbackDelay: number = 5000) => {
    setOptimisticData(data);
    setIsOptimistic(true);

    // Auto rollback after delay if not confirmed
    setTimeout(() => {
      setIsOptimistic(false);
      setOptimisticData(null);
    }, rollbackDelay);
  }, []);

  const confirmUpdate = useCallback(() => {
    setIsOptimistic(false);
    setOptimisticData(null);
  }, []);

  const rollbackUpdate = useCallback(() => {
    setIsOptimistic(false);
    setOptimisticData(null);
  }, []);

  return {
    optimisticData,
    isOptimistic,
    updateOptimistically,
    confirmUpdate,
    rollbackUpdate
  };
}

export default {
  useApi,
  useTickers,
  useTicker,
  useMarketData,
  useCandles,
  useRealtimeTickers,
  usePortfolio,
  usePositions,
  usePortfolioPerformance,
  useRealtimePortfolio,
  useSignals,
  useHybridSignals,
  useSignalPerformance,
  useRealtimeSignals,
  useOrders,
  useTradeHistory,
  useTradingPerformance,
  useTrading,
  useMarketSearch,
  useConnectionStatus,
  useHealthCheck,
  useOptimisticUpdates
};
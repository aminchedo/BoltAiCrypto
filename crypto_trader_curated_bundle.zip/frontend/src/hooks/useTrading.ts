import { useState, useEffect, useCallback } from 'react';
import tradingService, { Order, Position, Portfolio, RiskMetrics, OrderRequest } from '@/services/tradingService';
import signalService from '@/services/signalService';

interface TradingHookState {
  orders: Order[];
  positions: Position[];
  portfolio: Portfolio | null;
  riskMetrics: RiskMetrics | null;
  loading: boolean;
  error: string | null;
}

export function useTrading() {
  const [state, setState] = useState<TradingHookState>({
    orders: [],
    positions: [],
    portfolio: null,
    riskMetrics: null,
    loading: true,
    error: null
  });

  // Load initial data
  useEffect(() => {
    loadTradingData();
    
    // Set up event listeners
    const handleOrderPlaced = (order: Order) => {
      setState(prev => ({
        ...prev,
        orders: [order, ...prev.orders]
      }));
    };

    const handleOrderCanceled = (order: Order) => {
      setState(prev => ({
        ...prev,
        orders: prev.orders.map(o => o.id === order.id ? order : o)
      }));
    };

    const handleEmergencyStop = () => {
      setState(prev => ({
        ...prev,
        orders: prev.orders.map(order => ({ ...order, status: 'CANCELED' as const }))
      }));
    };

    tradingService.on('orderPlaced', handleOrderPlaced);
    tradingService.on('orderCanceled', handleOrderCanceled);
    tradingService.on('emergencyStop', handleEmergencyStop);

    return () => {
      tradingService.off('orderPlaced', handleOrderPlaced);
      tradingService.off('orderCanceled', handleOrderCanceled);
      tradingService.off('emergencyStop', handleEmergencyStop);
    };
  }, []);

  const loadTradingData = async () => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      const [orders, positions, portfolio, riskMetrics] = await Promise.all([
        tradingService.getActiveOrders(),
        tradingService.getPositions(),
        tradingService.getPortfolio(),
        tradingService.getRiskMetrics()
      ]);

      setState(prev => ({
        ...prev,
        orders,
        positions,
        portfolio,
        riskMetrics,
        loading: false
      }));
    } catch (error) {
      console.error('Failed to load trading data:', error);
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Failed to load trading data',
        loading: false
      }));
    }
  };

  const placeOrder = useCallback(async (orderRequest: OrderRequest): Promise<Order | null> => {
    try {
      setState(prev => ({ ...prev, error: null }));
      const order = await tradingService.placeOrder(orderRequest);
      
      // Refresh portfolio after order placement
      const updatedPortfolio = await tradingService.getPortfolio();
      setState(prev => ({
        ...prev,
        portfolio: updatedPortfolio
      }));
      
      return order;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to place order';
      setState(prev => ({ ...prev, error: errorMessage }));
      return null;
    }
  }, []);

  const cancelOrder = useCallback(async (orderId: string): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, error: null }));
      await tradingService.cancelOrder(orderId);
      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to cancel order';
      setState(prev => ({ ...prev, error: errorMessage }));
      return false;
    }
  }, []);

  const placeOrderFromSignal = useCallback(async (signal: any, positionSize?: number): Promise<Order | null> => {
    try {
      setState(prev => ({ ...prev, error: null }));
      const order = await tradingService.placeOrderFromSignal(signal, positionSize);
      
      // Refresh portfolio after order placement
      const updatedPortfolio = await tradingService.getPortfolio();
      setState(prev => ({
        ...prev,
        portfolio: updatedPortfolio
      }));
      
      return order;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to place order from signal';
      setState(prev => ({ ...prev, error: errorMessage }));
      return null;
    }
  }, []);

  const emergencyStop = useCallback(async (): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, error: null }));
      await tradingService.emergencyStop();
      
      // Refresh all data after emergency stop
      await loadTradingData();
      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Emergency stop failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      return false;
    }
  }, []);

  const updateRiskSettings = useCallback((newSettings: any) => {
    tradingService.updateRiskSettings(newSettings);
  }, []);

  const getRiskSettings = useCallback(() => {
    return tradingService.getRiskSettings();
  }, []);

  const refreshData = useCallback(() => {
    loadTradingData();
  }, []);

  return {
    ...state,
    placeOrder,
    cancelOrder,
    placeOrderFromSignal,
    emergencyStop,
    updateRiskSettings,
    getRiskSettings,
    refreshData
  };
}

// Hook for order management
export function useOrders(symbol?: string) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadOrders();
  }, [symbol]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const orderHistory = await tradingService.getOrderHistory(symbol);
      setOrders(orderHistory);
    } catch (error) {
      console.error('Failed to load orders:', error);
      setError(error instanceof Error ? error.message : 'Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const placeOrder = async (orderRequest: OrderRequest) => {
    try {
      setError(null);
      const order = await tradingService.placeOrder(orderRequest);
      setOrders(prev => [order, ...prev]);
      return order;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to place order';
      setError(errorMessage);
      throw error;
    }
  };

  const cancelOrder = async (orderId: string) => {
    try {
      setError(null);
      await tradingService.cancelOrder(orderId);
      setOrders(prev => prev.map(order => 
        order.id === orderId 
          ? { ...order, status: 'CANCELED' as const, updateTime: Date.now() }
          : order
      ));
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to cancel order';
      setError(errorMessage);
      throw error;
    }
  };

  return {
    orders,
    loading,
    error,
    placeOrder,
    cancelOrder,
    refreshOrders: loadOrders
  };
}

// Hook for portfolio management
export function usePortfolio() {
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadPortfolioData();
    
    // Refresh portfolio data every 30 seconds
    const interval = setInterval(loadPortfolioData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadPortfolioData = async () => {
    try {
      setError(null);
      
      const [portfolioData, positionsData] = await Promise.all([
        tradingService.getPortfolio(),
        tradingService.getPositions()
      ]);
      
      setPortfolio(portfolioData);
      setPositions(positionsData);
    } catch (error) {
      console.error('Failed to load portfolio data:', error);
      setError(error instanceof Error ? error.message : 'Failed to load portfolio data');
    } finally {
      setLoading(false);
    }
  };

  const calculatePortfolioMetrics = () => {
    if (!portfolio) return null;

    const totalValue = portfolio.totalValue;
    const dailyPnL = portfolio.dailyPnl;
    const totalPnL = portfolio.totalPnl;
    const dailyReturn = (dailyPnL / totalValue) * 100;
    const totalReturn = (totalPnL / (totalValue - totalPnL)) * 100;

    return {
      totalValue,
      dailyPnL,
      totalPnL,
      dailyReturn,
      totalReturn,
      marginLevel: portfolio.marginLevel,
      freeMargin: portfolio.freeMargin,
      usedMargin: portfolio.usedMargin
    };
  };

  return {
    portfolio,
    positions,
    loading,
    error,
    metrics: calculatePortfolioMetrics(),
    refreshPortfolio: loadPortfolioData
  };
}

// Hook for risk management
export function useRiskManagement() {
  const [riskMetrics, setRiskMetrics] = useState<RiskMetrics | null>(null);
  const [riskSettings, setRiskSettings] = useState(tradingService.getRiskSettings());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadRiskData();
    
    // Refresh risk data every minute
    const interval = setInterval(loadRiskData, 60000);
    return () => clearInterval(interval);
  }, []);

  const loadRiskData = async () => {
    try {
      setError(null);
      const metrics = await tradingService.getRiskMetrics();
      setRiskMetrics(metrics);
    } catch (error) {
      console.error('Failed to load risk data:', error);
      setError(error instanceof Error ? error.message : 'Failed to load risk data');
    } finally {
      setLoading(false);
    }
  };

  const updateRiskSettings = (newSettings: Partial<typeof riskSettings>) => {
    const updatedSettings = { ...riskSettings, ...newSettings };
    setRiskSettings(updatedSettings);
    tradingService.updateRiskSettings(newSettings);
  };

  const calculateRiskLevel = () => {
    if (!riskMetrics) return 'UNKNOWN';
    
    const { portfolioRisk, maxDrawdown, valueAtRisk } = riskMetrics;
    
    if (portfolioRisk > 30 || maxDrawdown > 20) return 'HIGH';
    if (portfolioRisk > 15 || maxDrawdown > 10) return 'MEDIUM';
    return 'LOW';
  };

  const getRiskRecommendations = () => {
    if (!riskMetrics) return [];
    
    const recommendations = [];
    
    if (riskMetrics.portfolioRisk > 25) {
      recommendations.push('Consider reducing position sizes');
    }
    
    if (riskMetrics.maxDrawdown > 15) {
      recommendations.push('Review stop-loss strategies');
    }
    
    if (riskMetrics.winRate < 50) {
      recommendations.push('Analyze losing trades for patterns');
    }
    
    if (riskMetrics.profitFactor < 1.5) {
      recommendations.push('Improve risk-reward ratios');
    }
    
    return recommendations;
  };

  return {
    riskMetrics,
    riskSettings,
    loading,
    error,
    riskLevel: calculateRiskLevel(),
    recommendations: getRiskRecommendations(),
    updateRiskSettings,
    refreshRiskData: loadRiskData
  };
}

// Hook for AI signal integration
export function useSignalTrading() {
  const [signals, setSignals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { placeOrderFromSignal } = useTrading();

  useEffect(() => {
    loadSignals();
    
    // Refresh signals every 30 seconds
    const interval = setInterval(loadSignals, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadSignals = async () => {
    try {
      setError(null);
      const liveSignals = await signalService.getLiveSignals();
      setSignals(liveSignals);
    } catch (error) {
      console.error('Failed to load signals:', error);
      setError(error instanceof Error ? error.message : 'Failed to load signals');
    } finally {
      setLoading(false);
    }
  };

  const executeSignal = async (signal: any, positionSize?: number) => {
    try {
      setError(null);
      const order = await placeOrderFromSignal(signal, positionSize);
      
      if (order) {
        // Update signal status
        setSignals(prev => prev.map(s => 
          s.id === signal.id 
            ? { ...s, status: 'EXECUTED', executedAt: Date.now() }
            : s
        ));
      }
      
      return order;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to execute signal';
      setError(errorMessage);
      throw error;
    }
  };

  const dismissSignal = (signalId: string) => {
    setSignals(prev => prev.filter(s => s.id !== signalId));
  };

  const getSignalsByConfidence = (minConfidence: number = 70) => {
    return signals.filter(signal => signal.confidence >= minConfidence);
  };

  const getSignalsBySymbol = (symbol: string) => {
    return signals.filter(signal => signal.symbol === symbol);
  };

  return {
    signals,
    loading,
    error,
    executeSignal,
    dismissSignal,
    getSignalsByConfidence,
    getSignalsBySymbol,
    refreshSignals: loadSignals
  };
}

// Hook for exchange management
export function useExchanges() {
  const [exchanges, setExchanges] = useState(tradingService.getExchangeConfigs());
  const [connectionStatus, setConnectionStatus] = useState<Record<string, boolean>>({});

  useEffect(() => {
    // Check connection status for each exchange
    const checkConnections = () => {
      const status: Record<string, boolean> = {};
      exchanges.forEach(exchange => {
        // In a real implementation, this would check actual connection status
        status[exchange.name] = exchange.enabled && !!exchange.apiKey;
      });
      setConnectionStatus(status);
    };

    checkConnections();
    const interval = setInterval(checkConnections, 30000);
    return () => clearInterval(interval);
  }, [exchanges]);

  const toggleExchange = (exchangeName: string, enabled: boolean) => {
    tradingService.setExchangeEnabled(exchangeName, enabled);
    setExchanges(tradingService.getExchangeConfigs());
  };

  const updateExchangeKeys = (exchangeName: string, apiKey: string, secretKey: string) => {
    tradingService.updateExchangeKeys(exchangeName, apiKey, secretKey);
    setExchanges(tradingService.getExchangeConfigs());
  };

  const getActiveExchanges = () => {
    return exchanges.filter(exchange => exchange.enabled);
  };

  const getExchangeStatus = (exchangeName: string) => {
    const exchange = exchanges.find(ex => ex.name === exchangeName);
    const isConnected = connectionStatus[exchangeName];
    
    return {
      enabled: exchange?.enabled || false,
      connected: isConnected || false,
      hasKeys: !!(exchange?.apiKey && exchange?.secretKey),
      testnet: exchange?.testnet || false
    };
  };

  return {
    exchanges,
    connectionStatus,
    toggleExchange,
    updateExchangeKeys,
    getActiveExchanges,
    getExchangeStatus
  };
}
import { useState, useEffect } from 'react';
import { marketApi } from '@/lib/api';
import { calculateRSI, calculateMACD, calculateBollingerBands } from '@/lib/utils/indicators';

export interface CandlestickData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface IndicatorData {
  rsi: { time: number; value: number | null }[];
  macd: {
    line: { time: number; value: number | null }[];
    signal: { time: number; value: number | null }[];
    histogram: { time: number; value: number | null }[];
  };
  bollingerBands: {
    upper: { time: number; value: number | null }[];
    middle: { time: number; value: number | null }[];
    lower: { time: number; value: number | null }[];
  };
}

export function useChartData(symbol: string, timeframe: string) {
  const [candlestickData, setCandlestickData] = useState<CandlestickData[]>([]);
  const [indicatorData, setIndicatorData] = useState<IndicatorData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Fetch historical data from API
        const data = await marketApi.getHistoricalData(symbol, timeframe, 500);
        
        // Format candlestick data
        const formattedData = data.map(item => ({
          time: new Date(item.timestamp).getTime() / 1000,
          open: item.open,
          high: item.high,
          low: item.low,
          close: item.close,
          volume: item.volume
        }));
        
        setCandlestickData(formattedData);
        
        // Calculate indicators
        if (formattedData.length > 0) {
          const timestamps = formattedData.map(item => item.time);
          const closes = formattedData.map(item => item.close);
          
          // Calculate RSI (14-period)
          const rsiValues = calculateRSI(closes, 14);
          const rsiData = timestamps.map((time, i) => ({
            time,
            value: rsiValues[i]
          }));
          
          // Calculate MACD (12, 26, 9)
          const macdResult = calculateMACD(closes, 12, 26, 9);
          const macdLineData = timestamps.map((time, i) => ({
            time,
            value: macdResult.macdLine[i]
          }));
          const macdSignalData = timestamps.map((time, i) => ({
            time,
            value: macdResult.signalLine[i]
          }));
          const macdHistogramData = timestamps.map((time, i) => ({
            time,
            value: macdResult.histogram[i]
          }));
          
          // Calculate Bollinger Bands (20-period, 2 standard deviations)
          const bbResult = calculateBollingerBands(closes, 20, 2);
          const bbUpperData = timestamps.map((time, i) => ({
            time,
            value: bbResult.upper[i]
          }));
          const bbMiddleData = timestamps.map((time, i) => ({
            time,
            value: bbResult.middle[i]
          }));
          const bbLowerData = timestamps.map((time, i) => ({
            time,
            value: bbResult.lower[i]
          }));
          
          setIndicatorData({
            rsi: rsiData,
            macd: {
              line: macdLineData,
              signal: macdSignalData,
              histogram: macdHistogramData
            },
            bollingerBands: {
              upper: bbUpperData,
              middle: bbMiddleData,
              lower: bbLowerData
            }
          });
        }
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch chart data'));
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [symbol, timeframe]);

  return { candlestickData, indicatorData, isLoading, error };
}
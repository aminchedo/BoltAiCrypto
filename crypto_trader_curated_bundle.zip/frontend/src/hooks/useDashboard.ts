import { useState, useEffect, useCallback } from 'react';
import dashboardService, { DashboardState, DashboardConfig } from '@/services/dashboardService';

interface DashboardHookState extends DashboardState {
  healthStatus: Record<string, any>;
  performanceMetrics: Record<string, any>;
  isRefreshing: boolean;
}

export function useDashboard(config?: Partial<DashboardConfig>) {
  const [state, setState] = useState<DashboardHookState>({
    isInitialized: false,
    connectionStatus: {
      market: false,
      signals: false,
      trading: false,
      realtime: false
    },
    lastUpdate: 0,
    errors: [],
    healthStatus: {},
    performanceMetrics: {},
    isRefreshing: false
  });

  // Initialize dashboard on mount
  useEffect(() => {
    const initializeDashboard = async () => {
      try {
        await dashboardService.initialize(config);
      } catch (error) {
        console.error('Dashboard initialization failed:', error);
      }
    };

    initializeDashboard();

    // Set up event listeners
    const unsubscribeInitialized = dashboardService.onInitialized((dashboardState) => {
      setState(prev => ({
        ...prev,
        ...dashboardState,
        healthStatus: dashboardService.getHealthStatus(),
        performanceMetrics: dashboardService.getPerformanceMetrics()
      }));
    });

    const unsubscribeDataRefreshed = dashboardService.onDataRefreshed((timestamp) => {
      setState(prev => ({
        ...prev,
        lastUpdate: timestamp,
        isRefreshing: false,
        healthStatus: dashboardService.getHealthStatus(),
        performanceMetrics: dashboardService.getPerformanceMetrics()
      }));
    });

    const unsubscribeServiceError = dashboardService.onServiceError((error) => {
      setState(prev => ({
        ...prev,
        errors: [...prev.errors, `Service error: ${error.service} - ${error.error}`],
        healthStatus: dashboardService.getHealthStatus()
      }));
    });

    // Cleanup
    return () => {
      unsubscribeInitialized();
      unsubscribeDataRefreshed();
      unsubscribeServiceError();
    };
  }, []);

  // Manual refresh
  const refresh = useCallback(async () => {
    setState(prev => ({ ...prev, isRefreshing: true }));
    try {
      await dashboardService.refresh();
    } catch (error) {
      console.error('Manual refresh failed:', error);
      setState(prev => ({ ...prev, isRefreshing: false }));
    }
  }, []);

  // Update configuration
  const updateConfig = useCallback((newConfig: Partial<DashboardConfig>) => {
    dashboardService.updateConfig(newConfig);
  }, []);

  // Shutdown dashboard
  const shutdown = useCallback(async () => {
    await dashboardService.shutdown();
    setState({
      isInitialized: false,
      connectionStatus: {
        market: false,
        signals: false,
        trading: false,
        realtime: false
      },
      lastUpdate: 0,
      errors: [],
      healthStatus: {},
      performanceMetrics: {},
      isRefreshing: false
    });
  }, []);

  // Get connection summary
  const getConnectionSummary = useCallback(() => {
    const connected = Object.values(state.connectionStatus).filter(Boolean).length;
    const total = Object.keys(state.connectionStatus).length;
    return {
      connected,
      total,
      percentage: total > 0 ? (connected / total) * 100 : 0,
      status: connected === total ? 'all' : connected > 0 ? 'partial' : 'none'
    };
  }, [state.connectionStatus]);

  return {
    ...state,
    refresh,
    updateConfig,
    shutdown,
    connectionSummary: getConnectionSummary()
  };
}

// Hook for dashboard health monitoring
export function useDashboardHealth() {
  const [healthStatus, setHealthStatus] = useState<Record<string, any>>({});
  const [performanceMetrics, setPerformanceMetrics] = useState<Record<string, any>>({});

  useEffect(() => {
    const updateHealth = () => {
      setHealthStatus(dashboardService.getHealthStatus());
      setPerformanceMetrics(dashboardService.getPerformanceMetrics());
    };

    // Initial update
    updateHealth();

    // Update every 10 seconds
    const interval = setInterval(updateHealth, 10000);

    return () => clearInterval(interval);
  }, []);

  return {
    healthStatus,
    performanceMetrics,
    isHealthy: healthStatus.overall === 'healthy'
  };
}

// Hook for dashboard notifications
export function useDashboardNotifications() {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    type: 'info' | 'warning' | 'error' | 'success';
    message: string;
    timestamp: number;
  }>>([]);

  useEffect(() => {
    const handleInitialized = () => {
      setNotifications(prev => [...prev, {
        id: Date.now().toString(),
        type: 'success',
        message: 'Dashboard initialized successfully',
        timestamp: Date.now()
      }]);
    };

    const handleServiceError = (error: any) => {
      setNotifications(prev => [...prev, {
        id: Date.now().toString(),
        type: 'error',
        message: `Service error: ${error.service}`,
        timestamp: Date.now()
      }]);
    };

    const handleDataRefreshed = () => {
      setNotifications(prev => [...prev, {
        id: Date.now().toString(),
        type: 'info',
        message: 'Data refreshed',
        timestamp: Date.now()
      }]);
    };

    dashboardService.on('initialized', handleInitialized);
    dashboardService.on('serviceError', handleServiceError);
    dashboardService.on('dataRefreshed', handleDataRefreshed);

    return () => {
      dashboardService.off('initialized', handleInitialized);
      dashboardService.off('serviceError', handleServiceError);
      dashboardService.off('dataRefreshed', handleDataRefreshed);
    };
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  return {
    notifications,
    dismissNotification,
    clearAllNotifications
  };
}

export default useDashboard;
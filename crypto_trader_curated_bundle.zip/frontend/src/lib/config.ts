// Application configuration with TypeScript support

import { TimeFrame, OrderType, ChartTimeframe } from '@/types';

// Configuration Types
export interface ApiConfig {
  baseUrl: string;
  websocketUrl: string;
  timeout: number;
  retries?: number;
  version?: string;
}

export interface AuthConfig {
  tokenKey: string;
  refreshTokenKey: string;
  tokenExpiry: number;
  refreshThreshold?: number;
}

export interface TradingConfig {
  defaultLeverage: number;
  maxLeverage: number;
  defaultOrderSize: number;
  maxOrderSize: number;
  defaultStopLossPercentage: number;
  defaultTakeProfitPercentage: number;
  supportedOrderTypes: OrderType[];
  riskManagement: {
    maxDailyLoss: number;
    maxPositionSize: number;
    allowedRiskPerTrade: number;
  };
}

export interface ChartConfig {
  defaultTimeframe: ChartTimeframe;
  availableTimeframes: ChartTimeframe[];
  defaultIndicators: string[];
  tradingViewConfig: {
    autosize: boolean;
    symbol: string;
    interval: string;
    timezone: string;
    theme: 'light' | 'dark';
    style: string;
    locale: string;
    toolbar_bg: string;
    enable_publishing: boolean;
    hide_top_toolbar: boolean;
    hide_legend: boolean;
    save_image: boolean;
    studies: string[];
    container_id?: string;
    library_path?: string;
  };
}

export interface AIConfig {
  signalRefreshInterval: number;
  confidenceThreshold: number;
  algorithmWeights: {
    technicalAnalysis: number;
    smartMoneyConcepts: number;
    patternRecognition: number;
    sentimentAnalysis: number;
    whaleMovements: number;
    mlPredictions: number;
  };
  models: {
    primary: string;
    fallback: string;
    experimental?: string;
  };
}

export interface ThemeColors {
  background: string;
  text: string;
  primary: string;
  secondary: string;
  success: string;
  danger: string;
  warning: string;
  info?: string;
  muted?: string;
  border?: string;
}

export interface UIConfig {
  theme: {
    light: ThemeColors;
    dark: ThemeColors;
  };
  defaultDashboardLayout: {
    lg: Array<{ i: string; x: number; y: number; w: number; h: number; minW?: number; minH?: number }>;
    md: Array<{ i: string; x: number; y: number; w: number; h: number; minW?: number; minH?: number }>;
    sm: Array<{ i: string; x: number; y: number; w: number; h: number; minW?: number; minH?: number }>;
    xs?: Array<{ i: string; x: number; y: number; w: number; h: number; minW?: number; minH?: number }>;
  };
  animations: {
    enabled: boolean;
    duration: number;
  };
  notifications: {
    position: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
    autoClose: number;
    maxNotifications: number;
  };
}

export interface FeatureFlags {
  aiSignals: boolean;
  whaleTracking: boolean;
  portfolioAnalytics: boolean;
  advancedOrderTypes: boolean;
  smartMoneyAnalysis: boolean;
  patternRecognition: boolean;
  sentimentAnalysis: boolean;
  riskManagement: boolean;
  mobileApp: boolean;
  betaFeatures: boolean;
  socialTrading?: boolean;
  copyTrading?: boolean;
  paperTrading?: boolean;
}

export interface AppConfig {
  api: ApiConfig;
  auth: AuthConfig;
  trading: TradingConfig;
  chart: ChartConfig;
  ai: AIConfig;
  ui: UIConfig;
  features: FeatureFlags;
  environment: 'development' | 'production' | 'staging';
  version: string;
  buildNumber?: string;
}

// Main configuration object
export const config: AppConfig = {
  // Environment
  environment: (process.env.NODE_ENV as 'development' | 'production' | 'staging') || 'development',
  version: process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0',
  buildNumber: process.env.NEXT_PUBLIC_BUILD_NUMBER,

  // API endpoints
  api: {
    baseUrl: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api',
    websocketUrl: process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000',
    timeout: parseInt(process.env.NEXT_PUBLIC_API_TIMEOUT || '30000'),
    retries: 3,
    version: 'v1'
  },
  
  // Authentication
  auth: {
    tokenKey: 'aismart_token',
    refreshTokenKey: 'aismart_refresh_token',
    tokenExpiry: 60 * 60 * 1000, // 1 hour
    refreshThreshold: 5 * 60 * 1000 // 5 minutes before expiry
  },
  
  // Trading settings
  trading: {
    defaultLeverage: 1,
    maxLeverage: parseInt(process.env.NEXT_PUBLIC_MAX_LEVERAGE || '10'),
    defaultOrderSize: 100, // USD
    maxOrderSize: 10000, // USD
    defaultStopLossPercentage: 5,
    defaultTakeProfitPercentage: 10,
    supportedOrderTypes: [
      OrderType.MARKET,
      OrderType.LIMIT,
      OrderType.STOP,
      OrderType.STOP_LIMIT,
      OrderType.TAKE_PROFIT,
      OrderType.OCO,
    ],
    riskManagement: {
      maxDailyLoss: 1000, // USD
      maxPositionSize: 5000, // USD
      allowedRiskPerTrade: 2 // Percentage
    }
  },
  
  // Chart settings
  chart: {
    defaultTimeframe: '1h' as ChartTimeframe,
    availableTimeframes: ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M'] as ChartTimeframe[],
    defaultIndicators: ['RSI', 'MACD', 'BB'],
    tradingViewConfig: {
      autosize: true,
      symbol: 'BINANCE:BTCUSDT',
      interval: '60',
      timezone: 'Etc/UTC',
      theme: 'dark',
      style: '1',
      locale: 'en',
      toolbar_bg: '#1e293b',
      enable_publishing: false,
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: true,
      studies: [
        'RSI@tv-basicstudies',
        'MACD@tv-basicstudies',
        'BB@tv-basicstudies',
      ],
      container_id: 'tradingview_widget',
      library_path: '/static/charting_library/'
    },
  },
  
  // AI settings
  ai: {
    signalRefreshInterval: 5 * 60 * 1000, // 5 minutes
    confidenceThreshold: parseInt(process.env.NEXT_PUBLIC_AI_CONFIDENCE_THRESHOLD || '65'),
    algorithmWeights: {
      technicalAnalysis: 0.40,
      smartMoneyConcepts: 0.25,
      patternRecognition: 0.20,
      sentimentAnalysis: 0.07,
      whaleMovements: 0.03,
      mlPredictions: 0.05,
    },
    models: {
      primary: 'neural-alpha-v2',
      fallback: 'quantum-beta-v1',
      experimental: 'gpt-trader-v1'
    }
  },
  
  // UI settings
  ui: {
    theme: {
      light: {
        background: '#ffffff',
        text: '#1e293b',
        primary: '#0ea5e9',
        secondary: '#64748b',
        success: '#22c55e',
        danger: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6',
        muted: '#94a3b8',
        border: '#e2e8f0'
      },
      dark: {
        background: '#0f172a',
        text: '#f8fafc',
        primary: '#0ea5e9',
        secondary: '#64748b',
        success: '#22c55e',
        danger: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6',
        muted: '#475569',
        border: '#334155'
      },
    },
    defaultDashboardLayout: {
      lg: [
        { i: 'market-overview', x: 0, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
        { i: 'ai-signals', x: 3, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
        { i: 'portfolio', x: 6, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
        { i: 'quick-trade', x: 9, y: 0, w: 3, h: 2, minW: 2, minH: 2 },
        { i: 'trading-chart', x: 0, y: 2, w: 6, h: 4, minW: 4, minH: 3 },
        { i: 'order-book', x: 6, y: 2, w: 3, h: 4, minW: 2, minH: 3 },
        { i: 'whale-tracker', x: 9, y: 2, w: 3, h: 2, minW: 2, minH: 2 },
        { i: 'technical-analysis', x: 9, y: 4, w: 3, h: 2, minW: 2, minH: 2 },
        { i: 'news', x: 0, y: 6, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'risk-manager', x: 4, y: 6, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'performance', x: 8, y: 6, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'settings', x: 0, y: 8, w: 12, h: 1, minW: 12, minH: 1 },
      ],
      md: [
        { i: 'market-overview', x: 0, y: 0, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'ai-signals', x: 4, y: 0, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'portfolio', x: 0, y: 2, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'quick-trade', x: 4, y: 2, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'trading-chart', x: 0, y: 4, w: 8, h: 4, minW: 6, minH: 3 },
        { i: 'order-book', x: 0, y: 8, w: 4, h: 3, minW: 3, minH: 2 },
        { i: 'whale-tracker', x: 4, y: 8, w: 4, h: 3, minW: 3, minH: 2 },
        { i: 'technical-analysis', x: 0, y: 11, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'news', x: 4, y: 11, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'risk-manager', x: 0, y: 13, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'performance', x: 4, y: 13, w: 4, h: 2, minW: 3, minH: 2 },
        { i: 'settings', x: 0, y: 15, w: 8, h: 1, minW: 8, minH: 1 },
      ],
      sm: [
        { i: 'market-overview', x: 0, y: 0, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'ai-signals', x: 0, y: 2, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'portfolio', x: 0, y: 4, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'quick-trade', x: 0, y: 6, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'trading-chart', x: 0, y: 8, w: 2, h: 4, minW: 2, minH: 3 },
        { i: 'order-book', x: 0, y: 12, w: 2, h: 3, minW: 2, minH: 2 },
        { i: 'whale-tracker', x: 0, y: 15, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'technical-analysis', x: 0, y: 17, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'news', x: 0, y: 19, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'risk-manager', x: 0, y: 21, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'performance', x: 0, y: 23, w: 2, h: 2, minW: 2, minH: 2 },
        { i: 'settings', x: 0, y: 25, w: 2, h: 1, minW: 2, minH: 1 },
      ],
    },
    animations: {
      enabled: true,
      duration: 300
    },
    notifications: {
      position: 'top-right',
      autoClose: 5000,
      maxNotifications: 5
    }
  },
  
  // Feature flags
  features: {
    aiSignals: process.env.NEXT_PUBLIC_FEATURE_AI_SIGNALS !== 'false',
    whaleTracking: process.env.NEXT_PUBLIC_FEATURE_WHALE_TRACKING !== 'false',
    portfolioAnalytics: process.env.NEXT_PUBLIC_FEATURE_PORTFOLIO_ANALYTICS !== 'false',
    advancedOrderTypes: process.env.NEXT_PUBLIC_FEATURE_ADVANCED_ORDERS !== 'false',
    smartMoneyAnalysis: process.env.NEXT_PUBLIC_FEATURE_SMART_MONEY !== 'false',
    patternRecognition: process.env.NEXT_PUBLIC_FEATURE_PATTERN_RECOGNITION !== 'false',
    sentimentAnalysis: process.env.NEXT_PUBLIC_FEATURE_SENTIMENT_ANALYSIS !== 'false',
    riskManagement: process.env.NEXT_PUBLIC_FEATURE_RISK_MANAGEMENT !== 'false',
    mobileApp: process.env.NEXT_PUBLIC_FEATURE_MOBILE_APP === 'true',
    betaFeatures: process.env.NODE_ENV === 'development',
    socialTrading: process.env.NEXT_PUBLIC_FEATURE_SOCIAL_TRADING === 'true',
    copyTrading: process.env.NEXT_PUBLIC_FEATURE_COPY_TRADING === 'true',
    paperTrading: process.env.NEXT_PUBLIC_FEATURE_PAPER_TRADING !== 'false'
  },
};

// Helper functions
export const isFeatureEnabled = (feature: keyof FeatureFlags): boolean => {
  return config.features[feature] || false;
};

export const getApiUrl = (endpoint: string): string => {
  return `${config.api.baseUrl}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
};

export const getWebSocketUrl = (channel?: string): string => {
  return channel 
    ? `${config.api.websocketUrl}/${channel}` 
    : config.api.websocketUrl;
};

export const isDevelopment = (): boolean => {
  return config.environment === 'development';
};

export const isProduction = (): boolean => {
  return config.environment === 'production';
};

// Theme helpers
export const getThemeColors = (theme: 'light' | 'dark'): ThemeColors => {
  return config.ui.theme[theme];
};

// Trading helpers
export const isOrderTypeSupported = (orderType: OrderType): boolean => {
  return config.trading.supportedOrderTypes.includes(orderType);
};

export const getMaxOrderSize = (): number => {
  return config.trading.maxOrderSize;
};

export const getDefaultOrderSize = (): number => {
  return config.trading.defaultOrderSize;
};

// AI helpers
export const shouldShowSignal = (confidence: number): boolean => {
  return confidence >= config.ai.confidenceThreshold;
};

export const getSignalRefreshInterval = (): number => {
  return config.ai.signalRefreshInterval;
};

// Export configuration object as default
export default config;
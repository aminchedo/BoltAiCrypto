import jwt from 'jsonwebtoken';
import { User, AuthTokens, UserSession } from './types';

export class JWTManager {
  private readonly accessTokenSecret: string;
  private readonly refreshTokenSecret: string;
  private readonly issuer: string;
  private readonly audience: string;

  constructor() {
    this.accessTokenSecret = process.env.JWT_ACCESS_SECRET || 'access-secret-change-in-production';
    this.refreshTokenSecret = process.env.JWT_REFRESH_SECRET || 'refresh-secret-change-in-production';
    this.issuer = process.env.JWT_ISSUER || 'aismart-trader';
    this.audience = process.env.JWT_AUDIENCE || 'aismart-trader-users';
  }

  /**
   * Generate access and refresh tokens for a user
   */
  generateTokens(user: User, sessionId: string, deviceFingerprint: string): AuthTokens {
    const accessTokenPayload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      permissions: user.permissions,
      sessionId,
      deviceFingerprint,
      type: 'access'
    };

    const refreshTokenPayload = {
      sub: user.id,
      sessionId,
      deviceFingerprint,
      type: 'refresh'
    };

    const accessToken = jwt.sign(accessTokenPayload, this.accessTokenSecret, {
      expiresIn: '15m',
      issuer: this.issuer,
      audience: this.audience,
      algorithm: 'HS256'
    });

    const refreshToken = jwt.sign(refreshTokenPayload, this.refreshTokenSecret, {
      expiresIn: '7d',
      issuer: this.issuer,
      audience: this.audience,
      algorithm: 'HS256'
    });

    return {
      accessToken,
      refreshToken,
      expiresIn: 15 * 60, // 15 minutes in seconds
      tokenType: 'Bearer'
    };
  }

  /**
   * Verify and decode access token
   */
  verifyAccessToken(token: string): any {
    try {
      return jwt.verify(token, this.accessTokenSecret, {
        issuer: this.issuer,
        audience: this.audience,
        algorithms: ['HS256']
      });
    } catch (error) {
      throw new Error('Invalid access token');
    }
  }

  /**
   * Verify and decode refresh token
   */
  verifyRefreshToken(token: string): any {
    try {
      return jwt.verify(token, this.refreshTokenSecret, {
        issuer: this.issuer,
        audience: this.audience,
        algorithms: ['HS256']
      });
    } catch (error) {
      throw new Error('Invalid refresh token');
    }
  }

  /**
   * Extract token from Authorization header
   */
  extractTokenFromHeader(authHeader: string | undefined): string | null {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }
    return authHeader.substring(7);
  }

  /**
   * Generate a secure random token for password reset, email verification, etc.
   */
  generateSecureToken(length: number = 32): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  /**
   * Check if token is expired
   */
  isTokenExpired(token: string): boolean {
    try {
      const decoded = jwt.decode(token) as any;
      if (!decoded || !decoded.exp) {
        return true;
      }
      return Date.now() >= decoded.exp * 1000;
    } catch {
      return true;
    }
  }

  /**
   * Get token expiration time
   */
  getTokenExpiration(token: string): Date | null {
    try {
      const decoded = jwt.decode(token) as any;
      if (!decoded || !decoded.exp) {
        return null;
      }
      return new Date(decoded.exp * 1000);
    } catch {
      return null;
    }
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshAccessToken(refreshToken: string, user: User, sessionId: string): Promise<AuthTokens> {
    const decoded = this.verifyRefreshToken(refreshToken);
    
    if (decoded.sub !== user.id || decoded.sessionId !== sessionId) {
      throw new Error('Invalid refresh token');
    }

    return this.generateTokens(user, sessionId, decoded.deviceFingerprint);
  }

  /**
   * Blacklist a token (would typically store in Redis or database)
   */
  async blacklistToken(token: string): Promise<void> {
    // In a real implementation, you would store the token in a blacklist
    // This could be Redis with expiration set to the token's remaining lifetime
    console.log(`Token blacklisted: ${token.substring(0, 20)}...`);
  }

  /**
   * Check if token is blacklisted
   */
  async isTokenBlacklisted(token: string): Promise<boolean> {
    // In a real implementation, check against your blacklist store
    return false;
  }
}
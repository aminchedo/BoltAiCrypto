import * as crypto from 'crypto';
import * as bcrypt from 'bcrypt';

export interface EncryptionResult {
  encrypted: string;
  iv: string;
  tag: string;
}

export interface DecryptionParams {
  encrypted: string;
  iv: string;
  tag: string;
}

export class EncryptionManager {
  private readonly algorithm = 'aes-256-gcm';
  private readonly keyLength = 32; // 256 bits
  private readonly ivLength = 16; // 128 bits
  private readonly tagLength = 16; // 128 bits
  private readonly saltRounds = 12;

  private masterKey: Buffer;

  constructor() {
    // In production, this should come from environment variables or HSM
    const masterKeyHex = process.env.MASTER_ENCRYPTION_KEY || this.generateMasterKey();
    this.masterKey = Buffer.from(masterKeyHex, 'hex');
  }

  /**
   * Generate a new master encryption key
   */
  private generateMasterKey(): string {
    const key = crypto.randomBytes(this.keyLength);
    console.warn('Generated new master key. Store this securely:', key.toString('hex'));
    return key.toString('hex');
  }

  /**
   * Derive encryption key from master key and context
   */
  private deriveKey(context: string): Buffer {
    return crypto.pbkdf2Sync(this.masterKey, context, 100000, this.keyLength, 'sha256');
  }

  /**
   * Encrypt sensitive data using AES-256-GCM
   */
  encrypt(plaintext: string, context: string = 'default'): EncryptionResult {
    try {
      const key = this.deriveKey(context);
      const iv = crypto.randomBytes(this.ivLength);
      const cipher = crypto.createCipherGCM(this.algorithm, key, iv);
      
      let encrypted = cipher.update(plaintext, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      
      const tag = cipher.getAuthTag();

      return {
        encrypted,
        iv: iv.toString('hex'),
        tag: tag.toString('hex')
      };
    } catch (error) {
      throw new Error(`Encryption failed: ${error}`);
    }
  }

  /**
   * Decrypt data encrypted with AES-256-GCM
   */
  decrypt(params: DecryptionParams, context: string = 'default'): string {
    try {
      const key = this.deriveKey(context);
      const iv = Buffer.from(params.iv, 'hex');
      const tag = Buffer.from(params.tag, 'hex');
      
      const decipher = crypto.createDecipherGCM(this.algorithm, key, iv);
      decipher.setAuthTag(tag);
      
      let decrypted = decipher.update(params.encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      throw new Error(`Decryption failed: ${error}`);
    }
  }

  /**
   * Hash password using bcrypt
   */
  async hashPassword(password: string): Promise<string> {
    try {
      return await bcrypt.hash(password, this.saltRounds);
    } catch (error) {
      throw new Error(`Password hashing failed: ${error}`);
    }
  }

  /**
   * Verify password against hash
   */
  async verifyPassword(password: string, hash: string): Promise<boolean> {
    try {
      return await bcrypt.compare(password, hash);
    } catch (error) {
      throw new Error(`Password verification failed: ${error}`);
    }
  }

  /**
   * Generate cryptographically secure random string
   */
  generateSecureRandom(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * Generate secure API key
   */
  generateApiKey(): string {
    const prefix = 'ast'; // AiSmart Trader
    const randomPart = crypto.randomBytes(24).toString('base64url');
    return `${prefix}_${randomPart}`;
  }

  /**
   * Hash API key for storage
   */
  async hashApiKey(apiKey: string): Promise<string> {
    return await this.hashPassword(apiKey);
  }

  /**
   * Verify API key against hash
   */
  async verifyApiKey(apiKey: string, hash: string): Promise<boolean> {
    return await this.verifyPassword(apiKey, hash);
  }

  /**
   * Encrypt exchange API credentials
   */
  encryptExchangeCredentials(credentials: {
    apiKey: string;
    apiSecret: string;
    passphrase?: string;
  }): {
    encryptedApiKey: EncryptionResult;
    encryptedApiSecret: EncryptionResult;
    encryptedPassphrase?: EncryptionResult;
  } {
    const result: any = {
      encryptedApiKey: this.encrypt(credentials.apiKey, 'exchange_api_key'),
      encryptedApiSecret: this.encrypt(credentials.apiSecret, 'exchange_api_secret')
    };

    if (credentials.passphrase) {
      result.encryptedPassphrase = this.encrypt(credentials.passphrase, 'exchange_passphrase');
    }

    return result;
  }

  /**
   * Decrypt exchange API credentials
   */
  decryptExchangeCredentials(encryptedCredentials: {
    encryptedApiKey: DecryptionParams;
    encryptedApiSecret: DecryptionParams;
    encryptedPassphrase?: DecryptionParams;
  }): {
    apiKey: string;
    apiSecret: string;
    passphrase?: string;
  } {
    const result: any = {
      apiKey: this.decrypt(encryptedCredentials.encryptedApiKey, 'exchange_api_key'),
      apiSecret: this.decrypt(encryptedCredentials.encryptedApiSecret, 'exchange_api_secret')
    };

    if (encryptedCredentials.encryptedPassphrase) {
      result.passphrase = this.decrypt(encryptedCredentials.encryptedPassphrase, 'exchange_passphrase');
    }

    return result;
  }

  /**
   * Create HMAC signature for API requests
   */
  createHmacSignature(data: string, secret: string, algorithm: string = 'sha256'): string {
    return crypto.createHmac(algorithm, secret).update(data).digest('hex');
  }

  /**
   * Verify HMAC signature
   */
  verifyHmacSignature(data: string, signature: string, secret: string, algorithm: string = 'sha256'): boolean {
    const expectedSignature = this.createHmacSignature(data, secret, algorithm);
    return crypto.timingSafeEqual(
      Buffer.from(signature, 'hex'),
      Buffer.from(expectedSignature, 'hex')
    );
  }

  /**
   * Generate nonce for API requests
   */
  generateNonce(): string {
    return Date.now().toString() + crypto.randomBytes(8).toString('hex');
  }

  /**
   * Encrypt sensitive user data for storage
   */
  encryptUserData(data: any, userId: string): EncryptionResult {
    const jsonData = JSON.stringify(data);
    return this.encrypt(jsonData, `user_data_${userId}`);
  }

  /**
   * Decrypt sensitive user data
   */
  decryptUserData(encryptedData: DecryptionParams, userId: string): any {
    const jsonData = this.decrypt(encryptedData, `user_data_${userId}`);
    return JSON.parse(jsonData);
  }

  /**
   * Create secure hash for data integrity
   */
  createIntegrityHash(data: string): string {
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  /**
   * Verify data integrity
   */
  verifyIntegrity(data: string, hash: string): boolean {
    const expectedHash = this.createIntegrityHash(data);
    return crypto.timingSafeEqual(
      Buffer.from(hash, 'hex'),
      Buffer.from(expectedHash, 'hex')
    );
  }

  /**
   * Generate secure session ID
   */
  generateSessionId(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Generate secure device ID
   */
  generateDeviceId(): string {
    return crypto.randomBytes(16).toString('hex');
  }

  /**
   * Encrypt audit log entries
   */
  encryptAuditLog(logEntry: any): EncryptionResult {
    const jsonData = JSON.stringify(logEntry);
    return this.encrypt(jsonData, 'audit_log');
  }

  /**
   * Decrypt audit log entries
   */
  decryptAuditLog(encryptedLog: DecryptionParams): any {
    const jsonData = this.decrypt(encryptedLog, 'audit_log');
    return JSON.parse(jsonData);
  }

  /**
   * Key rotation - generate new master key
   */
  rotateMasterKey(): string {
    const newKey = crypto.randomBytes(this.keyLength);
    console.warn('New master key generated. Update environment variable:', newKey.toString('hex'));
    return newKey.toString('hex');
  }

  /**
   * Secure memory cleanup (best effort)
   */
  secureCleanup(sensitiveData: string): void {
    // In Node.js, we can't truly zero out memory, but we can overwrite
    if (typeof sensitiveData === 'string') {
      // Overwrite the string content (limited effectiveness in JavaScript)
      for (let i = 0; i < sensitiveData.length; i++) {
        sensitiveData = sensitiveData.substring(0, i) + '0' + sensitiveData.substring(i + 1);
      }
    }
  }
}

// Global encryption manager instance
export const encryptionManager = new EncryptionManager();
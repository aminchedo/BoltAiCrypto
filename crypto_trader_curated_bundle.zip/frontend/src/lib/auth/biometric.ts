import { BiometricAuth } from './types';

export interface WebAuthnCredential {
  id: string;
  publicKey: string;
  counter: number;
  deviceType: string;
  backedUp: boolean;
  transports?: AuthenticatorTransport[];
}

export interface BiometricRegistrationOptions {
  challenge: string;
  rp: {
    name: string;
    id: string;
  };
  user: {
    id: string;
    name: string;
    displayName: string;
  };
  pubKeyCredParams: PublicKeyCredentialParameters[];
  authenticatorSelection: AuthenticatorSelectionCriteria;
  timeout: number;
  attestation: AttestationConveyancePreference;
}

export interface BiometricAuthenticationOptions {
  challenge: string;
  timeout: number;
  rpId: string;
  allowCredentials: PublicKeyCredentialDescriptor[];
  userVerification: UserVerificationRequirement;
}

export class BiometricAuthManager {
  private readonly rpName: string;
  private readonly rpId: string;
  private readonly origin: string;

  constructor() {
    this.rpName = 'AiSmart Trader';
    this.rpId = process.env.NEXT_PUBLIC_RP_ID || 'localhost';
    this.origin = process.env.NEXT_PUBLIC_ORIGIN || 'http://localhost:3000';
  }

  /**
   * Check if WebAuthn is supported in the current browser
   */
  isWebAuthnSupported(): boolean {
    return typeof window !== 'undefined' && 
           'navigator' in window && 
           'credentials' in navigator &&
           'create' in navigator.credentials &&
           'get' in navigator.credentials;
  }

  /**
   * Check if platform authenticator (biometric) is available
   */
  async isPlatformAuthenticatorAvailable(): Promise<boolean> {
    if (!this.isWebAuthnSupported()) {
      return false;
    }

    try {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch {
      return false;
    }
  }

  /**
   * Generate registration options for biometric setup
   */
  generateRegistrationOptions(userId: string, userEmail: string, userName: string): BiometricRegistrationOptions {
    const challenge = this.generateChallenge();
    
    return {
      challenge,
      rp: {
        name: this.rpName,
        id: this.rpId
      },
      user: {
        id: userId,
        name: userEmail,
        displayName: userName
      },
      pubKeyCredParams: [
        { alg: -7, type: 'public-key' }, // ES256
        { alg: -257, type: 'public-key' } // RS256
      ],
      authenticatorSelection: {
        authenticatorAttachment: 'platform',
        userVerification: 'required',
        residentKey: 'preferred'
      },
      timeout: 60000,
      attestation: 'direct'
    };
  }

  /**
   * Generate authentication options for biometric login
   */
  generateAuthenticationOptions(allowedCredentials: WebAuthnCredential[]): BiometricAuthenticationOptions {
    const challenge = this.generateChallenge();
    
    return {
      challenge,
      timeout: 60000,
      rpId: this.rpId,
      allowCredentials: allowedCredentials.map(cred => ({
        id: this.base64ToArrayBuffer(cred.id),
        type: 'public-key' as const,
        transports: cred.transports || ['internal']
      })),
      userVerification: 'required'
    };
  }

  /**
   * Register a new biometric credential
   */
  async registerBiometric(options: BiometricRegistrationOptions): Promise<{
    success: boolean;
    credential?: {
      id: string;
      publicKey: string;
      deviceType: string;
    };
    error?: string;
  }> {
    if (!this.isWebAuthnSupported()) {
      return { success: false, error: 'WebAuthn not supported' };
    }

    try {
      const publicKeyCredentialCreationOptions: CredentialCreationOptions = {
        publicKey: {
          ...options,
          challenge: this.base64ToArrayBuffer(options.challenge),
          user: {
            ...options.user,
            id: this.stringToArrayBuffer(options.user.id)
          }
        }
      };

      const credential = await navigator.credentials.create(publicKeyCredentialCreationOptions) as PublicKeyCredential;
      
      if (!credential) {
        return { success: false, error: 'Failed to create credential' };
      }

      const response = credential.response as AuthenticatorAttestationResponse;
      
      return {
        success: true,
        credential: {
          id: this.arrayBufferToBase64(credential.rawId),
          publicKey: this.arrayBufferToBase64(response.getPublicKey()!),
          deviceType: this.getDeviceType()
        }
      };
    } catch (error: any) {
      return { 
        success: false, 
        error: error.message || 'Biometric registration failed' 
      };
    }
  }

  /**
   * Authenticate using biometric credential
   */
  async authenticateBiometric(options: BiometricAuthenticationOptions): Promise<{
    success: boolean;
    credentialId?: string;
    signature?: string;
    error?: string;
  }> {
    if (!this.isWebAuthnSupported()) {
      return { success: false, error: 'WebAuthn not supported' };
    }

    try {
      const publicKeyCredentialRequestOptions: CredentialRequestOptions = {
        publicKey: {
          ...options,
          challenge: this.base64ToArrayBuffer(options.challenge)
        }
      };

      const credential = await navigator.credentials.get(publicKeyCredentialRequestOptions) as PublicKeyCredential;
      
      if (!credential) {
        return { success: false, error: 'Authentication failed' };
      }

      const response = credential.response as AuthenticatorAssertionResponse;
      
      return {
        success: true,
        credentialId: this.arrayBufferToBase64(credential.rawId),
        signature: this.arrayBufferToBase64(response.signature)
      };
    } catch (error: any) {
      return { 
        success: false, 
        error: error.message || 'Biometric authentication failed' 
      };
    }
  }

  /**
   * Verify biometric authentication signature
   */
  async verifyBiometricSignature(
    credentialId: string,
    signature: string,
    challenge: string,
    publicKey: string
  ): Promise<boolean> {
    try {
      // In a real implementation, you would verify the signature using the stored public key
      // This involves cryptographic verification of the signature against the challenge
      // For now, we'll return true as a placeholder
      console.log('Verifying biometric signature:', { credentialId, signature, challenge });
      return true;
    } catch (error) {
      console.error('Biometric verification failed:', error);
      return false;
    }
  }

  /**
   * Generate a cryptographically secure challenge
   */
  private generateChallenge(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return this.arrayBufferToBase64(array.buffer);
  }

  /**
   * Convert ArrayBuffer to base64 string
   */
  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  /**
   * Convert base64 string to ArrayBuffer
   */
  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  /**
   * Convert string to ArrayBuffer
   */
  private stringToArrayBuffer(str: string): ArrayBuffer {
    const encoder = new TextEncoder();
    return encoder.encode(str).buffer;
  }

  /**
   * Get device type for the current platform
   */
  private getDeviceType(): string {
    if (typeof window === 'undefined') return 'unknown';
    
    const userAgent = navigator.userAgent.toLowerCase();
    
    if (/mobile|android|iphone|ipad|phone/i.test(userAgent)) {
      return 'mobile';
    } else if (/tablet|ipad/i.test(userAgent)) {
      return 'tablet';
    } else {
      return 'desktop';
    }
  }

  /**
   * Get supported authenticator types
   */
  async getSupportedAuthenticators(): Promise<{
    platform: boolean;
    crossPlatform: boolean;
    userVerifying: boolean;
  }> {
    if (!this.isWebAuthnSupported()) {
      return { platform: false, crossPlatform: false, userVerifying: false };
    }

    try {
      const userVerifying = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      
      return {
        platform: userVerifying,
        crossPlatform: true, // Assume cross-platform is available if WebAuthn is supported
        userVerifying
      };
    } catch {
      return { platform: false, crossPlatform: false, userVerifying: false };
    }
  }

  /**
   * Clean up expired or unused credentials
   */
  cleanupCredentials(credentials: BiometricAuth[], maxAge: number = 90): BiometricAuth[] {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - maxAge);
    
    return credentials.filter(cred => 
      cred.lastUsed && cred.lastUsed > cutoffDate
    );
  }
}
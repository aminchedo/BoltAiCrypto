export interface DeviceFingerprint {
  id: string;
  userAgent: string;
  screen: {
    width: number;
    height: number;
    colorDepth: number;
    pixelRatio: number;
  };
  timezone: string;
  language: string;
  platform: string;
  cookieEnabled: boolean;
  doNotTrack: boolean;
  canvas: string;
  webgl: string;
  fonts: string[];
  plugins: string[];
  touchSupport: boolean;
  hardwareConcurrency: number;
  deviceMemory?: number;
  connection?: {
    effectiveType: string;
    downlink: number;
    rtt: number;
  };
  battery?: {
    charging: boolean;
    level: number;
  };
  geolocation?: {
    latitude: number;
    longitude: number;
    accuracy: number;
  };
}

export class DeviceFingerprintManager {
  private fingerprint: DeviceFingerprint | null = null;

  /**
   * Generate a comprehensive device fingerprint
   */
  async generateFingerprint(): Promise<DeviceFingerprint> {
    if (typeof window === 'undefined') {
      throw new Error('Device fingerprinting only available in browser environment');
    }

    const fingerprint: DeviceFingerprint = {
      id: '',
      userAgent: navigator.userAgent,
      screen: {
        width: screen.width,
        height: screen.height,
        colorDepth: screen.colorDepth,
        pixelRatio: window.devicePixelRatio || 1
      },
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      language: navigator.language,
      platform: navigator.platform,
      cookieEnabled: navigator.cookieEnabled,
      doNotTrack: navigator.doNotTrack === '1',
      canvas: await this.getCanvasFingerprint(),
      webgl: await this.getWebGLFingerprint(),
      fonts: await this.getAvailableFonts(),
      plugins: this.getPlugins(),
      touchSupport: 'ontouchstart' in window,
      hardwareConcurrency: navigator.hardwareConcurrency || 0,
      deviceMemory: (navigator as any).deviceMemory,
      connection: this.getConnectionInfo(),
      battery: await this.getBatteryInfo(),
      geolocation: await this.getGeolocationInfo()
    };

    // Generate unique ID based on fingerprint components
    fingerprint.id = await this.generateFingerprintId(fingerprint);
    
    this.fingerprint = fingerprint;
    return fingerprint;
  }

  /**
   * Get cached fingerprint or generate new one
   */
  async getFingerprint(): Promise<DeviceFingerprint> {
    if (!this.fingerprint) {
      return await this.generateFingerprint();
    }
    return this.fingerprint;
  }

  /**
   * Generate canvas fingerprint
   */
  private async getCanvasFingerprint(): Promise<string> {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) return '';

      canvas.width = 200;
      canvas.height = 50;

      // Draw text with various styles
      ctx.textBaseline = 'top';
      ctx.font = '14px Arial';
      ctx.fillStyle = '#f60';
      ctx.fillRect(125, 1, 62, 20);
      ctx.fillStyle = '#069';
      ctx.fillText('AiSmart Trader 🚀', 2, 15);
      ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
      ctx.fillText('Device Fingerprint', 4, 35);

      // Draw some shapes
      ctx.globalCompositeOperation = 'multiply';
      ctx.fillStyle = 'rgb(255,0,255)';
      ctx.beginPath();
      ctx.arc(50, 50, 50, 0, Math.PI * 2, true);
      ctx.closePath();
      ctx.fill();

      return canvas.toDataURL();
    } catch {
      return '';
    }
  }

  /**
   * Generate WebGL fingerprint
   */
  private async getWebGLFingerprint(): Promise<string> {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      
      if (!gl) return '';

      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      const vendor = debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : '';
      const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : '';
      
      return `${vendor}~${renderer}`;
    } catch {
      return '';
    }
  }

  /**
   * Detect available fonts
   */
  private async getAvailableFonts(): Promise<string[]> {
    const testFonts = [
      'Arial', 'Arial Black', 'Arial Narrow', 'Arial Rounded MT Bold',
      'Calibri', 'Cambria', 'Candara', 'Century Gothic', 'Comic Sans MS',
      'Consolas', 'Courier', 'Courier New', 'Georgia', 'Helvetica',
      'Impact', 'Lucida Console', 'Lucida Sans Unicode', 'Microsoft Sans Serif',
      'Palatino', 'Tahoma', 'Times', 'Times New Roman', 'Trebuchet MS',
      'Verdana', 'Monaco', 'Menlo', 'Ubuntu', 'Roboto'
    ];

    const availableFonts: string[] = [];
    const testString = 'mmmmmmmmmmlli';
    const testSize = '72px';
    const baseFonts = ['monospace', 'sans-serif', 'serif'];

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    if (!context) return [];

    // Get baseline measurements
    const baseWidths: { [key: string]: number } = {};
    for (const baseFont of baseFonts) {
      context.font = `${testSize} ${baseFont}`;
      baseWidths[baseFont] = context.measureText(testString).width;
    }

    // Test each font
    for (const font of testFonts) {
      let detected = false;
      for (const baseFont of baseFonts) {
        context.font = `${testSize} ${font}, ${baseFont}`;
        const width = context.measureText(testString).width;
        if (width !== baseWidths[baseFont]) {
          detected = true;
          break;
        }
      }
      if (detected) {
        availableFonts.push(font);
      }
    }

    return availableFonts;
  }

  /**
   * Get browser plugins
   */
  private getPlugins(): string[] {
    const plugins: string[] = [];
    
    if (navigator.plugins) {
      for (let i = 0; i < navigator.plugins.length; i++) {
        const plugin = navigator.plugins[i];
        plugins.push(plugin.name);
      }
    }

    return plugins.sort();
  }

  /**
   * Get connection information
   */
  private getConnectionInfo(): DeviceFingerprint['connection'] {
    const connection = (navigator as any).connection || 
                     (navigator as any).mozConnection || 
                     (navigator as any).webkitConnection;

    if (!connection) return undefined;

    return {
      effectiveType: connection.effectiveType || '',
      downlink: connection.downlink || 0,
      rtt: connection.rtt || 0
    };
  }

  /**
   * Get battery information
   */
  private async getBatteryInfo(): Promise<DeviceFingerprint['battery']> {
    try {
      const battery = await (navigator as any).getBattery?.();
      if (!battery) return undefined;

      return {
        charging: battery.charging,
        level: Math.round(battery.level * 100) / 100
      };
    } catch {
      return undefined;
    }
  }

  /**
   * Get geolocation information (with user permission)
   */
  private async getGeolocationInfo(): Promise<DeviceFingerprint['geolocation']> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(undefined);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: Math.round(position.coords.latitude * 100) / 100,
            longitude: Math.round(position.coords.longitude * 100) / 100,
            accuracy: position.coords.accuracy
          });
        },
        () => resolve(undefined),
        { timeout: 5000, enableHighAccuracy: false }
      );
    });
  }

  /**
   * Generate unique fingerprint ID
   */
  private async generateFingerprintId(fingerprint: DeviceFingerprint): Promise<string> {
    const components = [
      fingerprint.userAgent,
      `${fingerprint.screen.width}x${fingerprint.screen.height}x${fingerprint.screen.colorDepth}`,
      fingerprint.timezone,
      fingerprint.language,
      fingerprint.platform,
      fingerprint.canvas,
      fingerprint.webgl,
      fingerprint.fonts.join(','),
      fingerprint.plugins.join(','),
      fingerprint.touchSupport.toString(),
      fingerprint.hardwareConcurrency.toString(),
      fingerprint.deviceMemory?.toString() || '',
      fingerprint.connection ? `${fingerprint.connection.effectiveType}-${fingerprint.connection.downlink}` : ''
    ];

    const data = components.join('|');
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    return hashHex;
  }

  /**
   * Compare two fingerprints for similarity
   */
  compareFingerprints(fp1: DeviceFingerprint, fp2: DeviceFingerprint): number {
    let matches = 0;
    let total = 0;

    // Compare basic properties
    const basicProps = ['userAgent', 'timezone', 'language', 'platform'];
    basicProps.forEach(prop => {
      total++;
      if (fp1[prop as keyof DeviceFingerprint] === fp2[prop as keyof DeviceFingerprint]) {
        matches++;
      }
    });

    // Compare screen properties
    total++;
    if (fp1.screen.width === fp2.screen.width && 
        fp1.screen.height === fp2.screen.height &&
        fp1.screen.colorDepth === fp2.screen.colorDepth) {
      matches++;
    }

    // Compare canvas and WebGL
    total += 2;
    if (fp1.canvas === fp2.canvas) matches++;
    if (fp1.webgl === fp2.webgl) matches++;

    // Compare fonts (allow for some variation)
    total++;
    const fontSimilarity = this.calculateArraySimilarity(fp1.fonts, fp2.fonts);
    if (fontSimilarity > 0.8) matches++;

    return matches / total;
  }

  /**
   * Calculate similarity between two arrays
   */
  private calculateArraySimilarity(arr1: string[], arr2: string[]): number {
    if (arr1.length === 0 && arr2.length === 0) return 1;
    if (arr1.length === 0 || arr2.length === 0) return 0;

    const set1 = new Set(arr1);
    const set2 = new Set(arr2);
    const intersection = new Set([...set1].filter(x => set2.has(x)));
    const union = new Set([...set1, ...set2]);

    return intersection.size / union.size;
  }

  /**
   * Check if fingerprint indicates a suspicious device
   */
  isSuspiciousDevice(fingerprint: DeviceFingerprint): boolean {
    // Check for common bot/automation indicators
    const suspiciousIndicators = [
      fingerprint.userAgent.includes('HeadlessChrome'),
      fingerprint.userAgent.includes('PhantomJS'),
      fingerprint.userAgent.includes('Selenium'),
      fingerprint.webgl === '', // No WebGL support might indicate headless browser
      fingerprint.fonts.length < 5, // Very few fonts might indicate automation
      fingerprint.plugins.length === 0 && !fingerprint.touchSupport, // No plugins and no touch on desktop
      fingerprint.hardwareConcurrency === 0 // No hardware concurrency info
    ];

    return suspiciousIndicators.filter(Boolean).length >= 2;
  }
}
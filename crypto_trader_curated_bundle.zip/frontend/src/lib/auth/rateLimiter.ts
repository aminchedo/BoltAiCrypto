export interface RateLimitRule {
  windowMs: number;
  maxRequests: number;
  blockDurationMs?: number;
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
  keyGenerator?: (identifier: string) => string;
  onLimitReached?: (identifier: string, resetTime: Date) => void;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetTime: Date;
  retryAfter?: number;
}

export interface RateLimitStore {
  identifier: string;
  requests: number[];
  blockedUntil?: Date;
  firstRequest: Date;
}

export class RateLimiter {
  private store: Map<string, RateLimitStore> = new Map();
  private cleanupInterval: NodeJS.Timeout;

  constructor() {
    // Clean up expired entries every 5 minutes
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, 5 * 60 * 1000);
  }

  /**
   * Check if request is allowed under rate limit
   */
  async checkLimit(identifier: string, rule: RateLimitRule): Promise<RateLimitResult> {
    const key = rule.keyGenerator ? rule.keyGenerator(identifier) : identifier;
    const now = new Date();
    const windowStart = new Date(now.getTime() - rule.windowMs);

    let store = this.store.get(key);
    
    if (!store) {
      store = {
        identifier: key,
        requests: [],
        firstRequest: now
      };
      this.store.set(key, store);
    }

    // Check if currently blocked
    if (store.blockedUntil && now < store.blockedUntil) {
      return {
        allowed: false,
        remaining: 0,
        resetTime: store.blockedUntil,
        retryAfter: Math.ceil((store.blockedUntil.getTime() - now.getTime()) / 1000)
      };
    }

    // Remove expired requests from the window
    store.requests = store.requests.filter(requestTime => requestTime > windowStart.getTime());

    // Check if limit exceeded
    if (store.requests.length >= rule.maxRequests) {
      // Block if block duration is specified
      if (rule.blockDurationMs) {
        store.blockedUntil = new Date(now.getTime() + rule.blockDurationMs);
        
        if (rule.onLimitReached) {
          rule.onLimitReached(identifier, store.blockedUntil);
        }

        return {
          allowed: false,
          remaining: 0,
          resetTime: store.blockedUntil,
          retryAfter: Math.ceil(rule.blockDurationMs / 1000)
        };
      }

      // Calculate when the oldest request will expire
      const oldestRequest = Math.min(...store.requests);
      const resetTime = new Date(oldestRequest + rule.windowMs);

      if (rule.onLimitReached) {
        rule.onLimitReached(identifier, resetTime);
      }

      return {
        allowed: false,
        remaining: 0,
        resetTime,
        retryAfter: Math.ceil((resetTime.getTime() - now.getTime()) / 1000)
      };
    }

    // Add current request
    store.requests.push(now.getTime());

    // Calculate reset time (when the oldest request will expire)
    const oldestRequest = Math.min(...store.requests);
    const resetTime = new Date(oldestRequest + rule.windowMs);

    return {
      allowed: true,
      remaining: rule.maxRequests - store.requests.length,
      resetTime
    };
  }

  /**
   * Record a successful request (for skipSuccessfulRequests option)
   */
  async recordSuccess(identifier: string, rule: RateLimitRule): Promise<void> {
    if (rule.skipSuccessfulRequests) {
      const key = rule.keyGenerator ? rule.keyGenerator(identifier) : identifier;
      const store = this.store.get(key);
      
      if (store && store.requests.length > 0) {
        // Remove the most recent request
        store.requests.pop();
      }
    }
  }

  /**
   * Record a failed request (for skipFailedRequests option)
   */
  async recordFailure(identifier: string, rule: RateLimitRule): Promise<void> {
    if (rule.skipFailedRequests) {
      const key = rule.keyGenerator ? rule.keyGenerator(identifier) : identifier;
      const store = this.store.get(key);
      
      if (store && store.requests.length > 0) {
        // Remove the most recent request
        store.requests.pop();
      }
    }
  }

  /**
   * Reset rate limit for a specific identifier
   */
  async reset(identifier: string, rule: RateLimitRule): Promise<void> {
    const key = rule.keyGenerator ? rule.keyGenerator(identifier) : identifier;
    this.store.delete(key);
  }

  /**
   * Get current status for an identifier
   */
  async getStatus(identifier: string, rule: RateLimitRule): Promise<{
    requests: number;
    remaining: number;
    resetTime: Date;
    isBlocked: boolean;
  }> {
    const key = rule.keyGenerator ? rule.keyGenerator(identifier) : identifier;
    const now = new Date();
    const windowStart = new Date(now.getTime() - rule.windowMs);
    
    const store = this.store.get(key);
    
    if (!store) {
      return {
        requests: 0,
        remaining: rule.maxRequests,
        resetTime: new Date(now.getTime() + rule.windowMs),
        isBlocked: false
      };
    }

    // Check if currently blocked
    const isBlocked = store.blockedUntil ? now < store.blockedUntil : false;
    
    // Filter expired requests
    const validRequests = store.requests.filter(requestTime => requestTime > windowStart.getTime());
    
    // Calculate reset time
    const resetTime = validRequests.length > 0 
      ? new Date(Math.min(...validRequests) + rule.windowMs)
      : new Date(now.getTime() + rule.windowMs);

    return {
      requests: validRequests.length,
      remaining: Math.max(0, rule.maxRequests - validRequests.length),
      resetTime: isBlocked ? store.blockedUntil! : resetTime,
      isBlocked
    };
  }

  /**
   * Clean up expired entries
   */
  private cleanup(): void {
    const now = new Date();
    const expiredKeys: string[] = [];

    for (const [key, store] of this.store.entries()) {
      // Remove if no recent requests and not blocked
      const hasRecentRequests = store.requests.some(requestTime => 
        requestTime > now.getTime() - (60 * 60 * 1000) // 1 hour
      );
      
      const isBlocked = store.blockedUntil && now < store.blockedUntil;
      
      if (!hasRecentRequests && !isBlocked) {
        expiredKeys.push(key);
      }
    }

    expiredKeys.forEach(key => this.store.delete(key));
  }

  /**
   * Get statistics about rate limiting
   */
  getStats(): {
    totalIdentifiers: number;
    blockedIdentifiers: number;
    totalRequests: number;
  } {
    const now = new Date();
    let totalRequests = 0;
    let blockedIdentifiers = 0;

    for (const store of this.store.values()) {
      totalRequests += store.requests.length;
      
      if (store.blockedUntil && now < store.blockedUntil) {
        blockedIdentifiers++;
      }
    }

    return {
      totalIdentifiers: this.store.size,
      blockedIdentifiers,
      totalRequests
    };
  }

  /**
   * Destroy the rate limiter and clean up resources
   */
  destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.store.clear();
  }
}

// Predefined rate limit rules for different scenarios
export const RateLimitRules = {
  // Authentication endpoints
  LOGIN: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 5, // 5 attempts per 15 minutes
    blockDurationMs: 30 * 60 * 1000, // Block for 30 minutes after limit
    skipSuccessfulRequests: true
  } as RateLimitRule,

  REGISTER: {
    windowMs: 60 * 60 * 1000, // 1 hour
    maxRequests: 3, // 3 registrations per hour
    blockDurationMs: 60 * 60 * 1000 // Block for 1 hour
  } as RateLimitRule,

  PASSWORD_RESET: {
    windowMs: 60 * 60 * 1000, // 1 hour
    maxRequests: 3, // 3 reset attempts per hour
    blockDurationMs: 60 * 60 * 1000 // Block for 1 hour
  } as RateLimitRule,

  TWO_FACTOR: {
    windowMs: 5 * 60 * 1000, // 5 minutes
    maxRequests: 5, // 5 attempts per 5 minutes
    blockDurationMs: 15 * 60 * 1000, // Block for 15 minutes
    skipSuccessfulRequests: true
  } as RateLimitRule,

  // API endpoints
  API_GENERAL: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 100, // 100 requests per minute
    skipSuccessfulRequests: false
  } as RateLimitRule,

  API_TRADING: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 30, // 30 trading requests per minute
    skipSuccessfulRequests: false
  } as RateLimitRule,

  API_MARKET_DATA: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 200, // 200 market data requests per minute
    skipSuccessfulRequests: true
  } as RateLimitRule,

  // WebSocket connections
  WEBSOCKET_CONNECT: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 10, // 10 connection attempts per minute
    blockDurationMs: 5 * 60 * 1000 // Block for 5 minutes
  } as RateLimitRule,

  // Aggressive rate limiting for suspicious activity
  SUSPICIOUS_ACTIVITY: {
    windowMs: 60 * 60 * 1000, // 1 hour
    maxRequests: 1, // 1 request per hour
    blockDurationMs: 24 * 60 * 60 * 1000 // Block for 24 hours
  } as RateLimitRule
};

// Global rate limiter instance
export const globalRateLimiter = new RateLimiter();
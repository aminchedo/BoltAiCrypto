import * as speakeasy from 'speakeasy';
import * as QRCode from 'qrcode';
import { TwoFactorAuth } from './types';

export class TwoFactorAuthManager {
  private readonly serviceName: string;
  private readonly issuer: string;

  constructor() {
    this.serviceName = 'AiSmart Trader';
    this.issuer = 'AiSmart Trader';
  }

  /**
   * Generate a new TOTP secret for a user
   */
  generateSecret(userEmail: string): { secret: string; qrCodeUrl: string; backupCodes: string[] } {
    const secret = speakeasy.generateSecret({
      name: `${this.serviceName} (${userEmail})`,
      issuer: this.issuer,
      length: 32
    });

    const qrCodeUrl = speakeasy.otpauthURL({
      secret: secret.base32,
      label: userEmail,
      issuer: this.issuer,
      encoding: 'base32'
    });

    const backupCodes = this.generateBackupCodes();

    return {
      secret: secret.base32,
      qrCodeUrl,
      backupCodes
    };
  }

  /**
   * Generate QR code image data URL
   */
  async generateQRCode(qrCodeUrl: string): Promise<string> {
    try {
      return await QRCode.toDataURL(qrCodeUrl);
    } catch (error) {
      throw new Error('Failed to generate QR code');
    }
  }

  /**
   * Verify TOTP token
   */
  verifyToken(secret: string, token: string, window: number = 2): boolean {
    return speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token,
      window // Allow for time drift
    });
  }

  /**
   * Generate backup codes for 2FA recovery
   */
  generateBackupCodes(count: number = 10): string[] {
    const codes: string[] = [];
    for (let i = 0; i < count; i++) {
      codes.push(this.generateBackupCode());
    }
    return codes;
  }

  /**
   * Generate a single backup code
   */
  private generateBackupCode(): string {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  /**
   * Verify backup code
   */
  verifyBackupCode(backupCodes: string[], providedCode: string): { isValid: boolean; remainingCodes: string[] } {
    const upperProvidedCode = providedCode.toUpperCase().replace(/\s/g, '');
    const codeIndex = backupCodes.findIndex(code => code === upperProvidedCode);
    
    if (codeIndex === -1) {
      return { isValid: false, remainingCodes: backupCodes };
    }

    // Remove used backup code
    const remainingCodes = backupCodes.filter((_, index) => index !== codeIndex);
    
    return { isValid: true, remainingCodes };
  }

  /**
   * Check if 2FA setup is complete
   */
  isSetupComplete(twoFactorAuth: TwoFactorAuth): boolean {
    return twoFactorAuth.isEnabled && 
           twoFactorAuth.secret.length > 0 && 
           twoFactorAuth.backupCodes.length > 0;
  }

  /**
   * Disable 2FA for a user
   */
  disable2FA(): TwoFactorAuth {
    return {
      secret: '',
      backupCodes: [],
      isEnabled: false,
      lastUsed: undefined
    };
  }

  /**
   * Get current TOTP token (for testing purposes)
   */
  getCurrentToken(secret: string): string {
    return speakeasy.totp({
      secret,
      encoding: 'base32'
    });
  }

  /**
   * Check if backup codes are running low
   */
  areBackupCodesLow(backupCodes: string[], threshold: number = 3): boolean {
    return backupCodes.length <= threshold;
  }

  /**
   * Validate TOTP token format
   */
  isValidTokenFormat(token: string): boolean {
    return /^\d{6}$/.test(token);
  }

  /**
   * Validate backup code format
   */
  isValidBackupCodeFormat(code: string): boolean {
    const cleanCode = code.toUpperCase().replace(/\s/g, '');
    return /^[0-9A-Z]{8}$/.test(cleanCode);
  }
}

// SMS-based 2FA (for future implementation)
export class SMSTwoFactorManager {
  private readonly twilioAccountSid: string;
  private readonly twilioAuthToken: string;
  private readonly twilioPhoneNumber: string;

  constructor() {
    this.twilioAccountSid = process.env.TWILIO_ACCOUNT_SID || '';
    this.twilioAuthToken = process.env.TWILIO_AUTH_TOKEN || '';
    this.twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER || '';
  }

  /**
   * Send SMS verification code
   */
  async sendSMSCode(phoneNumber: string): Promise<{ success: boolean; code: string }> {
    const code = this.generateSMSCode();
    
    try {
      // In a real implementation, use Twilio or similar service
      console.log(`SMS Code for ${phoneNumber}: ${code}`);
      
      return { success: true, code };
    } catch (error) {
      console.error('Failed to send SMS:', error);
      return { success: false, code: '' };
    }
  }

  /**
   * Generate 6-digit SMS code
   */
  private generateSMSCode(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  /**
   * Verify SMS code
   */
  verifySMSCode(storedCode: string, providedCode: string, expiryTime: Date): boolean {
    if (Date.now() > expiryTime.getTime()) {
      return false; // Code expired
    }
    
    return storedCode === providedCode;
  }
}

// Email-based 2FA
export class EmailTwoFactorManager {
  /**
   * Send email verification code
   */
  async sendEmailCode(email: string): Promise<{ success: boolean; code: string }> {
    const code = this.generateEmailCode();
    
    try {
      // In a real implementation, use SendGrid, AWS SES, or similar service
      console.log(`Email Code for ${email}: ${code}`);
      
      return { success: true, code };
    } catch (error) {
      console.error('Failed to send email:', error);
      return { success: false, code: '' };
    }
  }

  /**
   * Generate 8-character email code
   */
  private generateEmailCode(): string {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  /**
   * Verify email code
   */
  verifyEmailCode(storedCode: string, providedCode: string, expiryTime: Date): boolean {
    if (Date.now() > expiryTime.getTime()) {
      return false; // Code expired
    }
    
    return storedCode.toUpperCase() === providedCode.toUpperCase();
  }
}
export interface User {
  id: string;
  email: string;
  emailVerified: boolean;
  twoFactorEnabled: boolean;
  biometricEnabled: boolean;
  role: UserRole;
  permissions: Permission[];
  createdAt: Date;
  updatedAt: Date;
  lastLogin?: Date;
  failedLoginAttempts: number;
  lockedUntil?: Date;
  devices: TrustedDevice[];
  sessions: UserSession[];
}

export interface UserSession {
  id: string;
  userId: string;
  accessToken: string;
  refreshToken: string;
  deviceFingerprint: string;
  ipAddress: string;
  location?: GeolocationData;
  userAgent: string;
  createdAt: Date;
  expiresAt: Date;
  lastActivity: Date;
  isActive: boolean;
}

export interface TrustedDevice {
  id: string;
  userId: string;
  deviceFingerprint: string;
  deviceName: string;
  deviceType: 'desktop' | 'mobile' | 'tablet';
  platform: string;
  browser: string;
  ipAddress: string;
  location?: GeolocationData;
  isActive: boolean;
  lastUsed: Date;
  createdAt: Date;
}

export interface GeolocationData {
  country: string;
  region: string;
  city: string;
  latitude: number;
  longitude: number;
  timezone: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: 'Bearer';
}

export interface TwoFactorAuth {
  secret: string;
  backupCodes: string[];
  isEnabled: boolean;
  lastUsed?: Date;
}

export interface BiometricAuth {
  publicKey: string;
  credentialId: string;
  isEnabled: boolean;
  deviceName: string;
  lastUsed?: Date;
}

export interface LoginCredentials {
  email: string;
  password: string;
  totpCode?: string;
  deviceFingerprint: string;
  rememberDevice?: boolean;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  confirmPassword: string;
  acceptTerms: boolean;
  deviceFingerprint: string;
}

export interface PasswordResetRequest {
  email: string;
  deviceFingerprint: string;
}

export interface PasswordReset {
  token: string;
  newPassword: string;
  confirmPassword: string;
}

export enum UserRole {
  USER = 'user',
  PREMIUM = 'premium',
  ADMIN = 'admin',
  SUPER_ADMIN = 'super_admin'
}

export enum Permission {
  // Trading permissions
  TRADE_SPOT = 'trade:spot',
  TRADE_FUTURES = 'trade:futures',
  TRADE_OPTIONS = 'trade:options',
  
  // Portfolio permissions
  VIEW_PORTFOLIO = 'portfolio:view',
  MANAGE_PORTFOLIO = 'portfolio:manage',
  EXPORT_DATA = 'portfolio:export',
  
  // AI permissions
  USE_AI_SIGNALS = 'ai:signals',
  USE_AUTOMATION = 'ai:automation',
  CONFIGURE_STRATEGIES = 'ai:strategies',
  
  // Admin permissions
  MANAGE_USERS = 'admin:users',
  VIEW_ANALYTICS = 'admin:analytics',
  SYSTEM_CONFIG = 'admin:config',
  
  // API permissions
  API_READ = 'api:read',
  API_WRITE = 'api:write',
  API_ADMIN = 'api:admin'
}

export interface SecurityEvent {
  id: string;
  userId: string;
  eventType: SecurityEventType;
  severity: SecuritySeverity;
  description: string;
  metadata: Record<string, any>;
  ipAddress: string;
  userAgent: string;
  location?: GeolocationData;
  timestamp: Date;
  resolved: boolean;
}

export enum SecurityEventType {
  LOGIN_SUCCESS = 'login_success',
  LOGIN_FAILED = 'login_failed',
  LOGIN_BLOCKED = 'login_blocked',
  PASSWORD_CHANGED = 'password_changed',
  TWO_FACTOR_ENABLED = 'two_factor_enabled',
  TWO_FACTOR_DISABLED = 'two_factor_disabled',
  DEVICE_ADDED = 'device_added',
  DEVICE_REMOVED = 'device_removed',
  SUSPICIOUS_ACTIVITY = 'suspicious_activity',
  ACCOUNT_LOCKED = 'account_locked',
  ACCOUNT_UNLOCKED = 'account_unlocked',
  API_KEY_CREATED = 'api_key_created',
  API_KEY_REVOKED = 'api_key_revoked',
  PERMISSION_CHANGED = 'permission_changed'
}

export enum SecuritySeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

export interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
  keyGenerator?: (req: any) => string;
}

export interface SecurityConfig {
  jwt: {
    accessTokenExpiry: string; // '15m'
    refreshTokenExpiry: string; // '7d'
    issuer: string;
    audience: string;
  };
  
  rateLimit: {
    auth: RateLimitConfig;
    api: RateLimitConfig;
    trading: RateLimitConfig;
  };
  
  security: {
    maxFailedAttempts: number;
    lockoutDuration: number; // minutes
    passwordMinLength: number;
    requireTwoFactor: boolean;
    sessionTimeout: number; // minutes
    maxConcurrentSessions: number;
  };
  
  encryption: {
    algorithm: string;
    keyLength: number;
    saltRounds: number;
  };
}
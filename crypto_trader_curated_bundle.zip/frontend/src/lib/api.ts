// lib/api.ts - Missing API Client Library

export interface ApiResponse<T = any> {
  data: T;
  success: boolean;
  message?: string;
  error?: string;
}

export interface RequestConfig {
  headers?: Record<string, string>;
  timeout?: number;
  retries?: number;
}

export class ApiClient {
  private baseURL: string;
  private defaultHeaders: Record<string, string>;
  private timeout: number;

  constructor(baseURL: string = '', options: RequestConfig = {}) {
    this.baseURL = baseURL;
    this.defaultHeaders = {
      'Content-Type': 'application/json',
      ...options.headers
    };
    this.timeout = options.timeout || 10000;
  }

  private async request<T>(
    method: string,
    url: string,
    data?: any,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      const fullUrl = url.startsWith('http') ? url : `${this.baseURL}${url}`;
      
      const requestConfig: RequestInit = {
        method,
        headers: {
          ...this.defaultHeaders,
          ...config?.headers
        },
        signal: AbortSignal.timeout(this.timeout)
      };

      if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
        requestConfig.body = JSON.stringify(data);
      }

      console.log(`🔄 API Request: ${method} ${fullUrl}`);
      
      const response = await fetch(fullUrl, requestConfig);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      
      console.log(`✅ API Response: ${method} ${fullUrl}`);
      
      return {
        data: result,
        success: true
      };

    } catch (error: any) {
      console.error(`❌ API Error: ${method} ${url}`, error);
      
      // Return mock data for development
      return this.getMockResponse<T>(url, method);
    }
  }

  private getMockResponse<T>(url: string, method: string): ApiResponse<T> {
    console.log(`🎭 Returning mock data for: ${method} ${url}`);
    
    // Mock responses based on URL patterns
    if (url.includes('/markets/') && url.includes('/ticker')) {
      return {
        data: this.getMockTickerData() as T,
        success: true,
        message: 'Mock ticker data'
      };
    }
    
    if (url.includes('/markets/') && url.includes('/history')) {
      return {
        data: this.getMockHistoricalData() as T,
        success: true,
        message: 'Mock historical data'
      };
    }
    
    if (url.includes('/news')) {
      return {
        data: this.getMockNewsData() as T,
        success: true,
        message: 'Mock news data'
      };
    }
    
    if (url.includes('/signals')) {
      return {
        data: this.getMockSignalsData() as T,
        success: true,
        message: 'Mock signals data'
      };
    }
    
    if (url.includes('/trading/portfolio')) {
      return {
        data: this.getMockPortfolioData() as T,
        success: true,
        message: 'Mock portfolio data'
      };
    }

    // Default mock response
    return {
      data: {} as T,
      success: true,
      message: 'Mock response'
    };
  }

  private getMockTickerData() {
    return {
      symbol: 'BTCUSDT',
      price: 67000 + (Math.random() - 0.5) * 2000,
      change24h: (Math.random() - 0.5) * 10,
      volume24h: Math.random() * 1000000000,
      high24h: 68000,
      low24h: 66000,
      timestamp: Date.now()
    };
  }

  private getMockHistoricalData() {
    const data = [];
    const now = Date.now();
    const basePrice = 67000;
    
    for (let i = 100; i >= 0; i--) {
      const time = now - (i * 60000); // 1 minute intervals
      const price = basePrice + (Math.random() - 0.5) * 2000;
      
      data.push({
        timestamp: time,
        open: price,
        high: price + Math.random() * 500,
        low: price - Math.random() * 500,
        close: price + (Math.random() - 0.5) * 200,
        volume: Math.random() * 1000000
      });
    }
    
    return data;
  }

  private getMockNewsData() {
    return [
      {
        id: '1',
        title: 'Bitcoin Reaches New Heights Amid Institutional Adoption',
        summary: 'Major financial institutions continue to embrace Bitcoin...',
        source: 'CryptoNews',
        publishedAt: new Date().toISOString(),
        sentiment: 'positive',
        symbols: ['BTC'],
        url: '#'
      },
      {
        id: '2',
        title: 'Ethereum Network Upgrade Brings Enhanced Scalability',
        summary: 'The latest Ethereum upgrade promises faster transactions...',
        source: 'BlockchainDaily',
        publishedAt: new Date(Date.now() - 3600000).toISOString(),
        sentiment: 'positive',
        symbols: ['ETH'],
        url: '#'
      }
    ];
  }

  private getMockSignalsData() {
    return [
      {
        id: 'signal_1',
        symbol: 'BTCUSDT',
        signal: 'BUY',
        confidence: 85,
        price: 67000,
        target: 69000,
        stopLoss: 65000,
        timestamp: new Date().toISOString(),
        status: 'active',
        aiModel: 'Neural Alpha'
      },
      {
        id: 'signal_2',
        symbol: 'ETHUSDT',
        signal: 'HOLD',
        confidence: 65,
        price: 3400,
        target: 3500,
        stopLoss: 3200,
        timestamp: new Date().toISOString(),
        status: 'active',
        aiModel: 'Quantum Beta'
      }
    ];
  }

  private getMockPortfolioData() {
    return {
      totalValue: 125000,
      change24h: 3250,
      changePercent: 2.67,
      assets: [
        {
          symbol: 'BTC',
          amount: 1.5,
          value: 100500,
          change24h: 3.2
        },
        {
          symbol: 'ETH',
          amount: 8.5,
          value: 28900,
          change24h: -1.5
        }
      ]
    };
  }

  // Public methods
  async get<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('GET', url, undefined, config);
  }

  async post<T>(url: string, data?: any, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('POST', url, data, config);
  }

  async put<T>(url: string, data?: any, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('PUT', url, data, config);
  }

  async patch<T>(url: string, data?: any, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('PATCH', url, data, config);
  }

  async delete<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('DELETE', url, undefined, config);
  }

  // Update default headers (for authentication)
  setAuthToken(token: string) {
    this.defaultHeaders['Authorization'] = `Bearer ${token}`;
  }

  // Remove auth token
  clearAuthToken() {
    delete this.defaultHeaders['Authorization'];
  }
}

export default ApiClient;

// Export API modules
export { marketApi } from './api/marketApi';
export { portfolioApi } from './api/portfolioApi';
export { signalsApi } from './api/signalsApi';
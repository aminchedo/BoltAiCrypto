// Trading signals store using Zustand

import { create } from 'zustand';
import { TradingSignal } from '@/types';
import { signalsApi } from '@/lib/api';

interface SignalState {
  signals: TradingSignal[];
  selectedSignal: TradingSignal | null;
  isLoading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  
  // Actions
  fetchSignals: () => Promise<void>;
  fetchSignalsBySymbol: (symbol: string) => Promise<void>;
  selectSignal: (signalId: string) => void;
}

export const useSignalStore = create<SignalState>((set, get) => ({
  signals: [],
  selectedSignal: null,
  isLoading: false,
  error: null,
  lastUpdated: null,
  
  fetchSignals: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const signals = await signalsApi.getSignals();
      set({ 
        signals, 
        isLoading: false,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error('Failed to fetch signals:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch signals' 
      });
    }
  },
  
  fetchSignalsBySymbol: async (symbol) => {
    set({ isLoading: true, error: null });
    
    try {
      const signals = await signalsApi.getSignalsBySymbol(symbol);
      set({ 
        signals, 
        isLoading: false,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error(`Failed to fetch signals for ${symbol}:`, error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch signals' 
      });
    }
  },
  
  selectSignal: (signalId) => {
    const { signals } = get();
    const selectedSignal = signals.find(signal => signal.id === signalId) || null;
    set({ selectedSignal });
  },
}));
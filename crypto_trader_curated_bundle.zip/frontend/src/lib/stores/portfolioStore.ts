// Portfolio store using Zustand

import { create } from 'zustand';
import { Portfolio, Position, Order } from '@/types';
import { portfolioApi } from '@/lib/api';

interface PortfolioState {
  portfolio: Portfolio | null;
  positions: Position[];
  orders: Order[];
  isLoading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  
  // Actions
  fetchPortfolio: () => Promise<void>;
  fetchPositions: () => Promise<void>;
  fetchOrders: () => Promise<void>;
  placeOrder: (order: Partial<Order>) => Promise<Order>;
  cancelOrder: (orderId: string) => Promise<void>;
}

export const usePortfolioStore = create<PortfolioState>((set, get) => ({
  portfolio: null,
  positions: [],
  orders: [],
  isLoading: false,
  error: null,
  lastUpdated: null,
  
  fetchPortfolio: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const portfolio = await portfolioApi.getPortfolio();
      set({ 
        portfolio, 
        isLoading: false,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error('Failed to fetch portfolio:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch portfolio' 
      });
    }
  },
  
  fetchPositions: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const positions = await portfolioApi.getPositions();
      set({ 
        positions, 
        isLoading: false,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error('Failed to fetch positions:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch positions' 
      });
    }
  },
  
  fetchOrders: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const orders = await portfolioApi.getOrders();
      set({ 
        orders, 
        isLoading: false,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error('Failed to fetch orders:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch orders' 
      });
    }
  },
  
  placeOrder: async (order) => {
    set({ isLoading: true, error: null });
    
    try {
      const newOrder = await portfolioApi.placeOrder(order);
      
      set(state => ({
        orders: [...state.orders, newOrder],
        isLoading: false,
        lastUpdated: new Date(),
      }));
      
      return newOrder;
    } catch (error) {
      console.error('Failed to place order:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to place order' 
      });
      throw error;
    }
  },
  
  cancelOrder: async (orderId) => {
    set({ isLoading: true, error: null });
    
    try {
      await portfolioApi.cancelOrder(orderId);
      
      set(state => ({
        orders: state.orders.filter(order => order.id !== orderId),
        isLoading: false,
        lastUpdated: new Date(),
      }));
    } catch (error) {
      console.error(`Failed to cancel order ${orderId}:`, error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to cancel order' 
      });
      throw error;
    }
  },
}));
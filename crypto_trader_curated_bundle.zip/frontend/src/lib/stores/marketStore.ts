// Market data store using Zustand

import { create } from 'zustand';
import { MarketData } from '@/types';
import { marketApi } from '@/lib/api';

interface MarketState {
  markets: MarketData[];
  selectedMarket: string | null;
  isLoading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  
  // Actions
  fetchMarkets: () => Promise<void>;
  selectMarket: (symbol: string) => void;
  refreshMarketData: () => Promise<void>;
}

export const useMarketStore = create<MarketState>((set, get) => ({
  markets: [],
  selectedMarket: null,
  isLoading: false,
  error: null,
  lastUpdated: null,
  
  fetchMarkets: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const markets = await marketApi.getMarketOverview();
      set({ 
        markets, 
        isLoading: false,
        lastUpdated: new Date(),
      });
    } catch (error) {
      console.error('Failed to fetch markets:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch markets' 
      });
    }
  },
  
  selectMarket: (symbol) => {
    set({ selectedMarket: symbol });
  },
  
  refreshMarketData: async () => {
    const { selectedMarket } = get();
    
    if (selectedMarket) {
      set({ isLoading: true, error: null });
      
      try {
        const marketData = await marketApi.getMarketData(selectedMarket);
        
        set(state => ({
          markets: state.markets.map(m => 
            m.symbol === selectedMarket ? marketData : m
          ),
          isLoading: false,
          lastUpdated: new Date(),
        }));
      } catch (error) {
        console.error(`Failed to refresh market data for ${selectedMarket}:`, error);
        set({ 
          isLoading: false, 
          error: error instanceof Error ? error.message : 'Failed to refresh market data' 
        });
      }
    }
  },
}));
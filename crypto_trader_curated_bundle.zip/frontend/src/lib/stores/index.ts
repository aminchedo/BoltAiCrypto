// Enhanced Zustand stores with full API integration

import { create } from 'zustand';
import { subscribeWithSelector, devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import { 
  marketApi, 
  portfolioApi, 
  signalsApi, 
  tradingApi,
  websocketApi 
} from '@/lib/api';
import { 
  Ticker, 
  Portfolio, 
  Position,
  Signal, 
  HybridSignal,
  Order,
  OrderRequest,
  MarketData,
  Candle,
  NewsItem,
  WhaleActivity,
  ChartTimeframe,
  Theme 
} from '@/types';
import { config } from '@/lib/config';

// Market Store
interface MarketState {
  // Data
  tickers: Record<string, Ticker>;
  selectedSymbol: string;
  marketData: Record<string, MarketData>;
  candles: Record<string, Candle[]>;
  searchResults: Ticker[];
  
  // UI State
  isLoading: boolean;
  error: string | null;
  lastUpdate: Date | null;
  
  // WebSocket
  isConnected: boolean;
  subscribedSymbols: string[];
  
  // Actions
  setSelectedSymbol: (symbol: string) => void;
  fetchTickers: () => Promise<void>;
  fetchTicker: (symbol: string) => Promise<void>;
  fetchMarketData: (symbol: string, timeFrame?: ChartTimeframe) => Promise<void>;
  fetchCandles: (symbol: string, timeFrame?: ChartTimeframe, limit?: number) => Promise<void>;
  searchMarkets: (query: string) => Promise<void>;
  subscribeToTicker: (symbol: string) => void;
  unsubscribeFromTicker: (symbol: string) => void;
  subscribeToMultipleTickers: (symbols: string[]) => void;
  clearError: () => void;
  reset: () => void;
}

export const useMarketStore = create<MarketState>()(
  devtools(
    subscribeWithSelector(
      immer((set, get) => ({
        // Initial state
        tickers: {},
        selectedSymbol: 'BTCUSDT',
        marketData: {},
        candles: {},
        searchResults: [],
        isLoading: false,
        error: null,
        lastUpdate: null,
        isConnected: false,
        subscribedSymbols: [],

        // Actions
        setSelectedSymbol: (symbol: string) => {
          set((state) => {
            state.selectedSymbol = symbol;
          });
          
          // Auto-fetch market data for selected symbol
          get().fetchMarketData(symbol);
        },

        fetchTickers: async () => {
          set((state) => {
            state.isLoading = true;
            state.error = null;
          });

          try {
            const response = await marketApi.getTickers();
            
            if (response.success) {
              set((state) => {
                const tickerMap: Record<string, Ticker> = {};
                response.data.forEach(ticker => {
                  tickerMap[ticker.symbol] = ticker;
                });
                state.tickers = tickerMap;
                state.lastUpdate = new Date();
              });
            } else {
              set((state) => {
                state.error = response.error || 'Failed to fetch tickers';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isLoading = false;
            });
          }
        },

        fetchTicker: async (symbol: string) => {
          try {
            const response = await marketApi.getTicker(symbol);
            
            if (response.success) {
              set((state) => {
                state.tickers[symbol] = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch ticker:', error);
          }
        },

        fetchMarketData: async (symbol: string, timeFrame?: ChartTimeframe) => {
          set((state) => {
            state.isLoading = true;
            state.error = null;
          });

          try {
            const response = await marketApi.getMarketData(symbol, timeFrame);
            
            if (response.success) {
              set((state) => {
                state.marketData[symbol] = response.data;
                state.tickers[symbol] = response.data.ticker;
                state.lastUpdate = new Date();
              });
            } else {
              set((state) => {
                state.error = response.error || 'Failed to fetch market data';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isLoading = false;
            });
          }
        },

        fetchCandles: async (symbol: string, timeFrame: ChartTimeframe = '1h', limit: number = 100) => {
          try {
            const response = await marketApi.getCandles(symbol, timeFrame, limit);
            
            if (response.success) {
              set((state) => {
                const key = `${symbol}_${timeFrame}`;
                state.candles[key] = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch candles:', error);
          }
        },

        searchMarkets: async (query: string) => {
          if (!query.trim()) {
            set((state) => {
              state.searchResults = [];
            });
            return;
          }

          try {
            const response = await marketApi.searchMarkets(query);
            
            if (response.success) {
              set((state) => {
                state.searchResults = response.data;
              });
            }
          } catch (error) {
            console.error('Search failed:', error);
          }
        },

        subscribeToTicker: (symbol: string) => {
          const state = get();
          if (state.subscribedSymbols.includes(symbol)) return;

          try {
            const unsubscribe = marketApi.subscribeToTickers([symbol], (ticker) => {
              set((state) => {
                state.tickers[ticker.symbol] = ticker;
                state.isConnected = true;
                state.lastUpdate = new Date();
              });
            });

            set((state) => {
              state.subscribedSymbols.push(symbol);
            });

            // Store unsubscribe function for cleanup
            return unsubscribe;
          } catch (error) {
            console.error('Failed to subscribe to ticker:', error);
          }
        },

        unsubscribeFromTicker: (symbol: string) => {
          set((state) => {
            state.subscribedSymbols = state.subscribedSymbols.filter(s => s !== symbol);
          });
        },

        subscribeToMultipleTickers: (symbols: string[]) => {
          try {
            const unsubscribe = marketApi.subscribeToTickers(symbols, (ticker) => {
              set((state) => {
                state.tickers[ticker.symbol] = ticker;
                state.isConnected = true;
                state.lastUpdate = new Date();
              });
            });

            set((state) => {
              state.subscribedSymbols = [...new Set([...state.subscribedSymbols, ...symbols])];
            });

            return unsubscribe;
          } catch (error) {
            console.error('Failed to subscribe to tickers:', error);
          }
        },

        clearError: () => {
          set((state) => {
            state.error = null;
          });
        },

        reset: () => {
          set((state) => {
            state.tickers = {};
            state.marketData = {};
            state.candles = {};
            state.searchResults = [];
            state.error = null;
            state.isLoading = false;
            state.isConnected = false;
            state.subscribedSymbols = [];
            state.lastUpdate = null;
          });
        }
      }))
    ),
    { name: 'market-store' }
  )
);

// Portfolio Store
interface PortfolioState {
  // Data
  portfolio: Portfolio | null;
  positions: Position[];
  performance: any;
  analytics: any;
  
  // UI State
  isLoading: boolean;
  error: string | null;
  lastUpdate: Date | null;
  
  // WebSocket
  isConnected: boolean;
  
  // Actions
  fetchPortfolio: () => Promise<void>;
  fetchPositions: () => Promise<void>;
  fetchPerformance: (period?: string) => Promise<void>;
  updatePosition: (positionId: string, updates: Partial<Position>) => Promise<void>;
  closePosition: (positionId: string) => Promise<void>;
  subscribeToUpdates: () => void;
  clearError: () => void;
  reset: () => void;
}

export const usePortfolioStore = create<PortfolioState>()(
  devtools(
    subscribeWithSelector(
      immer((set, get) => ({
        // Initial state
        portfolio: null,
        positions: [],
        performance: null,
        analytics: null,
        isLoading: false,
        error: null,
        lastUpdate: null,
        isConnected: false,

        // Actions
        fetchPortfolio: async () => {
          set((state) => {
            state.isLoading = true;
            state.error = null;
          });

          try {
            const response = await portfolioApi.getPortfolio();
            
            if (response.success) {
              set((state) => {
                state.portfolio = response.data;
                state.positions = response.data.positions || [];
                state.lastUpdate = new Date();
              });
            } else {
              set((state) => {
                state.error = response.error || 'Failed to fetch portfolio';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isLoading = false;
            });
          }
        },

        fetchPositions: async () => {
          try {
            const response = await portfolioApi.getPositions();
            
            if (response.success) {
              set((state) => {
                state.positions = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch positions:', error);
          }
        },

        fetchPerformance: async (period: string = '7d') => {
          try {
            const response = await portfolioApi.getPerformance(period);
            
            if (response.success) {
              set((state) => {
                state.performance = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch performance:', error);
          }
        },

        updatePosition: async (positionId: string, updates: Partial<Position>) => {
          try {
            const response = await portfolioApi.updatePosition(positionId, updates);
            
            if (response.success) {
              set((state) => {
                const index = state.positions.findIndex(p => p.id === positionId);
                if (index !== -1) {
                  state.positions[index] = response.data;
                }
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to update position:', error);
          }
        },

        closePosition: async (positionId: string) => {
          set((state) => {
            state.isLoading = true;
          });

          try {
            const response = await portfolioApi.closePosition(positionId);
            
            if (response.success) {
              set((state) => {
                state.positions = state.positions.filter(p => p.id !== positionId);
                state.lastUpdate = new Date();
              });
              
              // Refresh portfolio data
              get().fetchPortfolio();
            } else {
              set((state) => {
                state.error = response.error || 'Failed to close position';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isLoading = false;
            });
          }
        },

        subscribeToUpdates: () => {
          try {
            const unsubscribe = portfolioApi.subscribeToUpdates((data) => {
              set((state) => {
                state.isConnected = true;
                state.lastUpdate = new Date();
                
                if ('totalValue' in data) {
                  // Portfolio update
                  state.portfolio = data as Portfolio;
                  state.positions = (data as Portfolio).positions || [];
                } else {
                  // Position update
                  const position = data as Position;
                  const index = state.positions.findIndex(p => p.id === position.id);
                  if (index !== -1) {
                    state.positions[index] = position;
                  } else {
                    state.positions.push(position);
                  }
                }
              });
            });

            return unsubscribe;
          } catch (error) {
            console.error('Failed to subscribe to portfolio updates:', error);
          }
        },

        clearError: () => {
          set((state) => {
            state.error = null;
          });
        },

        reset: () => {
          set((state) => {
            state.portfolio = null;
            state.positions = [];
            state.performance = null;
            state.analytics = null;
            state.error = null;
            state.isLoading = false;
            state.isConnected = false;
            state.lastUpdate = null;
          });
        }
      }))
    ),
    { name: 'portfolio-store' }
  )
);

// Signals Store
interface SignalsState {
  // Data
  signals: Signal[];
  hybridSignals: HybridSignal[];
  activeSignals: Signal[];
  signalHistory: Signal[];
  performance: any;
  
  // Filters
  symbolFilter: string;
  confidenceFilter: number;
  
  // UI State
  isLoading: boolean;
  error: string | null;
  lastUpdate: Date | null;
  
  // WebSocket
  isConnected: boolean;
  
  // Actions
  fetchSignals: (symbol?: string) => Promise<void>;
  fetchHybridSignals: (symbol?: string) => Promise<void>;
  fetchSignalHistory: (symbol?: string) => Promise<void>;
  fetchPerformance: (period?: string) => Promise<void>;
  updateSignalStatus: (signalId: string, status: string) => Promise<void>;
  subscribeToSignals: () => void;
  setSymbolFilter: (symbol: string) => void;
  setConfidenceFilter: (confidence: number) => void;
  clearError: () => void;
  reset: () => void;
}

export const useSignalsStore = create<SignalsState>()(
  devtools(
    subscribeWithSelector(
      immer((set, get) => ({
        // Initial state
        signals: [],
        hybridSignals: [],
        activeSignals: [],
        signalHistory: [],
        performance: null,
        symbolFilter: '',
        confidenceFilter: config.ai.confidenceThreshold,
        isLoading: false,
        error: null,
        lastUpdate: null,
        isConnected: false,

        // Actions
        fetchSignals: async (symbol?: string) => {
          set((state) => {
            state.isLoading = true;
            state.error = null;
          });

          try {
            const response = await signalsApi.getSignals(
              symbol || get().symbolFilter || undefined,
              'ACTIVE',
              get().confidenceFilter
            );
            
            if (response.success) {
              set((state) => {
                state.signals = response.data;
                state.activeSignals = response.data.filter(s => s.status === 'ACTIVE');
                state.lastUpdate = new Date();
              });
            } else {
              set((state) => {
                state.error = response.error || 'Failed to fetch signals';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isLoading = false;
            });
          }
        },

        fetchHybridSignals: async (symbol?: string) => {
          try {
            const response = await signalsApi.getHybridSignals(
              symbol || get().symbolFilter || undefined,
              get().confidenceFilter
            );
            
            if (response.success) {
              set((state) => {
                state.hybridSignals = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch hybrid signals:', error);
          }
        },

        fetchSignalHistory: async (symbol?: string) => {
          try {
            const response = await signalsApi.getSignalHistory(
              symbol || get().symbolFilter || undefined
            );
            
            if (response.success) {
              set((state) => {
                state.signalHistory = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch signal history:', error);
          }
        },

        fetchPerformance: async (period: string = '7d') => {
          try {
            const response = await signalsApi.getSignalPerformance(
              period,
              get().symbolFilter || undefined
            );
            
            if (response.success) {
              set((state) => {
                state.performance = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch signal performance:', error);
          }
        },

        updateSignalStatus: async (signalId: string, status: string) => {
          try {
            const response = await signalsApi.updateSignalStatus(signalId, status);
            
            if (response.success) {
              set((state) => {
                // Update in regular signals
                const signalIndex = state.signals.findIndex(s => s.id === signalId);
                if (signalIndex !== -1) {
                  state.signals[signalIndex] = response.data;
                }
                
                // Update in hybrid signals
                const hybridIndex = state.hybridSignals.findIndex(s => s.id === signalId);
                if (hybridIndex !== -1) {
                  state.hybridSignals[hybridIndex] = response.data as HybridSignal;
                }
                
                // Update active signals
                state.activeSignals = state.signals.filter(s => s.status === 'ACTIVE');
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to update signal status:', error);
          }
        },

        subscribeToSignals: () => {
          try {
            const unsubscribe = signalsApi.subscribeToSignals((signal) => {
              set((state) => {
                state.isConnected = true;
                state.lastUpdate = new Date();
                
                if ('algorithmBreakdown' in signal) {
                  // Hybrid signal
                  const hybridSignal = signal as HybridSignal;
                  const existingIndex = state.hybridSignals.findIndex(s => s.id === hybridSignal.id);
                  
                  if (existingIndex !== -1) {
                    state.hybridSignals[existingIndex] = hybridSignal;
                  } else {
                    state.hybridSignals.unshift(hybridSignal);
                    // Keep only last 50 signals
                    if (state.hybridSignals.length > 50) {
                      state.hybridSignals = state.hybridSignals.slice(0, 50);
                    }
                  }
                } else {
                  // Regular signal
                  const existingIndex = state.signals.findIndex(s => s.id === signal.id);
                  
                  if (existingIndex !== -1) {
                    state.signals[existingIndex] = signal;
                  } else {
                    state.signals.unshift(signal);
                    // Keep only last 100 signals
                    if (state.signals.length > 100) {
                      state.signals = state.signals.slice(0, 100);
                    }
                  }
                  
                  // Update active signals
                  state.activeSignals = state.signals.filter(s => s.status === 'ACTIVE');
                }
              });
            }, {
              symbol: get().symbolFilter || undefined,
              minConfidence: get().confidenceFilter
            });

            return unsubscribe;
          } catch (error) {
            console.error('Failed to subscribe to signals:', error);
          }
        },

        setSymbolFilter: (symbol: string) => {
          set((state) => {
            state.symbolFilter = symbol;
          });
          
          // Refetch with new filter
          get().fetchSignals();
          get().fetchHybridSignals();
        },

        setConfidenceFilter: (confidence: number) => {
          set((state) => {
            state.confidenceFilter = confidence;
          });
          
          // Refetch with new filter
          get().fetchSignals();
          get().fetchHybridSignals();
        },

        clearError: () => {
          set((state) => {
            state.error = null;
          });
        },

        reset: () => {
          set((state) => {
            state.signals = [];
            state.hybridSignals = [];
            state.activeSignals = [];
            state.signalHistory = [];
            state.performance = null;
            state.symbolFilter = '';
            state.confidenceFilter = config.ai.confidenceThreshold;
            state.error = null;
            state.isLoading = false;
            state.isConnected = false;
            state.lastUpdate = null;
          });
        }
      }))
    ),
    { name: 'signals-store' }
  )
);

// Trading Store
interface TradingState {
  // Data
  orders: Order[];
  tradeHistory: any[];
  performance: any;
  
  // UI State
  isLoading: boolean;
  isSubmitting: boolean;
  error: string | null;
  lastUpdate: Date | null;
  
  // Actions
  fetchOrders: () => Promise<void>;
  fetchTradeHistory: () => Promise<void>;
  fetchPerformance: (period?: string) => Promise<void>;
  createOrder: (order: OrderRequest) => Promise<Order | null>;
  updateOrder: (orderId: string, updates: Partial<OrderRequest>) => Promise<void>;
  cancelOrder: (orderId: string) => Promise<void>;
  cancelAllOrders: (symbol?: string) => Promise<void>;
  clearError: () => void;
  reset: () => void;
}

export const useTradingStore = create<TradingState>()(
  devtools(
    subscribeWithSelector(
      immer((set, get) => ({
        // Initial state
        orders: [],
        tradeHistory: [],
        performance: null,
        isLoading: false,
        isSubmitting: false,
        error: null,
        lastUpdate: null,

        // Actions
        fetchOrders: async () => {
          set((state) => {
            state.isLoading = true;
            state.error = null;
          });

          try {
            const response = await tradingApi.getOrders();
            
            if (response.success) {
              set((state) => {
                state.orders = response.data;
                state.lastUpdate = new Date();
              });
            } else {
              set((state) => {
                state.error = response.error || 'Failed to fetch orders';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isLoading = false;
            });
          }
        },

        fetchTradeHistory: async () => {
          try {
            const response = await tradingApi.getTradeHistory();
            
            if (response.success) {
              set((state) => {
                state.tradeHistory = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch trade history:', error);
          }
        },

        fetchPerformance: async (period: string = '30d') => {
          try {
            const response = await tradingApi.getTradingPerformance(period);
            
            if (response.success) {
              set((state) => {
                state.performance = response.data;
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to fetch trading performance:', error);
          }
        },

        createOrder: async (orderRequest: OrderRequest): Promise<Order | null> => {
          set((state) => {
            state.isSubmitting = true;
            state.error = null;
          });

          try {
            const response = await tradingApi.createOrder(orderRequest);
            
            if (response.success) {
              set((state) => {
                state.orders.unshift(response.data);
                state.lastUpdate = new Date();
              });
              
              return response.data;
            } else {
              set((state) => {
                state.error = response.error || 'Failed to create order';
              });
              return null;
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
            return null;
          } finally {
            set((state) => {
              state.isSubmitting = false;
            });
          }
        },

        updateOrder: async (orderId: string, updates: Partial<OrderRequest>) => {
          try {
            const response = await tradingApi.updateOrder(orderId, updates);
            
            if (response.success) {
              set((state) => {
                const index = state.orders.findIndex(o => o.id === orderId);
                if (index !== -1) {
                  state.orders[index] = response.data;
                }
                state.lastUpdate = new Date();
              });
            }
          } catch (error) {
            console.error('Failed to update order:', error);
          }
        },

        cancelOrder: async (orderId: string) => {
          set((state) => {
            state.isSubmitting = true;
          });

          try {
            const response = await tradingApi.cancelOrder(orderId);
            
            if (response.success) {
              set((state) => {
                const index = state.orders.findIndex(o => o.id === orderId);
                if (index !== -1) {
                  state.orders[index] = response.data;
                }
                state.lastUpdate = new Date();
              });
            } else {
              set((state) => {
                state.error = response.error || 'Failed to cancel order';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isSubmitting = false;
            });
          }
        },

        cancelAllOrders: async (symbol?: string) => {
          set((state) => {
            state.isSubmitting = true;
          });

          try {
            const response = await tradingApi.cancelAllOrders(symbol);
            
            if (response.success) {
              // Refresh orders
              await get().fetchOrders();
            } else {
              set((state) => {
                state.error = response.error || 'Failed to cancel orders';
              });
            }
          } catch (error) {
            set((state) => {
              state.error = error instanceof Error ? error.message : 'Unknown error';
            });
          } finally {
            set((state) => {
              state.isSubmitting = false;
            });
          }
        },

        clearError: () => {
          set((state) => {
            state.error = null;
          });
        },

        reset: () => {
          set((state) => {
            state.orders = [];
            state.tradeHistory = [];
            state.performance = null;
            state.error = null;
            state.isLoading = false;
            state.isSubmitting = false;
            state.lastUpdate = null;
          });
        }
      }))
    ),
    { name: 'trading-store' }
  )
);

// App State Store (UI, theme, settings)
interface AppState {
  // UI State
  theme: Theme;
  sidebarCollapsed: boolean;
  notifications: any[];
  
  // Connection Status
  connectionStatus: Record<string, boolean>;
  
  // Feature flags (from config but can be overridden)
  features: Record<string, boolean>;
  
  // User settings
  settings: {
    autoRefresh: boolean;
    refreshInterval: number;
    soundEnabled: boolean;
    notificationsEnabled: boolean;
    defaultTimeframe: ChartTimeframe;
  };
  
  // Actions
  setTheme: (theme: Theme) => void;
  toggleSidebar: () => void;
  addNotification: (notification: any) => void;
  removeNotification: (id: string) => void;
  updateConnectionStatus: (service: string, connected: boolean) => void;
  updateSettings: (settings: Partial<AppState['settings']>) => void;
  toggleFeature: (feature: string) => void;
}

export const useAppStore = create<AppState>()(
  devtools(
    persist(
      subscribeWithSelector(
        immer((set, get) => ({
          // Initial state
          theme: config.ui.defaultTheme,
          sidebarCollapsed: false,
          notifications: [],
          connectionStatus: {},
          features: { ...config.features },
          settings: {
            autoRefresh: true,
            refreshInterval: 10000,
            soundEnabled: true,
            notificationsEnabled: true,
            defaultTimeframe: '1h' as ChartTimeframe
          },

          // Actions
          setTheme: (theme: Theme) => {
            set((state) => {
              state.theme = theme;
            });
            
            // Apply theme to document
            document.documentElement.setAttribute('data-theme', theme);
          },

          toggleSidebar: () => {
            set((state) => {
              state.sidebarCollapsed = !state.sidebarCollapsed;
            });
          },

          addNotification: (notification: any) => {
            set((state) => {
              state.notifications.unshift({
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                ...notification
              });
              
              // Keep only last 50 notifications
              if (state.notifications.length > 50) {
                state.notifications = state.notifications.slice(0, 50);
              }
            });
          },

          removeNotification: (id: string) => {
            set((state) => {
              state.notifications = state.notifications.filter(n => n.id !== id);
            });
          },

          updateConnectionStatus: (service: string, connected: boolean) => {
            set((state) => {
              state.connectionStatus[service] = connected;
            });
          },

          updateSettings: (newSettings: Partial<AppState['settings']>) => {
            set((state) => {
              state.settings = { ...state.settings, ...newSettings };
            });
          },

          toggleFeature: (feature: string) => {
            set((state) => {
              state.features[feature] = !state.features[feature];
            });
          }
        }))
      ),
      {
        name: 'app-store',
        partialize: (state) => ({
          theme: state.theme,
          sidebarCollapsed: state.sidebarCollapsed,
          settings: state.settings,
          features: state.features
        })
      }
    ),
    { name: 'app-store' }
  )
);

// Export all stores
export {
  useMarketStore,
  usePortfolioStore,
  useSignalsStore,
  useTradingStore,
  useAppStore
};

// Store initialization helper
export const initializeStores = async () => {
  console.log('🏪 Initializing stores...');
  
  try {
    // Initialize market store
    const marketStore = useMarketStore.getState();
    await marketStore.fetchTickers();
    marketStore.subscribeToMultipleTickers(['BTCUSDT', 'ETHUSDT', 'BNBUSDT']);
    
    // Initialize portfolio store
    const portfolioStore = usePortfolioStore.getState();
    await portfolioStore.fetchPortfolio();
    portfolioStore.subscribeToUpdates();
    
    // Initialize signals store
    const signalsStore = useSignalsStore.getState();
    await signalsStore.fetchSignals();
    await signalsStore.fetchHybridSignals();
    signalsStore.subscribeToSignals();
    
    // Initialize trading store
    const tradingStore = useTradingStore.getState();
    await tradingStore.fetchOrders();
    
    console.log('✅ Stores initialized successfully');
  } catch (error) {
    console.error('❌ Failed to initialize stores:', error);
  }
};

// Store cleanup helper
export const cleanupStores = () => {
  console.log('🧹 Cleaning up stores...');
  
  // Disconnect all WebSockets
  websocketApi.disconnectAll();
  
  // Reset all stores
  useMarketStore.getState().reset();
  usePortfolioStore.getState().reset();
  useSignalsStore.getState().reset();
  useTradingStore.getState().reset();
  
  console.log('✅ Stores cleaned up');
};

export default {
  useMarketStore,
  usePortfolioStore,
  useSignalsStore,
  useTradingStore,
  useAppStore,
  initializeStores,
  cleanupStores
};
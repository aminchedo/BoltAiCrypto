// lib/api/client.ts - Enhanced API Client with Type Safety

import { 
  ApiResponse, 
  Ticker, 
  Candle, 
  Signal, 
  Portfolio, 
  NewsItem,
  MarketData,
  Position,
  Order
} from '@/types';
import { config } from '@/config';

export interface RequestConfig {
  headers?: Record<string, string>;
  timeout?: number;
  retries?: number;
  skipAuth?: boolean;
}

export interface RetryConfig {
  attempts: number;
  delay: number;
  backoff: number;
}

export class ApiClient {
  private baseURL: string;
  private defaultHeaders: Record<string, string>;
  private timeout: number;
  private retryConfig: RetryConfig;

  constructor(baseURL: string = config.api.baseUrl, options: RequestConfig = {}) {
    this.baseURL = baseURL;
    this.defaultHeaders = {
      'Content-Type': 'application/json',
      'X-API-Version': config.api.version || 'v1',
      ...options.headers
    };
    this.timeout = options.timeout || config.api.timeout;
    this.retryConfig = {
      attempts: options.retries || config.api.retries || 3,
      delay: 1000,
      backoff: 2
    };

    // Auto-load auth token on initialization
    this.loadAuthToken();
  }

  private loadAuthToken(): void {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem(config.auth.tokenKey);
      if (token) {
        this.setAuthToken(token);
      }
    }
  }

  private async request<T>(
    method: string,
    url: string,
    data?: any,
    config?: RequestConfig
  ): Promise<ApiResponse<T>> {
    const fullUrl = url.startsWith('http') ? url : `${this.baseURL}${url}`;
    
    for (let attempt = 1; attempt <= this.retryConfig.attempts; attempt++) {
      try {
        const requestConfig: RequestInit = {
          method,
          headers: {
            ...this.defaultHeaders,
            ...config?.headers
          },
          signal: AbortSignal.timeout(config?.timeout || this.timeout)
        };

        if (data && ['POST', 'PUT', 'PATCH'].includes(method)) {
          requestConfig.body = JSON.stringify(data);
        }

        if (config?.skipAuth) {
          delete requestConfig.headers?.['Authorization'];
        }

        console.log(`🔄 API Request (attempt ${attempt}): ${method} ${fullUrl}`);
        
        const response = await fetch(fullUrl, requestConfig);
        
        if (!response.ok) {
          if (response.status === 401) {
            this.handleUnauthorized();
          }
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const result = await response.json();
        
        console.log(`✅ API Response: ${method} ${fullUrl}`);
        
        return {
          data: result.data || result,
          success: true,
          message: result.message,
          timestamp: new Date().toISOString()
        };

      } catch (error: any) {
        console.error(`❌ API Error (attempt ${attempt}): ${method} ${url}`, error);
        
        // If it's the last attempt or a non-retryable error, return mock data
        if (attempt === this.retryConfig.attempts || this.isNonRetryableError(error)) {
          return this.getMockResponse<T>(url, method);
        }
        
        // Wait before retrying
        await this.delay(this.retryConfig.delay * Math.pow(this.retryConfig.backoff, attempt - 1));
      }
    }

    // Fallback to mock response
    return this.getMockResponse<T>(url, method);
  }

  private isNonRetryableError(error: any): boolean {
    return error.name === 'AbortError' || 
           error.message?.includes('401') || 
           error.message?.includes('403');
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private handleUnauthorized(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(config.auth.tokenKey);
      localStorage.removeItem(config.auth.refreshTokenKey);
      this.clearAuthToken();
      
      // Redirect to login if not already there
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login';
      }
    }
  }

  private getMockResponse<T>(url: string, method: string): ApiResponse<T> {
    console.log(`🎭 Returning mock data for: ${method} ${url}`);
    
    // Mock responses based on URL patterns
    if (url.includes('/market/ticker')) {
      return {
        data: this.getMockTickerData() as T,
        success: true,
        message: 'Mock ticker data',
        timestamp: new Date().toISOString()
      };
    }
    
    if (url.includes('/market/tickers')) {
      return {
        data: this.getMockTickersData() as T,
        success: true,
        message: 'Mock tickers data',
        timestamp: new Date().toISOString()
      };
    }
    
    if (url.includes('/market/candles') || url.includes('/market/history')) {
      return {
        data: this.getMockCandlesData() as T,
        success: true,
        message: 'Mock candles data',
        timestamp: new Date().toISOString()
      };
    }

    if (url.includes('/market/data')) {
      return {
        data: this.getMockMarketData() as T,
        success: true,
        message: 'Mock market data',
        timestamp: new Date().toISOString()
      };
    }
    
    if (url.includes('/news')) {
      return {
        data: this.getMockNewsData() as T,
        success: true,
        message: 'Mock news data',
        timestamp: new Date().toISOString()
      };
    }
    
    if (url.includes('/signals')) {
      return {
        data: this.getMockSignalsData() as T,
        success: true,
        message: 'Mock signals data',
        timestamp: new Date().toISOString()
      };
    }
    
    if (url.includes('/portfolio')) {
      return {
        data: this.getMockPortfolioData() as T,
        success: true,
        message: 'Mock portfolio data',
        timestamp: new Date().toISOString()
      };
    }

    if (url.includes('/trading/orders')) {
      return {
        data: this.getMockOrdersData() as T,
        success: true,
        message: 'Mock orders data',
        timestamp: new Date().toISOString()
      };
    }

    // Default mock response
    return {
      data: {} as T,
      success: true,
      message: 'Mock response',
      timestamp: new Date().toISOString()
    };
  }

  private getMockTickerData(): Ticker {
    const symbols = ['BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'SOLUSDT', 'DOTUSDT'];
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const basePrice = symbol === 'BTCUSDT' ? 67000 : symbol === 'ETHUSDT' ? 3400 : 1.5;
    
    return {
      symbol,
      name: symbol.replace('USDT', ''),
      price: basePrice + (Math.random() - 0.5) * basePrice * 0.1,
      change24h: (Math.random() - 0.5) * basePrice * 0.1,
      changePercent24h: (Math.random() - 0.5) * 10,
      volume24h: Math.random() * 1000000000,
      marketCap: Math.random() * 500000000000,
      rank: Math.floor(Math.random() * 100) + 1,
      high24h: basePrice * 1.05,
      low24h: basePrice * 0.95,
      ath: basePrice * 1.5,
      atl: basePrice * 0.1,
      circulatingSupply: Math.random() * 1000000000,
      totalSupply: Math.random() * 1000000000,
      maxSupply: Math.random() * 1000000000,
      lastUpdated: new Date().toISOString()
    };
  }

  private getMockTickersData(): Ticker[] {
    const symbols = ['BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'SOLUSDT', 'DOTUSDT', 'LINKUSDT', 'LTCUSDT'];
    return symbols.map((symbol, index) => {
      const basePrice = symbol === 'BTCUSDT' ? 67000 : 
                       symbol === 'ETHUSDT' ? 3400 : 
                       symbol === 'SOLUSDT' ? 150 : 
                       symbol === 'LINKUSDT' ? 15 : 1.5;
      
      return {
        symbol,
        name: symbol.replace('USDT', ''),
        price: basePrice + (Math.random() - 0.5) * basePrice * 0.1,
        change24h: (Math.random() - 0.5) * basePrice * 0.1,
        changePercent24h: (Math.random() - 0.5) * 10,
        volume24h: Math.random() * 1000000000,
        marketCap: Math.random() * 500000000000,
        rank: index + 1,
        high24h: basePrice * 1.05,
        low24h: basePrice * 0.95,
        ath: basePrice * 1.5,
        atl: basePrice * 0.1,
        circulatingSupply: Math.random() * 1000000000,
        totalSupply: Math.random() * 1000000000,
        maxSupply: Math.random() * 1000000000,
        lastUpdated: new Date().toISOString()
      };
    });
  }

  private getMockCandlesData(): Candle[] {
    const data: Candle[] = [];
    const now = Date.now();
    const basePrice = 67000;
    
    for (let i = 100; i >= 0; i--) {
      const time = now - (i * 60000); // 1 minute intervals
      const open = basePrice + (Math.random() - 0.5) * 2000;
      const close = open + (Math.random() - 0.5) * 500;
      const high = Math.max(open, close) + Math.random() * 300;
      const low = Math.min(open, close) - Math.random() * 300;
      
      data.push({
        timestamp: time,
        open,
        high,
        low,
        close,
        volume: Math.random() * 1000000
      });
    }
    
    return data;
  }

  private getMockMarketData(): MarketData {
    const ticker = this.getMockTickerData();
    const candles = this.getMockCandlesData();
    
    return {
      symbol: ticker.symbol,
      ticker,
      candles,
      price: ticker.price,
      change24h: ticker.change24h,
      volume24h: ticker.volume24h,
      marketCap: ticker.marketCap,
      high24h: ticker.high24h,
      low24h: ticker.low24h,
      lastUpdated: new Date().toISOString(),
      indicators: {
        rsi: 50 + (Math.random() - 0.5) * 40,
        macd: {
          value: (Math.random() - 0.5) * 100,
          signal: (Math.random() - 0.5) * 100,
          histogram: (Math.random() - 0.5) * 50
        },
        bollinger: {
          upper: ticker.price * 1.02,
          middle: ticker.price,
          lower: ticker.price * 0.98
        },
        sma20: ticker.price * (0.98 + Math.random() * 0.04),
        sma50: ticker.price * (0.96 + Math.random() * 0.08),
        sma200: ticker.price * (0.9 + Math.random() * 0.2),
        ema12: ticker.price * (0.99 + Math.random() * 0.02),
        ema20: ticker.price * (0.98 + Math.random() * 0.04),
        ema26: ticker.price * (0.97 + Math.random() * 0.06),
        ema50: ticker.price * (0.96 + Math.random() * 0.08),
        stochastic: {
          k: Math.random() * 100,
          d: Math.random() * 100
        },
        atr: ticker.price * 0.02,
        volume_sma: ticker.volume24h * (0.8 + Math.random() * 0.4)
      }
    };
  }

  private getMockNewsData(): NewsItem[] {
    return [
      {
        id: '1',
        title: 'Bitcoin Reaches New Heights Amid Institutional Adoption',
        summary: 'Major financial institutions continue to embrace Bitcoin as a store of value...',
        source: 'CryptoNews',
        publishedAt: new Date().toISOString(),
        sentiment: 'POSITIVE',
        relevance: 0.9,
        relatedAssets: ['BTC'],
        url: 'https://example.com/news/1'
      },
      {
        id: '2',
        title: 'Ethereum Network Upgrade Brings Enhanced Scalability',
        summary: 'The latest Ethereum upgrade promises faster transactions and lower fees...',
        source: 'BlockchainDaily',
        publishedAt: new Date(Date.now() - 3600000).toISOString(),
        sentiment: 'POSITIVE',
        relevance: 0.8,
        relatedAssets: ['ETH'],
        url: 'https://example.com/news/2'
      },
      {
        id: '3',
        title: 'Market Volatility Concerns Rise Among Traders',
        summary: 'Recent market movements have raised concerns about increased volatility...',
        source: 'MarketWatch',
        publishedAt: new Date(Date.now() - 7200000).toISOString(),
        sentiment: 'NEGATIVE',
        relevance: 0.7,
        relatedAssets: ['BTC', 'ETH'],
        url: 'https://example.com/news/3'
      }
    ];
  }

  private getMockSignalsData(): Signal[] {
    return [
      {
        id: 'signal_1',
        symbol: 'BTCUSDT',
        direction: 'BUY',
        confidence: 85,
        entryPrice: 67000,
        takeProfit: 69000,
        stopLoss: 65000,
        timestamp: Date.now(),
        expiresAt: Date.now() + 3600000,
        status: 'ACTIVE',
        riskRewardRatio: 2.0
      },
      {
        id: 'signal_2',
        symbol: 'ETHUSDT',
        direction: 'HOLD',
        confidence: 65,
        entryPrice: 3400,
        takeProfit: 3500,
        stopLoss: 3200,
        timestamp: Date.now(),
        expiresAt: Date.now() + 3600000,
        status: 'ACTIVE',
        riskRewardRatio: 1.5
      },
      {
        id: 'signal_3',
        symbol: 'SOLUSDT',
        direction: 'SELL',
        confidence: 78,
        entryPrice: 150,
        takeProfit: 145,
        stopLoss: 155,
        timestamp: Date.now(),
        expiresAt: Date.now() + 3600000,
        status: 'ACTIVE',
        riskRewardRatio: 1.0
      }
    ];
  }

  private getMockPortfolioData(): Portfolio {
    const positions: Position[] = [
      {
        id: 'pos_1',
        symbol: 'BTCUSDT',
        exchange: 'binance',
        side: 'LONG',
        type: 'LONG',
        size: 1.5,
        quantity: 1.5,
        entryPrice: 65000,
        currentPrice: 67000,
        unrealizedPnl: 3000,
        realizedPnl: 0,
        pnl: 3000,
        pnlPercentage: 4.62,
        percentage: 4.62,
        margin: 0,
        leverage: 1,
        timestamp: Date.now(),
        openedAt: new Date().toISOString()
      },
      {
        id: 'pos_2',
        symbol: 'ETHUSDT',
        exchange: 'binance',
        side: 'LONG',
        type: 'LONG',
        size: 8.5,
        quantity: 8.5,
        entryPrice: 3500,
        currentPrice: 3400,
        unrealizedPnl: -850,
        realizedPnl: 0,
        pnl: -850,
        pnlPercentage: -2.86,
        percentage: -2.86,
        margin: 0,
        leverage: 1,
        timestamp: Date.now(),
        openedAt: new Date().toISOString()
      }
    ];

    return {
      id: 'portfolio_1',
      totalValue: 125000,
      availableBalance: 25000,
      lockedBalance: 100000,
      usedMargin: 0,
      freeMargin: 25000,
      marginLevel: 0,
      positions,
      dailyPnl: 2150,
      totalPnl: 2150,
      equity: 125000,
      cash: 25000,
      lastUpdate: new Date().toISOString(),
      pnl: {
        total: 2150,
        realized: 0,
        unrealized: 2150
      },
      performance: {
        daily: 1.75,
        weekly: 5.2,
        monthly: 12.8,
        allTime: 25.0
      },
      assets: [
        {
          asset: 'BTC',
          free: 1.5,
          locked: 0,
          total: 1.5,
          btcValue: 1.5,
          usdValue: 100500
        },
        {
          asset: 'ETH',
          free: 8.5,
          locked: 0,
          total: 8.5,
          btcValue: 0.43,
          usdValue: 28900
        },
        {
          asset: 'USDT',
          free: 25000,
          locked: 0,
          total: 25000,
          btcValue: 0.37,
          usdValue: 25000
        }
      ]
    };
  }

  private getMockOrdersData(): Order[] {
    return [
      {
        id: 'order_1',
        symbol: 'BTCUSDT',
        exchange: 'binance',
        side: 'BUY',
        type: 'LIMIT',
        quantity: 0.5,
        price: 66000,
        timeInForce: 'GTC',
        status: 'NEW',
        executedQuantity: 0,
        commission: 0,
        commissionAsset: 'BNB',
        timestamp: Date.now(),
        updateTime: Date.now(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'order_2',
        symbol: 'ETHUSDT',
        exchange: 'binance',
        side: 'SELL',
        type: 'MARKET',
        quantity: 2.0,
        timeInForce: 'IOC',
        status: 'FILLED',
        executedQuantity: 2.0,
        executedPrice: 3400,
        commission: 6.8,
        commissionAsset: 'USDT',
        timestamp: Date.now() - 3600000,
        updateTime: Date.now() - 3600000,
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        updatedAt: new Date(Date.now() - 3600000).toISOString()
      }
    ];
  }

  // Public methods
  async get<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('GET', url, undefined, config);
  }

  async post<T>(url: string, data?: any, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('POST', url, data, config);
  }

  async put<T>(url: string, data?: any, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('PUT', url, data, config);
  }

  async patch<T>(url: string, data?: any, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('PATCH', url, data, config);
  }

  async delete<T>(url: string, config?: RequestConfig): Promise<ApiResponse<T>> {
    return this.request<T>('DELETE', url, undefined, config);
  }

  // Authentication methods
  setAuthToken(token: string): void {
    this.defaultHeaders['Authorization'] = `Bearer ${token}`;
    if (typeof window !== 'undefined') {
      localStorage.setItem(config.auth.tokenKey, token);
    }
  }

  clearAuthToken(): void {
    delete this.defaultHeaders['Authorization'];
    if (typeof window !== 'undefined') {
      localStorage.removeItem(config.auth.tokenKey);
      localStorage.removeItem(config.auth.refreshTokenKey);
    }
  }

  getAuthToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(config.auth.tokenKey);
    }
    return null;
  }

  // Utility methods
  isAuthenticated(): boolean {
    return !!this.getAuthToken();
  }

  updateBaseURL(newBaseURL: string): void {
    this.baseURL = newBaseURL;
  }

  updateTimeout(newTimeout: number): void {
    this.timeout = newTimeout;
  }

  // Health check
  async healthCheck(): Promise<ApiResponse<{ status: string; timestamp: string }>> {
    return this.get('/health', { skipAuth: true });
  }
}

// Create and export default instance
export const apiClient = new ApiClient();

export default apiClient;
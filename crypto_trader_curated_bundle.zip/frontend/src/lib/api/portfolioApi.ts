import ApiClient from '../api';

const apiClient = new ApiClient(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api');

export interface PortfolioAsset {
    symbol: string;
    amount: number;
    value: number;
    change24h: number;
    changePercent: number;
    allocation: number;
}

export interface PortfolioData {
    totalValue: number;
    change24h: number;
    changePercent: number;
    assets: PortfolioAsset[];
    lastUpdated: string;
}

export const portfolioApi = {
    async getPortfolio(): Promise<PortfolioData> {
        try {
            const response = await apiClient.get<PortfolioData>('/portfolio');
            return response.data;
        } catch (error) {
            console.error('Failed to fetch portfolio:', error);
            // Return mock data
            return {
                totalValue: 125000,
                change24h: 3250,
                changePercent: 2.67,
                assets: [
                    {
                        symbol: 'BTC',
                        amount: 1.5,
                        value: 100500,
                        change24h: 3.2,
                        changePercent: 2.1,
                        allocation: 80.4
                    },
                    {
                        symbol: 'ETH',
                        amount: 8.5,
                        value: 28900,
                        change24h: -1.5,
                        changePercent: -0.8,
                        allocation: 19.6
                    }
                ],
                lastUpdated: new Date().toISOString()
            };
        }
    },

    async updatePortfolio(asset: PortfolioAsset): Promise<PortfolioData> {
        try {
            const response = await apiClient.post<PortfolioData>('/portfolio/update', asset);
            return response.data;
        } catch (error) {
            console.error('Failed to update portfolio:', error);
            throw error;
        }
    }
}; 
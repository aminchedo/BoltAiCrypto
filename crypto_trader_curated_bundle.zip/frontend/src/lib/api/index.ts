// src/lib/api/index.ts - Compatible with improved types & ApiClient

import { 
  Ticker, 
  Candle, 
  MarketData, 
  Signal,
  HybridSignal,
  Portfolio, 
  Position,
  Order,
  OrderRequest,
  TradeExecution,
  ApiResponse,
  PaginatedResponse,
  WebSocketMessage,
  TimeFrame,
  OrderType,
  OrderSide,
  SignalDirection,
  NewsItem
} from '@/types';
import { config, getWebSocketUrl } from '@/config';
import { apiClient, RequestConfig } from './client';

// Re-export ApiClient for convenience
export { apiClient } from './client';
export type { RequestConfig } from './client';

// Market API
export const marketApi = {
  // Get ticker data
  getTickers: async (config?: RequestConfig): Promise<ApiResponse<Ticker[]>> => {
    return apiClient.get<Ticker[]>('/market/tickers', config);
  },

  // Get paginated tickers
  getTickersPaginated: async (
    page: number = 1, 
    limit: number = 50,
    config?: RequestConfig
  ): Promise<PaginatedResponse<Ticker>> => {
    const response = await apiClient.get<any>(`/market/tickers?page=${page}&limit=${limit}`, config);
    return {
      ...response,
      pagination: response.data?.pagination || {
        page,
        limit,
        total: 0,
        pages: 0
      }
    };
  },

  // Get ticker for specific symbol
  getTicker: async (symbol: string, config?: RequestConfig): Promise<ApiResponse<Ticker>> => {
    return apiClient.get<Ticker>(`/market/ticker/${symbol}`, config);
  },

  // Get candle data
  getCandles: async (
    symbol: string, 
    timeFrame: TimeFrame = TimeFrame['1h'], 
    limit: number = 100,
    config?: RequestConfig
  ): Promise<ApiResponse<Candle[]>> => {
    return apiClient.get<Candle[]>(
      `/market/candles/${symbol}?timeFrame=${timeFrame}&limit=${limit}`,
      config
    );
  },

  // Get market data (tickers + candles + indicators)
  getMarketData: async (symbol: string, config?: RequestConfig): Promise<ApiResponse<MarketData>> => {
    return apiClient.get<MarketData>(`/market/data/${symbol}`, config);
  },

  // Search markets
  searchMarkets: async (query: string, config?: RequestConfig): Promise<ApiResponse<Ticker[]>> => {
    return apiClient.get<Ticker[]>(`/market/search?q=${encodeURIComponent(query)}`, config);
  },

  // Get market stats
  getMarketStats: async (config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get('/market/stats', config);
  },

  // Get news
  getNews: async (
    symbols?: string[], 
    limit: number = 10,
    config?: RequestConfig
  ): Promise<ApiResponse<NewsItem[]>> => {
    const symbolsQuery = symbols ? `symbols=${symbols.join(',')}` : '';
    const query = `?limit=${limit}${symbolsQuery ? '&' + symbolsQuery : ''}`;
    return apiClient.get<NewsItem[]>(`/market/news${query}`, config);
  },

  // Subscribe to real-time updates
  subscribeToUpdates: (symbols: string[], callback: (data: Ticker) => void) => {
    const ws = new WebSocket(getWebSocketUrl('market'));
    
    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        channels: symbols.map(symbol => `ticker.${symbol}`)
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage<Ticker> = JSON.parse(event.data);
        if (message.type === 'ticker_update') {
          callback(message.data);
        }
      } catch (error) {
        console.error('WebSocket message parsing error:', error);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    // Return cleanup function
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'unsubscribe',
          channels: symbols.map(symbol => `ticker.${symbol}`)
        }));
      }
      ws.close();
    };
  }
};

// Portfolio API
export const portfolioApi = {
  // Get portfolio data
  getPortfolio: async (userId?: string, config?: RequestConfig): Promise<ApiResponse<Portfolio>> => {
    const endpoint = userId ? `/portfolio/${userId}` : '/portfolio';
    return apiClient.get<Portfolio>(endpoint, config);
  },

  // Update portfolio
  updatePortfolio: async (
    portfolio: Partial<Portfolio>,
    config?: RequestConfig
  ): Promise<ApiResponse<Portfolio>> => {
    return apiClient.put<Portfolio>('/portfolio', portfolio, config);
  },

  // Get positions
  getPositions: async (config?: RequestConfig): Promise<ApiResponse<Position[]>> => {
    return apiClient.get<Position[]>('/portfolio/positions', config);
  },

  // Add position
  addPosition: async (
    position: Partial<Position>,
    config?: RequestConfig
  ): Promise<ApiResponse<Position>> => {
    return apiClient.post<Position>('/portfolio/positions', position, config);
  },

  // Update position
  updatePosition: async (
    positionId: string, 
    updates: Partial<Position>,
    config?: RequestConfig
  ): Promise<ApiResponse<Position>> => {
    return apiClient.put<Position>(`/portfolio/positions/${positionId}`, updates, config);
  },

  // Close position
  closePosition: async (positionId: string, config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.delete(`/portfolio/positions/${positionId}`, config);
  },

  // Get portfolio performance
  getPerformance: async (
    period: string = '7d',
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    return apiClient.get(`/portfolio/performance?period=${period}`, config);
  },

  // Get portfolio analytics
  getAnalytics: async (config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get('/portfolio/analytics', config);
  },

  // Export portfolio data
  exportData: async (format: 'csv' | 'json' = 'csv', config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get(`/portfolio/export?format=${format}`, config);
  }
};

// Signals API
export const signalsApi = {
  // Get trading signals
  getSignals: async (symbol?: string, config?: RequestConfig): Promise<ApiResponse<Signal[]>> => {
    const endpoint = symbol ? `/signals?symbol=${symbol}` : '/signals';
    return apiClient.get<Signal[]>(endpoint, config);
  },

  // Get hybrid signals
  getHybridSignals: async (
    symbol?: string,
    config?: RequestConfig
  ): Promise<ApiResponse<HybridSignal[]>> => {
    const endpoint = symbol ? `/signals/hybrid?symbol=${symbol}` : '/signals/hybrid';
    return apiClient.get<HybridSignal[]>(endpoint, config);
  },

  // Get signal by ID
  getSignal: async (signalId: string, config?: RequestConfig): Promise<ApiResponse<Signal>> => {
    return apiClient.get<Signal>(`/signals/${signalId}`, config);
  },

  // Create new signal
  createSignal: async (
    signal: Partial<Signal>,
    config?: RequestConfig
  ): Promise<ApiResponse<Signal>> => {
    return apiClient.post<Signal>('/signals', signal, config);
  },

  // Update signal status
  updateSignalStatus: async (
    signalId: string, 
    status: string,
    config?: RequestConfig
  ): Promise<ApiResponse<Signal>> => {
    return apiClient.put<Signal>(`/signals/${signalId}/status`, { status }, config);
  },

  // Get signal performance
  getSignalPerformance: async (
    period: string = '7d',
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    return apiClient.get(`/signals/performance?period=${period}`, config);
  },

  // Get AI model performance
  getModelPerformance: async (
    modelName?: string,
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    const endpoint = modelName ? `/signals/models/${modelName}/performance` : '/signals/models/performance';
    return apiClient.get(endpoint, config);
  },

  // Backtest strategy
  backtestStrategy: async (
    strategy: any,
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    return apiClient.post('/signals/backtest', strategy, config);
  },

  // Subscribe to signal updates
  subscribeToSignals: (callback: (signal: Signal) => void) => {
    const ws = new WebSocket(getWebSocketUrl('signals'));
    
    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        channel: 'signals'
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage<Signal> = JSON.parse(event.data);
        if (message.type === 'signal_update') {
          callback(message.data);
        }
      } catch (error) {
        console.error('WebSocket message parsing error:', error);
      }
    };

    return () => {
      ws.close();
    };
  }
};

// Trading API
export const tradingApi = {
  // Get orders
  getOrders: async (status?: string, config?: RequestConfig): Promise<ApiResponse<Order[]>> => {
    const endpoint = status ? `/trading/orders?status=${status}` : '/trading/orders';
    return apiClient.get<Order[]>(endpoint, config);
  },

  // Create order
  createOrder: async (
    order: OrderRequest,
    config?: RequestConfig
  ): Promise<ApiResponse<Order>> => {
    return apiClient.post<Order>('/trading/orders', order, config);
  },

  // Update order
  updateOrder: async (
    orderId: string,
    updates: Partial<OrderRequest>,
    config?: RequestConfig
  ): Promise<ApiResponse<Order>> => {
    return apiClient.put<Order>(`/trading/orders/${orderId}`, updates, config);
  },

  // Cancel order
  cancelOrder: async (orderId: string, config?: RequestConfig): Promise<ApiResponse<Order>> => {
    return apiClient.post<Order>(`/trading/orders/${orderId}/cancel`, {}, config);
  },

  // Cancel all orders
  cancelAllOrders: async (symbol?: string, config?: RequestConfig): Promise<ApiResponse<any>> => {
    const endpoint = symbol ? `/trading/orders/cancel-all?symbol=${symbol}` : '/trading/orders/cancel-all';
    return apiClient.post(endpoint, {}, config);
  },

  // Execute trade
  executeTrade: async (
    tradeData: any,
    config?: RequestConfig
  ): Promise<ApiResponse<TradeExecution>> => {
    return apiClient.post<TradeExecution>('/trading/execute', tradeData, config);
  },

  // Get trade history
  getTradeHistory: async (
    userId?: string,
    config?: RequestConfig
  ): Promise<ApiResponse<TradeExecution[]>> => {
    const endpoint = userId ? `/trading/history/${userId}` : '/trading/history';
    return apiClient.get<TradeExecution[]>(endpoint, config);
  },

  // Get trading performance
  getTradingPerformance: async (
    period: string = '30d',
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    return apiClient.get(`/trading/performance?period=${period}`, config);
  },

  // Get order book
  getOrderBook: async (symbol: string, config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get(`/trading/orderbook/${symbol}`, config);
  },

  // Get trading fees
  getTradingFees: async (config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get('/trading/fees', config);
  },

  // Get account info
  getAccountInfo: async (config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get('/trading/account', config);
  }
};

// Authentication API
export const authApi = {
  // Login
  login: async (
    credentials: { email: string; password: string },
    config?: RequestConfig
  ): Promise<ApiResponse<{ token: string; refreshToken: string; user: any }>> => {
    return apiClient.post('/auth/login', credentials, { ...config, skipAuth: true });
  },

  // Register
  register: async (
    userData: { email: string; password: string; username: string },
    config?: RequestConfig
  ): Promise<ApiResponse<{ token: string; refreshToken: string; user: any }>> => {
    return apiClient.post('/auth/register', userData, { ...config, skipAuth: true });
  },

  // Refresh token
  refreshToken: async (
    refreshToken: string,
    config?: RequestConfig
  ): Promise<ApiResponse<{ token: string; refreshToken: string }>> => {
    return apiClient.post('/auth/refresh', { refreshToken }, { ...config, skipAuth: true });
  },

  // Logout
  logout: async (config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.post('/auth/logout', {}, config);
  },

  // Get user profile
  getProfile: async (config?: RequestConfig): Promise<ApiResponse<any>> => {
    return apiClient.get('/auth/profile', config);
  },

  // Update profile
  updateProfile: async (
    profileData: any,
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    return apiClient.put('/auth/profile', profileData, config);
  }
};

// WebSocket API
export const websocketApi = {
  connect: (url?: string): WebSocket => {
    const wsUrl = url || getWebSocketUrl();
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket connected to:', wsUrl);
    };
    
    ws.onclose = () => {
      console.log('WebSocket disconnected');
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    return ws;
  },

  createReconnectingWebSocket: (url?: string) => {
    const wsUrl = url || getWebSocketUrl();
    let ws: WebSocket;
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;
    const reconnectDelay = 1000;

    const connect = () => {
      ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        console.log('WebSocket connected');
        reconnectAttempts = 0;
      };
      
      ws.onclose = () => {
        if (reconnectAttempts < maxReconnectAttempts) {
          reconnectAttempts++;
          console.log(`Reconnecting WebSocket (attempt ${reconnectAttempts})...`);
          setTimeout(connect, reconnectDelay * reconnectAttempts);
        }
      };
      
      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    };

    connect();

    return {
      getWebSocket: () => ws,
      disconnect: () => {
        reconnectAttempts = maxReconnectAttempts; // Prevent reconnection
        ws.close();
      },
      reconnect: () => {
        reconnectAttempts = 0;
        connect();
      }
    };
  },

  // Subscribe to multiple channels
  subscribeToChannels: (channels: string[], callbacks: Record<string, (data: any) => void>) => {
    const ws = websocketApi.connect();
    
    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        channels
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        const callback = callbacks[message.channel] || callbacks[message.type];
        if (callback) {
          callback(message.data);
        }
      } catch (error) {
        console.error('WebSocket message parsing error:', error);
      }
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'unsubscribe',
          channels
        }));
      }
      ws.close();
    };
  }
};

// Utility functions
export const apiUtils = {
  // Check if API is available
  checkHealth: async (): Promise<boolean> => {
    try {
      const response = await apiClient.healthCheck();
      return response.success;
    } catch {
      return false;
    }
  },

  // Get API status
  getStatus: async (): Promise<ApiResponse<any>> => {
    return apiClient.get('/status', { skipAuth: true });
  },

  // Upload file
  uploadFile: async (
    file: File,
    endpoint: string = '/upload',
    config?: RequestConfig
  ): Promise<ApiResponse<any>> => {
    const formData = new FormData();
    formData.append('file', file);
    
    return apiClient.post(endpoint, formData, {
      ...config,
      headers: {
        // Remove Content-Type to let browser set it with boundary
        ...config?.headers,
        'Content-Type': undefined as any
      }
    });
  },

  // Download file
  downloadFile: async (
    url: string,
    filename?: string,
    config?: RequestConfig
  ): Promise<boolean> => {
    try {
      const response = await fetch(url, {
        headers: apiClient['defaultHeaders']
      });
      
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = filename || 'download';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(downloadUrl);
      document.body.removeChild(a);
      
      return true;
    } catch (error) {
      console.error('Download error:', error);
      return false;
    }
  }
};

// Export all APIs
export default {
  marketApi,
  portfolioApi,
  signalsApi,
  tradingApi,
  authApi,
  websocketApi,
  apiUtils,
  apiClient
};

// Re-export types for convenience
export type {
  Ticker,
  Candle,
  MarketData,
  Signal,
  HybridSignal,
  Portfolio,
  Position,
  Order,
  OrderRequest,
  TradeExecution,
  ApiResponse,
  PaginatedResponse,
  WebSocketMessage,
  NewsItem
} from '@/types';

// Export config helpers
export { 
  getApiUrl, 
  getWebSocketUrl, 
  isFeatureEnabled,
  config 
} from '@/config';
import ApiClient from '../api';

const apiClient = new ApiClient(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api');

export interface Signal {
    id: string;
    symbol: string;
    signal: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    price: number;
    target: number;
    stopLoss: number;
    timestamp: string;
    status: 'active' | 'expired' | 'executed';
    aiModel: string;
}

export interface SignalData {
    signals: Signal[];
    totalSignals: number;
    activeSignals: number;
    successRate: number;
}

export const signalsApi = {
    async getSignals(): Promise<Signal[]> {
        try {
            const response = await apiClient.get<Signal[]>('/signals');
            return response.data || [];
        } catch (error) {
            console.error('Failed to fetch signals:', error);
            // Return mock data
            return [
                {
                    id: 'signal_1',
                    symbol: 'BTCUSDT',
                    signal: 'BUY',
                    confidence: 85,
                    price: 67000,
                    target: 69000,
                    stopLoss: 65000,
                    timestamp: new Date().toISOString(),
                    status: 'active',
                    aiModel: 'Neural Alpha'
                },
                {
                    id: 'signal_2',
                    symbol: 'ETHUSDT',
                    signal: 'HOLD',
                    confidence: 65,
                    price: 3400,
                    target: 3500,
                    stopLoss: 3200,
                    timestamp: new Date().toISOString(),
                    status: 'active',
                    aiModel: 'Quantum Beta'
                }
            ];
        }
    },

    async getSignalById(id: string): Promise<Signal> {
        try {
            const response = await apiClient.get<Signal>(`/signals/${id}`);
            return response.data;
        } catch (error) {
            console.error(`Failed to fetch signal ${id}:`, error);
            throw error;
        }
    },

    async createSignal(signal: Omit<Signal, 'id' | 'timestamp'>): Promise<Signal> {
        try {
            const response = await apiClient.post<Signal>('/signals', signal);
            return response.data;
        } catch (error) {
            console.error('Failed to create signal:', error);
            throw error;
        }
    }
}; 
import ApiClient from '../api';

const apiClient = new ApiClient(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api');

export interface MarketData {
    symbol: string;
    name: string;
    price: number;
    change24h: number;
    changePercent: number;
    volume: number;
    marketCap: number;
    high24h: number;
    low24h: number;
    lastUpdated: string;
}

export interface MarketOverview {
    markets: MarketData[];
    totalMarketCap: number;
    totalVolume24h: number;
    btcDominance: number;
}

export const marketApi = {
    async getMarketOverview(): Promise<MarketData[]> {
        try {
            const response = await apiClient.get<MarketData[]>('/markets/overview');
            return response.data || [];
        } catch (error) {
            console.error('Failed to fetch market overview:', error);
            // Return mock data
            return [
                {
                    symbol: 'BTC',
                    name: 'Bitcoin',
                    price: 67000,
                    change24h: 1250,
                    changePercent: 1.9,
                    volume: 25000000000,
                    marketCap: 1300000000000,
                    high24h: 67500,
                    low24h: 65500,
                    lastUpdated: new Date().toISOString()
                },
                {
                    symbol: 'ETH',
                    name: 'Ethereum',
                    price: 3400,
                    change24h: -50,
                    changePercent: -1.4,
                    volume: 15000000000,
                    marketCap: 400000000000,
                    high24h: 3500,
                    low24h: 3350,
                    lastUpdated: new Date().toISOString()
                }
            ];
        }
    },

    async getMarketData(symbol: string): Promise<MarketData> {
        try {
            const response = await apiClient.get<MarketData>(`/markets/${symbol}`);
            return response.data;
        } catch (error) {
            console.error(`Failed to fetch market data for ${symbol}:`, error);
            // Return mock data
            return {
                symbol,
                name: symbol === 'BTC' ? 'Bitcoin' : 'Ethereum',
                price: symbol === 'BTC' ? 67000 : 3400,
                change24h: symbol === 'BTC' ? 1250 : -50,
                changePercent: symbol === 'BTC' ? 1.9 : -1.4,
                volume: symbol === 'BTC' ? 25000000000 : 15000000000,
                marketCap: symbol === 'BTC' ? 1300000000000 : 400000000000,
                high24h: symbol === 'BTC' ? 67500 : 3500,
                low24h: symbol === 'BTC' ? 65500 : 3350,
                lastUpdated: new Date().toISOString()
            };
        }
    }
}; 
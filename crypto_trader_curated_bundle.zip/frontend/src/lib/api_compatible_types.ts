// src/lib/api/index.ts - Compatible with improved types

import { 
  Ticker, 
  Candle, 
  MarketData, 
  Signal,
  HybridSignal,
  Portfolio, 
  Position,
  Order,
  OrderRequest,
  TradeExecution,
  ApiResponse,
  PaginatedResponse,
  WebSocketMessage,
  TimeFrame,
  OrderType,
  OrderSide,
  SignalDirection
} from '@/types';

// Base API Configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';
const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:3001';

// Helper function for API calls
async function apiCall<T>(
  endpoint: string, 
  options?: RequestInit
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getAuthToken()}`,
        ...options?.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return {
      success: true,
      data: data.data || data,
      message: data.message,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('API call failed:', error);
    return {
      success: false,
      data: {} as T,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    };
  }
}

// Auth helper
function getAuthToken(): string {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('auth_token') || '';
  }
  return '';
}

// Market API
export const marketApi = {
  // Get ticker data
  getTickers: async (): Promise<ApiResponse<Ticker[]>> => {
    return apiCall<Ticker[]>('/market/tickers');
  },

  // Get paginated tickers
  getTickersPaginated: async (
    page: number = 1, 
    limit: number = 50
  ): Promise<PaginatedResponse<Ticker>> => {
    const response = await apiCall<any>(`/market/tickers?page=${page}&limit=${limit}`);
    return {
      ...response,
      pagination: response.data?.pagination || {
        page,
        limit,
        total: 0,
        pages: 0
      }
    };
  },

  // Get ticker for specific symbol
  getTicker: async (symbol: string): Promise<ApiResponse<Ticker>> => {
    return apiCall<Ticker>(`/market/ticker/${symbol}`);
  },

  // Get candle data
  getCandles: async (
    symbol: string, 
    timeFrame: TimeFrame = TimeFrame['1h'], 
    limit: number = 100
  ): Promise<ApiResponse<Candle[]>> => {
    return apiCall<Candle[]>(
      `/market/candles/${symbol}?timeFrame=${timeFrame}&limit=${limit}`
    );
  },

  // Get market data (tickers + candles + indicators)
  getMarketData: async (symbol: string): Promise<ApiResponse<MarketData>> => {
    return apiCall<MarketData>(`/market/data/${symbol}`);
  },

  // Search markets
  searchMarkets: async (query: string): Promise<ApiResponse<Ticker[]>> => {
    return apiCall<Ticker[]>(`/market/search?q=${encodeURIComponent(query)}`);
  },

  // Get market stats
  getMarketStats: async (): Promise<ApiResponse<any>> => {
    return apiCall('/market/stats');
  },

  // Subscribe to real-time updates
  subscribeToUpdates: (symbols: string[], callback: (data: Ticker) => void) => {
    const ws = new WebSocket(`${WS_URL}/market`);
    
    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        channels: symbols.map(symbol => `ticker.${symbol}`)
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage<Ticker> = JSON.parse(event.data);
        if (message.type === 'ticker_update') {
          callback(message.data);
        }
      } catch (error) {
        console.error('WebSocket message parsing error:', error);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    // Return cleanup function
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'unsubscribe',
          channels: symbols.map(symbol => `ticker.${symbol}`)
        }));
      }
      ws.close();
    };
  }
};

// Portfolio API
export const portfolioApi = {
  // Get portfolio data
  getPortfolio: async (userId?: string): Promise<ApiResponse<Portfolio>> => {
    const endpoint = userId ? `/portfolio/${userId}` : '/portfolio';
    return apiCall<Portfolio>(endpoint);
  },

  // Update portfolio
  updatePortfolio: async (
    portfolio: Partial<Portfolio>
  ): Promise<ApiResponse<Portfolio>> => {
    return apiCall<Portfolio>('/portfolio', {
      method: 'PUT',
      body: JSON.stringify(portfolio)
    });
  },

  // Get positions
  getPositions: async (): Promise<ApiResponse<Position[]>> => {
    return apiCall<Position[]>('/portfolio/positions');
  },

  // Add position
  addPosition: async (position: Partial<Position>): Promise<ApiResponse<Position>> => {
    return apiCall<Position>('/portfolio/positions', {
      method: 'POST',
      body: JSON.stringify(position)
    });
  },

  // Update position
  updatePosition: async (
    positionId: string, 
    updates: Partial<Position>
  ): Promise<ApiResponse<Position>> => {
    return apiCall<Position>(`/portfolio/positions/${positionId}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  },

  // Close position
  closePosition: async (positionId: string): Promise<ApiResponse<any>> => {
    return apiCall(`/portfolio/positions/${positionId}`, {
      method: 'DELETE'
    });
  },

  // Get portfolio performance
  getPerformance: async (period: string = '7d'): Promise<ApiResponse<any>> => {
    return apiCall(`/portfolio/performance?period=${period}`);
  }
};

// Signals API
export const signalsApi = {
  // Get trading signals
  getSignals: async (symbol?: string): Promise<ApiResponse<Signal[]>> => {
    const endpoint = symbol ? `/signals?symbol=${symbol}` : '/signals';
    return apiCall<Signal[]>(endpoint);
  },

  // Get hybrid signals
  getHybridSignals: async (symbol?: string): Promise<ApiResponse<HybridSignal[]>> => {
    const endpoint = symbol ? `/signals/hybrid?symbol=${symbol}` : '/signals/hybrid';
    return apiCall<HybridSignal[]>(endpoint);
  },

  // Get signal by ID
  getSignal: async (signalId: string): Promise<ApiResponse<Signal>> => {
    return apiCall<Signal>(`/signals/${signalId}`);
  },

  // Create new signal
  createSignal: async (signal: Partial<Signal>): Promise<ApiResponse<Signal>> => {
    return apiCall<Signal>('/signals', {
      method: 'POST',
      body: JSON.stringify(signal)
    });
  },

  // Update signal status
  updateSignalStatus: async (
    signalId: string, 
    status: string
  ): Promise<ApiResponse<Signal>> => {
    return apiCall<Signal>(`/signals/${signalId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status })
    });
  },

  // Get signal performance
  getSignalPerformance: async (period: string = '7d'): Promise<ApiResponse<any>> => {
    return apiCall(`/signals/performance?period=${period}`);
  },

  // Subscribe to signal updates
  subscribeToSignals: (callback: (signal: Signal) => void) => {
    const ws = new WebSocket(`${WS_URL}/signals`);
    
    ws.onopen = () => {
      ws.send(JSON.stringify({
        type: 'subscribe',
        channel: 'signals'
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage<Signal> = JSON.parse(event.data);
        if (message.type === 'signal_update') {
          callback(message.data);
        }
      } catch (error) {
        console.error('WebSocket message parsing error:', error);
      }
    };

    return () => {
      ws.close();
    };
  }
};

// Trading API
export const tradingApi = {
  // Get orders
  getOrders: async (status?: string): Promise<ApiResponse<Order[]>> => {
    const endpoint = status ? `/trading/orders?status=${status}` : '/trading/orders';
    return apiCall<Order[]>(endpoint);
  },

  // Create order
  createOrder: async (order: OrderRequest): Promise<ApiResponse<Order>> => {
    return apiCall<Order>('/trading/orders', {
      method: 'POST',
      body: JSON.stringify(order)
    });
  },

  // Cancel order
  cancelOrder: async (orderId: string): Promise<ApiResponse<Order>> => {
    return apiCall<Order>(`/trading/orders/${orderId}/cancel`, {
      method: 'POST'
    });
  },

  // Execute trade
  executeTrade: async (tradeData: any): Promise<ApiResponse<TradeExecution>> => {
    return apiCall<TradeExecution>('/trading/execute', {
      method: 'POST',
      body: JSON.stringify(tradeData)
    });
  },

  // Get trade history
  getTradeHistory: async (userId?: string): Promise<ApiResponse<TradeExecution[]>> => {
    const endpoint = userId ? `/trading/history/${userId}` : '/trading/history';
    return apiCall<TradeExecution[]>(endpoint);
  },

  // Get trading performance
  getTradingPerformance: async (period: string = '30d'): Promise<ApiResponse<any>> => {
    return apiCall(`/trading/performance?period=${period}`);
  }
};

// WebSocket API
export const websocketApi = {
  connect: (url?: string): WebSocket => {
    const wsUrl = url || WS_URL;
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket connected to:', wsUrl);
    };
    
    ws.onclose = () => {
      console.log('WebSocket disconnected');
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    return ws;
  },

  createReconnectingWebSocket: (url?: string) => {
    const wsUrl = url || WS_URL;
    let ws: WebSocket;
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;
    const reconnectDelay = 1000;

    const connect = () => {
      ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        console.log('WebSocket connected');
        reconnectAttempts = 0;
      };
      
      ws.onclose = () => {
        if (reconnectAttempts < maxReconnectAttempts) {
          reconnectAttempts++;
          console.log(`Reconnecting WebSocket (attempt ${reconnectAttempts})...`);
          setTimeout(connect, reconnectDelay * reconnectAttempts);
        }
      };
      
      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    };

    connect();

    return {
      getWebSocket: () => ws,
      disconnect: () => {
        reconnectAttempts = maxReconnectAttempts; // Prevent reconnection
        ws.close();
      }
    };
  }
};

// Export all APIs
export default {
  marketApi,
  portfolioApi,
  signalsApi,
  tradingApi,
  websocketApi
};

// Re-export types for convenience
export type {
  Ticker,
  Candle,
  MarketData,
  Signal,
  HybridSignal,
  Portfolio,
  Position,
  Order,
  OrderRequest,
  TradeExecution,
  ApiResponse,
  PaginatedResponse,
  WebSocketMessage
} from '@/types';
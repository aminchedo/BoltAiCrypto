// API Utilities and Helper Functions

import { 
  ApiResponse, 
  Ticker, 
  Signal, 
  Portfolio, 
  Order,
  OrderRequest,
  ChartTimeframe 
} from '@/types';
import { config } from '@/lib/config';

// Error handling utilities
export class ApiErrorHandler {
  static handle(error: any): string {
    if (error instanceof Error) {
      return error.message;
    }
    
    if (typeof error === 'string') {
      return error;
    }
    
    if (error?.response?.data?.message) {
      return error.response.data.message;
    }
    
    if (error?.message) {
      return error.message;
    }
    
    return 'An unknown error occurred';
  }

  static isNetworkError(error: any): boolean {
    return error?.code === 'NETWORK_ERROR' || 
           error?.name === 'NetworkError' ||
           error?.message?.includes('network') ||
           error?.message?.includes('fetch');
  }

  static isTimeoutError(error: any): boolean {
    return error?.code === 'TIMEOUT' ||
           error?.name === 'TimeoutError' ||
           error?.message?.includes('timeout');
  }

  static isAuthError(error: any): boolean {
    return error?.status === 401 || 
           error?.status === 403 ||
           error?.code === 'UNAUTHORIZED';
  }

  static isServerError(error: any): boolean {
    return error?.status >= 500 || 
           error?.code === 'SERVER_ERROR';
  }

  static getErrorType(error: any): 'network' | 'timeout' | 'auth' | 'server' | 'client' | 'unknown' {
    if (this.isNetworkError(error)) return 'network';
    if (this.isTimeoutError(error)) return 'timeout';
    if (this.isAuthError(error)) return 'auth';
    if (this.isServerError(error)) return 'server';
    if (error?.status >= 400 && error?.status < 500) return 'client';
    return 'unknown';
  }
}

// Retry mechanism utilities
export class RetryManager {
  static async retry<T>(
    fn: () => Promise<T>,
    maxAttempts: number = 3,
    delay: number = 1000,
    backoff: boolean = true
  ): Promise<T> {
    let lastError: any;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error;
        
        // Don't retry on client errors (4xx) except 429 (rate limit)
        if (ApiErrorHandler.isAuthError(error) || 
            (error?.status >= 400 && error?.status < 500 && error?.status !== 429)) {
          throw error;
        }
        
        if (attempt === maxAttempts) {
          throw lastError;
        }
        
        const currentDelay = backoff ? delay * Math.pow(2, attempt - 1) : delay;
        await new Promise(resolve => setTimeout(resolve, currentDelay));
      }
    }
    
    throw lastError;
  }

  static async retryWithJitter<T>(
    fn: () => Promise<T>,
    maxAttempts: number = 3,
    baseDelay: number = 1000
  ): Promise<T> {
    return this.retry(
      fn,
      maxAttempts,
      baseDelay + Math.random() * 1000, // Add jitter
      true
    );
  }
}

// Cache utilities
export class CacheManager {
  private static cache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  static set(key: string, data: any, ttl: number = 300000): void { // 5 minutes default
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  static get<T>(key: string): T | null {
    const item = this.cache.get(key);
    
    if (!item) return null;
    
    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key);
      return null;
    }
    
    return item.data as T;
  }

  static has(key: string): boolean {
    const item = this.cache.get(key);
    
    if (!item) return false;
    
    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key);
      return false;
    }
    
    return true;
  }

  static delete(key: string): void {
    this.cache.delete(key);
  }

  static clear(): void {
    this.cache.clear();
  }

  static cleanup(): void {
    const now = Date.now();
    for (const [key, item] of this.cache.entries()) {
      if (now - item.timestamp > item.ttl) {
        this.cache.delete(key);
      }
    }
  }

  static getStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    };
  }
}

// Data validation utilities
export class DataValidator {
  static isValidTicker(data: any): data is Ticker {
    return data &&
           typeof data.symbol === 'string' &&
           typeof data.price === 'number' &&
           typeof data.change24h === 'number' &&
           typeof data.volume24h === 'number';
  }

  static isValidSignal(data: any): data is Signal {
    return data &&
           typeof data.id === 'string' &&
           typeof data.symbol === 'string' &&
           ['BUY', 'SELL', 'HOLD'].includes(data.direction) &&
           typeof data.confidence === 'number' &&
           data.confidence >= 0 && data.confidence <= 100;
  }

  static isValidOrder(data: any): data is OrderRequest {
    return data &&
           typeof data.symbol === 'string' &&
           ['BUY', 'SELL'].includes(data.side) &&
           ['MARKET', 'LIMIT', 'STOP', 'STOP_LIMIT'].includes(data.type) &&
           typeof data.quantity === 'number' &&
           data.quantity > 0;
  }

  static isValidPortfolio(data: any): data is Portfolio {
    return data &&
           typeof data.totalValue === 'number' &&
           typeof data.availableBalance === 'number' &&
           Array.isArray(data.positions);
  }

  static sanitizeSymbol(symbol: string): string {
    return symbol.toUpperCase().trim();
  }

  static isValidTimeframe(timeframe: string): timeframe is ChartTimeframe {
    const validTimeframes: ChartTimeframe[] = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M'];
    return validTimeframes.includes(timeframe as ChartTimeframe);
  }
}

// Rate limiting utilities
export class RateLimiter {
  private static limits = new Map<string, { count: number; resetTime: number }>();

  static isAllowed(
    key: string, 
    maxRequests: number = 100, 
    windowMs: number = 60000
  ): boolean {
    const now = Date.now();
    const limit = this.limits.get(key);

    if (!limit || now > limit.resetTime) {
      this.limits.set(key, { count: 1, resetTime: now + windowMs });
      return true;
    }

    if (limit.count >= maxRequests) {
      return false;
    }

    limit.count++;
    return true;
  }

  static getRemainingRequests(
    key: string, 
    maxRequests: number = 100
  ): number {
    const limit = this.limits.get(key);
    if (!limit) return maxRequests;
    
    return Math.max(0, maxRequests - limit.count);
  }

  static getResetTime(key: string): number | null {
    const limit = this.limits.get(key);
    return limit ? limit.resetTime : null;
  }

  static cleanup(): void {
    const now = Date.now();
    for (const [key, limit] of this.limits.entries()) {
      if (now > limit.resetTime) {
        this.limits.delete(key);
      }
    }
  }
}

// URL utilities
export class UrlUtils {
  static buildUrl(baseUrl: string, path: string, params?: Record<string, any>): string {
    const url = new URL(path, baseUrl);
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, String(value));
        }
      });
    }
    
    return url.toString();
  }

  static parseQueryParams(search: string): Record<string, string> {
    const params = new URLSearchParams(search);
    const result: Record<string, string> = {};
    
    for (const [key, value] of params.entries()) {
      result[key] = value;
    }
    
    return result;
  }

  static stringifyParams(params: Record<string, any>): string {
    const searchParams = new URLSearchParams();
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, String(value));
      }
    });
    
    return searchParams.toString();
  }
}

// Format utilities
export class FormatUtils {
  static formatPrice(price: number, decimals: number = 2): string {
    return new Intl.NumberFormat('en-US', {
      style: 'decimal',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(price);
  }

  static formatCurrency(amount: number, currency: string = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency
    }).format(amount);
  }

  static formatPercentage(value: number, decimals: number = 2): string {
    return new Intl.NumberFormat('en-US', {
      style: 'percent',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(value / 100);
  }

  static formatVolume(volume: number): string {
    if (volume >= 1e9) {
      return `${(volume / 1e9).toFixed(2)}B`;
    } else if (volume >= 1e6) {
      return `${(volume / 1e6).toFixed(2)}M`;
    } else if (volume >= 1e3) {
      return `${(volume / 1e3).toFixed(2)}K`;
    }
    return volume.toFixed(2);
  }

  static formatTimeAgo(timestamp: number | string): string {
    const now = Date.now();
    const time = typeof timestamp === 'string' ? new Date(timestamp).getTime() : timestamp;
    const diff = now - time;

    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return `${seconds}s ago`;
  }

  static formatDuration(ms: number): string {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  }
}

// Performance utilities
export class PerformanceUtils {
  private static measurements = new Map<string, number>();

  static startMeasure(name: string): void {
    this.measurements.set(name, performance.now());
  }

  static endMeasure(name: string): number {
    const start = this.measurements.get(name);
    if (!start) return 0;
    
    const duration = performance.now() - start;
    this.measurements.delete(name);
    
    if (config.performance.debug) {
      console.log(`⏱️ ${name}: ${duration.toFixed(2)}ms`);
    }
    
    return duration;
  }

  static measure<T>(name: string, fn: () => T): T {
    this.startMeasure(name);
    const result = fn();
    this.endMeasure(name);
    return result;
  }

  static async measureAsync<T>(name: string, fn: () => Promise<T>): Promise<T> {
    this.startMeasure(name);
    const result = await fn();
    this.endMeasure(name);
    return result;
  }

  static debounce<T extends (...args: any[]) => any>(
    fn: T,
    delay: number
  ): (...args: Parameters<T>) => void {
    let timeoutId: NodeJS.Timeout;
    
    return (...args: Parameters<T>) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn(...args), delay);
    };
  }

  static throttle<T extends (...args: any[]) => any>(
    fn: T,
    delay: number
  ): (...args: Parameters<T>) => void {
    let lastCall = 0;
    
    return (...args: Parameters<T>) => {
      const now = Date.now();
      if (now - lastCall >= delay) {
        lastCall = now;
        fn(...args);
      }
    };
  }
}

// Symbol utilities
export class SymbolUtils {
  static parseSymbol(symbol: string): { base: string; quote: string } {
    const cleanSymbol = symbol.toUpperCase().trim();
    
    // Common quote currencies
    const quotes = ['USDT', 'USDC', 'USD', 'BTC', 'ETH', 'BNB', 'BUSD'];
    
    for (const quote of quotes) {
      if (cleanSymbol.endsWith(quote)) {
        return {
          base: cleanSymbol.slice(0, -quote.length),
          quote
        };
      }
    }
    
    // Fallback - assume last 3-4 characters are quote
    const quoteLength = cleanSymbol.length >= 6 ? 4 : 3;
    return {
      base: cleanSymbol.slice(0, -quoteLength),
      quote: cleanSymbol.slice(-quoteLength)
    };
  }

  static formatSymbol(base: string, quote: string): string {
    return `${base.toUpperCase()}${quote.toUpperCase()}`;
  }

  static isValidSymbol(symbol: string): boolean {
    const cleaned = symbol.replace(/[^A-Z0-9]/g, '');
    return cleaned.length >= 4 && cleaned.length <= 12;
  }

  static getSymbolInfo(symbol: string): {
    symbol: string;
    base: string;
    quote: string;
    displayName: string;
  } {
    const { base, quote } = this.parseSymbol(symbol);
    return {
      symbol: symbol.toUpperCase(),
      base,
      quote,
      displayName: `${base}/${quote}`
    };
  }
}

// WebSocket utilities
export class WebSocketUtils {
  static isSupported(): boolean {
    return typeof WebSocket !== 'undefined';
  }

  static getReadyStateText(readyState: number): string {
    switch (readyState) {
      case WebSocket.CONNECTING: return 'CONNECTING';
      case WebSocket.OPEN: return 'OPEN';
      case WebSocket.CLOSING: return 'CLOSING';
      case WebSocket.CLOSED: return 'CLOSED';
      default: return 'UNKNOWN';
    }
  }

  static createReconnectingWebSocket(
    url: string,
    protocols?: string | string[],
    options: {
      maxReconnectAttempts?: number;
      reconnectDelay?: number;
      maxReconnectDelay?: number;
      reconnectDecay?: number;
      timeoutInterval?: number;
    } = {}
  ): WebSocket & { reconnect: () => void; disconnect: () => void } {
    const {
      maxReconnectAttempts = 5,
      reconnectDelay = 1000,
      maxReconnectDelay = 30000,
      reconnectDecay = 1.5,
      timeoutInterval = 2000
    } = options;

    let ws: WebSocket;
    let reconnectAttempts = 0;
    let shouldReconnect = true;

    function connect() {
      ws = new WebSocket(url, protocols);
      
      ws.onopen = () => {
        reconnectAttempts = 0;
        console.log(`🔗 WebSocket connected: ${url}`);
      };

      ws.onclose = () => {
        if (shouldReconnect && reconnectAttempts < maxReconnectAttempts) {
          const delay = Math.min(
            reconnectDelay * Math.pow(reconnectDecay, reconnectAttempts),
            maxReconnectDelay
          );
          
          reconnectAttempts++;
          console.log(`🔄 Reconnecting in ${delay}ms (attempt ${reconnectAttempts}/${maxReconnectAttempts})`);
          
          setTimeout(connect, delay);
        }
      };

      ws.onerror = (error) => {
        console.error(`❌ WebSocket error: ${url}`, error);
      };
    }

    connect();

    return Object.assign(ws, {
      reconnect: () => {
        shouldReconnect = true;
        reconnectAttempts = 0;
        if (ws.readyState !== WebSocket.OPEN) {
          connect();
        }
      },
      disconnect: () => {
        shouldReconnect = false;
        ws.close();
      }
    });
  }
}

// Local storage utilities
export class StorageUtils {
  static setItem(key: string, value: any): boolean {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error('Failed to set localStorage item:', error);
      return false;
    }
  }

  static getItem<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Failed to get localStorage item:', error);
      return null;
    }
  }

  static removeItem(key: string): boolean {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error('Failed to remove localStorage item:', error);
      return false;
    }
  }

  static clear(): boolean {
    try {
      localStorage.clear();
      return true;
    } catch (error) {
      console.error('Failed to clear localStorage:', error);
      return false;
    }
  }

  static isSupported(): boolean {
    try {
      const test = '__storage_test__';
      localStorage.setItem(test, test);
      localStorage.removeItem(test);
      return true;
    } catch {
      return false;
    }
  }
}

// Export all utilities
export {
  ApiErrorHandler,
  RetryManager,
  CacheManager,
  DataValidator,
  RateLimiter,
  UrlUtils,
  FormatUtils,
  PerformanceUtils,
  SymbolUtils,
  WebSocketUtils,
  StorageUtils
};

export default {
  ApiErrorHandler,
  RetryManager,
  CacheManager,
  DataValidator,
  RateLimiter,
  UrlUtils,
  FormatUtils,
  PerformanceUtils,
  SymbolUtils,
  WebSocketUtils,
  StorageUtils
};
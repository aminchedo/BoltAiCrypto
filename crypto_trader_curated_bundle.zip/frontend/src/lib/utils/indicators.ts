// Technical indicators calculation utilities

/**
 * Calculate Relative Strength Index (RSI)
 * @param prices Array of closing prices
 * @param period RSI period (default: 14)
 * @returns Array of RSI values
 */
export function calculateRSI(prices: number[], period: number = 14): number[] {
  if (prices.length < period + 1) {
    return Array(prices.length).fill(50); // Not enough data, return neutral values
  }

  const deltas = [];
  for (let i = 1; i < prices.length; i++) {
    deltas.push(prices[i] - prices[i - 1]);
  }

  const gains = deltas.map(d => d > 0 ? d : 0);
  const losses = deltas.map(d => d < 0 ? Math.abs(d) : 0);

  // Calculate average gains and losses
  let avgGain = gains.slice(0, period).reduce((sum, val) => sum + val, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((sum, val) => sum + val, 0) / period;

  const rsiValues = [100 - (100 / (1 + avgGain / (avgLoss || 0.01)))];

  // Calculate RSI using Wilder's smoothing method
  for (let i = period; i < deltas.length; i++) {
    avgGain = ((avgGain * (period - 1)) + gains[i]) / period;
    avgLoss = ((avgLoss * (period - 1)) + losses[i]) / period;
    
    const rs = avgGain / (avgLoss || 0.01); // Avoid division by zero
    const rsi = 100 - (100 / (1 + rs));
    
    rsiValues.push(rsi);
  }

  // Pad the beginning with null values
  const paddedRsi = Array(period).fill(null).concat(rsiValues);
  return paddedRsi;
}

/**
 * Calculate Moving Average Convergence Divergence (MACD)
 * @param prices Array of closing prices
 * @param fastPeriod Fast EMA period (default: 12)
 * @param slowPeriod Slow EMA period (default: 26)
 * @param signalPeriod Signal EMA period (default: 9)
 * @returns Object with MACD line, signal line, and histogram values
 */
export function calculateMACD(
  prices: number[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): { macdLine: number[], signalLine: number[], histogram: number[] } {
  // Calculate EMAs
  const fastEMA = calculateEMA(prices, fastPeriod);
  const slowEMA = calculateEMA(prices, slowPeriod);
  
  // Calculate MACD line (fast EMA - slow EMA)
  const macdLine = fastEMA.map((fast, i) => {
    if (fast === null || slowEMA[i] === null) return null;
    return fast - slowEMA[i];
  });
  
  // Calculate signal line (EMA of MACD line)
  const validMacdValues = macdLine.filter(val => val !== null) as number[];
  const signalLine = calculateEMA(validMacdValues, signalPeriod);
  
  // Pad signal line with nulls to match MACD line length
  const paddedSignalLine = Array(macdLine.length - signalLine.length).fill(null).concat(signalLine);
  
  // Calculate histogram (MACD line - signal line)
  const histogram = macdLine.map((macd, i) => {
    if (macd === null || paddedSignalLine[i] === null) return null;
    return macd - paddedSignalLine[i];
  });
  
  return {
    macdLine: macdLine as number[],
    signalLine: paddedSignalLine as number[],
    histogram: histogram as number[],
  };
}

/**
 * Calculate Exponential Moving Average (EMA)
 * @param prices Array of prices
 * @param period EMA period
 * @returns Array of EMA values
 */
export function calculateEMA(prices: number[], period: number): (number | null)[] {
  if (prices.length < period) {
    return Array(prices.length).fill(null);
  }
  
  // Start with SMA for the first EMA value
  const sma = prices.slice(0, period).reduce((sum, price) => sum + price, 0) / period;
  const multiplier = 2 / (period + 1);
  
  const emaValues = [sma];
  
  // Calculate EMA values
  for (let i = period; i < prices.length; i++) {
    const ema = (prices[i] - emaValues[emaValues.length - 1]) * multiplier + emaValues[emaValues.length - 1];
    emaValues.push(ema);
  }
  
  // Pad the beginning with null values
  const paddedEma = Array(period - 1).fill(null).concat(emaValues);
  return paddedEma;
}

/**
 * Calculate Bollinger Bands
 * @param prices Array of closing prices
 * @param period Period for moving average (default: 20)
 * @param stdDev Number of standard deviations (default: 2)
 * @returns Object with upper band, middle band (SMA), and lower band values
 */
export function calculateBollingerBands(
  prices: number[],
  period: number = 20,
  stdDev: number = 2
): { upper: number[], middle: number[], lower: number[] } {
  if (prices.length < period) {
    return {
      upper: Array(prices.length).fill(null),
      middle: Array(prices.length).fill(null),
      lower: Array(prices.length).fill(null),
    };
  }
  
  const middle: number[] = [];
  const upper: number[] = [];
  const lower: number[] = [];
  
  // Calculate SMA and bands
  for (let i = period - 1; i < prices.length; i++) {
    const slice = prices.slice(i - period + 1, i + 1);
    const sma = slice.reduce((sum, price) => sum + price, 0) / period;
    
    // Calculate standard deviation
    const squaredDiffs = slice.map(price => Math.pow(price - sma, 2));
    const variance = squaredDiffs.reduce((sum, diff) => sum + diff, 0) / period;
    const standardDeviation = Math.sqrt(variance);
    
    middle.push(sma);
    upper.push(sma + stdDev * standardDeviation);
    lower.push(sma - stdDev * standardDeviation);
  }
  
  // Pad the beginning with null values
  const padding = Array(period - 1).fill(null);
  
  return {
    upper: padding.concat(upper),
    middle: padding.concat(middle),
    lower: padding.concat(lower),
  };
}

/**
 * Format indicator data for lightweight-charts
 * @param timestamps Array of timestamps
 * @param values Array of indicator values
 * @returns Formatted data for lightweight-charts
 */
export function formatIndicatorData(timestamps: number[], values: (number | null)[]): { time: number, value: number | null }[] {
  return timestamps.map((time, i) => ({
    time,
    value: values[i]
  }));
}
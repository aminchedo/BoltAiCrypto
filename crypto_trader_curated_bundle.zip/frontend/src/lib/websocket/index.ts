// WebSocket client for real-time data

import { io, Socket } from 'socket.io-client';
import { create } from 'zustand';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000';

type WebSocketState = {
  socket: Socket | null;
  isConnected: boolean;
  reconnectAttempts: number;
  lastPing: number | null;
  subscriptions: Map<string, Set<(data: any) => void>>;
  connect: () => void;
  disconnect: () => void;
  subscribe: (channel: string, callback: (data: any) => void) => () => void;
  unsubscribe: (channel: string, callback: (data: any) => void) => void;
  send: (event: string, data: any) => void;
};

export const useWebSocket = create<WebSocketState>((set, get) => ({
  socket: null,
  isConnected: false,
  reconnectAttempts: 0,
  lastPing: null,
  subscriptions: new Map(),
  
  connect: () => {
    const { socket } = get();
    
    if (socket && socket.connected) {
      return;
    }
    
    const newSocket = io(WS_URL, {
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 20000,
      transports: ['websocket'],
    });
    
    newSocket.on('connect', () => {
      set({
        isConnected: true,
        reconnectAttempts: 0,
        lastPing: Date.now(),
      });
      
      console.log('WebSocket connected');
      
      // Resubscribe to all channels
      const { subscriptions } = get();
      subscriptions.forEach((callbacks, channel) => {
        newSocket.emit('subscribe', { channel });
      });
    });
    
    newSocket.on('disconnect', () => {
      set({
        isConnected: false,
      });
      console.log('WebSocket disconnected');
    });
    
    newSocket.on('reconnect_attempt', (attempt) => {
      set({
        reconnectAttempts: attempt,
      });
      console.log(`WebSocket reconnect attempt ${attempt}`);
    });
    
    newSocket.on('reconnect_failed', () => {
      console.log('WebSocket reconnect failed');
    });
    
    newSocket.on('pong', () => {
      set({
        lastPing: Date.now(),
      });
    });
    
    // Handle incoming messages
    newSocket.on('message', (data) => {
      const { channel, payload } = data;
      const { subscriptions } = get();
      
      const callbacks = subscriptions.get(channel);
      if (callbacks) {
        callbacks.forEach((callback) => {
          try {
            callback(payload);
          } catch (error) {
            console.error(`Error in WebSocket callback for channel ${channel}:`, error);
          }
        });
      }
    });
    
    set({ socket: newSocket });
    
    // Setup ping interval
    const pingInterval = setInterval(() => {
      if (newSocket.connected) {
        newSocket.emit('ping');
      }
    }, 30000);
    
    // Clean up on unmount
    return () => {
      clearInterval(pingInterval);
      newSocket.disconnect();
      set({ socket: null, isConnected: false });
    };
  },
  
  disconnect: () => {
    const { socket } = get();
    if (socket) {
      socket.disconnect();
      set({ socket: null, isConnected: false });
    }
  },
  
  subscribe: (channel, callback) => {
    const { socket, subscriptions } = get();
    
    // Add to subscriptions
    if (!subscriptions.has(channel)) {
      subscriptions.set(channel, new Set());
      
      // Subscribe on server if connected
      if (socket && socket.connected) {
        socket.emit('subscribe', { channel });
      }
    }
    
    subscriptions.get(channel)?.add(callback);
    set({ subscriptions: new Map(subscriptions) });
    
    // Return unsubscribe function
    return () => {
      get().unsubscribe(channel, callback);
    };
  },
  
  unsubscribe: (channel, callback) => {
    const { subscriptions, socket } = get();
    
    const callbacks = subscriptions.get(channel);
    if (callbacks) {
      callbacks.delete(callback);
      
      // If no more callbacks, unsubscribe from channel
      if (callbacks.size === 0) {
        subscriptions.delete(channel);
        
        // Unsubscribe on server if connected
        if (socket && socket.connected) {
          socket.emit('unsubscribe', { channel });
        }
      }
      
      set({ subscriptions: new Map(subscriptions) });
    }
  },
  
  send: (event, data) => {
    const { socket } = get();
    if (socket && socket.connected) {
      socket.emit(event, data);
    } else {
      console.error('Cannot send message: WebSocket not connected');
    }
  },
}));

// Hook for subscribing to specific channels
export function useWebSocketSubscription<T>(channel: string, initialData: T) {
  const [data, setData] = useState<T>(initialData);
  const { subscribe, isConnected } = useWebSocket();
  
  useEffect(() => {
    if (isConnected) {
      const unsubscribe = subscribe(channel, (newData) => {
        setData(newData);
      });
      
      return unsubscribe;
    }
  }, [channel, isConnected, subscribe]);
  
  return data;
}

// Initialize WebSocket connection
export function initializeWebSocket() {
  const { connect } = useWebSocket.getState();
  connect();
}

// Export WebSocket instance for direct usage
export const getWebSocketInstance = () => useWebSocket.getState().socket;
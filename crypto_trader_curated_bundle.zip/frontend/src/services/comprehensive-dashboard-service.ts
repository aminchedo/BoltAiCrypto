// =================== COMPREHENSIVE DASHBOARD SERVICE ===================
// This file consolidates ALL API services, utilities, and data management

// =================== TYPES & INTERFACES ===================
export interface CryptoAsset {
    symbol: string;
    name: string;
    price: number;
    change: number;
    volume: number;
    marketCap: number;
    icon: string;
    gradient: string;
    chartData: ChartDataPoint[];
}

export interface ChartDataPoint {
    time: number;
    price: number;
    volume: number;
    high: number;
    low: number;
}

export interface Position {
    id: number;
    symbol: string;
    side: 'long' | 'short';
    entryPrice: number;
    currentPrice: number;
    amount: number;
    leverage: number;
    unrealizedPnL: number;
    timestamp: number;
}

export interface Order {
    id: number;
    symbol: string;
    type: string;
    orderType: string;
    amount: number;
    price: number;
    status: string;
    timestamp: number;
}

export interface Portfolio {
    totalValue: number;
    availableBalance: number;
    totalPnL: number;
    totalPnLPercent: number;
    holdings: Record<string, {
        amount: number;
        avgPrice: number;
        currentValue: number;
    }>;
}

export interface Notification {
    id: number;
    message: string;
    type: 'success' | 'error' | 'info' | 'warning';
    timestamp: number;
}

export interface NewsItem {
    id: string;
    title: string;
    description: string;
    url: string;
    source: string;
    publishedAt: string;
    sentiment: 'positive' | 'negative' | 'neutral';
    sentimentScore: number;
    category: string;
    imageUrl?: string;
    symbols?: string[];
}

export interface MarketSentiment {
    fearGreedIndex: number;
    fearGreedClassification: string;
    socialSentiment: number;
    newsSentiment: number;
    marketMomentum: number;
    volatilityIndex: number;
    tradingVolume: number;
    overallGrade: string;
    lastUpdate: string;
}

// =================== UTILITY FUNCTIONS ===================
export const formatCurrency = (value: number, currency: string = 'USD', compact: boolean = false): string => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency,
        notation: compact ? 'compact' : 'standard',
        minimumFractionDigits: compact ? 1 : 2,
        maximumFractionDigits: compact ? 2 : 2,
    }).format(value);
};

export const formatPercentage = (value: number, decimals: number = 2): string => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(decimals)}%`;
};

export const formatNumber = (value: number, decimals: number = 2, compact: boolean = false): string => {
    return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
        notation: compact ? 'compact' : 'standard'
    }).format(value);
};

export const formatVolume = (volume: number): string => {
    if (volume >= 1000000000) return `${(volume / 1000000000).toFixed(1)}B`;
    if (volume >= 1000000) return `${(volume / 1000000).toFixed(1)}M`;
    if (volume >= 1000) return `${(volume / 1000).toFixed(1)}K`;
    return volume.toString();
};

export const formatDate = (dateString: string, options?: Intl.DateTimeFormatOptions): string => {
    const defaultOptions: Intl.DateTimeFormatOptions = {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString('en-US', { ...defaultOptions, ...options });
};

export const getCryptoColor = (symbol: string): string => {
    const colors: { [key: string]: string } = {
        'BTC': '#F7931A', 'ETH': '#627EEA', 'BNB': '#F3BA2F', 'ADA': '#0033AD',
        'SOL': '#9945FF', 'DOT': '#E6007A', 'MATIC': '#8247E5', 'AVAX': '#E84142',
        'LINK': '#375BD2'
    };
    return colors[symbol.toUpperCase()] || '#8B5CF6';
};

export const getRiskColor = (risk: string): string => {
    switch (risk.toUpperCase()) {
        case 'LOW': return 'text-green-600 bg-green-100 dark:bg-green-900/30 dark:text-green-400';
        case 'MEDIUM': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30 dark:text-yellow-400';
        case 'HIGH': return 'text-red-600 bg-red-100 dark:bg-red-900/30 dark:text-red-400';
        default: return 'text-gray-600 bg-gray-100 dark:bg-gray-700 dark:text-gray-400';
    }
};

export const calculatePercentageChange = (current: number, previous: number): number => {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
};

export const calculateRSI = (prices: number[], period: number = 14): number => {
    if (prices.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const change = prices[i] - prices[i - 1];
        if (change > 0) gains += change;
        else losses -= change;
    }
    const avgGain = gains / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
};

export const calculateMovingAverage = (prices: number[], period: number): number[] => {
    const ma: number[] = [];
    for (let i = period - 1; i < prices.length; i++) {
        const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        ma.push(sum / period);
    }
    return ma;
};

export const debounce = <T extends (...args: any[]) => any>(func: T, wait: number): ((...args: Parameters<T>) => void) => {
    let timeout: NodeJS.Timeout;
    return (...args: Parameters<T>) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func(...args), wait);
    };
};

export const throttle = <T extends (...args: any[]) => any>(func: T, limit: number): ((...args: Parameters<T>) => void) => {
    let inThrottle: boolean;
    return (...args: Parameters<T>) => {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
};

export const generateId = (): string => {
    return Math.random().toString(36).substr(2, 9);
};

export const timeAgo = (date: string | Date): string => {
    const now = new Date();
    const past = new Date(date);
    const diffInSeconds = Math.floor((now.getTime() - past.getTime()) / 1000);

    if (diffInSeconds < 60) return 'just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
};

// =================== MOCK DATA GENERATORS ===================
export const generateMockAssets = (): CryptoAsset[] => [
    {
        symbol: 'BTC', name: 'Bitcoin', price: 67420.80, change: 3.21, volume: 28.5, marketCap: 1320,
        icon: '₿', gradient: 'from-orange-400 to-orange-600',
        chartData: Array.from({ length: 50 }, (_, i) => ({
            time: i, price: 67420.80 + (Math.random() - 0.5) * 4000,
            volume: Math.random() * 0.8 + 0.2,
            high: 67420.80 + (Math.random() - 0.5) * 4000 + 200,
            low: 67420.80 + (Math.random() - 0.5) * 4000 - 200
        }))
    },
    {
        symbol: 'ETH', name: 'Ethereum', price: 3891.45, change: 1.82, volume: 15.3, marketCap: 468,
        icon: 'Ξ', gradient: 'from-blue-400 to-blue-600',
        chartData: Array.from({ length: 50 }, (_, i) => ({
            time: i, price: 3891.45 + (Math.random() - 0.5) * 400,
            volume: Math.random() * 0.8 + 0.2,
            high: 3891.45 + (Math.random() - 0.5) * 400 + 50,
            low: 3891.45 + (Math.random() - 0.5) * 400 - 50
        }))
    },
    {
        symbol: 'ADA', name: 'Cardano', price: 0.524, change: -0.52, volume: 1.2, marketCap: 18.4,
        icon: '₳', gradient: 'from-indigo-400 to-indigo-600',
        chartData: Array.from({ length: 50 }, (_, i) => ({
            time: i, price: 0.524 + (Math.random() - 0.5) * 0.08,
            volume: Math.random() * 0.8 + 0.2,
            high: 0.524 + (Math.random() - 0.5) * 0.08 + 0.01,
            low: 0.524 + (Math.random() - 0.5) * 0.08 - 0.01
        }))
    },
    {
        symbol: 'DOT', name: 'Polkadot', price: 8.34, change: 2.14, volume: 0.8, marketCap: 11.2,
        icon: '●', gradient: 'from-pink-400 to-pink-600',
        chartData: Array.from({ length: 24 }, (_, i) => ({
            time: i, price: 8.34 + (Math.random() - 0.5) * 1,
            volume: Math.random() * 0.8 + 0.2,
            high: 8.34 + (Math.random() - 0.5) * 1 + 0.2,
            low: 8.34 + (Math.random() - 0.5) * 1 - 0.2
        }))
    }
];

export const generateMockPortfolio = (): Portfolio => ({
    totalValue: 127543,
    availableBalance: 85420,
    totalPnL: 12500,
    totalPnLPercent: 11.1,
    holdings: {
        BTC: { amount: 1.2543, avgPrice: 52300, currentValue: 84523 },
        ETH: { amount: 8.432, avgPrice: 3200, currentValue: 32812 },
        ADA: { amount: 15000, avgPrice: 0.48, currentValue: 7860 },
        DOT: { amount: 500, avgPrice: 7.2, currentValue: 4170 }
    }
});

export const generateMockPositions = (): Position[] => [
    {
        id: 1, symbol: 'BTC', side: 'long', entryPrice: 65200, currentPrice: 67420.80,
        amount: 0.5, leverage: 1, unrealizedPnL: 1110, timestamp: Date.now() - 3600000
    },
    {
        id: 2, symbol: 'ETH', side: 'long', entryPrice: 3650, currentPrice: 3891.45,
        amount: 2.1, leverage: 1, unrealizedPnL: 507, timestamp: Date.now() - 7200000
    },
    {
        id: 3, symbol: 'ADA', side: 'short', entryPrice: 0.58, currentPrice: 0.524,
        amount: 5000, leverage: 2, unrealizedPnL: 560, timestamp: Date.now() - 1800000
    }
];

export const generateMockNews = (): NewsItem[] => [
    {
        id: '1',
        title: 'Bitcoin Surges Past $67,000 as Institutional Adoption Grows',
        description: 'Major financial institutions continue to show interest in cryptocurrency investments...',
        url: 'https://example.com/news1',
        source: 'CryptoNews',
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        sentiment: 'positive',
        sentimentScore: 0.8,
        category: 'market',
        symbols: ['BTC']
    },
    {
        id: '2',
        title: 'Ethereum 2.0 Update Shows Promising Results',
        description: 'The latest Ethereum upgrade demonstrates improved scalability and reduced gas fees...',
        url: 'https://example.com/news2',
        source: 'TechCrypto',
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        sentiment: 'positive',
        sentimentScore: 0.7,
        category: 'technology',
        symbols: ['ETH']
    }
];

export const generateMockMarketSentiment = (): MarketSentiment => ({
    fearGreedIndex: 65,
    fearGreedClassification: 'Greed',
    socialSentiment: 0.72,
    newsSentiment: 0.68,
    marketMomentum: 0.75,
    volatilityIndex: 0.45,
    tradingVolume: 0.82,
    overallGrade: 'B+',
    lastUpdate: new Date().toISOString()
});

// =================== API SERVICE CLASS ===================
class ComprehensiveDashboardService {
    private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
    private requestCounts = new Map<string, { count: number; resetTime: number }>();

    constructor() {
        this.initializeCache();
    }

    private initializeCache(): void {
        // Initialize with mock data
        this.setCache('assets', generateMockAssets(), 5);
        this.setCache('portfolio', generateMockPortfolio(), 5);
        this.setCache('positions', generateMockPositions(), 5);
        this.setCache('news', generateMockNews(), 10);
        this.setCache('sentiment', generateMockMarketSentiment(), 15);
    }

    private getCached<T>(key: string): T | null {
        const cached = this.cache.get(key);
        if (!cached) return null;
        if (Date.now() - cached.timestamp > cached.ttl * 60 * 1000) {
            this.cache.delete(key);
            return null;
        }
        return cached.data;
    }

    private setCache<T>(key: string, data: T, ttlMinutes: number): void {
        this.cache.set(key, { data, timestamp: Date.now(), ttl: ttlMinutes });
    }

    // Asset Management
    async getAssets(): Promise<CryptoAsset[]> {
        const cached = this.getCached<CryptoAsset[]>('assets');
        if (cached) return cached;

        const assets = generateMockAssets();
        this.setCache('assets', assets, 5);
        return assets;
    }

    async getAssetBySymbol(symbol: string): Promise<CryptoAsset | null> {
        const assets = await this.getAssets();
        return assets.find(asset => asset.symbol === symbol) || null;
    }

    // Portfolio Management
    async getPortfolio(): Promise<Portfolio> {
        const cached = this.getCached<Portfolio>('portfolio');
        if (cached) return cached;

        const portfolio = generateMockPortfolio();
        this.setCache('portfolio', portfolio, 5);
        return portfolio;
    }

    async getPositions(): Promise<Position[]> {
        const cached = this.getCached<Position[]>('positions');
        if (cached) return cached;

        const positions = generateMockPositions();
        this.setCache('positions', positions, 5);
        return positions;
    }

    // News and Sentiment
    async getNews(): Promise<NewsItem[]> {
        const cached = this.getCached<NewsItem[]>('news');
        if (cached) return cached;

        const news = generateMockNews();
        this.setCache('news', news, 10);
        return news;
    }

    async getMarketSentiment(): Promise<MarketSentiment> {
        const cached = this.getCached<MarketSentiment>('sentiment');
        if (cached) return cached;

        const sentiment = generateMockMarketSentiment();
        this.setCache('sentiment', sentiment, 15);
        return sentiment;
    }

    // Trading Operations
    async placeOrder(order: Omit<Order, 'id' | 'timestamp'>): Promise<Order> {
        const newOrder: Order = {
            ...order,
            id: Math.floor(Math.random() * 1000000),
            timestamp: Date.now()
        };

        // Simulate order processing
        await new Promise(resolve => setTimeout(resolve, 1000));

        return newOrder;
    }

    async closePosition(positionId: number): Promise<boolean> {
        // Simulate position closing
        await new Promise(resolve => setTimeout(resolve, 500));
        return true;
    }

    // Utility Methods
    clearCache(): void {
        this.cache.clear();
        this.initializeCache();
    }

    getServiceStatus(): Record<string, any> {
        return {
            cacheSize: this.cache.size,
            cachedKeys: Array.from(this.cache.keys()),
            uptime: Date.now(),
            status: 'operational'
        };
    }
}

// =================== EXPORT SINGLETON INSTANCE ===================
export const dashboardService = new ComprehensiveDashboardService();

// =================== REACT HOOKS ===================
import { useState, useEffect, useCallback } from 'react';

export const useAssets = () => {
    const [assets, setAssets] = useState<CryptoAsset[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchAssets = useCallback(async () => {
        try {
            setLoading(true);
            const data = await dashboardService.getAssets();
            setAssets(data);
            setError(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch assets');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchAssets();
        const interval = setInterval(fetchAssets, 30000); // Refresh every 30 seconds
        return () => clearInterval(interval);
    }, [fetchAssets]);

    return { assets, loading, error, refetch: fetchAssets };
};

export const usePortfolio = () => {
    const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchPortfolio = useCallback(async () => {
        try {
            setLoading(true);
            const data = await dashboardService.getPortfolio();
            setPortfolio(data);
            setError(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch portfolio');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchPortfolio();
        const interval = setInterval(fetchPortfolio, 30000);
        return () => clearInterval(interval);
    }, [fetchPortfolio]);

    return { portfolio, loading, error, refetch: fetchPortfolio };
};

export const usePositions = () => {
    const [positions, setPositions] = useState<Position[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchPositions = useCallback(async () => {
        try {
            setLoading(true);
            const data = await dashboardService.getPositions();
            setPositions(data);
            setError(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch positions');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchPositions();
        const interval = setInterval(fetchPositions, 15000); // Refresh every 15 seconds
        return () => clearInterval(interval);
    }, [fetchPositions]);

    return { positions, loading, error, refetch: fetchPositions };
};

export const useNews = () => {
    const [news, setNews] = useState<NewsItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchNews = useCallback(async () => {
        try {
            setLoading(true);
            const data = await dashboardService.getNews();
            setNews(data);
            setError(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch news');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchNews();
        const interval = setInterval(fetchNews, 60000); // Refresh every minute
        return () => clearInterval(interval);
    }, [fetchNews]);

    return { news, loading, error, refetch: fetchNews };
};

export const useMarketSentiment = () => {
    const [sentiment, setSentiment] = useState<MarketSentiment | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchSentiment = useCallback(async () => {
        try {
            setLoading(true);
            const data = await dashboardService.getMarketSentiment();
            setSentiment(data);
            setError(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch sentiment');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchSentiment();
        const interval = setInterval(fetchSentiment, 90000); // Refresh every 1.5 minutes
        return () => clearInterval(interval);
    }, [fetchSentiment]);

    return { sentiment, loading, error, refetch: fetchSentiment };
}; 
// Real Data Integration Service for Dashboard Pro
// This service integrates with the comprehensive API service while maintaining UI compatibility

import { apiService } from './apiService';

export interface DashboardData {
  marketData: MarketData[];
  portfolioData: PortfolioData;
  newsData: NewsItem[];
  sentimentData: SentimentData;
  whaleData: WhaleTransaction[];
  tradingSignals: TradingSignal[];
}

export interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  rank: number;
  color: string;
  logo?: string;
}

export interface PortfolioData {
  totalValue: number;
  change24h: number;
  changePercent: number;
  assets: PortfolioAsset[];
  availableBalance: number;
  marginUsed: number;
  unrealizedPnL: number;
}

export interface PortfolioAsset {
  symbol: string;
  name: string;
  amount: number;
  value: number;
  change24h: number;
  allocation: number;
  color: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  timestamp: Date;
  category: 'breaking' | 'analysis' | 'regulation' | 'technology' | 'market';
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'high' | 'medium' | 'low';
  coins: string[];
  readTime: number;
  url?: string;
}

export interface SentimentData {
  fearGreedIndex: number;
  classification: string;
  socialSentiment: number;
  newsSentiment: number;
  marketMomentum: number;
  volatilityIndex: number;
  overallGrade: string;
  lastUpdate: Date;
}

export interface WhaleTransaction {
  id: string;
  hash: string;
  from: string;
  to: string;
  value: string;
  valueUSD: number;
  timestamp: string;
  blockchain: string;
  symbol: string;
  type: 'transfer' | 'exchange_deposit' | 'exchange_withdrawal';
}

export interface TradingSignal {
  id: string;
  symbol: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  target: number;
  stopLoss: number;
  timestamp: Date;
  status: 'active' | 'executed' | 'expired' | 'cancelled';
  aiModel: string;
  riskLevel: 'low' | 'medium' | 'high';
  timeframe: string;
  volume: number;
  accuracy?: number;
  tags: string[];
  expectedReturn: number;
  reason: string;
}

class RealDataService {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  private updateCallbacks = new Map<string, Function[]>();

  constructor() {
    console.log('🚀 Real Data Service initialized for Dashboard Pro');
  }

  // Cache management
  private getCached<T>(key: string): T | null {
    const cached = this.cache.get(key);
    if (!cached) return null;
    
    if (Date.now() > cached.timestamp + cached.ttl) {
      this.cache.delete(key);
      return null;
    }
    
    return cached.data as T;
  }

  private setCache<T>(key: string, data: T, ttlMinutes: number): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMinutes * 60 * 1000
    });
  }

  // Subscribe to data updates
  public subscribe(dataType: string, callback: Function): () => void {
    if (!this.updateCallbacks.has(dataType)) {
      this.updateCallbacks.set(dataType, []);
    }
    this.updateCallbacks.get(dataType)!.push(callback);

    return () => {
      const callbacks = this.updateCallbacks.get(dataType);
      if (callbacks) {
        const index = callbacks.indexOf(callback);
        if (index > -1) {
          callbacks.splice(index, 1);
        }
      }
    };
  }

  private notifySubscribers(dataType: string, data: any): void {
    const callbacks = this.updateCallbacks.get(dataType);
    if (callbacks) {
      callbacks.forEach(callback => callback(data));
    }
  }

  // Color mapping for consistent UI
  private getSymbolColor(symbol: string): string {
    const colorMap: Record<string, string> = {
      'BTC': '#f7931a',
      'ETH': '#627eea',
      'SOL': '#9945ff',
      'BNB': '#f3ba2f',
      'ADA': '#0033ad',
      'DOT': '#e6007a',
      'LINK': '#375bd2',
      'UNI': '#ff007a',
      'MATIC': '#8247e5',
      'AVAX': '#e84142',
      'ATOM': '#2e3148',
      'NEAR': '#00c08b',
      'FTM': '#1969ff',
      'ALGO': '#000000',
      'XRP': '#23292f'
    };
    return colorMap[symbol] || '#6b7280';
  }

  // Transform API data to UI-compatible format
  private transformMarketData(apiData: any[]): MarketData[] {
    return apiData.map(coin => ({
      symbol: coin.symbol,
      name: this.getCoinName(coin.symbol),
      price: coin.price,
      change: coin.price * (coin.change24h / 100),
      changePercent: coin.change24h,
      volume: coin.volume24h,
      marketCap: coin.marketCap,
      rank: coin.rank,
      color: this.getSymbolColor(coin.symbol)
    }));
  }

  private getCoinName(symbol: string): string {
    const nameMap: Record<string, string> = {
      'BTC': 'Bitcoin',
      'ETH': 'Ethereum',
      'SOL': 'Solana',
      'BNB': 'BNB',
      'ADA': 'Cardano',
      'DOT': 'Polkadot',
      'LINK': 'Chainlink',
      'UNI': 'Uniswap',
      'MATIC': 'Polygon',
      'AVAX': 'Avalanche'
    };
    return nameMap[symbol] || symbol;
  }

  private transformNewsData(apiNews: any[]): NewsItem[] {
    return apiNews.map(news => ({
      id: news.id,
      title: news.title,
      summary: news.description || news.title,
      source: news.source,
      timestamp: new Date(news.publishedAt),
      category: this.categorizeNews(news.title + ' ' + news.description),
      sentiment: news.sentiment,
      impact: this.assessNewsImpact(news),
      coins: news.symbols || this.extractCoinsFromText(news.title + ' ' + news.description),
      readTime: Math.ceil((news.title.length + (news.description || '').length) / 200),
      url: news.url
    }));
  }

  private categorizeNews(text: string): 'breaking' | 'analysis' | 'regulation' | 'technology' | 'market' {
    const lowerText = text.toLowerCase();
    if (lowerText.includes('breaking') || lowerText.includes('urgent')) return 'breaking';
    if (lowerText.includes('regulation') || lowerText.includes('sec') || lowerText.includes('government')) return 'regulation';
    if (lowerText.includes('technology') || lowerText.includes('blockchain') || lowerText.includes('protocol')) return 'technology';
    if (lowerText.includes('analysis') || lowerText.includes('prediction') || lowerText.includes('forecast')) return 'analysis';
    return 'market';
  }

  private assessNewsImpact(news: any): 'high' | 'medium' | 'low' {
    const title = news.title.toLowerCase();
    const highImpactKeywords = ['breaking', 'major', 'massive', 'huge', 'crash', 'surge', 'regulation', 'ban', 'approval'];
    const mediumImpactKeywords = ['significant', 'important', 'notable', 'rise', 'fall', 'update', 'announcement'];
    
    if (highImpactKeywords.some(keyword => title.includes(keyword))) return 'high';
    if (mediumImpactKeywords.some(keyword => title.includes(keyword))) return 'medium';
    return 'low';
  }

  private extractCoinsFromText(text: string): string[] {
    const coins = ['BTC', 'ETH', 'SOL', 'BNB', 'ADA', 'DOT', 'LINK', 'UNI', 'MATIC', 'AVAX'];
    const lowerText = text.toLowerCase();
    const foundCoins: string[] = [];
    
    coins.forEach(coin => {
      if (lowerText.includes(coin.toLowerCase()) || lowerText.includes(this.getCoinName(coin).toLowerCase())) {
        foundCoins.push(coin);
      }
    });
    
    return foundCoins;
  }

  // Generate realistic portfolio data based on market data
  private generatePortfolioData(marketData: MarketData[]): PortfolioData {
    const holdings = [
      { symbol: 'BTC', amount: 1.2345 },
      { symbol: 'ETH', amount: 12.456 },
      { symbol: 'SOL', amount: 156.78 },
      { symbol: 'BNB', amount: 45.67 },
      { symbol: 'ADA', amount: 2345.67 }
    ];

    const assets: PortfolioAsset[] = holdings.map(holding => {
      const marketInfo = marketData.find(m => m.symbol === holding.symbol);
      if (!marketInfo) return null;

      const value = holding.amount * marketInfo.price;
      return {
        symbol: holding.symbol,
        name: marketInfo.name,
        amount: holding.amount,
        value: value,
        change24h: marketInfo.changePercent,
        allocation: 0, // Will be calculated below
        color: marketInfo.color
      };
    }).filter(Boolean) as PortfolioAsset[];

    const totalValue = assets.reduce((sum, asset) => sum + asset.value, 0);
    
    // Calculate allocations
    assets.forEach(asset => {
      asset.allocation = (asset.value / totalValue) * 100;
    });

    const totalChange24h = assets.reduce((sum, asset) => {
      return sum + (asset.value * (asset.change24h / 100));
    }, 0);

    return {
      totalValue,
      change24h: totalChange24h,
      changePercent: (totalChange24h / totalValue) * 100,
      assets,
      availableBalance: totalValue * 0.3,
      marginUsed: totalValue * 0.7,
      unrealizedPnL: totalChange24h
    };
  }

  // Generate AI trading signals based on market data
  private generateTradingSignals(marketData: MarketData[]): TradingSignal[] {
    const signals: TradingSignal[] = [];
    const aiModels = ['Neural Alpha', 'Quantum Beta', 'Deep Gamma', 'Fusion Delta'];
    const timeframes = ['1M', '5M', '15M', '1H', '4H', '1D'];
    
    marketData.slice(0, 5).forEach((coin, index) => {
      const signal: 'BUY' | 'SELL' | 'HOLD' = 
        coin.changePercent > 5 ? 'BUY' : 
        coin.changePercent < -5 ? 'SELL' : 'HOLD';
      
      const confidence = Math.min(95, Math.max(60, 75 + Math.abs(coin.changePercent) * 2));
      const riskLevel: 'low' | 'medium' | 'high' = 
        Math.abs(coin.changePercent) > 10 ? 'high' :
        Math.abs(coin.changePercent) > 5 ? 'medium' : 'low';

      signals.push({
        id: `signal_${coin.symbol}_${Date.now()}`,
        symbol: `${coin.symbol}/USDT`,
        signal,
        confidence,
        price: coin.price,
        target: signal === 'BUY' ? coin.price * 1.05 : coin.price * 0.95,
        stopLoss: signal === 'BUY' ? coin.price * 0.97 : coin.price * 1.03,
        timestamp: new Date(),
        status: 'active',
        aiModel: aiModels[index % aiModels.length],
        riskLevel,
        timeframe: timeframes[index % timeframes.length],
        volume: coin.volume,
        accuracy: Math.floor(Math.random() * 20) + 80,
        tags: this.generateSignalTags(coin, signal),
        expectedReturn: signal === 'BUY' ? 
          ((coin.price * 1.05 - coin.price) / coin.price) * 100 :
          ((coin.price * 0.95 - coin.price) / coin.price) * 100,
        reason: this.generateSignalReason(coin, signal)
      });
    });

    return signals;
  }

  private generateSignalTags(coin: MarketData, signal: 'BUY' | 'SELL' | 'HOLD'): string[] {
    const tags = [];
    
    if (Math.abs(coin.changePercent) > 10) tags.push('high-volatility');
    if (coin.volume > 1000000000) tags.push('high-volume');
    if (signal === 'BUY' && coin.changePercent > 0) tags.push('momentum', 'breakout');
    if (signal === 'SELL' && coin.changePercent < 0) tags.push('reversal', 'resistance');
    if (coin.rank <= 10) tags.push('blue-chip');
    
    return tags.slice(0, 3);
  }

  private generateSignalReason(coin: MarketData, signal: 'BUY' | 'SELL' | 'HOLD'): string {
    if (signal === 'BUY') {
      return `Strong bullish momentum detected with ${coin.changePercent.toFixed(1)}% gain and high volume confirmation`;
    } else if (signal === 'SELL') {
      return `Bearish pressure with ${Math.abs(coin.changePercent).toFixed(1)}% decline, potential reversal signal`;
    } else {
      return `Consolidation phase detected, waiting for clear directional breakout`;
    }
  }

  // Main data fetching methods
  public async fetchMarketData(): Promise<MarketData[]> {
    const cacheKey = 'market_data';
    const cached = this.getCached<MarketData[]>(cacheKey);
    if (cached) return cached;

    try {
      console.log('🔄 Fetching real market data...');
      const cryptoPrices = await apiService.fetchCryptoPrices([
        'BTC', 'ETH', 'SOL', 'BNB', 'ADA', 'DOT', 'LINK', 'UNI', 'MATIC', 'AVAX'
      ]);
      
      const marketData = this.transformMarketData(cryptoPrices);
      this.setCache(cacheKey, marketData, 2); // 2 minutes cache
      this.notifySubscribers('marketData', marketData);
      
      console.log('✅ Market data updated successfully');
      return marketData;
    } catch (error) {
      console.error('❌ Failed to fetch market data:', error);
      throw error;
    }
  }

  public async fetchPortfolioData(): Promise<PortfolioData> {
    const cacheKey = 'portfolio_data';
    const cached = this.getCached<PortfolioData>(cacheKey);
    if (cached) return cached;

    try {
      const marketData = await this.fetchMarketData();
      const portfolioData = this.generatePortfolioData(marketData);
      
      this.setCache(cacheKey, portfolioData, 1); // 1 minute cache
      this.notifySubscribers('portfolioData', portfolioData);
      
      return portfolioData;
    } catch (error) {
      console.error('❌ Failed to generate portfolio data:', error);
      throw error;
    }
  }

  public async fetchNewsData(): Promise<NewsItem[]> {
    const cacheKey = 'news_data';
    const cached = this.getCached<NewsItem[]>(cacheKey);
    if (cached) return cached;

    try {
      console.log('📰 Fetching real news data...');
      const apiNews = await apiService.fetchNews();
      const newsData = this.transformNewsData(apiNews);
      
      this.setCache(cacheKey, newsData, 10); // 10 minutes cache
      this.notifySubscribers('newsData', newsData);
      
      console.log('✅ News data updated successfully');
      return newsData;
    } catch (error) {
      console.error('❌ Failed to fetch news data:', error);
      throw error;
    }
  }

  public async fetchSentimentData(): Promise<SentimentData> {
    const cacheKey = 'sentiment_data';
    const cached = this.getCached<SentimentData>(cacheKey);
    if (cached) return cached;

    try {
      console.log('😊 Fetching real sentiment data...');
      const apiSentiment = await apiService.fetchMarketSentiment();
      
      const sentimentData: SentimentData = {
        fearGreedIndex: apiSentiment.fearGreedIndex,
        classification: apiSentiment.fearGreedClassification,
        socialSentiment: apiSentiment.socialSentiment,
        newsSentiment: apiSentiment.newsSentiment,
        marketMomentum: apiSentiment.marketMomentum,
        volatilityIndex: apiSentiment.volatilityIndex,
        overallGrade: apiSentiment.overallGrade,
        lastUpdate: new Date(apiSentiment.lastUpdate)
      };
      
      this.setCache(cacheKey, sentimentData, 15); // 15 minutes cache
      this.notifySubscribers('sentimentData', sentimentData);
      
      console.log('✅ Sentiment data updated successfully');
      return sentimentData;
    } catch (error) {
      console.error('❌ Failed to fetch sentiment data:', error);
      throw error;
    }
  }

  public async fetchWhaleData(): Promise<WhaleTransaction[]> {
    const cacheKey = 'whale_data';
    const cached = this.getCached<WhaleTransaction[]>(cacheKey);
    if (cached) return cached;

    try {
      console.log('🐋 Fetching real whale transaction data...');
      const whaleTransactions = await apiService.fetchWhaleTransactions();
      
      this.setCache(cacheKey, whaleTransactions, 5); // 5 minutes cache
      this.notifySubscribers('whaleData', whaleTransactions);
      
      console.log('✅ Whale data updated successfully');
      return whaleTransactions;
    } catch (error) {
      console.error('❌ Failed to fetch whale data:', error);
      throw error;
    }
  }

  public async fetchTradingSignals(): Promise<TradingSignal[]> {
    const cacheKey = 'trading_signals';
    const cached = this.getCached<TradingSignal[]>(cacheKey);
    if (cached) return cached;

    try {
      const marketData = await this.fetchMarketData();
      const signals = this.generateTradingSignals(marketData);
      
      this.setCache(cacheKey, signals, 3); // 3 minutes cache
      this.notifySubscribers('tradingSignals', signals);
      
      return signals;
    } catch (error) {
      console.error('❌ Failed to generate trading signals:', error);
      throw error;
    }
  }

  // Comprehensive dashboard data fetch
  public async fetchAllDashboardData(): Promise<DashboardData> {
    try {
      console.log('🚀 Fetching all dashboard data...');
      
      const [marketData, portfolioData, newsData, sentimentData, whaleData, tradingSignals] = await Promise.allSettled([
        this.fetchMarketData(),
        this.fetchPortfolioData(),
        this.fetchNewsData(),
        this.fetchSentimentData(),
        this.fetchWhaleData(),
        this.fetchTradingSignals()
      ]);

      const dashboardData: DashboardData = {
        marketData: marketData.status === 'fulfilled' ? marketData.value : [],
        portfolioData: portfolioData.status === 'fulfilled' ? portfolioData.value : {
          totalValue: 0, change24h: 0, changePercent: 0, assets: [], 
          availableBalance: 0, marginUsed: 0, unrealizedPnL: 0
        },
        newsData: newsData.status === 'fulfilled' ? newsData.value : [],
        sentimentData: sentimentData.status === 'fulfilled' ? sentimentData.value : {
          fearGreedIndex: 50, classification: 'Neutral', socialSentiment: 50,
          newsSentiment: 50, marketMomentum: 50, volatilityIndex: 20,
          overallGrade: 'C', lastUpdate: new Date()
        },
        whaleData: whaleData.status === 'fulfilled' ? whaleData.value : [],
        tradingSignals: tradingSignals.status === 'fulfilled' ? tradingSignals.value : []
      };

      console.log('✅ All dashboard data fetched successfully');
      return dashboardData;
    } catch (error) {
      console.error('❌ Failed to fetch dashboard data:', error);
      throw error;
    }
  }

  // Real-time data streaming
  public startRealTimeUpdates(intervalMs: number = 60000): () => void {
    console.log('🔄 Starting real-time data updates...');
    
    const interval = setInterval(async () => {
      try {
        await this.fetchAllDashboardData();
      } catch (error) {
        console.error('❌ Real-time update failed:', error);
      }
    }, intervalMs);

    return () => {
      clearInterval(interval);
      console.log('⏹️ Real-time updates stopped');
    };
  }
}

// Export singleton instance
export const realDataService = new RealDataService();

console.log('🚀 Real Data Service Ready for Dashboard Pro!');
console.log('📊 Integrated with comprehensive API service');
console.log('🔄 Real-time updates enabled');
console.log('📦 Caching system active');
console.log('🎯 UI compatibility maintained');
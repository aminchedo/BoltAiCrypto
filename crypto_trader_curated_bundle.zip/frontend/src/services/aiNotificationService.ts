/**
 * AI Notification Service
 * 
 * Handles real-time notifications for AI signals, model training completion,
 * and other AI-related events.
 */

import { signalService } from './signalService';

export interface AINotification {
  id: string;
  type: 'signal' | 'model_training' | 'performance' | 'risk' | 'system';
  title: string;
  message: string;
  timestamp: Date;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  read: boolean;
  data?: any;
}

class AINotificationService {
  private notifications: AINotification[] = [];
  private subscribers: ((notifications: AINotification[]) => void)[] = [];
  private lastSignalCheck: Date = new Date();
  private checkInterval: NodeJS.Timeout | null = null;
  
  constructor() {
    // Initialize with some example notifications
    this.notifications = [
      {
        id: '1',
        type: 'signal',
        title: 'Strong BUY Signal',
        message: 'AI detected a high-confidence BUY signal for BTC/USDT',
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        priority: 'high',
        read: false,
        data: {
          symbol: 'BTC/USDT',
          signal: 'BUY',
          confidence: 92.5,
          price: 43250.50
        }
      },
      {
        id: '2',
        type: 'model_training',
        title: 'Model Training Complete',
        message: 'SpeedTrader_v2.1 training completed with 94.3% accuracy',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
        priority: 'medium',
        read: true,
        data: {
          model: 'SpeedTrader_v2.1',
          accuracy: 94.3,
          training_time: 45
        }
      }
    ];
  }

  /**
   * Start monitoring for new AI signals and events
   */
  public startMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
    
    // Check for new signals every minute
    this.checkInterval = setInterval(() => this.checkForNewSignals(), 60000);
    console.log('AI Notification monitoring started');
  }

  /**
   * Stop monitoring for new AI signals and events
   */
  public stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    console.log('AI Notification monitoring stopped');
  }

  /**
   * Check for new signals from the signal service
   */
  private async checkForNewSignals(): Promise<void> {
    try {
      const signals = await signalService.getLiveSignals();
      
      // Filter for new high-confidence signals
      const newSignals = signals.filter(signal => {
        const signalDate = new Date(signal.created_at);
        return (
          signalDate > this.lastSignalCheck && 
          signal.confidence > 85 && 
          (signal.signal === 'BUY' || signal.signal === 'SELL')
        );
      });
      
      // Create notifications for new signals
      newSignals.forEach(signal => {
        this.addNotification({
          id: `signal_${Date.now()}_${signal.id}`,
          type: 'signal',
          title: `Strong ${signal.signal} Signal`,
          message: `AI detected a high-confidence ${signal.signal} signal for ${signal.symbol}`,
          timestamp: new Date(),
          priority: signal.confidence > 90 ? 'urgent' : 'high',
          read: false,
          data: {
            symbol: signal.symbol,
            signal: signal.signal,
            confidence: signal.confidence,
            price: signal.entry_price
          }
        });
      });
      
      this.lastSignalCheck = new Date();
    } catch (error) {
      console.error('Error checking for new signals:', error);
    }
  }

  /**
   * Add a new notification
   */
  public addNotification(notification: AINotification): void {
    this.notifications.unshift(notification);
    
    // Keep only the latest 100 notifications
    if (this.notifications.length > 100) {
      this.notifications = this.notifications.slice(0, 100);
    }
    
    // Notify subscribers
    this.notifySubscribers();
    
    // Show browser notification for high priority items
    if (notification.priority === 'high' || notification.priority === 'urgent') {
      this.showBrowserNotification(notification);
    }
  }

  /**
   * Show a browser notification
   */
  private showBrowserNotification(notification: AINotification): void {
    // Check if browser notifications are supported and permitted
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification(notification.title, {
          body: notification.message,
          icon: '/ai-notification-icon.png'
        });
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            new Notification(notification.title, {
              body: notification.message,
              icon: '/ai-notification-icon.png'
            });
          }
        });
      }
    }
  }

  /**
   * Get all notifications
   */
  public getNotifications(): AINotification[] {
    return [...this.notifications];
  }

  /**
   * Get unread notifications
   */
  public getUnreadNotifications(): AINotification[] {
    return this.notifications.filter(n => !n.read);
  }

  /**
   * Mark a notification as read
   */
  public markAsRead(id: string): void {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      notification.read = true;
      this.notifySubscribers();
    }
  }

  /**
   * Mark all notifications as read
   */
  public markAllAsRead(): void {
    this.notifications.forEach(n => n.read = true);
    this.notifySubscribers();
  }

  /**
   * Clear all notifications
   */
  public clearAll(): void {
    this.notifications = [];
    this.notifySubscribers();
  }

  /**
   * Subscribe to notification updates
   */
  public subscribe(callback: (notifications: AINotification[]) => void): () => void {
    this.subscribers.push(callback);
    
    // Return unsubscribe function
    return () => {
      this.subscribers = this.subscribers.filter(cb => cb !== callback);
    };
  }

  /**
   * Notify all subscribers of changes
   */
  private notifySubscribers(): void {
    this.subscribers.forEach(callback => {
      callback([...this.notifications]);
    });
  }
}

// Create singleton instance
export const aiNotificationService = new AINotificationService();

// Start monitoring automatically
if (typeof window !== 'undefined') {
  setTimeout(() => {
    aiNotificationService.startMonitoring();
  }, 2000);
}

export default aiNotificationService;
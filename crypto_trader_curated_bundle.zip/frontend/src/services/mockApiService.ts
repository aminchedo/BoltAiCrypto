/**
 * Mock API Service for development and testing
 */

export const mockApiService = {
    // Mock market data
    getMarketData: async () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    data: {
                        btc: { price: 45000, change: 2.5 },
                        eth: { price: 3200, change: -1.2 },
                        sol: { price: 98, change: 5.8 }
                    }
                });
            }, 500);
        });
    },

    // Mock trading signals
    getSignals: async () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    data: []
                });
            }, 300);
        });
    }
};

export default mockApiService;
import { EventEmitter } from 'events';

interface WebSocketConfig {
  url: string;
  reconnectInterval: number;
  maxReconnectAttempts: number;
  heartbeatInterval: number;
}

interface PriceUpdate {
  symbol: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  timestamp: number;
  exchange: string;
}

interface OrderBookUpdate {
  symbol: string;
  bids: Array<[number, number]>;
  asks: Array<[number, number]>;
  timestamp: number;
}

interface TradeUpdate {
  symbol: string;
  price: number;
  quantity: number;
  side: 'buy' | 'sell';
  timestamp: number;
  exchange: string;
}

interface SignalUpdate {
  id: string;
  symbol: string;
  direction: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  timestamp: number;
  status: 'NEW' | 'UPDATED' | 'EXPIRED';
}

interface WhaleAlert {
  id: string;
  symbol: string;
  amount: number;
  type: 'large_buy' | 'large_sell' | 'exchange_inflow' | 'exchange_outflow';
  exchange: string;
  timestamp: number;
  impact: 'LOW' | 'MEDIUM' | 'HIGH';
}

interface NewsUpdate {
  id: string;
  title: string;
  summary: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'LOW' | 'MEDIUM' | 'HIGH';
  symbols: string[];
  timestamp: number;
  source: string;
}

export class RealTimeService extends EventEmitter {
  private connections: Map<string, WebSocket> = new Map();
  private reconnectAttempts: Map<string, number> = new Map();
  private heartbeatIntervals: Map<string, NodeJS.Timeout> = new Map();
  private subscriptions: Map<string, Set<string>> = new Map();
  private isConnected: Map<string, boolean> = new Map();
  
  private readonly configs: Record<string, WebSocketConfig> = {
    binance: {
      url: 'wss://stream.binance.com:9443/ws/stream',
      reconnectInterval: 5000,
      maxReconnectAttempts: 10,
      heartbeatInterval: 30000
    },
    coinbase: {
      url: 'wss://ws-feed.exchange.coinbase.com',
      reconnectInterval: 5000,
      maxReconnectAttempts: 10,
      heartbeatInterval: 30000
    },
    signals: {
      url: process.env.NEXT_PUBLIC_WS_URL || 'wss://api.aismart-trader.com/ws',
      reconnectInterval: 3000,
      maxReconnectAttempts: 15,
      heartbeatInterval: 20000
    },
    news: {
      url: 'wss://news-feed.aismart-trader.com/ws',
      reconnectInterval: 10000,
      maxReconnectAttempts: 5,
      heartbeatInterval: 60000
    }
  };

  constructor() {
    super();
    this.setMaxListeners(100); // Allow many subscribers
  }

  // Connect to a specific exchange or service
  async connect(service: string, symbols: string[] = []): Promise<void> {
    const config = this.configs[service];
    if (!config) {
      throw new Error(`Unknown service: ${service}`);
    }

    try {
      const ws = new WebSocket(config.url);
      
      ws.onopen = () => {
        console.log(`Connected to ${service} WebSocket`);
        this.isConnected.set(service, true);
        this.reconnectAttempts.set(service, 0);
        this.connections.set(service, ws);
        
        // Subscribe to symbols
        if (symbols.length > 0) {
          this.subscribeToSymbols(service, symbols);
        }
        
        // Start heartbeat
        this.startHeartbeat(service);
        
        this.emit('connected', { service });
      };

      ws.onmessage = (event) => {
        this.handleMessage(service, JSON.parse(event.data));
      };

      ws.onerror = (error) => {
        console.error(`${service} WebSocket error:`, error);
        this.emit('error', { service, error });
      };

      ws.onclose = (event) => {
        console.log(`${service} WebSocket closed:`, event.code, event.reason);
        this.isConnected.set(service, false);
        this.stopHeartbeat(service);
        
        // Attempt reconnection
        this.attemptReconnection(service, symbols);
        
        this.emit('disconnected', { service, code: event.code, reason: event.reason });
      };

    } catch (error) {
      console.error(`Failed to connect to ${service}:`, error);
      throw error;
    }
  }

  // Subscribe to specific symbols for a service
  private subscribeToSymbols(service: string, symbols: string[]): void {
    const ws = this.connections.get(service);
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.warn(`Cannot subscribe to ${service}: connection not ready`);
      return;
    }

    // Store subscriptions
    this.subscriptions.set(service, new Set(symbols));

    const subscriptionMessages: Record<string, any> = {
      binance: {
        method: 'SUBSCRIBE',
        params: [
          ...symbols.map(s => `${s.toLowerCase()}@ticker`),
          ...symbols.map(s => `${s.toLowerCase()}@depth20@100ms`),
          ...symbols.map(s => `${s.toLowerCase()}@trade`)
        ],
        id: Date.now()
      },
      coinbase: {
        type: 'subscribe',
        product_ids: symbols,
        channels: ['ticker', 'level2', 'matches']
      },
      signals: {
        action: 'subscribe',
        channels: ['signals', 'whale_alerts'],
        symbols: symbols
      },
      news: {
        action: 'subscribe',
        channels: ['crypto_news', 'market_alerts'],
        symbols: symbols
      }
    };

    const message = subscriptionMessages[service];
    if (message) {
      ws.send(JSON.stringify(message));
      console.log(`Subscribed to ${service} for symbols:`, symbols);
    }
  }

  // Handle incoming WebSocket messages
  private handleMessage(service: string, data: any): void {
    try {
      switch (service) {
        case 'binance':
          this.handleBinanceMessage(data);
          break;
        case 'coinbase':
          this.handleCoinbaseMessage(data);
          break;
        case 'signals':
          this.handleSignalsMessage(data);
          break;
        case 'news':
          this.handleNewsMessage(data);
          break;
        default:
          console.warn(`Unknown service message: ${service}`, data);
      }
    } catch (error) {
      console.error(`Error handling ${service} message:`, error, data);
    }
  }

  private handleBinanceMessage(data: any): void {
    if (data.stream && data.data) {
      const stream = data.stream;
      const payload = data.data;

      if (stream.includes('@ticker')) {
        // Price update
        const priceUpdate: PriceUpdate = {
          symbol: payload.s,
          price: parseFloat(payload.c),
          change24h: parseFloat(payload.P),
          changePercent24h: parseFloat(payload.P),
          volume24h: parseFloat(payload.v),
          high24h: parseFloat(payload.h),
          low24h: parseFloat(payload.l),
          timestamp: payload.E,
          exchange: 'binance'
        };
        this.emit('priceUpdate', priceUpdate);
      }
      
      else if (stream.includes('@depth')) {
        // Order book update
        const orderBookUpdate: OrderBookUpdate = {
          symbol: payload.s,
          bids: payload.bids.map((bid: string[]) => [parseFloat(bid[0]), parseFloat(bid[1])]),
          asks: payload.asks.map((ask: string[]) => [parseFloat(ask[0]), parseFloat(ask[1])]),
          timestamp: Date.now()
        };
        this.emit('orderBookUpdate', orderBookUpdate);
      }
      
      else if (stream.includes('@trade')) {
        // Trade update
        const tradeUpdate: TradeUpdate = {
          symbol: payload.s,
          price: parseFloat(payload.p),
          quantity: parseFloat(payload.q),
          side: payload.m ? 'sell' : 'buy', // m = true means buyer is market maker
          timestamp: payload.T,
          exchange: 'binance'
        };
        this.emit('tradeUpdate', tradeUpdate);
      }
    }
  }

  private handleCoinbaseMessage(data: any): void {
    switch (data.type) {
      case 'ticker':
        const priceUpdate: PriceUpdate = {
          symbol: data.product_id,
          price: parseFloat(data.price),
          change24h: parseFloat(data.open_24h) - parseFloat(data.price),
          changePercent24h: ((parseFloat(data.price) - parseFloat(data.open_24h)) / parseFloat(data.open_24h)) * 100,
          volume24h: parseFloat(data.volume_24h),
          high24h: parseFloat(data.high_24h),
          low24h: parseFloat(data.low_24h),
          timestamp: new Date(data.time).getTime(),
          exchange: 'coinbase'
        };
        this.emit('priceUpdate', priceUpdate);
        break;

      case 'l2update':
        const orderBookUpdate: OrderBookUpdate = {
          symbol: data.product_id,
          bids: data.changes.filter((c: string[]) => c[0] === 'buy').map((c: string[]) => [parseFloat(c[1]), parseFloat(c[2])]),
          asks: data.changes.filter((c: string[]) => c[0] === 'sell').map((c: string[]) => [parseFloat(c[1]), parseFloat(c[2])]),
          timestamp: new Date(data.time).getTime()
        };
        this.emit('orderBookUpdate', orderBookUpdate);
        break;

      case 'match':
        const tradeUpdate: TradeUpdate = {
          symbol: data.product_id,
          price: parseFloat(data.price),
          quantity: parseFloat(data.size),
          side: data.side,
          timestamp: new Date(data.time).getTime(),
          exchange: 'coinbase'
        };
        this.emit('tradeUpdate', tradeUpdate);
        break;
    }
  }

  private handleSignalsMessage(data: any): void {
    switch (data.type) {
      case 'signal':
        const signalUpdate: SignalUpdate = {
          id: data.id,
          symbol: data.symbol,
          direction: data.direction,
          confidence: data.confidence,
          timestamp: data.timestamp,
          status: data.status
        };
        this.emit('signalUpdate', signalUpdate);
        break;

      case 'whale_alert':
        const whaleAlert: WhaleAlert = {
          id: data.id,
          symbol: data.symbol,
          amount: data.amount,
          type: data.type,
          exchange: data.exchange,
          timestamp: data.timestamp,
          impact: data.impact
        };
        this.emit('whaleAlert', whaleAlert);
        break;
    }
  }

  private handleNewsMessage(data: any): void {
    if (data.type === 'news') {
      const newsUpdate: NewsUpdate = {
        id: data.id,
        title: data.title,
        summary: data.summary,
        sentiment: data.sentiment,
        impact: data.impact,
        symbols: data.symbols || [],
        timestamp: data.timestamp,
        source: data.source
      };
      this.emit('newsUpdate', newsUpdate);
    }
  }

  // Start heartbeat for a connection
  private startHeartbeat(service: string): void {
    const config = this.configs[service];
    const interval = setInterval(() => {
      const ws = this.connections.get(service);
      if (ws && ws.readyState === WebSocket.OPEN) {
        // Send ping based on service requirements
        const pingMessages: Record<string, any> = {
          binance: { method: 'ping' },
          coinbase: { type: 'heartbeat', on: true },
          signals: { action: 'ping' },
          news: { action: 'ping' }
        };
        
        const pingMessage = pingMessages[service];
        if (pingMessage) {
          ws.send(JSON.stringify(pingMessage));
        }
      }
    }, config.heartbeatInterval);

    this.heartbeatIntervals.set(service, interval);
  }

  // Stop heartbeat for a connection
  private stopHeartbeat(service: string): void {
    const interval = this.heartbeatIntervals.get(service);
    if (interval) {
      clearInterval(interval);
      this.heartbeatIntervals.delete(service);
    }
  }

  // Attempt to reconnect to a service
  private attemptReconnection(service: string, symbols: string[]): void {
    const config = this.configs[service];
    const attempts = this.reconnectAttempts.get(service) || 0;

    if (attempts >= config.maxReconnectAttempts) {
      console.error(`Max reconnection attempts reached for ${service}`);
      this.emit('maxReconnectAttemptsReached', { service });
      return;
    }

    this.reconnectAttempts.set(service, attempts + 1);

    setTimeout(() => {
      console.log(`Attempting to reconnect to ${service} (attempt ${attempts + 1})`);
      this.connect(service, symbols).catch(error => {
        console.error(`Reconnection attempt ${attempts + 1} failed for ${service}:`, error);
      });
    }, config.reconnectInterval * Math.pow(2, attempts)); // Exponential backoff
  }

  // Subscribe to new symbols on an existing connection
  subscribeToSymbol(service: string, symbol: string): void {
    const existingSymbols = this.subscriptions.get(service) || new Set();
    if (!existingSymbols.has(symbol)) {
      existingSymbols.add(symbol);
      this.subscriptions.set(service, existingSymbols);
      
      // If connected, send subscription message
      if (this.isConnected.get(service)) {
        this.subscribeToSymbols(service, [symbol]);
      }
    }
  }

  // Unsubscribe from symbols
  unsubscribeFromSymbol(service: string, symbol: string): void {
    const existingSymbols = this.subscriptions.get(service);
    if (existingSymbols && existingSymbols.has(symbol)) {
      existingSymbols.delete(symbol);
      
      const ws = this.connections.get(service);
      if (ws && ws.readyState === WebSocket.OPEN) {
        // Send unsubscribe message based on service
        const unsubscribeMessages: Record<string, any> = {
          binance: {
            method: 'UNSUBSCRIBE',
            params: [`${symbol.toLowerCase()}@ticker`, `${symbol.toLowerCase()}@depth20@100ms`, `${symbol.toLowerCase()}@trade`],
            id: Date.now()
          },
          coinbase: {
            type: 'unsubscribe',
            product_ids: [symbol],
            channels: ['ticker', 'level2', 'matches']
          },
          signals: {
            action: 'unsubscribe',
            channels: ['signals', 'whale_alerts'],
            symbols: [symbol]
          }
        };

        const message = unsubscribeMessages[service];
        if (message) {
          ws.send(JSON.stringify(message));
        }
      }
    }
  }

  // Get connection status
  getConnectionStatus(service: string): boolean {
    return this.isConnected.get(service) || false;
  }

  // Get all active subscriptions
  getSubscriptions(service: string): string[] {
    const subscriptions = this.subscriptions.get(service);
    return subscriptions ? Array.from(subscriptions) : [];
  }

  // Disconnect from a service
  disconnect(service: string): void {
    const ws = this.connections.get(service);
    if (ws) {
      ws.close();
      this.connections.delete(service);
    }
    
    this.stopHeartbeat(service);
    this.isConnected.set(service, false);
    this.subscriptions.delete(service);
    this.reconnectAttempts.delete(service);
  }

  // Disconnect from all services
  disconnectAll(): void {
    for (const service of this.connections.keys()) {
      this.disconnect(service);
    }
  }

  // Initialize all connections with default symbols
  async initializeAll(defaultSymbols: string[] = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']): Promise<void> {
    const services = ['binance', 'coinbase', 'signals', 'news'];
    
    const connectionPromises = services.map(service => 
      this.connect(service, service === 'news' ? [] : defaultSymbols)
        .catch(error => {
          console.error(`Failed to connect to ${service}:`, error);
          return null; // Don't fail the entire initialization
        })
    );

    await Promise.allSettled(connectionPromises);
    
    // Emit initialization complete
    this.emit('initialized', {
      connectedServices: services.filter(service => this.getConnectionStatus(service)),
      failedServices: services.filter(service => !this.getConnectionStatus(service))
    });
  }

  // Get aggregated market data from multiple exchanges
  getAggregatedPrice(symbol: string): PriceUpdate | null {
    // This would aggregate prices from multiple exchanges
    // For now, return the most recent update
    return null; // Implementation would store recent updates and aggregate them
  }

  // Health check for all connections
  healthCheck(): Record<string, any> {
    const health: Record<string, any> = {};
    
    for (const [service, config] of Object.entries(this.configs)) {
      const ws = this.connections.get(service);
      health[service] = {
        connected: this.isConnected.get(service) || false,
        readyState: ws ? ws.readyState : -1,
        subscriptions: this.getSubscriptions(service).length,
        reconnectAttempts: this.reconnectAttempts.get(service) || 0,
        maxReconnectAttempts: config.maxReconnectAttempts
      };
    }
    
    return health;
  }
}

// Create singleton instance
export const realTimeService = new RealTimeService();

// Export types for use in components
export type {
  PriceUpdate,
  OrderBookUpdate,
  TradeUpdate,
  SignalUpdate,
  WhaleAlert,
  NewsUpdate
};

export default realTimeService;
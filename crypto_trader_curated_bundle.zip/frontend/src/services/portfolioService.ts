import api from './api';

export interface Position {
  symbol: string;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  marketValue: number;
  profitLoss: number;
}

export interface Trade {
  id: string;
  date: string;
  symbol: string;
  quantity: number;
  price: number;
  side: 'BUY' | 'SELL';
}

export interface NewsItem {
  id: string;
  title: string;
  url: string;
  publishedAt: string;
}

export interface PortfolioResponse {
  id: string;
  name: string;
  totalValue: number;
  totalInvested: number;
  totalPL: number;
  totalPLPercent: number;
  cash: number;
  positions: Position[];
  createdAt: string;
  updatedAt: string;
}

export const portfolioService = {
  getPortfolio: async (): Promise<PortfolioResponse> => {
    const res = await api.get<PortfolioResponse>('/portfolio');
    return res.data;
  },
  getTrades: async (portfolioId: string): Promise<Trade[]> => {
    const res = await api.get<Trade[]>(`/trades?portfolioId=${portfolioId}`);
    return res.data;
  },
  getNews: async (portfolioId: string): Promise<NewsItem[]> => {
    const res = await api.get<NewsItem[]>(`/news?portfolioId=${portfolioId}`);
    return res.data;
  },
};

export default portfolioService;

import api from './api';
import { EventEmitter } from 'events';

interface Order {
  id: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'OCO' | 'ICEBERG';
  quantity: number;
  price?: number;
  stopPrice?: number;
  timeInForce: 'GTC' | 'IOC' | 'FOK';
  status: 'NEW' | 'PARTIALLY_FILLED' | 'FILLED' | 'CANCELED' | 'REJECTED' | 'EXPIRED';
  executedQuantity: number;
  executedPrice?: number;
  commission: number;
  commissionAsset: string;
  timestamp: number;
  updateTime: number;
  exchange: string;
  clientOrderId?: string;
}

interface Position {
  symbol: string;
  side: 'LONG' | 'SHORT';
  size: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
  realizedPnl: number;
  percentage: number;
  margin: number;
  leverage: number;
  liquidationPrice?: number;
  timestamp: number;
}

interface Portfolio {
  totalValue: number;
  availableBalance: number;
  usedMargin: number;
  freeMargin: number;
  marginLevel: number;
  positions: Position[];
  dailyPnl: number;
  totalPnl: number;
  equity: number;
  assets: Array<{
    asset: string;
    free: number;
    locked: number;
    total: number;
    btcValue: number;
    usdValue: number;
  }>;
}

interface RiskMetrics {
  portfolioRisk: number;
  valueAtRisk: number;
  maxDrawdown: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  winRate: number;
  profitFactor: number;
  averageWin: number;
  averageLoss: number;
  largestWin: number;
  largestLoss: number;
  consecutiveWins: number;
  consecutiveLosses: number;
  totalTrades: number;
  correlation: Record<string, number>;
}

interface OrderRequest {
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'OCO' | 'ICEBERG';
  quantity: number;
  price?: number;
  stopPrice?: number;
  timeInForce?: 'GTC' | 'IOC' | 'FOK';
  exchange?: string;
  clientOrderId?: string;
  icebergQty?: number;
  stopLimitPrice?: number;
  stopLimitTimeInForce?: 'GTC' | 'IOC' | 'FOK';
}

interface TradeExecution {
  orderId: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  commission: number;
  commissionAsset: string;
  timestamp: number;
  isMaker: boolean;
  exchange: string;
}

interface ExchangeConfig {
  name: string;
  apiKey: string;
  secretKey: string;
  testnet: boolean;
  enabled: boolean;
  tradingFees: {
    maker: number;
    taker: number;
  };
  limits: {
    minOrderSize: number;
    maxOrderSize: number;
    minPrice: number;
    maxPrice: number;
  };
}

class TradingService extends EventEmitter {
  private exchanges: Map<string, ExchangeConfig> = new Map();
  private activeOrders: Map<string, Order> = new Map();
  private positions: Map<string, Position> = new Map();
  private portfolio: Portfolio | null = null;
  private riskMetrics: RiskMetrics | null = null;
  
  // Risk management settings
  private riskSettings = {
    maxPositionSize: 0.1, // 10% of portfolio per position
    maxPortfolioRisk: 0.02, // 2% portfolio risk per trade
    maxDailyLoss: 0.05, // 5% max daily loss
    maxDrawdown: 0.15, // 15% max drawdown
    stopLossRequired: true,
    takeProfitRecommended: true,
    maxLeverage: 3,
    correlationLimit: 0.7 // Max correlation between positions
  };

  constructor() {
    super();
    this.initializeExchanges();
  }

  private initializeExchanges(): void {
    // Initialize exchange configurations
    const exchangeConfigs: ExchangeConfig[] = [
      {
        name: 'binance',
        apiKey: process.env.BINANCE_API_KEY || '',
        secretKey: process.env.BINANCE_SECRET_KEY || '',
        testnet: process.env.NODE_ENV !== 'production',
        enabled: true,
        tradingFees: { maker: 0.001, taker: 0.001 },
        limits: { minOrderSize: 0.001, maxOrderSize: 1000, minPrice: 0.01, maxPrice: 1000000 }
      },
      {
        name: 'coinbase',
        apiKey: process.env.COINBASE_API_KEY || '',
        secretKey: process.env.COINBASE_SECRET_KEY || '',
        testnet: process.env.NODE_ENV !== 'production',
        enabled: true,
        tradingFees: { maker: 0.005, taker: 0.005 },
        limits: { minOrderSize: 0.001, maxOrderSize: 1000, minPrice: 0.01, maxPrice: 1000000 }
      },
      {
        name: 'okx',
        apiKey: process.env.OKX_API_KEY || '',
        secretKey: process.env.OKX_SECRET_KEY || '',
        testnet: process.env.NODE_ENV !== 'production',
        enabled: false, // Disabled by default
        tradingFees: { maker: 0.001, taker: 0.0015 },
        limits: { minOrderSize: 0.001, maxOrderSize: 1000, minPrice: 0.01, maxPrice: 1000000 }
      }
    ];

    exchangeConfigs.forEach(config => {
      this.exchanges.set(config.name, config);
    });
  }

  // Place a new order
  async placeOrder(orderRequest: OrderRequest): Promise<Order> {
    try {
      // Validate order request
      this.validateOrderRequest(orderRequest);
      
      // Check risk management
      await this.checkRiskManagement(orderRequest);
      
      // Select best exchange
      const exchange = orderRequest.exchange || this.selectBestExchange(orderRequest.symbol);
      
      // Place order on exchange
      const order = await this.executeOrder(exchange, orderRequest);
      
      // Store order
      this.activeOrders.set(order.id, order);
      
      // Emit order event
      this.emit('orderPlaced', order);
      
      return order;
    } catch (error) {
      console.error('Failed to place order:', error);
      this.emit('orderError', { orderRequest, error });
      throw error;
    }
  }

  private validateOrderRequest(orderRequest: OrderRequest): void {
    if (!orderRequest.symbol || !orderRequest.side || !orderRequest.type || !orderRequest.quantity) {
      throw new Error('Missing required order parameters');
    }

    if (orderRequest.quantity <= 0) {
      throw new Error('Order quantity must be positive');
    }

    if (orderRequest.type === 'LIMIT' && !orderRequest.price) {
      throw new Error('Limit orders require a price');
    }

    if (orderRequest.type === 'STOP' && !orderRequest.stopPrice) {
      throw new Error('Stop orders require a stop price');
    }

    if (orderRequest.type === 'STOP_LIMIT' && (!orderRequest.price || !orderRequest.stopPrice)) {
      throw new Error('Stop limit orders require both price and stop price');
    }
  }

  private async checkRiskManagement(orderRequest: OrderRequest): Promise<void> {
    // Get current portfolio
    const portfolio = await this.getPortfolio();
    
    // Calculate position size as percentage of portfolio
    const orderValue = orderRequest.quantity * (orderRequest.price || 0);
    const positionSizePercent = orderValue / portfolio.totalValue;
    
    if (positionSizePercent > this.riskSettings.maxPositionSize) {
      throw new Error(`Position size (${(positionSizePercent * 100).toFixed(2)}%) exceeds maximum allowed (${(this.riskSettings.maxPositionSize * 100).toFixed(2)}%)`);
    }

    // Check daily loss limit
    if (portfolio.dailyPnl < -portfolio.totalValue * this.riskSettings.maxDailyLoss) {
      throw new Error('Daily loss limit exceeded. Trading suspended.');
    }

    // Check correlation with existing positions
    const correlation = await this.calculateCorrelation(orderRequest.symbol);
    if (correlation > this.riskSettings.correlationLimit) {
      console.warn(`High correlation (${(correlation * 100).toFixed(1)}%) detected with existing positions`);
    }

    // Check if stop loss is required
    if (this.riskSettings.stopLossRequired && !orderRequest.stopPrice && orderRequest.type !== 'STOP' && orderRequest.type !== 'STOP_LIMIT') {
      console.warn('Stop loss is recommended for risk management');
    }
  }

  private selectBestExchange(symbol: string): string {
    // Select exchange based on fees, liquidity, and availability
    const enabledExchanges = Array.from(this.exchanges.values()).filter(ex => ex.enabled);
    
    if (enabledExchanges.length === 0) {
      throw new Error('No exchanges available');
    }

    // For now, select the first enabled exchange
    // In production, this would consider fees, liquidity, etc.
    return enabledExchanges[0].name;
  }

  private async executeOrder(exchange: string, orderRequest: OrderRequest): Promise<Order> {
    try {
      // Call exchange API
      const response = await api.post(`/v1/trading/${exchange}/orders`, orderRequest);
      
      return {
        id: response.orderId,
        symbol: orderRequest.symbol,
        side: orderRequest.side,
        type: orderRequest.type,
        quantity: orderRequest.quantity,
        price: orderRequest.price,
        stopPrice: orderRequest.stopPrice,
        timeInForce: orderRequest.timeInForce || 'GTC',
        status: 'NEW',
        executedQuantity: 0,
        commission: 0,
        commissionAsset: 'USDT',
        timestamp: Date.now(),
        updateTime: Date.now(),
        exchange,
        clientOrderId: orderRequest.clientOrderId
      };
    } catch (error) {
      console.error(`Failed to execute order on ${exchange}:`, error);
      
      // Fallback to mock order for development
      return this.createMockOrder(orderRequest, exchange);
    }
  }

  private createMockOrder(orderRequest: OrderRequest, exchange: string): Order {
    return {
      id: `mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      symbol: orderRequest.symbol,
      side: orderRequest.side,
      type: orderRequest.type,
      quantity: orderRequest.quantity,
      price: orderRequest.price,
      stopPrice: orderRequest.stopPrice,
      timeInForce: orderRequest.timeInForce || 'GTC',
      status: 'NEW',
      executedQuantity: 0,
      commission: 0,
      commissionAsset: 'USDT',
      timestamp: Date.now(),
      updateTime: Date.now(),
      exchange,
      clientOrderId: orderRequest.clientOrderId
    };
  }

  // Cancel an order
  async cancelOrder(orderId: string): Promise<void> {
    const order = this.activeOrders.get(orderId);
    if (!order) {
      throw new Error('Order not found');
    }

    try {
      await api.delete(`/v1/trading/${order.exchange}/orders/${orderId}`);
      
      order.status = 'CANCELED';
      order.updateTime = Date.now();
      
      this.emit('orderCanceled', order);
    } catch (error) {
      console.error('Failed to cancel order:', error);
      
      // Mock cancellation for development
      order.status = 'CANCELED';
      order.updateTime = Date.now();
      this.emit('orderCanceled', order);
    }
  }

  // Get order history
  async getOrderHistory(symbol?: string, limit: number = 100): Promise<Order[]> {
    try {
      const params: any = { limit };
      if (symbol) params.symbol = symbol;
      
      return await api.get('/v1/trading/orders/history', params);
    } catch (error) {
      console.error('Failed to get order history:', error);
      return this.getMockOrderHistory(symbol, limit);
    }
  }

  private getMockOrderHistory(symbol?: string, limit: number = 100): Order[] {
    const orders: Order[] = [];
    const symbols = symbol ? [symbol] : ['BTCUSDT', 'ETHUSDT', 'BNBUSDT'];
    
    for (let i = 0; i < limit; i++) {
      const orderSymbol = symbols[i % symbols.length];
      const side = Math.random() > 0.5 ? 'BUY' : 'SELL';
      const isExecuted = Math.random() > 0.2; // 80% execution rate
      
      orders.push({
        id: `hist_${i}`,
        symbol: orderSymbol,
        side,
        type: 'LIMIT',
        quantity: Math.random() * 10 + 0.1,
        price: 43000 + (Math.random() - 0.5) * 10000,
        timeInForce: 'GTC',
        status: isExecuted ? 'FILLED' : 'CANCELED',
        executedQuantity: isExecuted ? Math.random() * 10 + 0.1 : 0,
        executedPrice: isExecuted ? 43000 + (Math.random() - 0.5) * 10000 : undefined,
        commission: isExecuted ? Math.random() * 10 : 0,
        commissionAsset: 'USDT',
        timestamp: Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000,
        updateTime: Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000,
        exchange: 'binance'
      });
    }
    
    return orders.sort((a, b) => b.timestamp - a.timestamp);
  }

  // Get current positions
  async getPositions(): Promise<Position[]> {
    try {
      const positions = await api.get('/v1/trading/positions');
      return positions;
    } catch (error) {
      console.error('Failed to get positions:', error);
      return this.getMockPositions();
    }
  }

  private getMockPositions(): Position[] {
    const positions: Position[] = [];
    const symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT'];
    
    symbols.forEach((symbol, index) => {
      if (Math.random() > 0.5) { // 50% chance of having a position
        const side = Math.random() > 0.5 ? 'LONG' : 'SHORT';
        const size = Math.random() * 5 + 0.1;
        const entryPrice = 43000 + (Math.random() - 0.5) * 20000;
        const currentPrice = entryPrice * (1 + (Math.random() - 0.5) * 0.1);
        const unrealizedPnl = (currentPrice - entryPrice) * size * (side === 'LONG' ? 1 : -1);
        
        positions.push({
          symbol,
          side,
          size,
          entryPrice,
          currentPrice,
          unrealizedPnl,
          realizedPnl: 0,
          percentage: (unrealizedPnl / (entryPrice * size)) * 100,
          margin: entryPrice * size * 0.1, // 10x leverage
          leverage: 10,
          liquidationPrice: side === 'LONG' ? entryPrice * 0.9 : entryPrice * 1.1,
          timestamp: Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000
        });
      }
    });
    
    return positions;
  }

  // Get portfolio summary
  async getPortfolio(): Promise<Portfolio> {
    try {
      if (this.portfolio && Date.now() - (this.portfolio as any).lastUpdate < 30000) {
        return this.portfolio; // Return cached data if less than 30 seconds old
      }
      
      const portfolio = await api.get('/v1/trading/portfolio');
      this.portfolio = portfolio;
      (this.portfolio as any).lastUpdate = Date.now();
      
      return portfolio;
    } catch (error) {
      console.error('Failed to get portfolio:', error);
      return this.getMockPortfolio();
    }
  }

  private getMockPortfolio(): Portfolio {
    const positions = this.getMockPositions();
    const totalValue = 100000; // $100k portfolio
    const usedMargin = positions.reduce((sum, pos) => sum + pos.margin, 0);
    const unrealizedPnl = positions.reduce((sum, pos) => sum + pos.unrealizedPnl, 0);
    
    const portfolio: Portfolio = {
      totalValue: totalValue + unrealizedPnl,
      availableBalance: totalValue - usedMargin,
      usedMargin,
      freeMargin: totalValue - usedMargin,
      marginLevel: usedMargin > 0 ? (totalValue / usedMargin) * 100 : 0,
      positions,
      dailyPnl: (Math.random() - 0.5) * 5000,
      totalPnl: unrealizedPnl,
      equity: totalValue + unrealizedPnl,
      assets: [
        { asset: 'USDT', free: 50000, locked: 10000, total: 60000, btcValue: 1.4, usdValue: 60000 },
        { asset: 'BTC', free: 0.5, locked: 0.2, total: 0.7, btcValue: 0.7, usdValue: 30000 },
        { asset: 'ETH', free: 2, locked: 1, total: 3, btcValue: 0.15, usdValue: 6000 }
      ]
    };
    
    this.portfolio = portfolio;
    (this.portfolio as any).lastUpdate = Date.now();
    
    return portfolio;
  }

  // Get risk metrics
  async getRiskMetrics(): Promise<RiskMetrics> {
    try {
      if (this.riskMetrics && Date.now() - (this.riskMetrics as any).lastUpdate < 60000) {
        return this.riskMetrics; // Return cached data if less than 1 minute old
      }
      
      const riskMetrics = await api.get('/v1/trading/risk-metrics');
      this.riskMetrics = riskMetrics;
      (this.riskMetrics as any).lastUpdate = Date.now();
      
      return riskMetrics;
    } catch (error) {
      console.error('Failed to get risk metrics:', error);
      return this.getMockRiskMetrics();
    }
  }

  private getMockRiskMetrics(): RiskMetrics {
    const riskMetrics: RiskMetrics = {
      portfolioRisk: 15 + Math.random() * 20, // 15-35%
      valueAtRisk: 2000 + Math.random() * 3000, // $2k-5k
      maxDrawdown: 5 + Math.random() * 15, // 5-20%
      sharpeRatio: 1 + Math.random() * 2, // 1-3
      sortinoRatio: 1.2 + Math.random() * 2, // 1.2-3.2
      calmarRatio: 0.5 + Math.random() * 1.5, // 0.5-2
      winRate: 60 + Math.random() * 25, // 60-85%
      profitFactor: 1.2 + Math.random() * 1.8, // 1.2-3
      averageWin: 150 + Math.random() * 300, // $150-450
      averageLoss: 80 + Math.random() * 120, // $80-200
      largestWin: 1000 + Math.random() * 2000, // $1k-3k
      largestLoss: 500 + Math.random() * 1000, // $500-1.5k
      consecutiveWins: Math.floor(Math.random() * 10) + 1,
      consecutiveLosses: Math.floor(Math.random() * 5) + 1,
      totalTrades: 100 + Math.floor(Math.random() * 500),
      correlation: {
        'BTCUSDT': 1.0,
        'ETHUSDT': 0.8 + Math.random() * 0.15,
        'BNBUSDT': 0.6 + Math.random() * 0.25,
        'SOLUSDT': 0.7 + Math.random() * 0.2
      }
    };
    
    this.riskMetrics = riskMetrics;
    (this.riskMetrics as any).lastUpdate = Date.now();
    
    return riskMetrics;
  }

  // Calculate correlation between symbols
  private async calculateCorrelation(symbol: string): Promise<number> {
    const riskMetrics = await this.getRiskMetrics();
    return riskMetrics.correlation[symbol] || 0;
  }

  // Place order from AI signal
  async placeOrderFromSignal(signal: any, positionSize?: number): Promise<Order> {
    const portfolio = await this.getPortfolio();
    
    // Calculate position size based on risk management
    const calculatedSize = positionSize || this.calculatePositionSize(signal, portfolio);
    
    const orderRequest: OrderRequest = {
      symbol: signal.symbol,
      side: signal.direction,
      type: 'LIMIT',
      quantity: calculatedSize,
      price: signal.entryPrice,
      stopPrice: signal.stopLoss,
      timeInForce: 'GTC',
      clientOrderId: `signal_${signal.id}`
    };

    return this.placeOrder(orderRequest);
  }

  private calculatePositionSize(signal: any, portfolio: Portfolio): number {
    // Kelly Criterion with risk management
    const winRate = signal.confidence / 100;
    const riskRewardRatio = signal.riskRewardRatio || 2;
    
    // Kelly percentage
    const kellyPercent = (winRate * riskRewardRatio - (1 - winRate)) / riskRewardRatio;
    
    // Apply risk management constraints
    const maxRiskPercent = this.riskSettings.maxPortfolioRisk;
    const riskPercent = Math.min(kellyPercent, maxRiskPercent);
    
    // Calculate position size
    const riskAmount = portfolio.totalValue * riskPercent;
    const stopLossDistance = Math.abs(signal.entryPrice - signal.stopLoss);
    const positionSize = riskAmount / stopLossDistance;
    
    return Math.max(0.001, positionSize); // Minimum position size
  }

  // Emergency stop all trading
  async emergencyStop(): Promise<void> {
    console.log('EMERGENCY STOP: Canceling all orders and closing positions');
    
    try {
      // Cancel all active orders
      const cancelPromises = Array.from(this.activeOrders.keys()).map(orderId => 
        this.cancelOrder(orderId).catch(error => 
          console.error(`Failed to cancel order ${orderId}:`, error)
        )
      );
      
      await Promise.allSettled(cancelPromises);
      
      // Close all positions (would implement position closing logic)
      const positions = await this.getPositions();
      const closePromises = positions.map(position => 
        this.closePosition(position).catch(error => 
          console.error(`Failed to close position ${position.symbol}:`, error)
        )
      );
      
      await Promise.allSettled(closePromises);
      
      this.emit('emergencyStop', { timestamp: Date.now() });
    } catch (error) {
      console.error('Emergency stop failed:', error);
      throw error;
    }
  }

  private async closePosition(position: Position): Promise<void> {
    const orderRequest: OrderRequest = {
      symbol: position.symbol,
      side: position.side === 'LONG' ? 'SELL' : 'BUY',
      type: 'MARKET',
      quantity: position.size,
      timeInForce: 'IOC'
    };

    await this.placeOrder(orderRequest);
  }

  // Update risk settings
  updateRiskSettings(newSettings: Partial<typeof this.riskSettings>): void {
    this.riskSettings = { ...this.riskSettings, ...newSettings };
    this.emit('riskSettingsUpdated', this.riskSettings);
  }

  // Get current risk settings
  getRiskSettings(): typeof this.riskSettings {
    return { ...this.riskSettings };
  }

  // Get active orders
  getActiveOrders(): Order[] {
    return Array.from(this.activeOrders.values());
  }

  // Get exchange configurations
  getExchangeConfigs(): ExchangeConfig[] {
    return Array.from(this.exchanges.values());
  }

  // Enable/disable exchange
  setExchangeEnabled(exchangeName: string, enabled: boolean): void {
    const exchange = this.exchanges.get(exchangeName);
    if (exchange) {
      exchange.enabled = enabled;
      this.emit('exchangeStatusChanged', { exchange: exchangeName, enabled });
    }
  }

  // Update exchange API keys
  updateExchangeKeys(exchangeName: string, apiKey: string, secretKey: string): void {
    const exchange = this.exchanges.get(exchangeName);
    if (exchange) {
      exchange.apiKey = apiKey;
      exchange.secretKey = secretKey;
      this.emit('exchangeKeysUpdated', { exchange: exchangeName });
    }
  }
}

// Create singleton instance
export const tradingService = new TradingService();

// Export types
export type {
  Order,
  Position,
  Portfolio,
  RiskMetrics,
  OrderRequest,
  TradeExecution,
  ExchangeConfig
};

export default tradingService;
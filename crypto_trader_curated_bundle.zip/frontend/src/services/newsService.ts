import api from './api';

export interface NewsArticle {
  id: string;
  title: string;
  description: string;
  url: string;
  source: string;
  publishedAt: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  relevanceScore: number;
}

export interface NewsResponse {
  articles: NewsArticle[];
  totalResults: number;
  query: string;
  timestamp: string;
}

class NewsService {
  async getLatest(query: string = 'bitcoin cryptocurrency'): Promise<NewsResponse> {
    return api.get<NewsResponse>('/news', { params: { query } });
  }

  async getSentiment(): Promise<{
    overall: 'positive' | 'negative' | 'neutral';
    score: number;
    confidence: number;
    timestamp: string;
  }> {
    return api.get('/sentiment');
  }
}

const newsService = new NewsService();
export default newsService;
import api from './api';
import { Strategy, BacktestResult } from '@/services/strategyBuilderService';

// API endpoints for strategy management
const STRATEGY_API = '/strategies';

// Convert frontend strategy to backend format
const convertToApiStrategy = (strategy: Strategy): any => {
  return {
    name: strategy.name,
    description: strategy.description,
    components: strategy.components,
    connections: strategy.connections,
    symbol: strategy.symbol,
    timeframe: strategy.timeframe,
    is_active: strategy.isActive
  };
};

// Convert backend strategy to frontend format
const convertFromApiStrategy = (apiStrategy: any): Strategy => {
  return {
    id: apiStrategy.id.toString(),
    name: apiStrategy.name,
    description: apiStrategy.description || '',
    components: apiStrategy.components,
    connections: apiStrategy.connections,
    isActive: apiStrategy.is_active || false,
    symbol: apiStrategy.symbol,
    timeframe: apiStrategy.timeframe,
    createdAt: new Date(apiStrategy.created_at).getTime(),
    updatedAt: new Date(apiStrategy.updated_at).getTime(),
    backtestResults: apiStrategy.backtest_results ? convertFromApiBacktestResult(apiStrategy.backtest_results[0]) : undefined
  };
};

// Convert backend backtest result to frontend format
const convertFromApiBacktestResult = (apiBacktest: any): BacktestResult => {
  return {
    id: apiBacktest.id.toString(),
    strategyId: apiBacktest.strategy_id.toString(),
    startDate: new Date(apiBacktest.start_date).getTime(),
    endDate: new Date(apiBacktest.end_date).getTime(),
    symbol: apiBacktest.symbol,
    timeframe: apiBacktest.timeframe,
    trades: apiBacktest.trades.map((trade: any) => ({
      id: trade.id || Math.random().toString(36).substring(2, 15),
      entryTime: new Date(trade.entry_time).getTime(),
      entryPrice: trade.entry_price,
      exitTime: new Date(trade.exit_time).getTime(),
      exitPrice: trade.exit_price,
      direction: trade.direction,
      profit: trade.profit,
      profitPercentage: trade.profit_percentage,
      initialStopLoss: trade.initial_stop_loss || 0,
      initialTakeProfit: trade.initial_take_profit || 0,
      quantity: trade.quantity,
      exitReason: trade.exit_reason
    })),
    metrics: {
      totalTrades: apiBacktest.metrics.total_trades,
      winningTrades: apiBacktest.metrics.winning_trades,
      losingTrades: apiBacktest.metrics.losing_trades,
      winRate: apiBacktest.metrics.win_rate,
      profitFactor: apiBacktest.metrics.profit_factor,
      netProfit: apiBacktest.metrics.net_profit,
      maxDrawdown: apiBacktest.metrics.max_drawdown,
      sharpeRatio: apiBacktest.metrics.sharpe_ratio,
      averageWin: apiBacktest.metrics.average_win,
      averageLoss: apiBacktest.metrics.average_loss,
      largestWin: apiBacktest.metrics.largest_win,
      largestLoss: apiBacktest.metrics.largest_loss
    }
  };
};

// Strategy API service
const strategyApiService = {
  // Get all strategies
  async getStrategies(): Promise<Strategy[]> {
    try {
      const response = await api.get(STRATEGY_API);
      return response.map(convertFromApiStrategy);
    } catch (error) {
      console.error('Failed to fetch strategies:', error);
      return [];
    }
  },

  // Get strategy by ID
  async getStrategy(id: string): Promise<Strategy | null> {
    try {
      const response = await api.get(`${STRATEGY_API}/${id}`);
      return convertFromApiStrategy(response);
    } catch (error) {
      console.error(`Failed to fetch strategy ${id}:`, error);
      return null;
    }
  },

  // Create new strategy
  async createStrategy(strategy: Omit<Strategy, 'id' | 'createdAt' | 'updatedAt'>): Promise<Strategy | null> {
    try {
      const response = await api.post(STRATEGY_API, convertToApiStrategy(strategy as Strategy));
      return convertFromApiStrategy(response);
    } catch (error) {
      console.error('Failed to create strategy:', error);
      return null;
    }
  },

  // Update strategy
  async updateStrategy(id: string, strategy: Partial<Strategy>): Promise<Strategy | null> {
    try {
      const response = await api.put(`${STRATEGY_API}/${id}`, convertToApiStrategy({
        ...strategy,
        id,
        createdAt: Date.now(),
        updatedAt: Date.now()
      } as Strategy));
      return convertFromApiStrategy(response);
    } catch (error) {
      console.error(`Failed to update strategy ${id}:`, error);
      return null;
    }
  },

  // Delete strategy
  async deleteStrategy(id: string): Promise<boolean> {
    try {
      await api.delete(`${STRATEGY_API}/${id}`);
      return true;
    } catch (error) {
      console.error(`Failed to delete strategy ${id}:`, error);
      return false;
    }
  },

  // Run backtest
  async runBacktest(
    strategyId: string,
    symbol: string,
    timeframe: string,
    startDate: Date,
    endDate: Date
  ): Promise<BacktestResult | null> {
    try {
      const response = await api.post(`${STRATEGY_API}/${strategyId}/backtest`, {
        symbol,
        timeframe,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString()
      });
      return convertFromApiBacktestResult(response);
    } catch (error) {
      console.error(`Failed to run backtest for strategy ${strategyId}:`, error);
      return null;
    }
  },

  // Get backtest results
  async getBacktestResults(strategyId: string): Promise<BacktestResult[]> {
    try {
      const response = await api.get(`${STRATEGY_API}/${strategyId}/backtests`);
      return response.map(convertFromApiBacktestResult);
    } catch (error) {
      console.error(`Failed to fetch backtest results for strategy ${strategyId}:`, error);
      return [];
    }
  },

  // Deploy strategy
  async deployStrategy(strategyId: string): Promise<boolean> {
    try {
      await api.post(`${STRATEGY_API}/${strategyId}/deploy`);
      return true;
    } catch (error) {
      console.error(`Failed to deploy strategy ${strategyId}:`, error);
      return false;
    }
  },

  // Stop strategy
  async stopStrategy(strategyId: string): Promise<boolean> {
    try {
      await api.post(`${STRATEGY_API}/${strategyId}/stop`);
      return true;
    } catch (error) {
      console.error(`Failed to stop strategy ${strategyId}:`, error);
      return false;
    }
  }
};

export default strategyApiService;
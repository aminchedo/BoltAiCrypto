import api from './api';
import marketService, { Candle } from './marketService';
import { Signal } from './signalService';

// Define interfaces for each component of the hybrid trading system
interface TechnicalAnalysisResult {
  rsi: number;
  macd: { macd: number; signal: number; histogram: number };
  score: number; // -1 to 1 range
}

interface SmartMoneyResult {
  orderBlocks: Array<{ price: number; strength: number; type: 'bullish' | 'bearish' }>;
  fairValueGaps: Array<{ high: number; low: number; strength: number }>;
  liquidityZones: Array<{ price: number; volume: number; type: 'buy' | 'sell' }>;
  marketStructure: {
    trend: 'bullish' | 'bearish' | 'sideways';
    strength: number;
    breakOfStructure: boolean;
  };
  supplyDemand: {
    supply: Array<{ price: number; strength: number }>;
    demand: Array<{ price: number; strength: number }>;
  };
  score: number; // -1 to 1 range
}

interface PatternRecognitionResult {
  harmonicPatterns: Array<{
    type: 'butterfly' | 'bat' | 'gartley' | 'crab';
    confidence: number;
    target: number;
    stopLoss: number;
  }>;
  classicPatterns: Array<{
    type: 'head_shoulders' | 'double_top' | 'double_bottom' | 'triangle';
    confidence: number;
    target: number;
  }>;
  candlestickPatterns: Array<{
    type: string;
    confidence: number;
    bullish: boolean;
  }>;
  score: number; // -1 to 1 range
}

interface SentimentAnalysisResult {
  newsScore: number; // -1 to 1
  socialScore: number; // -1 to 1
  fearGreedIndex: number; // 0 to 100
  overallSentiment: number; // -1 to 1
  score: number; // -1 to 1 range
}

interface WhaleMovementResult {
  largeTransactions: Array<{
    amount: number;
    type: 'inflow' | 'outflow';
    exchange: string;
    timestamp: number;
  }>;
  exchangeFlows: {
    netFlow: number;
    inflowVolume: number;
    outflowVolume: number;
  };
  whaleScore: number; // -1 to 1
  score: number; // -1 to 1 range
}

interface MLPredictionResult {
  priceTarget1h: number;
  priceTarget4h: number;
  priceTarget24h: number;
  confidence: number;
  volatilityPrediction: number;
  trendPrediction: 'up' | 'down' | 'sideways';
  score: number; // -1 to 1 range
}

// Hybrid signal with algorithm breakdown
export interface HybridSignal extends Signal {
  algorithmBreakdown: {
    technicalAnalysis: { score: number; weight: number; contribution: number };
    smartMoneyConcepts: { score: number; weight: number; contribution: number };
    patternRecognition: { score: number; weight: number; contribution: number };
    sentimentAnalysis: { score: number; weight: number; contribution: number };
    whaleIntelligence: { score: number; weight: number; contribution: number };
    mlPredictions: { score: number; weight: number; contribution: number };
    finalScore: number;
  };
  riskAssessment: {
    riskScore: number;
    maxLossAmount: number;
    positionSizeRecommendation: number;
    marketImpact: 'LOW' | 'MEDIUM' | 'HIGH';
  };
  marketConditions: {
    volatility: number;
    volumeProfile: 'HIGH' | 'MEDIUM' | 'LOW';
    trendStrength: number;
    supportResistance: { support: number; resistance: number };
  };
}

/**
 * HybridTradingEngine implements the AI Hybrid Trading System with the following weights:
 * - RSI + MACD Analysis: 40%
 * - Smart Money Concepts: 25%
 * - Pattern Recognition: 20%
 * - Sentiment Analysis: 7%
 * - Whale Movements: 3%
 * - ML Predictions: 5%
 */
class HybridTradingEngine {
  // Component weights
  private readonly TECHNICAL_ANALYSIS_WEIGHT = 0.40;
  private readonly SMART_MONEY_WEIGHT = 0.25;
  private readonly PATTERN_RECOGNITION_WEIGHT = 0.20;
  private readonly SENTIMENT_ANALYSIS_WEIGHT = 0.07;
  private readonly WHALE_MOVEMENT_WEIGHT = 0.03;
  private readonly ML_PREDICTION_WEIGHT = 0.05;

  // Cache for signals
  private signalCache: Map<string, HybridSignal> = new Map();
  private lastUpdate: Map<string, number> = new Map();
  private readonly CACHE_DURATION = 60000; // 1 minute

  /**
   * Generate a trading signal for the specified symbol
   * @param symbol Trading pair symbol (e.g., BTCUSDT)
   * @returns A hybrid trading signal with confidence score and entry/exit recommendations
   */
  async generateTradingSignal(symbol: string): Promise<HybridSignal | null> {
    try {
      // Check cache first
      const cacheKey = symbol;
      const lastUpdateTime = this.lastUpdate.get(cacheKey) || 0;
      const cachedSignal = this.signalCache.get(cacheKey);

      if (cachedSignal && Date.now() - lastUpdateTime < this.CACHE_DURATION) {
        return cachedSignal;
      }

      // Get historical data for analysis
      const historicalData = await marketService.getHistoricalPrices(
        symbol,
        new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
        new Date(),
        '1h'
      );

      if (historicalData.length < 50) {
        console.warn(`Insufficient data for ${symbol}`);
        return null;
      }

      // Calculate all components
      const technicalAnalysis = await this.calculateTechnicalAnalysis(symbol, historicalData);
      const smartMoney = await this.analyzeSmartMoney(symbol, historicalData);
      const patternRecognition = await this.recognizePatterns(symbol, historicalData);
      const sentimentAnalysis = await this.analyzeSentiment(symbol);
      const whaleMovement = await this.analyzeWhaleMovement(symbol);
      const mlPrediction = await this.generateMLPrediction(symbol, historicalData);

      // Calculate weighted final score
      const finalScore = 
        technicalAnalysis.score * this.TECHNICAL_ANALYSIS_WEIGHT +
        smartMoney.score * this.SMART_MONEY_WEIGHT +
        patternRecognition.score * this.PATTERN_RECOGNITION_WEIGHT +
        sentimentAnalysis.score * this.SENTIMENT_ANALYSIS_WEIGHT +
        whaleMovement.score * this.WHALE_MOVEMENT_WEIGHT +
        mlPrediction.score * this.ML_PREDICTION_WEIGHT;

      // Determine signal direction and confidence
      const direction = finalScore > 0.1 ? 'BUY' : finalScore < -0.1 ? 'SELL' : 'HOLD';
      const confidence = Math.min(Math.abs(finalScore) * 100, 100);

      if (confidence < 60) {
        return null; // Don't generate low-confidence signals
      }

      const currentPrice = historicalData[historicalData.length - 1].close;
      const volatility = this.calculateVolatility(historicalData);

      // Calculate entry, stop loss, and take profit
      const stopLossDistance = volatility * 2;
      const takeProfitDistance = volatility * 3;

      const signal: HybridSignal = {
        id: `${symbol}_${Date.now()}`,
        symbol,
        direction: direction as 'BUY' | 'SELL' | 'HOLD',
        confidence: Math.round(confidence),
        entryPrice: currentPrice,
        stopLoss: direction === 'BUY'
          ? currentPrice - stopLossDistance
          : currentPrice + stopLossDistance,
        takeProfit: direction === 'BUY'
          ? currentPrice + takeProfitDistance
          : currentPrice - takeProfitDistance,
        riskRewardRatio: takeProfitDistance / stopLossDistance,
        timestamp: Date.now(),
        expiresAt: Date.now() + 4 * 60 * 60 * 1000, // 4 hours
        status: 'ACTIVE',
        algorithmBreakdown: {
          technicalAnalysis: {
            score: technicalAnalysis.score,
            weight: this.TECHNICAL_ANALYSIS_WEIGHT,
            contribution: technicalAnalysis.score * this.TECHNICAL_ANALYSIS_WEIGHT
          },
          smartMoneyConcepts: {
            score: smartMoney.score,
            weight: this.SMART_MONEY_WEIGHT,
            contribution: smartMoney.score * this.SMART_MONEY_WEIGHT
          },
          patternRecognition: {
            score: patternRecognition.score,
            weight: this.PATTERN_RECOGNITION_WEIGHT,
            contribution: patternRecognition.score * this.PATTERN_RECOGNITION_WEIGHT
          },
          sentimentAnalysis: {
            score: sentimentAnalysis.score,
            weight: this.SENTIMENT_ANALYSIS_WEIGHT,
            contribution: sentimentAnalysis.score * this.SENTIMENT_ANALYSIS_WEIGHT
          },
          whaleIntelligence: {
            score: whaleMovement.score,
            weight: this.WHALE_MOVEMENT_WEIGHT,
            contribution: whaleMovement.score * this.WHALE_MOVEMENT_WEIGHT
          },
          mlPredictions: {
            score: mlPrediction.score,
            weight: this.ML_PREDICTION_WEIGHT,
            contribution: mlPrediction.score * this.ML_PREDICTION_WEIGHT
          },
          finalScore
        },
        riskAssessment: {
          riskScore: this.calculateRiskScore(historicalData, smartMoney),
          maxLossAmount: stopLossDistance,
          positionSizeRecommendation: this.calculatePositionSize(confidence, stopLossDistance),
          marketImpact: this.assessMarketImpact(historicalData)
        },
        marketConditions: {
          volatility: (volatility / currentPrice) * 100,
          volumeProfile: this.assessVolumeProfile(historicalData),
          trendStrength: Math.abs(technicalAnalysis.score) * 100,
          supportResistance: this.findSupportResistance(historicalData)
        }
      };

      // Cache the signal
      this.signalCache.set(cacheKey, signal);
      this.lastUpdate.set(cacheKey, Date.now());

      return signal;
    } catch (error) {
      console.error(`Error generating trading signal for ${symbol}:`, error);
      return null;
    }
  }

  /**
   * Generate trading signals for multiple symbols
   * @param symbols Array of trading pair symbols
   * @returns Array of hybrid trading signals
   */
  async generateTradingSignals(symbols: string[]): Promise<HybridSignal[]> {
    const signals: HybridSignal[] = [];

    for (const symbol of symbols) {
      try {
        const signal = await this.generateTradingSignal(symbol);
        if (signal) {
          signals.push(signal);
        }
      } catch (error) {
        console.error(`Failed to generate signal for ${symbol}:`, error);
      }
    }

    return signals;
  }

  /**
   * Calculate technical analysis indicators (RSI + MACD)
   * Weight: 40%
   */
  private async calculateTechnicalAnalysis(symbol: string, data: Candle[]): Promise<TechnicalAnalysisResult> {
    try {
      // Try to get from API first
      const apiResult = await api.get<TechnicalAnalysisResult>(`/v1/analysis/technical/${symbol}`).catch(() => null);
      
      if (apiResult) {
        return apiResult;
      }

      // Calculate locally if API fails
      const closes = data.map(d => d.close);
      
      // Calculate RSI
      const rsi = this.calculateRSI(closes, 14);
      
      // Calculate MACD
      const macd = this.calculateMACD(closes);
      
      // Calculate score based on indicators
      let score = 0;
      
      // RSI contribution
      if (rsi < 30) score += 0.8; // Oversold - bullish
      else if (rsi > 70) score -= 0.8; // Overbought - bearish
      else if (rsi > 45 && rsi < 55) score += 0.2; // Neutral
      
      // MACD contribution
      if (macd.histogram > 0 && macd.macd > macd.signal) score += 0.6; // Bullish
      else if (macd.histogram < 0 && macd.macd < macd.signal) score -= 0.6; // Bearish
      
      // Normalize score to -1 to 1 range
      score = Math.max(-1, Math.min(1, score));
      
      return {
        rsi,
        macd,
        score
      };
    } catch (error) {
      console.error('Error calculating technical analysis:', error);
      return {
        rsi: 50,
        macd: { macd: 0, signal: 0, histogram: 0 },
        score: 0
      };
    }
  }

  /**
   * Analyze smart money concepts
   * Weight: 25%
   */
  private async analyzeSmartMoney(symbol: string, data: Candle[]): Promise<SmartMoneyResult> {
    try {
      // Try to get from API first
      const apiResult = await api.get<SmartMoneyResult>(`/v1/analysis/smartmoney/${symbol}`).catch(() => null);
      
      if (apiResult) {
        return apiResult;
      }

      // Calculate locally if API fails
      const orderBlocks = this.findOrderBlocks(data);
      const fairValueGaps = this.findFairValueGaps(data);
      const liquidityZones = this.findLiquidityZones(data);
      const marketStructure = this.analyzeMarketStructure(data);
      const supplyDemand = this.findSupplyDemandZones(data);
      
      // Calculate score based on smart money concepts
      let score = 0;
      
      // Market structure contribution
      if (marketStructure.trend === 'bullish') score += 0.4;
      else if (marketStructure.trend === 'bearish') score -= 0.4;
      
      // Break of structure contribution
      if (marketStructure.breakOfStructure) {
        score += marketStructure.trend === 'bullish' ? 0.3 : -0.3;
      }
      
      // Order blocks contribution
      const bullishBlocks = orderBlocks.filter(ob => ob.type === 'bullish').length;
      const bearishBlocks = orderBlocks.filter(ob => ob.type === 'bearish').length;
      score += (bullishBlocks - bearishBlocks) * 0.1;
      
      // Supply/demand balance
      const supplyStrength = supplyDemand.supply.reduce((sum, s) => sum + s.strength, 0);
      const demandStrength = supplyDemand.demand.reduce((sum, d) => sum + d.strength, 0);
      score += (demandStrength - supplyStrength) * 0.001;
      
      // Normalize score to -1 to 1 range
      score = Math.max(-1, Math.min(1, score));
      
      return {
        orderBlocks,
        fairValueGaps,
        liquidityZones,
        marketStructure,
        supplyDemand,
        score
      };
    } catch (error) {
      console.error('Error analyzing smart money concepts:', error);
      return {
        orderBlocks: [],
        fairValueGaps: [],
        liquidityZones: [],
        marketStructure: { trend: 'sideways', strength: 0, breakOfStructure: false },
        supplyDemand: { supply: [], demand: [] },
        score: 0
      };
    }
  }

  /**
   * Recognize chart and candlestick patterns
   * Weight: 20%
   */
  private async recognizePatterns(symbol: string, data: Candle[]): Promise<PatternRecognitionResult> {
    try {
      // Try to get from API first
      const apiResult = await api.get<PatternRecognitionResult>(`/v1/analysis/patterns/${symbol}`).catch(() => null);
      
      if (apiResult) {
        return apiResult;
      }

      // Calculate locally if API fails
      const harmonicPatterns = this.findHarmonicPatterns(data);
      const classicPatterns = this.findClassicPatterns(data);
      const candlestickPatterns = this.findCandlestickPatterns(data);
      
      // Calculate score based on patterns
      let score = 0;
      let weight = 0;
      
      // Harmonic patterns contribution
      harmonicPatterns.forEach(pattern => {
        const patternScore = (pattern.confidence / 100) * 0.8;
        score += patternScore;
        weight += 0.8;
      });
      
      // Classic patterns contribution
      classicPatterns.forEach(pattern => {
        const patternScore = (pattern.confidence / 100) * 0.6;
        score += patternScore;
        weight += 0.6;
      });
      
      // Candlestick patterns contribution
      candlestickPatterns.forEach(pattern => {
        const patternScore = (pattern.confidence / 100) * (pattern.bullish ? 0.4 : -0.4);
        score += patternScore;
        weight += 0.4;
      });
      
      // Normalize score
      score = weight > 0 ? score / weight : 0;
      
      // Ensure score is in -1 to 1 range
      score = Math.max(-1, Math.min(1, score));
      
      return {
        harmonicPatterns,
        classicPatterns,
        candlestickPatterns,
        score
      };
    } catch (error) {
      console.error('Error recognizing patterns:', error);
      return {
        harmonicPatterns: [],
        classicPatterns: [],
        candlestickPatterns: [],
        score: 0
      };
    }
  }

  /**
   * Analyze market sentiment from news and social media
   * Weight: 7%
   */
  private async analyzeSentiment(symbol: string): Promise<SentimentAnalysisResult> {
    try {
      // Try to get from API first
      const apiResult = await api.get<SentimentAnalysisResult>(`/v1/analysis/sentiment/${symbol}`).catch(() => null);
      
      if (apiResult) {
        return apiResult;
      }

      // Mock data if API fails
      // In a real implementation, this would call news and social media APIs
      const newsScore = (Math.random() - 0.5) * 2;
      const socialScore = (Math.random() - 0.5) * 2;
      const fearGreedIndex = Math.random() * 100;
      
      // Calculate overall sentiment score
      const overallSentiment = (newsScore * 0.6 + socialScore * 0.4);
      
      return {
        newsScore,
        socialScore,
        fearGreedIndex,
        overallSentiment,
        score: overallSentiment
      };
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
      return {
        newsScore: 0,
        socialScore: 0,
        fearGreedIndex: 50,
        overallSentiment: 0,
        score: 0
      };
    }
  }

  /**
   * Analyze whale movements and large transactions
   * Weight: 3%
   */
  private async analyzeWhaleMovement(symbol: string): Promise<WhaleMovementResult> {
    try {
      // Try to get from API first
      const apiResult = await api.get<WhaleMovementResult>(`/v1/analysis/whale/${symbol}`).catch(() => null);
      
      if (apiResult) {
        return apiResult;
      }

      // Mock data if API fails
      // In a real implementation, this would analyze blockchain data
      const whaleScore = (Math.random() - 0.5) * 2;
      
      return {
        largeTransactions: [
          {
            amount: Math.random() * 1000000,
            type: Math.random() > 0.5 ? 'inflow' : 'outflow',
            exchange: 'binance',
            timestamp: Date.now() - Math.random() * 24 * 60 * 60 * 1000
          }
        ],
        exchangeFlows: {
          netFlow: (Math.random() - 0.5) * 10000000,
          inflowVolume: Math.random() * 50000000,
          outflowVolume: Math.random() * 50000000
        },
        whaleScore,
        score: whaleScore
      };
    } catch (error) {
      console.error('Error analyzing whale movements:', error);
      return {
        largeTransactions: [],
        exchangeFlows: { netFlow: 0, inflowVolume: 0, outflowVolume: 0 },
        whaleScore: 0,
        score: 0
      };
    }
  }

  /**
   * Generate ML-based price predictions
   * Weight: 5%
   */
  private async generateMLPrediction(symbol: string, data: Candle[]): Promise<MLPredictionResult> {
    try {
      // Try to get from API first
      const apiResult = await api.get<MLPredictionResult>(`/v1/analysis/ml/${symbol}`).catch(() => null);
      
      if (apiResult) {
        return apiResult;
      }

      // Mock data if API fails
      // In a real implementation, this would use trained ML models
      const currentPrice = data[data.length - 1].close;
      const volatility = this.calculateVolatility(data);
      
      const priceChange24h = (Math.random() - 0.5) * 0.1; // -5% to +5%
      const confidence = 60 + Math.random() * 30; // 60-90% confidence
      
      // Calculate score based on predicted direction and confidence
      const score = priceChange24h * (confidence / 100);
      
      return {
        priceTarget1h: currentPrice * (1 + (Math.random() - 0.5) * 0.02),
        priceTarget4h: currentPrice * (1 + (Math.random() - 0.5) * 0.05),
        priceTarget24h: currentPrice * (1 + priceChange24h),
        confidence,
        volatilityPrediction: volatility * (0.8 + Math.random() * 0.4),
        trendPrediction: priceChange24h > 0.01 ? 'up' : priceChange24h < -0.01 ? 'down' : 'sideways',
        score
      };
    } catch (error) {
      console.error('Error generating ML prediction:', error);
      return {
        priceTarget1h: 0,
        priceTarget4h: 0,
        priceTarget24h: 0,
        confidence: 0,
        volatilityPrediction: 0,
        trendPrediction: 'sideways',
        score: 0
      };
    }
  }

  // Helper methods for technical analysis
  private calculateRSI(prices: number[], period: number): number {
    if (prices.length < period + 1) return 50;

    let gains = 0;
    let losses = 0;

    for (let i = 1; i <= period; i++) {
      const change = prices[prices.length - i] - prices[prices.length - i - 1];
      if (change > 0) gains += change;
      else losses -= change;
    }

    const avgGain = gains / period;
    const avgLoss = losses / period;

    if (avgLoss === 0) return 100;

    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  private calculateMACD(prices: number[]): { macd: number; signal: number; histogram: number } {
    const ema12 = this.calculateEMA(prices, 12);
    const ema26 = this.calculateEMA(prices, 26);
    const macd = ema12 - ema26;
    const signal = this.calculateEMA(prices.slice(-9).map(() => macd), 9); // Simplified
    const histogram = macd - signal;

    return { macd, signal, histogram };
  }

  private calculateEMA(prices: number[], period: number): number {
    if (prices.length === 0) return 0;

    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }

    return ema;
  }

  private calculateVolatility(data: Candle[]): number {
    // Use ATR (Average True Range) as volatility measure
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);
    const closes = data.map(d => d.close);
    
    const trueRanges = [];
    for (let i = 1; i < data.length; i++) {
      const tr1 = highs[i] - lows[i];
      const tr2 = Math.abs(highs[i] - closes[i - 1]);
      const tr3 = Math.abs(lows[i] - closes[i - 1]);
      trueRanges.push(Math.max(tr1, tr2, tr3));
    }
    
    // Calculate average of true ranges
    const atr = trueRanges.reduce((sum, tr) => sum + tr, 0) / trueRanges.length;
    return atr;
  }

  // Helper methods for smart money analysis
  private findOrderBlocks(data: Candle[]): Array<{ price: number; strength: number; type: 'bullish' | 'bearish' }> {
    const orderBlocks = [];
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;

    for (let i = 2; i < data.length - 2; i++) {
      if (data[i].volume > avgVolume * 1.5) {
        const strength = (data[i].volume / avgVolume - 1) * 100;
        const type = data[i].close > data[i].open ? 'bullish' : 'bearish';

        orderBlocks.push({
          price: (data[i].high + data[i].low) / 2,
          strength,
          type
        });
      }
    }

    return orderBlocks.slice(-5); // Return last 5 order blocks
  }

  private findFairValueGaps(data: Candle[]): Array<{ high: number; low: number; strength: number }> {
    const gaps = [];

    for (let i = 1; i < data.length; i++) {
      const prevHigh = data[i - 1].high;
      const prevLow = data[i - 1].low;
      const currentHigh = data[i].high;
      const currentLow = data[i].low;

      // Gap up
      if (currentLow > prevHigh) {
        gaps.push({
          high: currentLow,
          low: prevHigh,
          strength: ((currentLow - prevHigh) / prevHigh) * 100
        });
      }
      // Gap down
      else if (currentHigh < prevLow) {
        gaps.push({
          high: prevLow,
          low: currentHigh,
          strength: ((prevLow - currentHigh) / currentHigh) * 100
        });
      }
    }

    return gaps.slice(-3); // Return last 3 gaps
  }

  private findLiquidityZones(data: Candle[]): Array<{ price: number; volume: number; type: 'buy' | 'sell' }> {
    const zones = [];
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;

    for (let i = 0; i < data.length; i++) {
      if (data[i].volume > avgVolume * 2) {
        zones.push({
          price: (data[i].high + data[i].low) / 2,
          volume: data[i].volume,
          type: data[i].close > data[i].open ? 'buy' : 'sell'
        });
      }
    }

    return zones.slice(-10); // Return last 10 zones
  }

  private analyzeMarketStructure(data: Candle[]): { trend: 'bullish' | 'bearish' | 'sideways'; strength: number; breakOfStructure: boolean } {
    const closes = data.map(d => d.close);
    const recentCloses = closes.slice(-20);

    const firstPrice = recentCloses[0];
    const lastPrice = recentCloses[recentCloses.length - 1];
    const change = (lastPrice - firstPrice) / firstPrice;

    let trend: 'bullish' | 'bearish' | 'sideways';
    if (change > 0.02) trend = 'bullish';
    else if (change < -0.02) trend = 'bearish';
    else trend = 'sideways';

    const strength = Math.abs(change) * 100;
    const breakOfStructure = strength > 5; // Simplified BOS detection

    return { trend, strength, breakOfStructure };
  }

  private findSupplyDemandZones(data: Candle[]): { supply: Array<{ price: number; strength: number }>; demand: Array<{ price: number; strength: number }> } {
    const supply = [];
    const demand = [];

    // Find resistance levels (supply)
    for (let i = 2; i < data.length - 2; i++) {
      if (data[i].high > data[i - 1].high && data[i].high > data[i - 2].high &&
        data[i].high > data[i + 1].high && data[i].high > data[i + 2].high) {
        supply.push({
          price: data[i].high,
          strength: data[i].volume / 1000000 // Simplified strength calculation
        });
      }
    }

    // Find support levels (demand)
    for (let i = 2; i < data.length - 2; i++) {
      if (data[i].low < data[i - 1].low && data[i].low < data[i - 2].low &&
        data[i].low < data[i + 1].low && data[i].low < data[i + 2].low) {
        demand.push({
          price: data[i].low,
          strength: data[i].volume / 1000000 // Simplified strength calculation
        });
      }
    }

    return {
      supply: supply.slice(-3),
      demand: demand.slice(-3)
    };
  }

  // Helper methods for pattern recognition
  private findHarmonicPatterns(data: Candle[]): Array<{ type: 'butterfly' | 'bat' | 'gartley' | 'crab'; confidence: number; target: number; stopLoss: number }> {
    // Simplified harmonic pattern detection
    const patterns = [];

    if (data.length < 20) return patterns;

    // Mock pattern detection for demonstration
    const currentPrice = data[data.length - 1].close;

    if (Math.random() > 0.7) { // 30% chance of finding a pattern
      const patternTypes: ('butterfly' | 'bat' | 'gartley' | 'crab')[] = ['butterfly', 'bat', 'gartley', 'crab'];
      const type = patternTypes[Math.floor(Math.random() * patternTypes.length)];

      patterns.push({
        type,
        confidence: 60 + Math.random() * 30,
        target: currentPrice * (1 + (Math.random() - 0.5) * 0.1),
        stopLoss: currentPrice * (1 - Math.random() * 0.05)
      });
    }

    return patterns;
  }

  private findClassicPatterns(data: Candle[]): Array<{ type: 'head_shoulders' | 'double_top' | 'double_bottom' | 'triangle'; confidence: number; target: number }> {
    const patterns = [];

    if (data.length < 30) return patterns;

    // Simplified classic pattern detection
    const currentPrice = data[data.length - 1].close;

    // Mock pattern detection
    if (Math.random() > 0.8) { // 20% chance
      const patternTypes: ('head_shoulders' | 'double_top' | 'double_bottom' | 'triangle')[] =
        ['head_shoulders', 'double_top', 'double_bottom', 'triangle'];
      const type = patternTypes[Math.floor(Math.random() * patternTypes.length)];

      patterns.push({
        type,
        confidence: 50 + Math.random() * 40,
        target: currentPrice * (1 + (Math.random() - 0.5) * 0.08)
      });
    }

    return patterns;
  }

  private findCandlestickPatterns(data: Candle[]): Array<{ type: string; confidence: number; bullish: boolean }> {
    const patterns = [];

    if (data.length < 3) return patterns;

    // Simplified candlestick pattern detection
    const patternTypes = [
      'doji', 'hammer', 'shooting_star', 'engulfing', 'harami',
      'morning_star', 'evening_star', 'three_white_soldiers'
    ];

    // Mock detection
    if (Math.random() > 0.6) { // 40% chance
      const type = patternTypes[Math.floor(Math.random() * patternTypes.length)];
      const bullish = ['hammer', 'engulfing', 'morning_star', 'three_white_soldiers'].includes(type);

      patterns.push({
        type,
        confidence: 60 + Math.random() * 30,
        bullish
      });
    }

    return patterns;
  }

  // Risk assessment methods
  private calculateRiskScore(data: Candle[], smartMoney: SmartMoneyResult): number {
    let riskScore = 50; // Base risk score

    // Volatility risk
    const volatility = this.calculateVolatility(data);
    const currentPrice = data[data.length - 1].close;
    const volatilityRisk = (volatility / currentPrice) * 100;
    riskScore += volatilityRisk * 10;

    // Market structure risk
    if (smartMoney.marketStructure.breakOfStructure) {
      riskScore += 20;
    }

    // Trend strength risk
    riskScore += smartMoney.marketStructure.strength * 0.2;

    return Math.min(100, Math.max(0, riskScore));
  }

  private calculatePositionSize(confidence: number, stopLossDistance: number): number {
    // Kelly Criterion simplified
    const winRate = confidence / 100;
    const avgWin = 2; // Assume 2:1 reward ratio
    const avgLoss = 1;

    const kellyPercent = (winRate * avgWin - (1 - winRate) * avgLoss) / avgWin;

    // Conservative position sizing (max 5% of portfolio)
    return Math.min(5, Math.max(0.5, kellyPercent * 100));
  }

  private assessMarketImpact(data: Candle[]): 'LOW' | 'MEDIUM' | 'HIGH' {
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    const recentVolume = volumes[volumes.length - 1];

    const volumeRatio = recentVolume / avgVolume;

    if (volumeRatio > 2) return 'HIGH';
    if (volumeRatio > 1.5) return 'MEDIUM';
    return 'LOW';
  }

  private assessVolumeProfile(data: Candle[]): 'HIGH' | 'MEDIUM' | 'LOW' {
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    const recentAvgVolume = volumes.slice(-5).reduce((sum, vol) => sum + vol, 0) / 5;

    const ratio = recentAvgVolume / avgVolume;

    if (ratio > 1.5) return 'HIGH';
    if (ratio > 0.8) return 'MEDIUM';
    return 'LOW';
  }

  private findSupportResistance(data: Candle[]): { support: number; resistance: number } {
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);

    // Simple support/resistance calculation
    const recentHighs = highs.slice(-20);
    const recentLows = lows.slice(-20);

    const resistance = Math.max(...recentHighs);
    const support = Math.min(...recentLows);

    return { support, resistance };
  }
}

const hybridTradingEngine = new HybridTradingEngine();
export default hybridTradingEngine;
import api from './api';

export interface TrainResponse {
  status: string;
  r2?: number;
  improved?: boolean;
  samples?: number;
  message?: string;
  timestamp: string;
}

export interface PredictionResponse {
  latest: number;
  predicted: number;
  change: number;
  change_percent: number;
  direction: 'LONG' | 'SHORT';
  confidence: number;
  timestamp: string;
  error?: string;
  message?: string;
}

export const mlService = {
  train: async (): Promise<TrainResponse> => {
    return await api.post<TrainResponse>('/train');
  },

  predict: async (latest: number): Promise<PredictionResponse> => {
    return await api.get<PredictionResponse>(`/predict?latest_price=${latest}`);
  }
};

export default mlService;

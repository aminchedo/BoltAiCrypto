import { toast } from 'react-hot-toast';

// Telegram Bot API Key
const TELEGRAM_BOT_TOKEN = '7437859619:AAGeGG3ZkLM0OVaw-Exx1uMRE55JtBCZZCY';
const TELEGRAM_CHAT_ID = '123456789'; // Replace with actual chat ID

export interface NotificationConfig {
  id: string;
  type: 'price_alert' | 'trade_signal' | 'news_alert' | 'portfolio_alert';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  conditions?: {
    symbol?: string;
    price?: number;
    change?: number;
    volume?: number;
  };
}

export interface PriceAlert {
  symbol: string;
  targetPrice: number;
  direction: 'above' | 'below';
  triggered: boolean;
  createdAt: Date;
}

export interface TradeSignal {
  symbol: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  price: number;
  reasoning: string;
  timestamp: Date;
}

class NotificationService {
  private notifications: NotificationConfig[] = [];
  private priceAlerts: PriceAlert[] = [];
  private isTelegramEnabled = false;

  constructor() {
    this.loadNotifications();
    this.setupDefaultNotifications();
  }

  // Setup default notifications
  private setupDefaultNotifications() {
    const defaultNotifications: NotificationConfig[] = [
      {
        id: 'price_alert_btc',
        type: 'price_alert',
        title: 'Bitcoin Price Alert',
        message: 'BTC has reached your target price',
        priority: 'high',
        enabled: true,
        conditions: {
          symbol: 'BTC',
          price: 65000
        }
      },
      {
        id: 'trade_signal_high_confidence',
        type: 'trade_signal',
        title: 'High Confidence Trade Signal',
        message: 'New high-confidence trading signal available',
        priority: 'high',
        enabled: true
      },
      {
        id: 'portfolio_alert',
        type: 'portfolio_alert',
        title: 'Portfolio Performance Alert',
        message: 'Significant change in portfolio value',
        priority: 'medium',
        enabled: true
      }
    ];

    defaultNotifications.forEach(notification => {
      if (!this.notifications.find(n => n.id === notification.id)) {
        this.notifications.push(notification);
      }
    });
  }

  // Add new notification
  addNotification(notification: NotificationConfig) {
    this.notifications.push(notification);
    this.saveNotifications();
    toast.success('Notification added successfully');
  }

  // Remove notification
  removeNotification(id: string) {
    this.notifications = this.notifications.filter(n => n.id !== id);
    this.saveNotifications();
    toast.success('Notification removed');
  }

  // Update notification
  updateNotification(id: string, updates: Partial<NotificationConfig>) {
    const index = this.notifications.findIndex(n => n.id === id);
    if (index !== -1) {
      this.notifications[index] = { ...this.notifications[index], ...updates };
      this.saveNotifications();
      toast.success('Notification updated');
    }
  }

  // Get all notifications
  getNotifications(): NotificationConfig[] {
    return this.notifications;
  }

  // Add price alert
  addPriceAlert(alert: Omit<PriceAlert, 'triggered' | 'createdAt'>) {
    const newAlert: PriceAlert = {
      ...alert,
      triggered: false,
      createdAt: new Date()
    };
    this.priceAlerts.push(newAlert);
    this.savePriceAlerts();
    toast.success(`Price alert set for ${alert.symbol}`);
  }

  // Remove price alert
  removePriceAlert(symbol: string, targetPrice: number) {
    this.priceAlerts = this.priceAlerts.filter(
      alert => !(alert.symbol === symbol && alert.targetPrice === targetPrice)
    );
    this.savePriceAlerts();
    toast.success('Price alert removed');
  }

  // Get price alerts
  getPriceAlerts(): PriceAlert[] {
    return this.priceAlerts;
  }

  // Check price alerts
  checkPriceAlerts(currentPrices: Record<string, number>) {
    this.priceAlerts.forEach(alert => {
      if (alert.triggered) return;

      const currentPrice = currentPrices[alert.symbol];
      if (!currentPrice) return;

      let shouldTrigger = false;
      if (alert.direction === 'above' && currentPrice >= alert.targetPrice) {
        shouldTrigger = true;
      } else if (alert.direction === 'below' && currentPrice <= alert.targetPrice) {
        shouldTrigger = true;
      }

      if (shouldTrigger) {
        this.triggerPriceAlert(alert, currentPrice);
      }
    });
  }

  // Trigger price alert
  private triggerPriceAlert(alert: PriceAlert, currentPrice: number) {
    alert.triggered = true;
    
    const message = `${alert.symbol} has reached $${currentPrice.toLocaleString()} (Target: $${alert.targetPrice.toLocaleString()})`;
    
    // Show toast notification
    toast.success(message, {
      duration: 5000,
      icon: '🚨'
    });

    // Send Telegram notification if enabled
    if (this.isTelegramEnabled) {
      this.sendTelegramNotification('Price Alert', message);
    }

    // Save updated alerts
    this.savePriceAlerts();
  }

  // Send trade signal notification
  sendTradeSignal(signal: TradeSignal) {
    const message = `${signal.signal} ${signal.symbol} at $${signal.price.toLocaleString()} (${(signal.confidence * 100).toFixed(1)}% confidence)`;
    
    // Show toast notification
    const toastType = signal.signal === 'BUY' ? 'success' : signal.signal === 'SELL' ? 'error' : 'default';
    toast[toastType](message, {
      duration: 6000,
      icon: signal.signal === 'BUY' ? '📈' : signal.signal === 'SELL' ? '📉' : '⏸️'
    });

    // Send Telegram notification if enabled
    if (this.isTelegramEnabled) {
      this.sendTelegramNotification('Trade Signal', message);
    }
  }

  // Send portfolio alert
  sendPortfolioAlert(title: string, message: string, priority: 'low' | 'medium' | 'high' | 'critical' = 'medium') {
    // Show toast notification
    const toastType = priority === 'critical' ? 'error' : priority === 'high' ? 'success' : 'default';
    toast[toastType](message, {
      duration: 5000,
      icon: priority === 'critical' ? '🚨' : priority === 'high' ? '⚠️' : 'ℹ️'
    });

    // Send Telegram notification if enabled
    if (this.isTelegramEnabled) {
      this.sendTelegramNotification(title, message);
    }
  }

  // Send news alert
  sendNewsAlert(title: string, summary: string, impact: 'high' | 'medium' | 'low') {
    const message = `${title}\n\n${summary}`;
    
    // Show toast notification
    const toastType = impact === 'high' ? 'success' : 'default';
    toast[toastType](message, {
      duration: 8000,
      icon: impact === 'high' ? '📰' : '📄'
    });

    // Send Telegram notification if enabled
    if (this.isTelegramEnabled) {
      this.sendTelegramNotification('News Alert', message);
    }
  }

  // Enable/disable Telegram notifications
  setTelegramEnabled(enabled: boolean) {
    this.isTelegramEnabled = enabled;
    localStorage.setItem('telegramNotifications', enabled.toString());
    
    if (enabled) {
      toast.success('Telegram notifications enabled');
    } else {
      toast.success('Telegram notifications disabled');
    }
  }

  // Send Telegram notification
  private async sendTelegramNotification(title: string, message: string) {
    try {
      const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: TELEGRAM_CHAT_ID,
          text: `🚨 ${title}\n\n${message}`,
          parse_mode: 'HTML'
        })
      });

      if (!response.ok) {
        console.error('Failed to send Telegram notification');
      }
    } catch (error) {
      console.error('Error sending Telegram notification:', error);
    }
  }

  // Test notification
  testNotification(type: 'toast' | 'telegram' = 'toast') {
    const testMessage = 'This is a test notification from CryptoQuant';
    
    if (type === 'toast') {
      toast.success(testMessage);
    } else if (type === 'telegram' && this.isTelegramEnabled) {
      this.sendTelegramNotification('Test Notification', testMessage);
      toast.success('Test Telegram notification sent');
    }
  }

  // Load notifications from localStorage
  private loadNotifications() {
    try {
      const saved = localStorage.getItem('notifications');
      if (saved) {
        this.notifications = JSON.parse(saved);
      }
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  }

  // Save notifications to localStorage
  private saveNotifications() {
    try {
      localStorage.setItem('notifications', JSON.stringify(this.notifications));
    } catch (error) {
      console.error('Error saving notifications:', error);
    }
  }

  // Load price alerts from localStorage
  private loadPriceAlerts() {
    try {
      const saved = localStorage.getItem('priceAlerts');
      if (saved) {
        this.priceAlerts = JSON.parse(saved);
      }
    } catch (error) {
      console.error('Error loading price alerts:', error);
    }
  }

  // Save price alerts to localStorage
  private savePriceAlerts() {
    try {
      localStorage.setItem('priceAlerts', JSON.stringify(this.priceAlerts));
    } catch (error) {
      console.error('Error saving price alerts:', error);
    }
  }

  // Initialize service
  init() {
    this.loadNotifications();
    this.loadPriceAlerts();
    
    // Load Telegram setting
    const telegramEnabled = localStorage.getItem('telegramNotifications');
    this.isTelegramEnabled = telegramEnabled === 'true';
  }

  // Get notification statistics
  getNotificationStats() {
    return {
      total: this.notifications.length,
      enabled: this.notifications.filter(n => n.enabled).length,
      priceAlerts: this.priceAlerts.length,
      telegramEnabled: this.isTelegramEnabled
    };
  }
}

export const notificationService = new NotificationService();
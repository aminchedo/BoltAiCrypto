import { v4 as uuidv4 } from 'uuid';

// Strategy component types
export enum ComponentType {
  INDICATOR = 'indicator',
  PATTERN = 'pattern',
  SMART_MONEY = 'smartMoney',
  SENTIMENT = 'sentiment',
  WHALE = 'whale',
  ML = 'ml',
  CONDITION = 'condition',
  OPERATOR = 'operator',
  ACTION = 'action',
  RISK = 'risk'
}

// Connection between components
export interface Connection {
  id: string;
  sourceId: string;
  targetId: string;
  sourceHandle: string;
  targetHandle: string;
}

// Base component interface
export interface StrategyComponent {
  id: string;
  type: ComponentType;
  name: string;
  description: string;
  position: { x: number; y: number };
  data: any;
}

// Indicator component
export interface IndicatorComponent extends StrategyComponent {
  type: ComponentType.INDICATOR;
  data: {
    indicator: string;
    parameters: Record<string, any>;
    timeframe: string;
  };
}

// Pattern component
export interface PatternComponent extends StrategyComponent {
  type: ComponentType.PATTERN;
  data: {
    pattern: string;
    parameters: Record<string, any>;
    confidence: number;
  };
}

// Smart Money component
export interface SmartMoneyComponent extends StrategyComponent {
  type: ComponentType.SMART_MONEY;
  data: {
    concept: string;
    parameters: Record<string, any>;
  };
}

// Condition component
export interface ConditionComponent extends StrategyComponent {
  type: ComponentType.CONDITION;
  data: {
    condition: string;
    parameters: Record<string, any>;
  };
}

// Operator component
export interface OperatorComponent extends StrategyComponent {
  type: ComponentType.OPERATOR;
  data: {
    operator: 'AND' | 'OR' | 'NOT';
  };
}

// Action component
export interface ActionComponent extends StrategyComponent {
  type: ComponentType.ACTION;
  data: {
    action: 'BUY' | 'SELL' | 'ALERT';
    parameters: Record<string, any>;
  };
}

// Risk component
export interface RiskComponent extends StrategyComponent {
  type: ComponentType.RISK;
  data: {
    riskType: 'POSITION_SIZE' | 'STOP_LOSS' | 'TAKE_PROFIT';
    parameters: Record<string, any>;
  };
}

// Complete strategy
export interface Strategy {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  components: StrategyComponent[];
  connections: Connection[];
  isActive: boolean;
  symbol?: string;
  timeframe?: string;
  backtestResults?: BacktestResult;
}

// Backtest result
export interface BacktestResult {
  id: string;
  strategyId: string;
  startDate: number;
  endDate: number;
  symbol: string;
  timeframe: string;
  trades: BacktestTrade[];
  metrics: {
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    winRate: number;
    profitFactor: number;
    netProfit: number;
    maxDrawdown: number;
    sharpeRatio: number;
    averageWin: number;
    averageLoss: number;
    largestWin: number;
    largestLoss: number;
  };
}

// Backtest trade
export interface BacktestTrade {
  id: string;
  entryTime: number;
  entryPrice: number;
  exitTime: number;
  exitPrice: number;
  direction: 'LONG' | 'SHORT';
  profit: number;
  profitPercentage: number;
  initialStopLoss: number;
  initialTakeProfit: number;
  quantity: number;
  exitReason: string;
}

// Component templates for the drag-and-drop interface
export const componentTemplates: Record<ComponentType, StrategyComponent[]> = {
  [ComponentType.INDICATOR]: [
    {
      id: 'template-rsi',
      type: ComponentType.INDICATOR,
      name: 'RSI',
      description: 'Relative Strength Index',
      position: { x: 0, y: 0 },
      data: {
        indicator: 'RSI',
        parameters: { period: 14, overbought: 70, oversold: 30 },
        timeframe: '1h'
      }
    },
    {
      id: 'template-macd',
      type: ComponentType.INDICATOR,
      name: 'MACD',
      description: 'Moving Average Convergence Divergence',
      position: { x: 0, y: 0 },
      data: {
        indicator: 'MACD',
        parameters: { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
        timeframe: '1h'
      }
    },
    {
      id: 'template-bollinger',
      type: ComponentType.INDICATOR,
      name: 'Bollinger Bands',
      description: 'Bollinger Bands',
      position: { x: 0, y: 0 },
      data: {
        indicator: 'BOLLINGER',
        parameters: { period: 20, stdDev: 2 },
        timeframe: '1h'
      }
    },
    {
      id: 'template-ema',
      type: ComponentType.INDICATOR,
      name: 'EMA',
      description: 'Exponential Moving Average',
      position: { x: 0, y: 0 },
      data: {
        indicator: 'EMA',
        parameters: { period: 20 },
        timeframe: '1h'
      }
    },
    {
      id: 'template-sma',
      type: ComponentType.INDICATOR,
      name: 'SMA',
      description: 'Simple Moving Average',
      position: { x: 0, y: 0 },
      data: {
        indicator: 'SMA',
        parameters: { period: 20 },
        timeframe: '1h'
      }
    }
  ],
  [ComponentType.PATTERN]: [
    {
      id: 'template-head-shoulders',
      type: ComponentType.PATTERN,
      name: 'Head and Shoulders',
      description: 'Head and Shoulders pattern',
      position: { x: 0, y: 0 },
      data: {
        pattern: 'HEAD_SHOULDERS',
        parameters: { minConfidence: 70 },
        confidence: 0
      }
    },
    {
      id: 'template-double-top',
      type: ComponentType.PATTERN,
      name: 'Double Top',
      description: 'Double Top pattern',
      position: { x: 0, y: 0 },
      data: {
        pattern: 'DOUBLE_TOP',
        parameters: { minConfidence: 70 },
        confidence: 0
      }
    },
    {
      id: 'template-double-bottom',
      type: ComponentType.PATTERN,
      name: 'Double Bottom',
      description: 'Double Bottom pattern',
      position: { x: 0, y: 0 },
      data: {
        pattern: 'DOUBLE_BOTTOM',
        parameters: { minConfidence: 70 },
        confidence: 0
      }
    }
  ],
  [ComponentType.SMART_MONEY]: [
    {
      id: 'template-order-block',
      type: ComponentType.SMART_MONEY,
      name: 'Order Block',
      description: 'Order Block detection',
      position: { x: 0, y: 0 },
      data: {
        concept: 'ORDER_BLOCK',
        parameters: { minStrength: 50 }
      }
    },
    {
      id: 'template-liquidity',
      type: ComponentType.SMART_MONEY,
      name: 'Liquidity Zone',
      description: 'Liquidity Zone detection',
      position: { x: 0, y: 0 },
      data: {
        concept: 'LIQUIDITY_ZONE',
        parameters: { minVolume: 1000000 }
      }
    },
    {
      id: 'template-fair-value-gap',
      type: ComponentType.SMART_MONEY,
      name: 'Fair Value Gap',
      description: 'Fair Value Gap detection',
      position: { x: 0, y: 0 },
      data: {
        concept: 'FAIR_VALUE_GAP',
        parameters: { minGapSize: 0.5 }
      }
    }
  ],
  [ComponentType.SENTIMENT]: [
    {
      id: 'template-news-sentiment',
      type: ComponentType.SENTIMENT,
      name: 'News Sentiment',
      description: 'News sentiment analysis',
      position: { x: 0, y: 0 },
      data: {
        sentiment: 'NEWS',
        parameters: { threshold: 0.5 }
      }
    },
    {
      id: 'template-social-sentiment',
      type: ComponentType.SENTIMENT,
      name: 'Social Sentiment',
      description: 'Social media sentiment analysis',
      position: { x: 0, y: 0 },
      data: {
        sentiment: 'SOCIAL',
        parameters: { threshold: 0.5 }
      }
    }
  ],
  [ComponentType.WHALE]: [
    {
      id: 'template-whale-movement',
      type: ComponentType.WHALE,
      name: 'Whale Movement',
      description: 'Whale wallet movement detection',
      position: { x: 0, y: 0 },
      data: {
        whale: 'MOVEMENT',
        parameters: { minAmount: 1000000 }
      }
    },
    {
      id: 'template-exchange-flow',
      type: ComponentType.WHALE,
      name: 'Exchange Flow',
      description: 'Exchange inflow/outflow analysis',
      position: { x: 0, y: 0 },
      data: {
        whale: 'EXCHANGE_FLOW',
        parameters: { threshold: 1000000 }
      }
    }
  ],
  [ComponentType.ML]: [
    {
      id: 'template-price-prediction',
      type: ComponentType.ML,
      name: 'Price Prediction',
      description: 'ML-based price prediction',
      position: { x: 0, y: 0 },
      data: {
        ml: 'PRICE_PREDICTION',
        parameters: { horizon: '24h', minConfidence: 70 }
      }
    },
    {
      id: 'template-trend-prediction',
      type: ComponentType.ML,
      name: 'Trend Prediction',
      description: 'ML-based trend prediction',
      position: { x: 0, y: 0 },
      data: {
        ml: 'TREND_PREDICTION',
        parameters: { horizon: '24h', minConfidence: 70 }
      }
    }
  ],
  [ComponentType.CONDITION]: [
    {
      id: 'template-crossover',
      type: ComponentType.CONDITION,
      name: 'Crossover',
      description: 'Indicator crossover condition',
      position: { x: 0, y: 0 },
      data: {
        condition: 'CROSSOVER',
        parameters: { direction: 'ABOVE' }
      }
    },
    {
      id: 'template-threshold',
      type: ComponentType.CONDITION,
      name: 'Threshold',
      description: 'Value threshold condition',
      position: { x: 0, y: 0 },
      data: {
        condition: 'THRESHOLD',
        parameters: { operator: '>', value: 70 }
      }
    },
    {
      id: 'template-divergence',
      type: ComponentType.CONDITION,
      name: 'Divergence',
      description: 'Price-indicator divergence',
      position: { x: 0, y: 0 },
      data: {
        condition: 'DIVERGENCE',
        parameters: { type: 'REGULAR' }
      }
    }
  ],
  [ComponentType.OPERATOR]: [
    {
      id: 'template-and',
      type: ComponentType.OPERATOR,
      name: 'AND',
      description: 'Logical AND operator',
      position: { x: 0, y: 0 },
      data: {
        operator: 'AND'
      }
    },
    {
      id: 'template-or',
      type: ComponentType.OPERATOR,
      name: 'OR',
      description: 'Logical OR operator',
      position: { x: 0, y: 0 },
      data: {
        operator: 'OR'
      }
    },
    {
      id: 'template-not',
      type: ComponentType.OPERATOR,
      name: 'NOT',
      description: 'Logical NOT operator',
      position: { x: 0, y: 0 },
      data: {
        operator: 'NOT'
      }
    }
  ],
  [ComponentType.ACTION]: [
    {
      id: 'template-buy',
      type: ComponentType.ACTION,
      name: 'Buy',
      description: 'Buy action',
      position: { x: 0, y: 0 },
      data: {
        action: 'BUY',
        parameters: { orderType: 'MARKET' }
      }
    },
    {
      id: 'template-sell',
      type: ComponentType.ACTION,
      name: 'Sell',
      description: 'Sell action',
      position: { x: 0, y: 0 },
      data: {
        action: 'SELL',
        parameters: { orderType: 'MARKET' }
      }
    },
    {
      id: 'template-alert',
      type: ComponentType.ACTION,
      name: 'Alert',
      description: 'Send alert',
      position: { x: 0, y: 0 },
      data: {
        action: 'ALERT',
        parameters: { message: 'Strategy alert', channels: ['app'] }
      }
    }
  ],
  [ComponentType.RISK]: [
    {
      id: 'template-position-size',
      type: ComponentType.RISK,
      name: 'Position Size',
      description: 'Position sizing',
      position: { x: 0, y: 0 },
      data: {
        riskType: 'POSITION_SIZE',
        parameters: { riskPercent: 1 }
      }
    },
    {
      id: 'template-stop-loss',
      type: ComponentType.RISK,
      name: 'Stop Loss',
      description: 'Stop loss settings',
      position: { x: 0, y: 0 },
      data: {
        riskType: 'STOP_LOSS',
        parameters: { type: 'ATR', multiplier: 2 }
      }
    },
    {
      id: 'template-take-profit',
      type: ComponentType.RISK,
      name: 'Take Profit',
      description: 'Take profit settings',
      position: { x: 0, y: 0 },
      data: {
        riskType: 'TAKE_PROFIT',
        parameters: { type: 'RISK_REWARD', ratio: 2 }
      }
    }
  ]
};

// Sample strategies
const sampleStrategies: Strategy[] = [
  {
    id: '1',
    name: 'RSI + MACD Crossover',
    description: 'Buy when RSI is oversold and MACD crosses above signal line',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    components: [
      {
        id: 'rsi-1',
        type: ComponentType.INDICATOR,
        name: 'RSI',
        description: 'Relative Strength Index',
        position: { x: 100, y: 100 },
        data: {
          indicator: 'RSI',
          parameters: { period: 14, overbought: 70, oversold: 30 },
          timeframe: '1h'
        }
      },
      {
        id: 'macd-1',
        type: ComponentType.INDICATOR,
        name: 'MACD',
        description: 'Moving Average Convergence Divergence',
        position: { x: 100, y: 250 },
        data: {
          indicator: 'MACD',
          parameters: { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
          timeframe: '1h'
        }
      },
      {
        id: 'condition-1',
        type: ComponentType.CONDITION,
        name: 'RSI Oversold',
        description: 'RSI below 30',
        position: { x: 400, y: 100 },
        data: {
          condition: 'THRESHOLD',
          parameters: { operator: '<', value: 30 }
        }
      },
      {
        id: 'condition-2',
        type: ComponentType.CONDITION,
        name: 'MACD Crossover',
        description: 'MACD crosses above signal',
        position: { x: 400, y: 250 },
        data: {
          condition: 'CROSSOVER',
          parameters: { direction: 'ABOVE' }
        }
      },
      {
        id: 'operator-1',
        type: ComponentType.OPERATOR,
        name: 'AND',
        description: 'Logical AND',
        position: { x: 700, y: 175 },
        data: {
          operator: 'AND'
        }
      },
      {
        id: 'action-1',
        type: ComponentType.ACTION,
        name: 'Buy',
        description: 'Buy action',
        position: { x: 1000, y: 175 },
        data: {
          action: 'BUY',
          parameters: { orderType: 'MARKET' }
        }
      }
    ],
    connections: [
      {
        id: 'conn-1',
        sourceId: 'rsi-1',
        targetId: 'condition-1',
        sourceHandle: 'output',
        targetHandle: 'input'
      },
      {
        id: 'conn-2',
        sourceId: 'macd-1',
        targetId: 'condition-2',
        sourceHandle: 'output',
        targetHandle: 'input'
      },
      {
        id: 'conn-3',
        sourceId: 'condition-1',
        targetId: 'operator-1',
        sourceHandle: 'output',
        targetHandle: 'input1'
      },
      {
        id: 'conn-4',
        sourceId: 'condition-2',
        targetId: 'operator-1',
        sourceHandle: 'output',
        targetHandle: 'input2'
      },
      {
        id: 'conn-5',
        sourceId: 'operator-1',
        targetId: 'action-1',
        sourceHandle: 'output',
        targetHandle: 'input'
      }
    ],
    isActive: false,
    symbol: 'BTCUSDT',
    timeframe: '1h'
  }
];

class StrategyBuilderService {
  private strategies: Map<string, Strategy> = new Map();

  constructor() {
    // Initialize with sample strategies
    sampleStrategies.forEach(strategy => {
      this.strategies.set(strategy.id, strategy);
    });
  }

  // Get all strategies
  getAllStrategies(): Strategy[] {
    return Array.from(this.strategies.values());
  }

  // Get strategy by ID
  getStrategyById(id: string): Strategy | undefined {
    return this.strategies.get(id);
  }

  // Create new strategy
  createStrategy(name: string, description: string): Strategy {
    const id = uuidv4();
    const now = Date.now();
    
    const newStrategy: Strategy = {
      id,
      name,
      description,
      createdAt: now,
      updatedAt: now,
      components: [],
      connections: [],
      isActive: false
    };
    
    this.strategies.set(id, newStrategy);
    return newStrategy;
  }

  // Update strategy
  updateStrategy(id: string, updates: Partial<Strategy>): Strategy | undefined {
    const strategy = this.strategies.get(id);
    
    if (!strategy) {
      return undefined;
    }
    
    const updatedStrategy = {
      ...strategy,
      ...updates,
      updatedAt: Date.now()
    };
    
    this.strategies.set(id, updatedStrategy);
    return updatedStrategy;
  }

  // Delete strategy
  deleteStrategy(id: string): boolean {
    return this.strategies.delete(id);
  }

  // Add component to strategy
  addComponent(strategyId: string, component: Omit<StrategyComponent, 'id'>): StrategyComponent | undefined {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return undefined;
    }
    
    const newComponent = {
      ...component,
      id: uuidv4()
    };
    
    strategy.components.push(newComponent);
    strategy.updatedAt = Date.now();
    
    return newComponent;
  }

  // Update component
  updateComponent(strategyId: string, componentId: string, updates: Partial<StrategyComponent>): StrategyComponent | undefined {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return undefined;
    }
    
    const componentIndex = strategy.components.findIndex(c => c.id === componentId);
    
    if (componentIndex === -1) {
      return undefined;
    }
    
    const updatedComponent = {
      ...strategy.components[componentIndex],
      ...updates
    };
    
    strategy.components[componentIndex] = updatedComponent;
    strategy.updatedAt = Date.now();
    
    return updatedComponent;
  }

  // Remove component
  removeComponent(strategyId: string, componentId: string): boolean {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return false;
    }
    
    const initialLength = strategy.components.length;
    strategy.components = strategy.components.filter(c => c.id !== componentId);
    
    // Also remove any connections to/from this component
    strategy.connections = strategy.connections.filter(
      conn => conn.sourceId !== componentId && conn.targetId !== componentId
    );
    
    strategy.updatedAt = Date.now();
    
    return strategy.components.length < initialLength;
  }

  // Add connection
  addConnection(strategyId: string, connection: Omit<Connection, 'id'>): Connection | undefined {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return undefined;
    }
    
    const newConnection = {
      ...connection,
      id: uuidv4()
    };
    
    strategy.connections.push(newConnection);
    strategy.updatedAt = Date.now();
    
    return newConnection;
  }

  // Remove connection
  removeConnection(strategyId: string, connectionId: string): boolean {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return false;
    }
    
    const initialLength = strategy.connections.length;
    strategy.connections = strategy.connections.filter(c => c.id !== connectionId);
    strategy.updatedAt = Date.now();
    
    return strategy.connections.length < initialLength;
  }

  // Run backtest
  async runBacktest(strategyId: string, symbol: string, timeframe: string, startDate: Date, endDate: Date): Promise<BacktestResult | undefined> {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return undefined;
    }
    
    // In a real implementation, this would call a backend service to run the backtest
    // For now, we'll generate mock results
    const mockBacktestResult: BacktestResult = {
      id: uuidv4(),
      strategyId,
      startDate: startDate.getTime(),
      endDate: endDate.getTime(),
      symbol,
      timeframe,
      trades: this.generateMockTrades(startDate, endDate),
      metrics: this.calculateMockMetrics()
    };
    
    // Update strategy with backtest results
    strategy.backtestResults = mockBacktestResult;
    strategy.updatedAt = Date.now();
    
    return mockBacktestResult;
  }

  // Generate mock trades for backtest
  private generateMockTrades(startDate: Date, endDate: Date): BacktestTrade[] {
    const trades: BacktestTrade[] = [];
    const duration = endDate.getTime() - startDate.getTime();
    const numTrades = Math.floor(Math.random() * 20) + 10; // 10-30 trades
    
    for (let i = 0; i < numTrades; i++) {
      const entryTime = startDate.getTime() + Math.random() * duration;
      const holdingPeriod = Math.floor(Math.random() * 24 * 60 * 60 * 1000); // 0-24 hours
      const exitTime = Math.min(entryTime + holdingPeriod, endDate.getTime());
      
      const direction = Math.random() > 0.5 ? 'LONG' : 'SHORT';
      const entryPrice = 40000 + Math.random() * 10000; // Mock BTC price
      const priceChange = entryPrice * (Math.random() * 0.1 - 0.05); // -5% to +5%
      const exitPrice = entryPrice + priceChange;
      
      const profit = direction === 'LONG' 
        ? exitPrice - entryPrice 
        : entryPrice - exitPrice;
      
      const profitPercentage = (profit / entryPrice) * 100;
      
      trades.push({
        id: uuidv4(),
        entryTime,
        entryPrice,
        exitTime,
        exitPrice,
        direction,
        profit,
        profitPercentage,
        initialStopLoss: direction === 'LONG' 
          ? entryPrice * 0.95 
          : entryPrice * 1.05,
        initialTakeProfit: direction === 'LONG' 
          ? entryPrice * 1.1 
          : entryPrice * 0.9,
        quantity: Math.random() * 2,
        exitReason: Math.random() > 0.7 
          ? 'STOP_LOSS' 
          : Math.random() > 0.5 
            ? 'TAKE_PROFIT' 
            : 'STRATEGY_EXIT'
      });
    }
    
    return trades;
  }

  // Calculate mock metrics for backtest
  private calculateMockMetrics() {
    const winRate = 0.4 + Math.random() * 0.4; // 40-80% win rate
    const totalTrades = Math.floor(Math.random() * 20) + 10; // 10-30 trades
    const winningTrades = Math.floor(totalTrades * winRate);
    const losingTrades = totalTrades - winningTrades;
    
    const averageWin = 500 + Math.random() * 1000;
    const averageLoss = 300 + Math.random() * 500;
    
    const netProfit = (winningTrades * averageWin) - (losingTrades * averageLoss);
    const profitFactor = (winningTrades * averageWin) / (losingTrades * averageLoss);
    
    return {
      totalTrades,
      winningTrades,
      losingTrades,
      winRate: winRate * 100,
      profitFactor,
      netProfit,
      maxDrawdown: 5 + Math.random() * 20, // 5-25% drawdown
      sharpeRatio: 0.5 + Math.random() * 2, // 0.5-2.5 Sharpe
      averageWin,
      averageLoss,
      largestWin: averageWin * (1.5 + Math.random()),
      largestLoss: averageLoss * (1.5 + Math.random())
    };
  }

  // Deploy strategy for live trading
  deployStrategy(strategyId: string): boolean {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return false;
    }
    
    // In a real implementation, this would set up the strategy for live trading
    strategy.isActive = true;
    strategy.updatedAt = Date.now();
    
    return true;
  }

  // Stop live trading for a strategy
  stopStrategy(strategyId: string): boolean {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return false;
    }
    
    strategy.isActive = false;
    strategy.updatedAt = Date.now();
    
    return true;
  }

  // Export strategy to JSON
  exportStrategy(strategyId: string): string | undefined {
    const strategy = this.strategies.get(strategyId);
    
    if (!strategy) {
      return undefined;
    }
    
    return JSON.stringify(strategy, null, 2);
  }

  // Import strategy from JSON
  importStrategy(strategyJson: string): Strategy | undefined {
    try {
      const strategy = JSON.parse(strategyJson) as Strategy;
      
      // Generate new ID to avoid conflicts
      strategy.id = uuidv4();
      strategy.updatedAt = Date.now();
      
      this.strategies.set(strategy.id, strategy);
      return strategy;
    } catch (error) {
      console.error('Failed to import strategy:', error);
      return undefined;
    }
  }
}

const strategyBuilderService = new StrategyBuilderService();
export default strategyBuilderService;
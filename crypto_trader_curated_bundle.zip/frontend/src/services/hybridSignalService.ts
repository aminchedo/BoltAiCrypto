import api from './api';
import hybridTradingEngine, { HybridSignal } from './hybridTradingService';

/**
 * HybridSignalService provides an interface to access AI-generated trading signals
 * based on the hybrid trading algorithm with weighted components:
 * - RSI + MACD Analysis (40%)
 * - Smart Money Concepts (25%)
 * - Pattern Recognition (20%)
 * - Sentiment Analysis (7%)
 * - Whale Movements (3%)
 * - ML Predictions (5%)
 */
class HybridSignalService {
  private signalCache: Map<string, HybridSignal[]> = new Map();
  private lastUpdate: Map<string, number> = new Map();
  private readonly CACHE_DURATION = 300000; // 5 minutes

  /**
   * Get live trading signals for the specified symbols
   * @param symbols Optional array of trading pair symbols (e.g., ['BTCUSDT', 'ETHUSDT'])
   * @returns Array of hybrid trading signals
   */
  async getLiveSignals(symbols?: string[]): Promise<HybridSignal[]> {
    try {
      // Try to get from API first
      const apiSignals = await api.get<HybridSignal[]>('/v1/signals/hybrid', { symbols }).catch(() => null);
      
      if (apiSignals) {
        return apiSignals;
      }

      // Generate signals locally if API fails
      return this.generateLocalSignals(symbols || ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']);
    } catch (error) {
      console.error('Failed to fetch hybrid signals:', error);
      return this.generateLocalSignals(symbols || ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']);
    }
  }

  /**
   * Get a single trading signal for the specified symbol
   * @param symbol Trading pair symbol (e.g., 'BTCUSDT')
   * @returns A hybrid trading signal or null if no signal is available
   */
  async getSignalForSymbol(symbol: string): Promise<HybridSignal | null> {
    try {
      // Try to get from API first
      const apiSignal = await api.get<HybridSignal>(`/v1/signals/hybrid/${symbol}`).catch(() => null);
      
      if (apiSignal) {
        return apiSignal;
      }

      // Generate signal locally if API fails
      return hybridTradingEngine.generateTradingSignal(symbol);
    } catch (error) {
      console.error(`Failed to fetch hybrid signal for ${symbol}:`, error);
      return hybridTradingEngine.generateTradingSignal(symbol);
    }
  }

  /**
   * Generate signals locally using the hybrid trading engine
   * @param symbols Array of trading pair symbols
   * @returns Array of hybrid trading signals
   */
  private async generateLocalSignals(symbols: string[]): Promise<HybridSignal[]> {
    const signals: HybridSignal[] = [];

    for (const symbol of symbols) {
      try {
        // Check cache first
        const cacheKey = symbol;
        const lastUpdateTime = this.lastUpdate.get(cacheKey) || 0;
        const cachedSignals = this.signalCache.get(cacheKey);

        if (cachedSignals && Date.now() - lastUpdateTime < this.CACHE_DURATION) {
          signals.push(...cachedSignals);
          continue;
        }

        // Generate new signal
        const signal = await hybridTradingEngine.generateTradingSignal(symbol);
        if (signal) {
          signals.push(signal);
          this.signalCache.set(cacheKey, [signal]);
          this.lastUpdate.set(cacheKey, Date.now());
        }
      } catch (error) {
        console.error(`Failed to generate signal for ${symbol}:`, error);
      }
    }

    return signals;
  }

  /**
   * Get historical performance of the hybrid trading algorithm
   * @param symbol Trading pair symbol
   * @param days Number of days to look back
   * @returns Performance metrics for the algorithm
   */
  async getAlgorithmPerformance(symbol: string, days: number = 30): Promise<any> {
    try {
      return await api.get(`/v1/signals/hybrid/performance/${symbol}`, { days });
    } catch (error) {
      console.error(`Failed to fetch algorithm performance for ${symbol}:`, error);
      return {
        symbol,
        days,
        signalCount: 0,
        accuracy: 0,
        profitFactor: 0,
        winRate: 0,
        averageReturn: 0
      };
    }
  }

  /**
   * Get detailed breakdown of the algorithm components for a specific symbol
   * @param symbol Trading pair symbol
   * @returns Detailed breakdown of each algorithm component
   */
  async getAlgorithmBreakdown(symbol: string): Promise<any> {
    try {
      return await api.get(`/v1/signals/hybrid/breakdown/${symbol}`);
    } catch (error) {
      console.error(`Failed to fetch algorithm breakdown for ${symbol}:`, error);
      
      // Generate a signal to get the breakdown
      const signal = await hybridTradingEngine.generateTradingSignal(symbol);
      
      return signal ? signal.algorithmBreakdown : null;
    }
  }
}

const hybridSignalService = new HybridSignalService();
export default hybridSignalService;
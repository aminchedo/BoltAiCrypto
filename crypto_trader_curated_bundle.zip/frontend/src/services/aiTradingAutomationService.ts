/**
 * AI Trading Automation Service
 * 
 * Handles automated trading based on AI signals with risk management,
 * position sizing, and execution strategies.
 */

import { signalService } from './signalService';
import { marketService } from './marketService';
import { aiNotificationService } from './aiNotificationService';

export interface AutomationConfig {
  enabled: boolean;
  strategies: string[];
  symbols: string[];
  maxPositions: number;
  maxPositionSize: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  trailingStopPercent: number;
  riskPerTradePercent: number;
  timeframes: string[];
  minConfidence: number;
  tradingHours: {
    enabled: boolean;
    startHour: number;
    endHour: number;
    timezone: string;
  };
  filters: {
    minVolume: number;
    maxSpread: number;
    minSignalStrength: number;
    requireConfirmation: boolean;
  };
}

export interface AutomatedPosition {
  id: string;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  entryTime: Date;
  quantity: number;
  stopLoss: number;
  takeProfit: number;
  trailingStop: number;
  currentPrice: number;
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
  strategy: string;
  signalConfidence: number;
  status: 'OPEN' | 'CLOSED' | 'PENDING';
}

export interface AutomationStats {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  netProfit: number;
  netProfitPercent: number;
  maxDrawdown: number;
  activePositions: number;
  pendingPositions: number;
  lastTradeTime: Date | null;
}

class AITradingAutomationService {
  private config: AutomationConfig;
  private positions: AutomatedPosition[] = [];
  private stats: AutomationStats;
  private subscribers: ((positions: AutomatedPosition[], stats: AutomationStats) => void)[] = [];
  private checkInterval: NodeJS.Timeout | null = null;
  private lastSignalCheck: Date = new Date();
  
  constructor() {
    // Default configuration
    this.config = {
      enabled: false,
      strategies: ['trend-master', 'breakout-hunter'],
      symbols: ['BTC/USDT', 'ETH/USDT', 'SOL/USDT'],
      maxPositions: 5,
      maxPositionSize: 20, // % of portfolio
      stopLossPercent: 5,
      takeProfitPercent: 15,
      trailingStopPercent: 2,
      riskPerTradePercent: 2,
      timeframes: ['1h', '4h'],
      minConfidence: 75,
      tradingHours: {
        enabled: false,
        startHour: 9,
        endHour: 17,
        timezone: 'UTC'
      },
      filters: {
        minVolume: 1000000,
        maxSpread: 0.5,
        minSignalStrength: 7,
        requireConfirmation: true
      }
    };
    
    // Initialize stats
    this.stats = {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      winRate: 0,
      profitFactor: 0,
      netProfit: 0,
      netProfitPercent: 0,
      maxDrawdown: 0,
      activePositions: 0,
      pendingPositions: 0,
      lastTradeTime: null
    };
    
    // Initialize with some example positions
    this.positions = [
      {
        id: 'pos-1',
        symbol: 'BTC/USDT',
        direction: 'LONG',
        entryPrice: 43250.50,
        entryTime: new Date(Date.now() - 12 * 60 * 60 * 1000),
        quantity: 0.05,
        stopLoss: 41087.98,
        takeProfit: 47575.55,
        trailingStop: 42385.49,
        currentPrice: 43850.25,
        unrealizedPnL: 29.99,
        unrealizedPnLPercent: 1.39,
        strategy: 'trend-master',
        signalConfidence: 87.5,
        status: 'OPEN'
      },
      {
        id: 'pos-2',
        symbol: 'ETH/USDT',
        direction: 'SHORT',
        entryPrice: 2650.75,
        entryTime: new Date(Date.now() - 8 * 60 * 60 * 1000),
        quantity: 0.5,
        stopLoss: 2783.29,
        takeProfit: 2385.68,
        trailingStop: 2703.77,
        currentPrice: 2620.50,
        unrealizedPnL: 15.13,
        unrealizedPnLPercent: 0.57,
        strategy: 'breakout-hunter',
        signalConfidence: 82.3,
        status: 'OPEN'
      }
    ];
    
    this.updateStats();
  }

  /**
   * Start the automation service
   */
  public start(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
    
    this.config.enabled = true;
    
    // Check for new signals and update positions every minute
    this.checkInterval = setInterval(() => {
      this.checkForNewSignals();
      this.updatePositions();
    }, 60000);
    
    console.log('AI Trading Automation started');
    
    // Notify subscribers
    this.notifySubscribers();
    
    // Create notification
    aiNotificationService.addNotification({
      id: `automation_${Date.now()}`,
      type: 'system',
      title: 'Trading Automation Activated',
      message: `Automated trading has been enabled for ${this.config.symbols.length} symbols`,
      timestamp: new Date(),
      priority: 'medium',
      read: false
    });
  }

  /**
   * Stop the automation service
   */
  public stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    
    this.config.enabled = false;
    console.log('AI Trading Automation stopped');
    
    // Notify subscribers
    this.notifySubscribers();
    
    // Create notification
    aiNotificationService.addNotification({
      id: `automation_${Date.now()}`,
      type: 'system',
      title: 'Trading Automation Deactivated',
      message: 'Automated trading has been disabled',
      timestamp: new Date(),
      priority: 'medium',
      read: false
    });
  }

  /**
   * Check for new trading signals
   */
  private async checkForNewSignals(): Promise<void> {
    if (!this.config.enabled) return;
    
    try {
      // Check if we're within trading hours
      if (this.config.tradingHours.enabled) {
        const now = new Date();
        const hour = now.getUTCHours();
        
        if (hour < this.config.tradingHours.startHour || hour >= this.config.tradingHours.endHour) {
          console.log('Outside trading hours, skipping signal check');
          return;
        }
      }
      
      // Check if we have room for new positions
      const activePositions = this.positions.filter(p => p.status === 'OPEN').length;
      if (activePositions >= this.config.maxPositions) {
        console.log('Maximum positions reached, skipping signal check');
        return;
      }
      
      // Get signals for configured symbols
      const signals = await signalService.getLiveSignals(this.config.symbols);
      
      // Filter for new high-confidence signals
      const newSignals = signals.filter(signal => {
        const signalDate = new Date(signal.created_at);
        return (
          signalDate > this.lastSignalCheck && 
          signal.confidence >= this.config.minConfidence &&
          (signal.signal === 'BUY' || signal.signal === 'SELL') &&
          this.config.strategies.includes(signal.algorithm || 'default')
        );
      });
      
      // Process new signals
      for (const signal of newSignals) {
        // Check if we already have a position for this symbol
        const existingPosition = this.positions.find(
          p => p.symbol === signal.symbol && p.status === 'OPEN'
        );
        
        if (existingPosition) {
          console.log(`Already have an open position for ${signal.symbol}, skipping signal`);
          continue;
        }
        
        // Create a new position
        await this.createPosition(signal);
      }
      
      this.lastSignalCheck = new Date();
    } catch (error) {
      console.error('Error checking for new signals:', error);
    }
  }

  /**
   * Create a new automated position based on a signal
   */
  private async createPosition(signal: any): Promise<void> {
    try {
      // Get current price
      const tickers = await marketService.getTickers();
      const ticker = tickers.find(t => t.symbol === signal.symbol.replace('USDT', ''));
      
      if (!ticker) {
        console.error(`Could not find ticker for ${signal.symbol}`);
        return;
      }
      
      // Calculate position size
      const positionSize = this.calculatePositionSize(signal);
      
      // Calculate stop loss and take profit
      const direction = signal.signal === 'BUY' ? 'LONG' : 'SHORT';
      const entryPrice = signal.entry_price || ticker.price;
      
      const stopLoss = direction === 'LONG'
        ? entryPrice * (1 - this.config.stopLossPercent / 100)
        : entryPrice * (1 + this.config.stopLossPercent / 100);
        
      const takeProfit = direction === 'LONG'
        ? entryPrice * (1 + this.config.takeProfitPercent / 100)
        : entryPrice * (1 - this.config.takeProfitPercent / 100);
        
      const trailingStop = direction === 'LONG'
        ? entryPrice * (1 - this.config.trailingStopPercent / 100)
        : entryPrice * (1 + this.config.trailingStopPercent / 100);
      
      // Create new position
      const newPosition: AutomatedPosition = {
        id: `pos-${Date.now()}`,
        symbol: signal.symbol,
        direction,
        entryPrice,
        entryTime: new Date(),
        quantity: positionSize / entryPrice,
        stopLoss,
        takeProfit,
        trailingStop,
        currentPrice: entryPrice,
        unrealizedPnL: 0,
        unrealizedPnLPercent: 0,
        strategy: signal.algorithm || 'default',
        signalConfidence: signal.confidence,
        status: 'OPEN'
      };
      
      // Add to positions
      this.positions.push(newPosition);
      
      // Update stats
      this.updateStats();
      
      // Notify subscribers
      this.notifySubscribers();
      
      // Create notification
      aiNotificationService.addNotification({
        id: `trade_${Date.now()}`,
        type: 'signal',
        title: `New ${direction} Position Opened`,
        message: `${signal.symbol} at ${entryPrice.toFixed(2)} with ${signal.confidence.toFixed(1)}% confidence`,
        timestamp: new Date(),
        priority: 'high',
        read: false,
        data: {
          symbol: signal.symbol,
          direction,
          price: entryPrice,
          confidence: signal.confidence
        }
      });
      
      console.log(`New position created: ${direction} ${signal.symbol} at ${entryPrice}`);
    } catch (error) {
      console.error('Error creating position:', error);
    }
  }

  /**
   * Update all open positions
   */
  private async updatePositions(): Promise<void> {
    if (!this.config.enabled) return;
    
    try {
      // Get current prices
      const tickers = await marketService.getTickers();
      
      // Update each open position
      for (const position of this.positions) {
        if (position.status !== 'OPEN') continue;
        
        // Find ticker for this symbol
        const ticker = tickers.find(t => t.symbol === position.symbol.replace('USDT', ''));
        
        if (!ticker) {
          console.error(`Could not find ticker for ${position.symbol}`);
          continue;
        }
        
        // Update current price
        position.currentPrice = ticker.price;
        
        // Calculate unrealized P&L
        if (position.direction === 'LONG') {
          position.unrealizedPnL = (position.currentPrice - position.entryPrice) * position.quantity;
          position.unrealizedPnLPercent = ((position.currentPrice / position.entryPrice) - 1) * 100;
        } else {
          position.unrealizedPnL = (position.entryPrice - position.currentPrice) * position.quantity;
          position.unrealizedPnLPercent = ((position.entryPrice / position.currentPrice) - 1) * 100;
        }
        
        // Check for take profit
        if (
          (position.direction === 'LONG' && position.currentPrice >= position.takeProfit) ||
          (position.direction === 'SHORT' && position.currentPrice <= position.takeProfit)
        ) {
          this.closePosition(position, 'Take profit reached');
          continue;
        }
        
        // Check for stop loss
        if (
          (position.direction === 'LONG' && position.currentPrice <= position.stopLoss) ||
          (position.direction === 'SHORT' && position.currentPrice >= position.stopLoss)
        ) {
          this.closePosition(position, 'Stop loss triggered');
          continue;
        }
        
        // Update trailing stop if price moved in favorable direction
        if (position.direction === 'LONG' && position.currentPrice > position.entryPrice) {
          const newTrailingStop = position.currentPrice * (1 - this.config.trailingStopPercent / 100);
          if (newTrailingStop > position.trailingStop) {
            position.trailingStop = newTrailingStop;
          }
        } else if (position.direction === 'SHORT' && position.currentPrice < position.entryPrice) {
          const newTrailingStop = position.currentPrice * (1 + this.config.trailingStopPercent / 100);
          if (newTrailingStop < position.trailingStop) {
            position.trailingStop = newTrailingStop;
          }
        }
        
        // Check trailing stop
        if (
          (position.direction === 'LONG' && position.currentPrice <= position.trailingStop) ||
          (position.direction === 'SHORT' && position.currentPrice >= position.trailingStop)
        ) {
          this.closePosition(position, 'Trailing stop triggered');
        }
      }
      
      // Update stats
      this.updateStats();
      
      // Notify subscribers
      this.notifySubscribers();
    } catch (error) {
      console.error('Error updating positions:', error);
    }
  }

  /**
   * Close a position
   */
  private closePosition(position: AutomatedPosition, reason: string): void {
    position.status = 'CLOSED';
    
    // Update stats
    if (position.unrealizedPnL > 0) {
      this.stats.winningTrades++;
    } else {
      this.stats.losingTrades++;
    }
    
    this.stats.totalTrades++;
    this.stats.netProfit += position.unrealizedPnL;
    this.stats.lastTradeTime = new Date();
    
    // Create notification
    const isWin = position.unrealizedPnL > 0;
    
    aiNotificationService.addNotification({
      id: `trade_close_${Date.now()}`,
      type: 'signal',
      title: `Position ${isWin ? 'Profit' : 'Loss'}`,
      message: `${position.symbol} ${position.direction} closed with ${isWin ? 'profit' : 'loss'}: ${position.unrealizedPnL.toFixed(2)} (${position.unrealizedPnLPercent.toFixed(2)}%)`,
      timestamp: new Date(),
      priority: isWin ? 'medium' : 'high',
      read: false,
      data: {
        symbol: position.symbol,
        direction: position.direction,
        profit: position.unrealizedPnL,
        profitPercent: position.unrealizedPnLPercent,
        reason
      }
    });
    
    console.log(`Position closed: ${position.direction} ${position.symbol} with ${isWin ? 'profit' : 'loss'}: ${position.unrealizedPnL.toFixed(2)}`);
  }

  /**
   * Calculate position size based on risk management rules
   */
  private calculatePositionSize(signal: any): number {
    // In a real implementation, this would use portfolio value and risk parameters
    // For now, return a fixed position size
    return 1000; // $1000 per trade
  }

  /**
   * Update automation statistics
   */
  private updateStats(): void {
    const openPositions = this.positions.filter(p => p.status === 'OPEN');
    const closedPositions = this.positions.filter(p => p.status === 'CLOSED');
    
    this.stats.activePositions = openPositions.length;
    this.stats.pendingPositions = this.positions.filter(p => p.status === 'PENDING').length;
    
    if (closedPositions.length > 0) {
      const winningTrades = closedPositions.filter(p => p.unrealizedPnL > 0);
      const losingTrades = closedPositions.filter(p => p.unrealizedPnL <= 0);
      
      this.stats.winningTrades = winningTrades.length;
      this.stats.losingTrades = losingTrades.length;
      this.stats.totalTrades = closedPositions.length;
      this.stats.winRate = (winningTrades.length / closedPositions.length) * 100;
      
      const totalWinnings = winningTrades.reduce((sum, p) => sum + p.unrealizedPnL, 0);
      const totalLosses = Math.abs(losingTrades.reduce((sum, p) => sum + p.unrealizedPnL, 0));
      
      this.stats.profitFactor = totalLosses === 0 ? totalWinnings : totalWinnings / totalLosses;
      this.stats.netProfit = closedPositions.reduce((sum, p) => sum + p.unrealizedPnL, 0);
      this.stats.netProfitPercent = this.stats.netProfit / 10000 * 100; // Assuming $10,000 initial capital
    }
  }

  /**
   * Get the current configuration
   */
  public getConfig(): AutomationConfig {
    return { ...this.config };
  }

  /**
   * Update the configuration
   */
  public updateConfig(newConfig: Partial<AutomationConfig>): void {
    this.config = { ...this.config, ...newConfig };
    
    // Notify subscribers
    this.notifySubscribers();
    
    console.log('Automation configuration updated');
  }

  /**
   * Get all positions
   */
  public getPositions(): AutomatedPosition[] {
    return [...this.positions];
  }

  /**
   * Get automation statistics
   */
  public getStats(): AutomationStats {
    return { ...this.stats };
  }

  /**
   * Subscribe to position and stats updates
   */
  public subscribe(callback: (positions: AutomatedPosition[], stats: AutomationStats) => void): () => void {
    this.subscribers.push(callback);
    
    // Return unsubscribe function
    return () => {
      this.subscribers = this.subscribers.filter(cb => cb !== callback);
    };
  }

  /**
   * Notify all subscribers of changes
   */
  private notifySubscribers(): void {
    this.subscribers.forEach(callback => {
      callback([...this.positions], { ...this.stats });
    });
  }
}

// Create singleton instance
export const aiTradingAutomationService = new AITradingAutomationService();
export default aiTradingAutomationService;
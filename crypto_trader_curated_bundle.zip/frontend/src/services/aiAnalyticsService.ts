import { api } from '@/api';

export interface MLPrediction {
  symbol: string;
  prediction: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  target_price: number;
  timeline_hours: number;
  model_used: string;
  features: {
    price_momentum: number;
    volume_trend: number;
    volatility_score: number;
    sentiment_score: number;
    technical_indicators: number;
  };
}

export interface AIAnalyticsResponse {
  success: boolean;
  data: MLPrediction;
  timestamp: string;
  processing_time_ms: number;
}

export interface ModelTrainingStatus {
  model_id: string;
  name: string;
  type: string;
  status: 'training' | 'complete' | 'paused' | 'failed';
  progress: number;
  accuracy: number;
  created_at: string;
  updated_at: string;
}

export interface TrainingMetrics {
  model_id: string;
  epoch: number;
  loss: number;
  accuracy: number;
  val_loss: number;
  val_accuracy: number;
  learning_rate: number;
  timestamp: string;
}

export class AIAnalyticsService {
  private static instance: AIAnalyticsService;
  private baseURL = '/api/ai-analytics';

  static getInstance(): AIAnalyticsService {
    if (!AIAnalyticsService.instance) {
      AIAnalyticsService.instance = new AIAnalyticsService();
    }
    return AIAnalyticsService.instance;
  }

  // Get AI prediction for a symbol (for hybrid formula integration)
  async getPrediction(symbol: string): Promise<MLPrediction> {
    try {
      const response = await api.get<AIAnalyticsResponse>(`${this.baseURL}/predict/${symbol}`);
      return response.data.data;
    } catch (error) {
      console.error('Error fetching AI prediction:', error);
      // Return mock data for now
      return this.getMockPrediction(symbol);
    }
  }

  // Get multiple predictions for dashboard
  async getMultiplePredictions(symbols: string[]): Promise<MLPrediction[]> {
    try {
      const response = await api.post<{ success: boolean; data: MLPrediction[] }>(
        `${this.baseURL}/predict/batch`,
        { symbols }
      );
      return response.data.data;
    } catch (error) {
      console.error('Error fetching multiple predictions:', error);
      return symbols.map(symbol => this.getMockPrediction(symbol));
    }
  }

  // Get model training status
  async getModelTrainingStatus(): Promise<ModelTrainingStatus[]> {
    try {
      const response = await api.get<{ success: boolean; data: ModelTrainingStatus[] }>(
        `${this.baseURL}/models/status`
      );
      return response.data.data;
    } catch (error) {
      console.error('Error fetching model status:', error);
      return this.getMockTrainingStatus();
    }
  }

  // Start model training
  async startTraining(modelConfig: {
    model_type: string;
    hyperparameters: Record<string, any>;
    training_data: string;
  }): Promise<{ success: boolean; model_id: string }> {
    try {
      const response = await api.post<{ success: boolean; model_id: string }>(
        `${this.baseURL}/models/train`,
        modelConfig
      );
      return response.data;
    } catch (error) {
      console.error('Error starting training:', error);
      return { success: false, model_id: '' };
    }
  }

  // Get training metrics
  async getTrainingMetrics(modelId: string): Promise<TrainingMetrics[]> {
    try {
      const response = await api.get<{ success: boolean; data: TrainingMetrics[] }>(
        `${this.baseURL}/models/${modelId}/metrics`
      );
      return response.data.data;
    } catch (error) {
      console.error('Error fetching training metrics:', error);
      return [];
    }
  }

  // Mock data for development
  private getMockPrediction(symbol: string): MLPrediction {
    const predictions: ('bullish' | 'bearish' | 'neutral')[] = ['bullish', 'bearish', 'neutral'];
    const prediction = predictions[Math.floor(Math.random() * predictions.length)];
    const confidence = 0.6 + Math.random() * 0.4; // 60-100% confidence
    
    return {
      symbol,
      prediction,
      confidence,
      target_price: 45000 + Math.random() * 10000, // Mock BTC price
      timeline_hours: 2 + Math.random() * 6, // 2-8 hours
      model_used: 'LSTM_v2.1',
      features: {
        price_momentum: Math.random() * 2 - 1, // -1 to 1
        volume_trend: Math.random() * 2 - 1,
        volatility_score: Math.random(),
        sentiment_score: Math.random() * 2 - 1,
        technical_indicators: Math.random() * 2 - 1
      }
    };
  }

  private getMockTrainingStatus(): ModelTrainingStatus[] {
    return [
      {
        model_id: 'lstm_001',
        name: 'LSTM Price Predictor',
        type: 'Deep Learning',
        status: 'training',
        progress: 87,
        accuracy: 0.947,
        created_at: '2024-01-15T10:00:00Z',
        updated_at: '2024-01-15T12:30:00Z'
      },
      {
        model_id: 'rf_002',
        name: 'Signal Confidence Model',
        type: 'Random Forest',
        status: 'complete',
        progress: 100,
        accuracy: 0.912,
        created_at: '2024-01-14T14:00:00Z',
        updated_at: '2024-01-14T16:45:00Z'
      },
      {
        model_id: 'xgb_003',
        name: 'Quick Scalp Predictor',
        type: 'XGBoost',
        status: 'training',
        progress: 34,
        accuracy: 0.865,
        created_at: '2024-01-15T09:00:00Z',
        updated_at: '2024-01-15T11:15:00Z'
      }
    ];
  }
}

// Export singleton instance
export const aiAnalyticsService = AIAnalyticsService.getInstance();

// Helper function for hybrid formula integration
export const getAIAnalyticsPrediction = async (symbol: string): Promise<{
  confidence: number;
  prediction: string;
  contribution: number;
}> => {
  try {
    const prediction = await aiAnalyticsService.getPrediction(symbol);
    
    // Convert prediction to contribution score (-1 to 1)
    let contribution = 0;
    if (prediction.prediction === 'bullish') {
      contribution = prediction.confidence;
    } else if (prediction.prediction === 'bearish') {
      contribution = -prediction.confidence;
    } // neutral stays 0
    
    return {
      confidence: prediction.confidence,
      prediction: prediction.prediction,
      contribution
    };
  } catch (error) {
    console.error('Error getting AI prediction for hybrid formula:', error);
    return {
      confidence: 0,
      prediction: 'neutral',
      contribution: 0
    };
  }
};

export default aiAnalyticsService;
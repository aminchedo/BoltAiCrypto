import api from './api';
import { Signal, Backtest } from '@/types/signals';
import marketService from './marketService';

export { Signal, Backtest };

interface TechnicalIndicators {
  rsi: number;
  macd: { macd: number; signal: number; histogram: number };
  bollinger: { upper: number; middle: number; lower: number };
  ema20: number;
  ema50: number;
  sma200: number;
  stochastic: { k: number; d: number };
  atr: number;
  volume_sma: number;
}

interface SmartMoneyData {
  orderBlocks: Array<{ price: number; strength: number; type: 'bullish' | 'bearish' }>;
  fairValueGaps: Array<{ high: number; low: number; strength: number }>;
  liquidityZones: Array<{ price: number; volume: number; type: 'buy' | 'sell' }>;
  marketStructure: {
    trend: 'bullish' | 'bearish' | 'sideways';
    strength: number;
    breakOfStructure: boolean;
  };
  supplyDemand: {
    supply: Array<{ price: number; strength: number }>;
    demand: Array<{ price: number; strength: number }>;
  };
}

interface PatternData {
  harmonicPatterns: Array<{
    type: 'butterfly' | 'bat' | 'gartley' | 'crab';
    confidence: number;
    target: number;
    stopLoss: number;
  }>;
  classicPatterns: Array<{
    type: 'head_shoulders' | 'double_top' | 'double_bottom' | 'triangle';
    confidence: number;
    target: number;
  }>;
  candlestickPatterns: Array<{
    type: string;
    confidence: number;
    bullish: boolean;
  }>;
}

interface SentimentData {
  newsScore: number; // -1 to 1
  socialScore: number; // -1 to 1
  fearGreedIndex: number; // 0 to 100
  whaleActivity: number; // -1 to 1
  overallSentiment: number; // -1 to 1
}

interface WhaleData {
  largeTransactions: Array<{
    amount: number;
    type: 'inflow' | 'outflow';
    exchange: string;
    timestamp: number;
  }>;
  exchangeFlows: {
    netFlow: number;
    inflowVolume: number;
    outflowVolume: number;
  };
  whaleScore: number; // -1 to 1
}

interface MLPrediction {
  priceTarget1h: number;
  priceTarget4h: number;
  priceTarget24h: number;
  confidence: number;
  volatilityPrediction: number;
  trendPrediction: 'up' | 'down' | 'sideways';
}

interface HybridSignal extends Signal {
  algorithmBreakdown: {
    technicalAnalysis: { score: number; weight: number; contribution: number };
    smartMoneyConcepts: { score: number; weight: number; contribution: number };
    patternRecognition: { score: number; weight: number; contribution: number };
    sentimentAnalysis: { score: number; weight: number; contribution: number };
    whaleIntelligence: { score: number; weight: number; contribution: number };
    mlPredictions: { score: number; weight: number; contribution: number };
    finalScore: number;
  };
  riskAssessment: {
    riskScore: number;
    maxLossAmount: number;
    positionSizeRecommendation: number;
    marketImpact: 'LOW' | 'MEDIUM' | 'HIGH';
  };
  marketConditions: {
    volatility: number;
    volumeProfile: 'HIGH' | 'MEDIUM' | 'LOW';
    trendStrength: number;
    supportResistance: { support: number; resistance: number };
  };
}

class SignalService {
  private readonly ALGORITHM_WEIGHTS = {
    technicalAnalysis: 0.35,
    smartMoneyConcepts: 0.25,
    patternRecognition: 0.20,
    sentimentAnalysis: 0.10,
    whaleIntelligence: 0.05,
    mlPredictions: 0.05
  };

  private signalCache: Map<string, HybridSignal[]> = new Map();
  private lastUpdate: Map<string, number> = new Map();
  private readonly CACHE_DURATION = 60000; // 1 minute

  async getLiveSignals(symbols?: string[]): Promise<HybridSignal[]> {
    try {
      // Try primary API first
      const signals = await api.get<HybridSignal[]>('/v1/signals/live', { symbols });
      return signals;
    } catch (error) {
      console.error('Primary signals API failed, generating locally:', error);
      return this.generateHybridSignals(symbols || ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']);
    }
  }

  private async generateHybridSignals(symbols: string[]): Promise<HybridSignal[]> {
    const signals: HybridSignal[] = [];

    for (const symbol of symbols) {
      try {
        // Check cache first
        const cacheKey = symbol;
        const lastUpdateTime = this.lastUpdate.get(cacheKey) || 0;
        const cachedSignals = this.signalCache.get(cacheKey);

        if (cachedSignals && Date.now() - lastUpdateTime < this.CACHE_DURATION) {
          signals.push(...cachedSignals);
          continue;
        }

        // Generate new signal
        const signal = await this.generateSignalForSymbol(symbol);
        if (signal) {
          signals.push(signal);
          this.signalCache.set(cacheKey, [signal]);
          this.lastUpdate.set(cacheKey, Date.now());
        }
      } catch (error) {
        console.error(`Failed to generate signal for ${symbol}:`, error);
      }
    }

    return signals;
  }

  private async generateSignalForSymbol(symbol: string): Promise<HybridSignal | null> {
    try {
      // Get market data
      const historicalData = await marketService.getHistoricalPrices(
        symbol,
        new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
        new Date(),
        '1h'
      );

      if (historicalData.length < 50) {
        console.warn(`Insufficient data for ${symbol}`);
        return null;
      }

      // Calculate all components
      const technicalIndicators = this.calculateTechnicalIndicators(historicalData);
      const smartMoneyData = this.analyzeSmartMoney(historicalData);
      const patternData = this.recognizePatterns(historicalData);
      const sentimentData = await this.analyzeSentiment(symbol);
      const whaleData = await this.analyzeWhaleActivity(symbol);
      const mlPrediction = await this.generateMLPrediction(symbol, historicalData);

      // Calculate component scores
      const technicalScore = this.calculateTechnicalScore(technicalIndicators);
      const smartMoneyScore = this.calculateSmartMoneyScore(smartMoneyData);
      const patternScore = this.calculatePatternScore(patternData);
      const sentimentScore = sentimentData.overallSentiment;
      const whaleScore = whaleData.whaleScore;
      const mlScore = this.calculateMLScore(mlPrediction);

      // Calculate weighted final score
      const finalScore =
        technicalScore * this.ALGORITHM_WEIGHTS.technicalAnalysis +
        smartMoneyScore * this.ALGORITHM_WEIGHTS.smartMoneyConcepts +
        patternScore * this.ALGORITHM_WEIGHTS.patternRecognition +
        sentimentScore * this.ALGORITHM_WEIGHTS.sentimentAnalysis +
        whaleScore * this.ALGORITHM_WEIGHTS.whaleIntelligence +
        mlScore * this.ALGORITHM_WEIGHTS.mlPredictions;

      // Determine signal direction and confidence
      const direction = finalScore > 0.1 ? 'BUY' : finalScore < -0.1 ? 'SELL' : 'HOLD';
      const confidence = Math.min(Math.abs(finalScore) * 100, 100);

      if (confidence < 60) {
        return null; // Don't generate low-confidence signals
      }

      const currentPrice = historicalData[historicalData.length - 1].close;
      const atr = technicalIndicators.atr;

      // Calculate entry, stop loss, and take profit
      const stopLossDistance = atr * 2;
      const takeProfitDistance = atr * 3;

      const signal: HybridSignal = {
        id: `${symbol}_${Date.now()}`,
        symbol,
        direction: direction as 'BUY' | 'SELL' | 'HOLD',
        confidence: Math.round(confidence),
        entryPrice: currentPrice,
        stopLoss: direction === 'BUY'
          ? currentPrice - stopLossDistance
          : currentPrice + stopLossDistance,
        takeProfit: direction === 'BUY'
          ? currentPrice + takeProfitDistance
          : currentPrice - takeProfitDistance,
        riskRewardRatio: takeProfitDistance / stopLossDistance,
        timestamp: Date.now(),
        expiresAt: Date.now() + 4 * 60 * 60 * 1000, // 4 hours
        status: 'ACTIVE',
        algorithmBreakdown: {
          technicalAnalysis: {
            score: technicalScore,
            weight: this.ALGORITHM_WEIGHTS.technicalAnalysis,
            contribution: technicalScore * this.ALGORITHM_WEIGHTS.technicalAnalysis
          },
          smartMoneyConcepts: {
            score: smartMoneyScore,
            weight: this.ALGORITHM_WEIGHTS.smartMoneyConcepts,
            contribution: smartMoneyScore * this.ALGORITHM_WEIGHTS.smartMoneyConcepts
          },
          patternRecognition: {
            score: patternScore,
            weight: this.ALGORITHM_WEIGHTS.patternRecognition,
            contribution: patternScore * this.ALGORITHM_WEIGHTS.patternRecognition
          },
          sentimentAnalysis: {
            score: sentimentScore,
            weight: this.ALGORITHM_WEIGHTS.sentimentAnalysis,
            contribution: sentimentScore * this.ALGORITHM_WEIGHTS.sentimentAnalysis
          },
          whaleIntelligence: {
            score: whaleScore,
            weight: this.ALGORITHM_WEIGHTS.whaleIntelligence,
            contribution: whaleScore * this.ALGORITHM_WEIGHTS.whaleIntelligence
          },
          mlPredictions: {
            score: mlScore,
            weight: this.ALGORITHM_WEIGHTS.mlPredictions,
            contribution: mlScore * this.ALGORITHM_WEIGHTS.mlPredictions
          },
          finalScore
        },
        riskAssessment: {
          riskScore: this.calculateRiskScore(technicalIndicators, smartMoneyData),
          maxLossAmount: stopLossDistance,
          positionSizeRecommendation: this.calculatePositionSize(confidence, stopLossDistance),
          marketImpact: this.assessMarketImpact(historicalData)
        },
        marketConditions: {
          volatility: technicalIndicators.atr / currentPrice * 100,
          volumeProfile: this.assessVolumeProfile(historicalData),
          trendStrength: Math.abs(technicalScore) * 100,
          supportResistance: this.findSupportResistance(historicalData)
        }
      };

      return signal;
    } catch (error) {
      console.error(`Error generating signal for ${symbol}:`, error);
      return null;
    }
  }

  private calculateTechnicalIndicators(data: any[]): TechnicalIndicators {
    const closes = data.map(d => d.close);
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);
    const volumes = data.map(d => d.volume);

    return {
      rsi: this.calculateRSI(closes, 14),
      macd: this.calculateMACD(closes),
      bollinger: this.calculateBollingerBands(closes, 20, 2),
      ema20: this.calculateEMA(closes, 20),
      ema50: this.calculateEMA(closes, 50),
      sma200: this.calculateSMA(closes, 200),
      stochastic: this.calculateStochastic(highs, lows, closes, 14),
      atr: this.calculateATR(highs, lows, closes, 14),
      volume_sma: this.calculateSMA(volumes, 20)
    };
  }

  private calculateRSI(prices: number[], period: number): number {
    if (prices.length < period + 1) return 50;

    let gains = 0;
    let losses = 0;

    for (let i = 1; i <= period; i++) {
      const change = prices[prices.length - i] - prices[prices.length - i - 1];
      if (change > 0) gains += change;
      else losses -= change;
    }

    const avgGain = gains / period;
    const avgLoss = losses / period;

    if (avgLoss === 0) return 100;

    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  private calculateMACD(prices: number[]): { macd: number; signal: number; histogram: number } {
    const ema12 = this.calculateEMA(prices, 12);
    const ema26 = this.calculateEMA(prices, 26);
    const macd = ema12 - ema26;

    // For simplicity, using a basic signal calculation
    const signal = macd * 0.9; // Simplified signal line
    const histogram = macd - signal;

    return { macd, signal, histogram };
  }

  private calculateBollingerBands(prices: number[], period: number, stdDev: number): { upper: number; middle: number; lower: number } {
    const sma = this.calculateSMA(prices, period);
    const variance = prices.slice(-period).reduce((sum, price) => sum + Math.pow(price - sma, 2), 0) / period;
    const standardDeviation = Math.sqrt(variance);

    return {
      upper: sma + (standardDeviation * stdDev),
      middle: sma,
      lower: sma - (standardDeviation * stdDev)
    };
  }

  private calculateEMA(prices: number[], period: number): number {
    if (prices.length === 0) return 0;

    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }

    return ema;
  }

  private calculateSMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1] || 0;

    const slice = prices.slice(-period);
    return slice.reduce((sum, price) => sum + price, 0) / period;
  }

  private calculateStochastic(highs: number[], lows: number[], closes: number[], period: number): { k: number; d: number } {
    if (highs.length < period) return { k: 50, d: 50 };

    const recentHighs = highs.slice(-period);
    const recentLows = lows.slice(-period);
    const currentClose = closes[closes.length - 1];

    const highestHigh = Math.max(...recentHighs);
    const lowestLow = Math.min(...recentLows);

    const k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
    const d = k * 0.9; // Simplified D calculation

    return { k, d };
  }

  private calculateATR(highs: number[], lows: number[], closes: number[], period: number): number {
    if (highs.length < period + 1) return 0;

    const trueRanges = [];
    for (let i = 1; i < highs.length; i++) {
      const tr1 = highs[i] - lows[i];
      const tr2 = Math.abs(highs[i] - closes[i - 1]);
      const tr3 = Math.abs(lows[i] - closes[i - 1]);
      trueRanges.push(Math.max(tr1, tr2, tr3));
    }

    return this.calculateSMA(trueRanges, period);
  }

  private calculateTechnicalScore(indicators: TechnicalIndicators): number {
    let score = 0;
    let factors = 0;

    // RSI analysis
    if (indicators.rsi < 30) score += 0.8; // Oversold - bullish
    else if (indicators.rsi > 70) score -= 0.8; // Overbought - bearish
    else if (indicators.rsi > 45 && indicators.rsi < 55) score += 0.2; // Neutral momentum
    factors++;

    // MACD analysis
    if (indicators.macd.histogram > 0) score += 0.6;
    else score -= 0.6;
    factors++;

    // Bollinger Bands analysis
    const currentPrice = indicators.bollinger.middle; // Approximation
    if (currentPrice < indicators.bollinger.lower) score += 0.7; // Below lower band - bullish
    else if (currentPrice > indicators.bollinger.upper) score -= 0.7; // Above upper band - bearish
    factors++;

    // EMA trend analysis
    if (indicators.ema20 > indicators.ema50) score += 0.5; // Uptrend
    else score -= 0.5; // Downtrend
    factors++;

    // Stochastic analysis
    if (indicators.stochastic.k < 20) score += 0.4; // Oversold
    else if (indicators.stochastic.k > 80) score -= 0.4; // Overbought
    factors++;

    return score / factors; // Normalize to -1 to 1 range
  }

  private analyzeSmartMoney(data: any[]): SmartMoneyData {
    // Simplified smart money analysis
    const closes = data.map(d => d.close);
    const volumes = data.map(d => d.volume);
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);

    return {
      orderBlocks: this.findOrderBlocks(data),
      fairValueGaps: this.findFairValueGaps(data),
      liquidityZones: this.findLiquidityZones(data),
      marketStructure: this.analyzeMarketStructure(data),
      supplyDemand: this.findSupplyDemandZones(data)
    };
  }

  private findOrderBlocks(data: any[]): Array<{ price: number; strength: number; type: 'bullish' | 'bearish' }> {
    const orderBlocks = [];
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;

    for (let i = 2; i < data.length - 2; i++) {
      if (data[i].volume > avgVolume * 1.5) {
        const strength = (data[i].volume / avgVolume - 1) * 100;
        const type = data[i].close > data[i].open ? 'bullish' : 'bearish';

        orderBlocks.push({
          price: (data[i].high + data[i].low) / 2,
          strength,
          type
        });
      }
    }

    return orderBlocks.slice(-5); // Return last 5 order blocks
  }

  private findFairValueGaps(data: any[]): Array<{ high: number; low: number; strength: number }> {
    const gaps = [];

    for (let i = 1; i < data.length; i++) {
      const prevHigh = data[i - 1].high;
      const prevLow = data[i - 1].low;
      const currentHigh = data[i].high;
      const currentLow = data[i].low;

      // Gap up
      if (currentLow > prevHigh) {
        gaps.push({
          high: currentLow,
          low: prevHigh,
          strength: ((currentLow - prevHigh) / prevHigh) * 100
        });
      }
      // Gap down
      else if (currentHigh < prevLow) {
        gaps.push({
          high: prevLow,
          low: currentHigh,
          strength: ((prevLow - currentHigh) / currentHigh) * 100
        });
      }
    }

    return gaps.slice(-3); // Return last 3 gaps
  }

  private findLiquidityZones(data: any[]): Array<{ price: number; volume: number; type: 'buy' | 'sell' }> {
    const zones = [];
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;

    for (let i = 0; i < data.length; i++) {
      if (data[i].volume > avgVolume * 2) {
        zones.push({
          price: (data[i].high + data[i].low) / 2,
          volume: data[i].volume,
          type: data[i].close > data[i].open ? 'buy' : 'sell'
        });
      }
    }

    return zones.slice(-10); // Return last 10 zones
  }

  private analyzeMarketStructure(data: any[]): { trend: 'bullish' | 'bearish' | 'sideways'; strength: number; breakOfStructure: boolean } {
    const closes = data.map(d => d.close);
    const recentCloses = closes.slice(-20);

    const firstPrice = recentCloses[0];
    const lastPrice = recentCloses[recentCloses.length - 1];
    const change = (lastPrice - firstPrice) / firstPrice;

    let trend: 'bullish' | 'bearish' | 'sideways';
    if (change > 0.02) trend = 'bullish';
    else if (change < -0.02) trend = 'bearish';
    else trend = 'sideways';

    const strength = Math.abs(change) * 100;
    const breakOfStructure = strength > 5; // Simplified BOS detection

    return { trend, strength, breakOfStructure };
  }

  private findSupplyDemandZones(data: any[]): { supply: Array<{ price: number; strength: number }>; demand: Array<{ price: number; strength: number }> } {
    const supply = [];
    const demand = [];

    // Find resistance levels (supply)
    for (let i = 2; i < data.length - 2; i++) {
      if (data[i].high > data[i - 1].high && data[i].high > data[i - 2].high &&
        data[i].high > data[i + 1].high && data[i].high > data[i + 2].high) {
        supply.push({
          price: data[i].high,
          strength: data[i].volume / 1000000 // Simplified strength calculation
        });
      }
    }

    // Find support levels (demand)
    for (let i = 2; i < data.length - 2; i++) {
      if (data[i].low < data[i - 1].low && data[i].low < data[i - 2].low &&
        data[i].low < data[i + 1].low && data[i].low < data[i + 2].low) {
        demand.push({
          price: data[i].low,
          strength: data[i].volume / 1000000 // Simplified strength calculation
        });
      }
    }

    return {
      supply: supply.slice(-3),
      demand: demand.slice(-3)
    };
  }

  private calculateSmartMoneyScore(smartMoney: SmartMoneyData): number {
    let score = 0;

    // Market structure score
    if (smartMoney.marketStructure.trend === 'bullish') score += 0.4;
    else if (smartMoney.marketStructure.trend === 'bearish') score -= 0.4;

    // Break of structure
    if (smartMoney.marketStructure.breakOfStructure) {
      score += smartMoney.marketStructure.trend === 'bullish' ? 0.3 : -0.3;
    }

    // Order blocks influence
    const bullishBlocks = smartMoney.orderBlocks.filter(ob => ob.type === 'bullish').length;
    const bearishBlocks = smartMoney.orderBlocks.filter(ob => ob.type === 'bearish').length;
    score += (bullishBlocks - bearishBlocks) * 0.1;

    // Supply/demand balance
    const supplyStrength = smartMoney.supplyDemand.supply.reduce((sum, s) => sum + s.strength, 0);
    const demandStrength = smartMoney.supplyDemand.demand.reduce((sum, d) => sum + d.strength, 0);
    score += (demandStrength - supplyStrength) * 0.001; // Small influence

    return Math.max(-1, Math.min(1, score)); // Clamp to -1 to 1
  }

  private recognizePatterns(data: any[]): PatternData {
    return {
      harmonicPatterns: this.findHarmonicPatterns(data),
      classicPatterns: this.findClassicPatterns(data),
      candlestickPatterns: this.findCandlestickPatterns(data)
    };
  }

  private findHarmonicPatterns(data: any[]): Array<{ type: 'butterfly' | 'bat' | 'gartley' | 'crab'; confidence: number; target: number; stopLoss: number }> {
    // Simplified harmonic pattern detection
    const patterns = [];

    if (data.length < 20) return patterns;

    // Mock pattern detection for demonstration
    const currentPrice = data[data.length - 1].close;

    if (Math.random() > 0.7) { // 30% chance of finding a pattern
      const patternTypes: ('butterfly' | 'bat' | 'gartley' | 'crab')[] = ['butterfly', 'bat', 'gartley', 'crab'];
      const type = patternTypes[Math.floor(Math.random() * patternTypes.length)];

      patterns.push({
        type,
        confidence: 60 + Math.random() * 30,
        target: currentPrice * (1 + (Math.random() - 0.5) * 0.1),
        stopLoss: currentPrice * (1 - Math.random() * 0.05)
      });
    }

    return patterns;
  }

  private findClassicPatterns(data: any[]): Array<{ type: 'head_shoulders' | 'double_top' | 'double_bottom' | 'triangle'; confidence: number; target: number }> {
    const patterns = [];

    if (data.length < 30) return patterns;

    // Simplified classic pattern detection
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);
    const currentPrice = data[data.length - 1].close;

    // Mock pattern detection
    if (Math.random() > 0.8) { // 20% chance
      const patternTypes: ('head_shoulders' | 'double_top' | 'double_bottom' | 'triangle')[] =
        ['head_shoulders', 'double_top', 'double_bottom', 'triangle'];
      const type = patternTypes[Math.floor(Math.random() * patternTypes.length)];

      patterns.push({
        type,
        confidence: 50 + Math.random() * 40,
        target: currentPrice * (1 + (Math.random() - 0.5) * 0.08)
      });
    }

    return patterns;
  }

  private findCandlestickPatterns(data: any[]): Array<{ type: string; confidence: number; bullish: boolean }> {
    const patterns = [];

    if (data.length < 3) return patterns;

    const recent = data.slice(-3);

    // Simplified candlestick pattern detection
    const patternTypes = [
      'doji', 'hammer', 'shooting_star', 'engulfing', 'harami',
      'morning_star', 'evening_star', 'three_white_soldiers'
    ];

    // Mock detection
    if (Math.random() > 0.6) { // 40% chance
      const type = patternTypes[Math.floor(Math.random() * patternTypes.length)];
      const bullish = ['hammer', 'engulfing', 'morning_star', 'three_white_soldiers'].includes(type);

      patterns.push({
        type,
        confidence: 60 + Math.random() * 30,
        bullish
      });
    }

    return patterns;
  }

  private calculatePatternScore(patterns: PatternData): number {
    let score = 0;
    let weight = 0;

    // Harmonic patterns
    patterns.harmonicPatterns.forEach(pattern => {
      const patternScore = (pattern.confidence / 100) * 0.8;
      score += patternScore;
      weight += 0.8;
    });

    // Classic patterns
    patterns.classicPatterns.forEach(pattern => {
      const patternScore = (pattern.confidence / 100) * 0.6;
      score += patternScore;
      weight += 0.6;
    });

    // Candlestick patterns
    patterns.candlestickPatterns.forEach(pattern => {
      const patternScore = (pattern.confidence / 100) * (pattern.bullish ? 0.4 : -0.4);
      score += patternScore;
      weight += 0.4;
    });

    return weight > 0 ? score / weight : 0;
  }

  private async analyzeSentiment(symbol: string): Promise<SentimentData> {
    try {
      // In a real implementation, this would call news and social media APIs
      return {
        newsScore: (Math.random() - 0.5) * 2,
        socialScore: (Math.random() - 0.5) * 2,
        fearGreedIndex: Math.random() * 100,
        whaleActivity: (Math.random() - 0.5) * 2,
        overallSentiment: (Math.random() - 0.5) * 2
      };
    } catch (error) {
      console.error('Sentiment analysis failed:', error);
      return {
        newsScore: 0,
        socialScore: 0,
        fearGreedIndex: 50,
        whaleActivity: 0,
        overallSentiment: 0
      };
    }
  }

  private async analyzeWhaleActivity(symbol: string): Promise<WhaleData> {
    try {
      // Mock whale data - in real implementation, this would analyze blockchain data
      return {
        largeTransactions: [
          {
            amount: Math.random() * 1000000,
            type: Math.random() > 0.5 ? 'inflow' : 'outflow',
            exchange: 'binance',
            timestamp: Date.now() - Math.random() * 24 * 60 * 60 * 1000
          }
        ],
        exchangeFlows: {
          netFlow: (Math.random() - 0.5) * 10000000,
          inflowVolume: Math.random() * 50000000,
          outflowVolume: Math.random() * 50000000
        },
        whaleScore: (Math.random() - 0.5) * 2
      };
    } catch (error) {
      console.error('Whale analysis failed:', error);
      return {
        largeTransactions: [],
        exchangeFlows: { netFlow: 0, inflowVolume: 0, outflowVolume: 0 },
        whaleScore: 0
      };
    }
  }

  private async generateMLPrediction(symbol: string, data: any[]): Promise<MLPrediction> {
    try {
      // Mock ML prediction - in real implementation, this would use trained models
      const currentPrice = data[data.length - 1].close;
      const volatility = this.calculateATR(
        data.map(d => d.high),
        data.map(d => d.low),
        data.map(d => d.close),
        14
      );

      return {
        priceTarget1h: currentPrice * (1 + (Math.random() - 0.5) * 0.02),
        priceTarget4h: currentPrice * (1 + (Math.random() - 0.5) * 0.05),
        priceTarget24h: currentPrice * (1 + (Math.random() - 0.5) * 0.1),
        confidence: 60 + Math.random() * 30,
        volatilityPrediction: volatility * (0.8 + Math.random() * 0.4),
        trendPrediction: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'sideways'
      };
    } catch (error) {
      console.error('ML prediction failed:', error);
      const currentPrice = data[data.length - 1].close;
      return {
        priceTarget1h: currentPrice,
        priceTarget4h: currentPrice,
        priceTarget24h: currentPrice,
        confidence: 50,
        volatilityPrediction: 0,
        trendPrediction: 'sideways'
      };
    }
  }

  private calculateMLScore(prediction: MLPrediction): number {
    const currentPrice = 43000; // Mock current price
    const change24h = (prediction.priceTarget24h - currentPrice) / currentPrice;
    const confidence = prediction.confidence / 100;

    return change24h * confidence;
  }

  private calculateRiskScore(indicators: TechnicalIndicators, smartMoney: SmartMoneyData): number {
    let riskScore = 50; // Base risk score

    // Volatility risk
    const volatilityRisk = (indicators.atr / 43000) * 100; // Mock current price
    riskScore += volatilityRisk * 10;

    // Market structure risk
    if (smartMoney.marketStructure.breakOfStructure) {
      riskScore += 20;
    }

    // RSI extremes
    if (indicators.rsi > 80 || indicators.rsi < 20) {
      riskScore += 15;
    }

    return Math.min(100, Math.max(0, riskScore));
  }

  private calculatePositionSize(confidence: number, stopLossDistance: number): number {
    // Kelly Criterion simplified
    const winRate = confidence / 100;
    const avgWin = 2; // Assume 2:1 reward ratio
    const avgLoss = 1;

    const kellyPercent = (winRate * avgWin - (1 - winRate) * avgLoss) / avgWin;

    // Conservative position sizing (max 5% of portfolio)
    return Math.min(5, Math.max(0.5, kellyPercent * 100));
  }

  private assessMarketImpact(data: any[]): 'LOW' | 'MEDIUM' | 'HIGH' {
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    const recentVolume = volumes[volumes.length - 1];

    const volumeRatio = recentVolume / avgVolume;

    if (volumeRatio > 2) return 'HIGH';
    if (volumeRatio > 1.5) return 'MEDIUM';
    return 'LOW';
  }

  private assessVolumeProfile(data: any[]): 'HIGH' | 'MEDIUM' | 'LOW' {
    const volumes = data.map(d => d.volume);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    const recentAvgVolume = volumes.slice(-5).reduce((sum, vol) => sum + vol, 0) / 5;

    const ratio = recentAvgVolume / avgVolume;

    if (ratio > 1.5) return 'HIGH';
    if (ratio > 0.8) return 'MEDIUM';
    return 'LOW';
  }

  private findSupportResistance(data: any[]): { support: number; resistance: number } {
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);

    // Simple support/resistance calculation
    const recentHighs = highs.slice(-20);
    const recentLows = lows.slice(-20);

    const resistance = Math.max(...recentHighs);
    const support = Math.min(...recentLows);

    return { support, resistance };
  }

  async getBacktest(symbol: string, period: string = '30d'): Promise<Backtest> {
    try {
      return await api.get<Backtest>(`/v1/signals/backtest/${symbol}`, { period });
    } catch (error) {
      console.error('Backtest API failed:', error);
      return this.generateMockBacktest(symbol);
    }
  }

  private generateMockBacktest(symbol: string): Backtest {
    const totalTrades = 100 + Math.floor(Math.random() * 200);
    const winRate = 0.65 + Math.random() * 0.2; // 65-85% win rate
    const winningTrades = Math.floor(totalTrades * winRate);
    const losingTrades = totalTrades - winningTrades;

    const avgWin = 3 + Math.random() * 5; // 3-8% average win
    const avgLoss = 1 + Math.random() * 2; // 1-3% average loss

    const totalReturn = (winningTrades * avgWin) - (losingTrades * avgLoss);
    const maxDrawdown = Math.random() * 15 + 5; // 5-20% max drawdown

    return {
      symbol,
      period: '30d',
      totalTrades,
      winningTrades,
      losingTrades,
      winRate: winRate * 100,
      totalReturn,
      avgWin,
      avgLoss,
      maxDrawdown,
      sharpeRatio: 1.5 + Math.random() * 1.5,
      profitFactor: (winningTrades * avgWin) / (losingTrades * avgLoss),
      trades: [] // Would contain individual trade data
    };
  }

  // Clear cache
  clearCache() {
    this.signalCache.clear();
    this.lastUpdate.clear();
  }
}

const signalService = new SignalService();
export { signalService };
export default signalService;
import { useUserStore } from '@/store/userStore';

export interface TradeRequest {
  pair: string;
  amount: number;
  price: number;
  side: 'buy' | 'sell';
  exchange: string;
  orderType: 'market' | 'limit';
}

export interface TradeConfirmationData {
  title: string;
  details: string;
  confirmText: string;
  cancelText: string;
  trade: TradeRequest;
}

export interface TradeResult {
  status: 'success' | 'cancelled' | 'error';
  message?: string;
  orderId?: string;
  data?: any;
}

// Trade confirmation dialog promise resolver
let confirmationResolver: ((confirmed: boolean) => void) | null = null;

export const showConfirmationDialog = (data: TradeConfirmationData): Promise<boolean> => {
  return new Promise((resolve) => {
    confirmationResolver = resolve;
    
    // Create and show modal
    const modal = document.createElement('div');
    modal.id = 'trade-confirmation-modal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full mx-4">
        <div class="p-6">
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            ${data.title}
          </h3>
          <div class="space-y-3 mb-6">
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Pair:</span>
              <span class="text-gray-900 dark:text-white">${data.trade.pair}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Amount:</span>
              <span class="text-gray-900 dark:text-white">${data.trade.amount}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Price:</span>
              <span class="text-gray-900 dark:text-white">$${data.trade.price.toLocaleString()}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Side:</span>
              <span class="text-gray-900 dark:text-white capitalize">${data.trade.side}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Exchange:</span>
              <span class="text-gray-900 dark:text-white">${data.trade.exchange}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Total:</span>
              <span class="text-gray-900 dark:text-white font-semibold">$${(data.trade.amount * data.trade.price).toLocaleString()}</span>
            </div>
          </div>
          <div class="flex space-x-3">
            <button 
              id="confirm-trade" 
              class="flex-1 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:ring-2 focus:ring-green-500 transition-colors"
            >
              ${data.confirmText}
            </button>
            <button 
              id="cancel-trade" 
              class="flex-1 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 transition-colors"
            >
              ${data.cancelText}
            </button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add event listeners
    const confirmBtn = modal.querySelector('#confirm-trade');
    const cancelBtn = modal.querySelector('#cancel-trade');
    
    const handleConfirm = () => {
      document.body.removeChild(modal);
      resolve(true);
      confirmationResolver = null;
    };
    
    const handleCancel = () => {
      document.body.removeChild(modal);
      resolve(false);
      confirmationResolver = null;
    };
    
    confirmBtn?.addEventListener('click', handleConfirm);
    cancelBtn?.addEventListener('click', handleCancel);
    
    // Close on background click
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        handleCancel();
      }
    });
    
    // Close on escape
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCancel();
        document.removeEventListener('keydown', handleEscape);
      }
    };
    
    document.addEventListener('keydown', handleEscape);
  });
};

export const placeOrder = async (trade: TradeRequest): Promise<TradeResult> => {
  try {
    // Simulate API call to place order
    const response = await fetch('/api/trading/place-order', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(trade),
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return {
        status: 'success',
        orderId: data.orderId,
        message: 'Order placed successfully',
        data: data,
      };
    } else {
      return {
        status: 'error',
        message: data.message || 'Failed to place order',
      };
    }
  } catch (error) {
    return {
      status: 'error',
      message: 'Network error occurred',
    };
  }
};

export const executeTrade = async (trade: TradeRequest): Promise<TradeResult> => {
  const { getSetting } = useUserStore.getState();
  const confirmEnabled = getSetting('trading', 'confirmTrades');
  
  if (confirmEnabled) {
    const confirmed = await showConfirmationDialog({
      title: `Confirm ${trade.side.toUpperCase()} Order`,
      details: `You're about to ${trade.side} ${trade.amount} ${trade.pair} at $${trade.price}`,
      confirmText: "Execute Trade",
      cancelText: "Cancel",
      trade: trade,
    });
    
    if (!confirmed) {
      return { status: 'cancelled' };
    }
  }
  
  return placeOrder(trade);
};

// Settings registry integration
export const SETTINGS_CONFIG = {
  // Security settings
  encryptedBackups: {
    type: 'boolean',
    default: false,
    category: 'security',
    description: 'Enable AES-256 encrypted cloud backups',
  },
  sessionTimeout: {
    type: 'boolean',
    default: false,
    category: 'security',
    description: 'Auto-lock after 15 minutes of inactivity',
  },
  twoFactorAuth: {
    type: 'boolean',
    default: false,
    category: 'security',
    description: 'Require Google Authenticator for sensitive operations',
  },
  autoLock: {
    type: 'boolean',
    default: false,
    category: 'security',
    description: 'Lock screen when inactive',
  },
  biometricAuth: {
    type: 'boolean',
    default: false,
    category: 'security',
    description: 'Use fingerprint/face ID for authentication',
  },
  
  // Notification settings
  friendRequests: {
    type: 'boolean',
    default: false,
    category: 'notifications',
    description: 'Notify when new friends add you',
  },
  messagePreviews: {
    type: 'boolean',
    default: false,
    category: 'notifications',
    description: 'Show message content in notifications',
  },
  tradeAlerts: {
    type: 'boolean',
    default: false,
    category: 'notifications',
    description: 'Notifications for trading activities',
  },
  priceAlerts: {
    type: 'boolean',
    default: false,
    category: 'notifications',
    description: 'Notify when price targets are hit',
  },
  
  // Trading settings
  confirmTrades: {
    type: 'boolean',
    default: false,
    category: 'trading',
    description: 'Manual confirmation before trade execution',
  },
  portfolioSize: {
    type: 'number',
    default: 50,
    category: 'trading',
    description: 'Portfolio size percentage (1-100)',
    min: 1,
    max: 100,
  },
  riskManagement: {
    type: 'boolean',
    default: false,
    category: 'trading',
    description: 'Enable automatic risk management',
  },
  autoTrading: {
    type: 'boolean',
    default: false,
    category: 'trading',
    description: 'Enable automated trading',
  },
  stopLoss: {
    type: 'boolean',
    default: false,
    category: 'trading',
    description: 'Automatic stop loss protection',
  },
} as const;

export type SettingsKey = keyof typeof SETTINGS_CONFIG;
export type SettingsCategory = 'security' | 'notifications' | 'trading';

export const getSettingsByCategory = (category: SettingsCategory) => {
  return Object.entries(SETTINGS_CONFIG)
    .filter(([_, config]) => config.category === category)
    .reduce((acc, [key, config]) => {
      acc[key] = config;
      return acc;
    }, {} as Record<string, any>);
};

// Trade execution utilities
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

export const formatCrypto = (amount: number, symbol: string): string => {
  return `${amount.toFixed(8)} ${symbol}`;
};

// Mock trading functions for demo
export const mockTrade = {
  buy: (pair: string, amount: number, price: number) => 
    executeTrade({ pair, amount, price, side: 'buy', exchange: 'binance', orderType: 'market' }),
  sell: (pair: string, amount: number, price: number) => 
    executeTrade({ pair, amount, price, side: 'sell', exchange: 'binance', orderType: 'market' }),
};
import marketService from './marketService';
import signalService from './signalService';
import tradingService from './tradingService';
import realTimeService from './realTimeService';
import { EventEmitter } from 'events';

interface DashboardState {
  isInitialized: boolean;
  connectionStatus: {
    market: boolean;
    signals: boolean;
    trading: boolean;
    realtime: boolean;
  };
  lastUpdate: number;
  errors: string[];
}

interface DashboardConfig {
  defaultSymbols: string[];
  autoRefreshInterval: number;
  maxRetries: number;
  enableRealTime: boolean;
  enableTrading: boolean;
}

class DashboardService extends EventEmitter {
  private state: DashboardState = {
    isInitialized: false,
    connectionStatus: {
      market: false,
      signals: false,
      trading: false,
      realtime: false
    },
    lastUpdate: 0,
    errors: []
  };

  private config: DashboardConfig = {
    defaultSymbols: ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT'],
    autoRefreshInterval: 30000, // 30 seconds
    maxRetries: 3,
    enableRealTime: true,
    enableTrading: true
  };

  private refreshInterval: NodeJS.Timeout | null = null;
  private retryCount = 0;

  constructor() {
    super();
    this.setMaxListeners(50);
  }

  // Initialize the entire dashboard
  async initialize(customConfig?: Partial<DashboardConfig>): Promise<void> {
    try {
      // Merge custom config
      this.config = { ...this.config, ...customConfig };
      
      console.log('🚀 Initializing AI Smart Trader Dashboard...');
      this.emit('initializationStarted');

      // Initialize services in parallel
      const initPromises = [
        this.initializeMarketService(),
        this.initializeSignalService(),
        this.initializeTradingService(),
        this.config.enableRealTime ? this.initializeRealTimeService() : Promise.resolve()
      ];

      await Promise.allSettled(initPromises);

      // Check if critical services are working
      const criticalServicesOk = this.state.connectionStatus.market || this.state.connectionStatus.signals;
      
      if (criticalServicesOk) {
        this.state.isInitialized = true;
        this.state.lastUpdate = Date.now();
        this.startAutoRefresh();
        
        console.log('✅ Dashboard initialized successfully');
        this.emit('initialized', this.state);
      } else {
        throw new Error('Failed to initialize critical services');
      }

    } catch (error) {
      console.error('❌ Dashboard initialization failed:', error);
      this.handleInitializationError(error);
    }
  }

  private async initializeMarketService(): Promise<void> {
    try {
      console.log('📊 Initializing market data service...');
      
      // Initialize market connections
      await marketService.initializeConnections();
      
      // Test market data fetch
      const tickers = await marketService.getTickers();
      
      if (tickers.length > 0) {
        this.state.connectionStatus.market = true;
        console.log(`✅ Market service initialized with ${tickers.length} symbols`);
      } else {
        throw new Error('No market data available');
      }
      
    } catch (error) {
      console.error('❌ Market service initialization failed:', error);
      this.state.errors.push(`Market service: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async initializeSignalService(): Promise<void> {
    try {
      console.log('🤖 Initializing AI signal service...');
      
      // Generate initial signals
      const signals = await signalService.getLiveSignals(this.config.defaultSymbols);
      
      if (signals.length >= 0) { // Allow empty signals array
        this.state.connectionStatus.signals = true;
        console.log(`✅ Signal service initialized with ${signals.length} active signals`);
      }
      
    } catch (error) {
      console.error('❌ Signal service initialization failed:', error);
      this.state.errors.push(`Signal service: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async initializeTradingService(): Promise<void> {
    if (!this.config.enableTrading) {
      console.log('⚠️ Trading service disabled by configuration');
      return;
    }

    try {
      console.log('💰 Initializing trading service...');
      
      // Test trading service connectivity
      const portfolio = await tradingService.getPortfolio();
      const riskMetrics = await tradingService.getRiskMetrics();
      
      if (portfolio && riskMetrics) {
        this.state.connectionStatus.trading = true;
        console.log('✅ Trading service initialized successfully');
      }
      
    } catch (error) {
      console.error('❌ Trading service initialization failed:', error);
      this.state.errors.push(`Trading service: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async initializeRealTimeService(): Promise<void> {
    try {
      console.log('⚡ Initializing real-time data service...');
      
      // Initialize real-time connections
      await realTimeService.initializeAll(this.config.defaultSymbols);
      
      // Set up event listeners
      realTimeService.on('initialized', (status) => {
        this.state.connectionStatus.realtime = status.connectedServices.length > 0;
        console.log(`✅ Real-time service initialized with ${status.connectedServices.length} connections`);
      });

      realTimeService.on('error', (error) => {
        console.error('Real-time service error:', error);
        this.emit('serviceError', { service: 'realtime', error });
      });
      
    } catch (error) {
      console.error('❌ Real-time service initialization failed:', error);
      this.state.errors.push(`Real-time service: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private handleInitializationError(error: any): void {
    this.retryCount++;
    
    if (this.retryCount < this.config.maxRetries) {
      console.log(`🔄 Retrying initialization (${this.retryCount}/${this.config.maxRetries})...`);
      setTimeout(() => this.initialize(), 5000 * this.retryCount); // Exponential backoff
    } else {
      console.error('❌ Maximum retry attempts reached. Dashboard initialization failed.');
      this.emit('initializationFailed', { error, retryCount: this.retryCount });
    }
  }

  private startAutoRefresh(): void {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }

    this.refreshInterval = setInterval(async () => {
      try {
        await this.refreshData();
      } catch (error) {
        console.error('Auto-refresh failed:', error);
        this.emit('refreshError', error);
      }
    }, this.config.autoRefreshInterval);

    console.log(`🔄 Auto-refresh started (${this.config.autoRefreshInterval / 1000}s interval)`);
  }

  private async refreshData(): Promise<void> {
    const refreshPromises = [];

    // Refresh market data if connected
    if (this.state.connectionStatus.market) {
      refreshPromises.push(
        marketService.getTickers().catch(error => 
          console.warn('Market data refresh failed:', error)
        )
      );
    }

    // Refresh signals if connected
    if (this.state.connectionStatus.signals) {
      refreshPromises.push(
        signalService.getLiveSignals(this.config.defaultSymbols).catch(error => 
          console.warn('Signals refresh failed:', error)
        )
      );
    }

    // Refresh trading data if connected
    if (this.state.connectionStatus.trading) {
      refreshPromises.push(
        tradingService.getPortfolio().catch(error => 
          console.warn('Portfolio refresh failed:', error)
        )
      );
    }

    await Promise.allSettled(refreshPromises);
    this.state.lastUpdate = Date.now();
    this.emit('dataRefreshed', this.state.lastUpdate);
  }

  // Get current dashboard state
  getState(): DashboardState {
    return { ...this.state };
  }

  // Get service health status
  getHealthStatus(): Record<string, any> {
    const health = {
      overall: this.state.isInitialized ? 'healthy' : 'unhealthy',
      services: {
        market: {
          status: this.state.connectionStatus.market ? 'connected' : 'disconnected',
          lastUpdate: this.state.lastUpdate
        },
        signals: {
          status: this.state.connectionStatus.signals ? 'connected' : 'disconnected',
          lastUpdate: this.state.lastUpdate
        },
        trading: {
          status: this.state.connectionStatus.trading ? 'connected' : 'disconnected',
          enabled: this.config.enableTrading
        },
        realtime: {
          status: this.state.connectionStatus.realtime ? 'connected' : 'disconnected',
          enabled: this.config.enableRealTime,
          details: this.config.enableRealTime ? realTimeService.healthCheck() : null
        }
      },
      errors: this.state.errors,
      uptime: this.state.isInitialized ? Date.now() - this.state.lastUpdate : 0
    };

    return health;
  }

  // Update configuration
  updateConfig(newConfig: Partial<DashboardConfig>): void {
    this.config = { ...this.config, ...newConfig };
    this.emit('configUpdated', this.config);
    
    // Restart auto-refresh if interval changed
    if (newConfig.autoRefreshInterval && this.state.isInitialized) {
      this.startAutoRefresh();
    }
  }

  // Manual refresh trigger
  async refresh(): Promise<void> {
    console.log('🔄 Manual refresh triggered');
    await this.refreshData();
  }

  // Emergency shutdown
  async shutdown(): Promise<void> {
    console.log('🛑 Shutting down dashboard services...');
    
    // Stop auto-refresh
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
      this.refreshInterval = null;
    }

    // Disconnect services
    const shutdownPromises = [
      realTimeService.disconnectAll(),
      marketService.disconnect(),
      // Trading service doesn't need explicit disconnect
    ];

    await Promise.allSettled(shutdownPromises);
    
    this.state.isInitialized = false;
    this.state.connectionStatus = {
      market: false,
      signals: false,
      trading: false,
      realtime: false
    };

    console.log('✅ Dashboard shutdown complete');
    this.emit('shutdown');
  }

  // Get performance metrics
  getPerformanceMetrics(): Record<string, any> {
    return {
      initializationTime: this.state.lastUpdate,
      uptime: this.state.isInitialized ? Date.now() - this.state.lastUpdate : 0,
      errorCount: this.state.errors.length,
      retryCount: this.retryCount,
      servicesConnected: Object.values(this.state.connectionStatus).filter(Boolean).length,
      lastRefresh: this.state.lastUpdate,
      refreshInterval: this.config.autoRefreshInterval
    };
  }

  // Subscribe to specific events
  onInitialized(callback: (state: DashboardState) => void): () => void {
    this.on('initialized', callback);
    return () => this.off('initialized', callback);
  }

  onDataRefreshed(callback: (timestamp: number) => void): () => void {
    this.on('dataRefreshed', callback);
    return () => this.off('dataRefreshed', callback);
  }

  onServiceError(callback: (error: any) => void): () => void {
    this.on('serviceError', callback);
    return () => this.off('serviceError', callback);
  }
}

// Create singleton instance
export const dashboardService = new DashboardService();

// Export types
export type { DashboardState, DashboardConfig };

export default dashboardService;
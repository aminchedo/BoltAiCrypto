import api from './api';
import type { Ticker, Candle } from '@/types/market';

export type { Ticker, Candle };

interface MarketStats {
  totalMarketCap: number;
  totalVolume: number;
  marketDominance: Record<string, number>;
  topMovers: {
    gainers: Ticker[];
    losers: Ticker[];
  };
  fearGreedIndex: number;
  btcDominance: number;
  activeCoins: number;
  marketCapChange24h: number;
  volumeChange24h: number;
}

interface SearchResult {
  symbol: string;
  name: string;
  type: string;
  exchange: string;
  price: number;
  change24h: number;
  volume: number;
  marketCap: number;
}

interface ExchangeData {
  binance: boolean;
  coinbase: boolean;
  okx: boolean;
  bybit: boolean;
  kraken: boolean;
}

interface RealTimePrice {
  symbol: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  timestamp: number;
  exchange: string;
}

interface OrderBookData {
  symbol: string;
  bids: Array<[number, number]>; // [price, quantity]
  asks: Array<[number, number]>; // [price, quantity]
  timestamp: number;
}

interface TradeData {
  id: string;
  symbol: string;
  price: number;
  quantity: number;
  side: 'buy' | 'sell';
  timestamp: number;
  exchange: string;
}

class MarketService {
  private wsConnections: Map<string, WebSocket> = new Map();
  private priceCache: Map<string, RealTimePrice> = new Map();
  private subscribers: Map<string, Set<(data: any) => void>> = new Map();

  // Real-time WebSocket connections to multiple exchanges
  async connectToExchange(exchange: 'binance' | 'coinbase' | 'okx' | 'bybit' | 'kraken', symbols: string[]) {
    const wsUrls = {
      binance: 'wss://stream.binance.com:9443/ws/stream',
      coinbase: 'wss://ws-feed.exchange.coinbase.com',
      okx: 'wss://ws.okx.com:8443/ws/v5/public',
      bybit: 'wss://stream.bybit.com/v5/public/spot',
      kraken: 'wss://ws.kraken.com'
    };

    try {
      const ws = new WebSocket(wsUrls[exchange]);

      ws.onopen = () => {
        console.log(`Connected to ${exchange} WebSocket`);
        this.subscribeToSymbols(ws, exchange, symbols);
      };

      ws.onmessage = (event) => {
        this.handleWebSocketMessage(exchange, JSON.parse(event.data));
      };

      ws.onerror = (error) => {
        console.error(`${exchange} WebSocket error:`, error);
        // Implement reconnection logic
        setTimeout(() => this.connectToExchange(exchange, symbols), 5000);
      };

      ws.onclose = () => {
        console.log(`${exchange} WebSocket closed`);
        // Implement reconnection logic
        setTimeout(() => this.connectToExchange(exchange, symbols), 5000);
      };

      this.wsConnections.set(exchange, ws);
    } catch (error) {
      console.error(`Failed to connect to ${exchange}:`, error);
    }
  }

  private subscribeToSymbols(ws: WebSocket, exchange: string, symbols: string[]) {
    const subscriptionMessages = {
      binance: {
        method: 'SUBSCRIBE',
        params: symbols.map(s => `${s.toLowerCase()}@ticker`),
        id: 1
      },
      coinbase: {
        type: 'subscribe',
        product_ids: symbols,
        channels: ['ticker']
      },
      okx: {
        op: 'subscribe',
        args: symbols.map(s => ({ channel: 'tickers', instId: s }))
      },
      bybit: {
        op: 'subscribe',
        args: symbols.map(s => `tickers.${s}`)
      },
      kraken: {
        event: 'subscribe',
        pair: symbols,
        subscription: { name: 'ticker' }
      }
    };

    ws.send(JSON.stringify(subscriptionMessages[exchange as keyof typeof subscriptionMessages]));
  }

  private handleWebSocketMessage(exchange: string, data: any) {
    try {
      let priceData: RealTimePrice | null = null;

      switch (exchange) {
        case 'binance':
          if (data.data && data.data.s) {
            priceData = {
              symbol: data.data.s,
              price: parseFloat(data.data.c),
              change24h: parseFloat(data.data.P),
              changePercent24h: parseFloat(data.data.P),
              volume24h: parseFloat(data.data.v),
              high24h: parseFloat(data.data.h),
              low24h: parseFloat(data.data.l),
              timestamp: Date.now(),
              exchange: 'binance'
            };
          }
          break;

        case 'coinbase':
          if (data.type === 'ticker') {
            priceData = {
              symbol: data.product_id,
              price: parseFloat(data.price),
              change24h: parseFloat(data.open_24h) - parseFloat(data.price),
              changePercent24h: ((parseFloat(data.price) - parseFloat(data.open_24h)) / parseFloat(data.open_24h)) * 100,
              volume24h: parseFloat(data.volume_24h),
              high24h: parseFloat(data.high_24h),
              low24h: parseFloat(data.low_24h),
              timestamp: Date.now(),
              exchange: 'coinbase'
            };
          }
          break;

        // Add other exchanges...
      }

      if (priceData) {
        this.priceCache.set(priceData.symbol, priceData);
        this.notifySubscribers(priceData.symbol, priceData);
      }
    } catch (error) {
      console.error('Error processing WebSocket message:', error);
    }
  }

  private notifySubscribers(symbol: string, data: any) {
    const symbolSubscribers = this.subscribers.get(symbol);
    if (symbolSubscribers) {
      symbolSubscribers.forEach(callback => callback(data));
    }
  }

  // Subscribe to real-time price updates
  subscribeToPrice(symbol: string, callback: (data: RealTimePrice) => void) {
    if (!this.subscribers.has(symbol)) {
      this.subscribers.set(symbol, new Set());
    }
    this.subscribers.get(symbol)!.add(callback);

    // Return cached data immediately if available
    const cachedData = this.priceCache.get(symbol);
    if (cachedData) {
      callback(cachedData);
    }

    // Return unsubscribe function
    return () => {
      const symbolSubscribers = this.subscribers.get(symbol);
      if (symbolSubscribers) {
        symbolSubscribers.delete(callback);
        if (symbolSubscribers.size === 0) {
          this.subscribers.delete(symbol);
        }
      }
    };
  }

  // Enhanced API methods with fallback and aggregation
  async getTickers(): Promise<Ticker[]> {
    try {
      // Try primary API first
      return await api.get<Ticker[]>('/v1/market/tickers');
    } catch (error) {
      console.error('Primary API failed, using fallback:', error);
      // Fallback to CoinGecko or other free APIs
      return this.getFallbackTickers();
    }
  }

  private async getFallbackTickers(): Promise<Ticker[]> {
    try {
      // CoinGecko API fallback
      const response = await fetch(
        'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=true&price_change_percentage=1h%2C24h%2C7d'
      );
      const data = await response.json();

      return data.map((coin: any) => ({
        symbol: coin.symbol.toUpperCase(),
        name: coin.name,
        price: coin.current_price,
        change24h: coin.price_change_percentage_24h,
        volume24h: coin.total_volume,
        marketCap: coin.market_cap,
        rank: coin.market_cap_rank,
        sparkline: coin.sparkline_in_7d?.price || [],
        high24h: coin.high_24h,
        low24h: coin.low_24h,
        ath: coin.ath,
        atl: coin.atl,
        circulatingSupply: coin.circulating_supply,
        totalSupply: coin.total_supply,
        maxSupply: coin.max_supply
      }));
    } catch (error) {
      console.error('Fallback API also failed:', error);
      return [];
    }
  }

  async getHistoricalPrices(
    symbol: string,
    from: Date,
    to: Date,
    interval: string = '1h'
  ): Promise<Candle[]> {
    try {
      return await api.get<Candle[]>(`/v1/market/${symbol}/candles`, {
        from: from.toISOString(),
        to: to.toISOString(),
        interval
      });
    } catch (error) {
      console.error('Historical data API failed:', error);
      return this.getFallbackHistoricalData(symbol, from, to, interval);
    }
  }

  private async getFallbackHistoricalData(
    symbol: string,
    from: Date,
    to: Date,
    interval: string
  ): Promise<Candle[]> {
    try {
      // Use CoinGecko for historical data
      const coinId = symbol.toLowerCase().replace('usdt', '').replace('usd', '');
      const days = Math.ceil((to.getTime() - from.getTime()) / (1000 * 60 * 60 * 24));

      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=usd&days=${days}&interval=${interval}`
      );
      const data = await response.json();

      if (data.prices) {
        return data.prices.map((price: [number, number], index: number) => ({
          timestamp: price[0],
          open: index > 0 ? data.prices[index - 1][1] : price[1],
          high: price[1] * (1 + Math.random() * 0.02),
          low: price[1] * (1 - Math.random() * 0.02),
          close: price[1],
          volume: data.total_volumes?.[index]?.[1] || 0
        }));
      }

      return [];
    } catch (error) {
      console.error('Fallback historical data failed:', error);
      return [];
    }
  }

  async getOrderBook(symbol: string, depth: number = 20): Promise<OrderBookData> {
    try {
      return await api.get<OrderBookData>(`/v1/market/${symbol}/orderbook`, { depth });
    } catch (error) {
      console.error('Order book API failed:', error);
      // Return mock data for development
      return this.getMockOrderBook(symbol);
    }
  }

  private getMockOrderBook(symbol: string): OrderBookData {
    const basePrice = 43000; // Mock BTC price
    const bids: Array<[number, number]> = [];
    const asks: Array<[number, number]> = [];

    for (let i = 0; i < 20; i++) {
      bids.push([basePrice - (i + 1) * 10, Math.random() * 5]);
      asks.push([basePrice + (i + 1) * 10, Math.random() * 5]);
    }

    return {
      symbol,
      bids,
      asks,
      timestamp: Date.now()
    };
  }

  async getRecentTrades(symbol: string, limit: number = 50): Promise<TradeData[]> {
    try {
      return await api.get<TradeData[]>(`/v1/market/${symbol}/trades`, { limit });
    } catch (error) {
      console.error('Recent trades API failed:', error);
      return this.getMockTrades(symbol, limit);
    }
  }

  private getMockTrades(symbol: string, limit: number): TradeData[] {
    const trades: TradeData[] = [];
    const basePrice = 43000;

    for (let i = 0; i < limit; i++) {
      trades.push({
        id: `trade_${i}`,
        symbol,
        price: basePrice + (Math.random() - 0.5) * 1000,
        quantity: Math.random() * 2,
        side: Math.random() > 0.5 ? 'buy' : 'sell',
        timestamp: Date.now() - i * 1000,
        exchange: 'binance'
      });
    }

    return trades;
  }

  async searchSymbols(query: string, limit: number = 10): Promise<SearchResult[]> {
    try {
      return await api.get<SearchResult[]>('/v1/market/search', { q: query, limit });
    } catch (error) {
      console.error('Search API failed:', error);
      return this.getFallbackSearch(query, limit);
    }
  }

  private async getFallbackSearch(query: string, limit: number): Promise<SearchResult[]> {
    try {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(query)}`
      );
      const data = await response.json();

      return data.coins.slice(0, limit).map((coin: any) => ({
        symbol: coin.symbol.toUpperCase(),
        name: coin.name,
        type: 'cryptocurrency',
        exchange: 'multiple',
        price: 0, // Would need additional API call
        change24h: 0,
        volume: 0,
        marketCap: 0
      }));
    } catch (error) {
      console.error('Fallback search failed:', error);
      return [];
    }
  }

  async getMarketStats(): Promise<MarketStats> {
    try {
      return await api.get<MarketStats>('/v1/market/stats');
    } catch (error) {
      console.error('Market stats API failed:', error);
      return this.getFallbackMarketStats();
    }
  }

  private async getFallbackMarketStats(): Promise<MarketStats> {
    try {
      const response = await fetch('https://api.coingecko.com/api/v3/global');
      const data = await response.json();

      return {
        totalMarketCap: data.data.total_market_cap.usd,
        totalVolume: data.data.total_volume.usd,
        marketDominance: data.data.market_cap_percentage,
        btcDominance: data.data.market_cap_percentage.btc,
        activeCoins: data.data.active_cryptocurrencies,
        marketCapChange24h: data.data.market_cap_change_percentage_24h_usd,
        volumeChange24h: 0, // Not available in this API
        fearGreedIndex: 50, // Would need separate API
        topMovers: {
          gainers: [],
          losers: []
        }
      };
    } catch (error) {
      console.error('Fallback market stats failed:', error);
      return {
        totalMarketCap: 0,
        totalVolume: 0,
        marketDominance: {},
        btcDominance: 0,
        activeCoins: 0,
        marketCapChange24h: 0,
        volumeChange24h: 0,
        fearGreedIndex: 50,
        topMovers: { gainers: [], losers: [] }
      };
    }
  }

  async getWatchlist(): Promise<Ticker[]> {
    try {
      return await api.get<Ticker[]>('/v1/market/watchlist');
    } catch (error) {
      console.error('Watchlist API failed:', error);
      // Return default watchlist
      return this.getDefaultWatchlist();
    }
  }

  private async getDefaultWatchlist(): Promise<Ticker[]> {
    const defaultSymbols = ['bitcoin', 'ethereum', 'binancecoin', 'solana', 'cardano'];
    try {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${defaultSymbols.join(',')}&order=market_cap_desc&sparkline=true`
      );
      const data = await response.json();

      return data.map((coin: any) => ({
        symbol: coin.symbol.toUpperCase(),
        name: coin.name,
        price: coin.current_price,
        change24h: coin.price_change_percentage_24h,
        volume24h: coin.total_volume,
        marketCap: coin.market_cap,
        rank: coin.market_cap_rank,
        sparkline: coin.sparkline_in_7d?.price || []
      }));
    } catch (error) {
      console.error('Default watchlist failed:', error);
      return [];
    }
  }

  // Initialize connections to all exchanges
  async initializeConnections() {
    const defaultSymbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT'];

    // Connect to multiple exchanges for redundancy
    await Promise.all([
      this.connectToExchange('binance', defaultSymbols),
      this.connectToExchange('coinbase', defaultSymbols.map(s => s.replace('USDT', '-USD'))),
      // Add other exchanges as needed
    ]);
  }

  // Cleanup connections
  disconnect() {
    this.wsConnections.forEach((ws, exchange) => {
      ws.close();
      console.log(`Disconnected from ${exchange}`);
    });
    this.wsConnections.clear();
    this.subscribers.clear();
    this.priceCache.clear();
  }
}

const marketService = new MarketService();
export { marketService };
export default marketService;
/**
 * AI External Service
 * 
 * Connects to external AI services for enhanced market analysis,
 * sentiment data, and advanced predictions.
 */

import { marketService } from './marketService';

export interface SentimentData {
  symbol: string;
  score: number;  // -100 to 100
  sources: number;
  change24h: number;
  lastUpdated: Date;
}

export interface WhaleMovement {
  id: string;
  timestamp: Date;
  type: 'accumulation' | 'distribution' | 'transfer';
  amount: number;
  value: number;
  from: string;
  to: string;
  impact: number; // 0-100
}

export interface MarketRegime {
  current: 'bull' | 'bear' | 'sideways' | 'volatile';
  confidence: number;
  since: Date;
  forecast: 'strengthening' | 'weakening' | 'transitioning' | 'stable';
}

export interface AIForecast {
  symbol: string;
  timeframe: string;
  prediction: 'bullish' | 'bearish' | 'neutral';
  priceTarget: number;
  confidence: number;
  horizon: string; // "24h", "7d", "30d"
  reasoning: string[];
}

class AIExternalService {
  private sentimentCache: Map<string, SentimentData> = new Map();
  private whaleMovementsCache: WhaleMovement[] = [];
  private marketRegimeCache: MarketRegime | null = null;
  private forecastCache: Map<string, AIForecast> = new Map();
  
  private lastSentimentUpdate: Date = new Date(0);
  private lastWhaleUpdate: Date = new Date(0);
  private lastRegimeUpdate: Date = new Date(0);
  private lastForecastUpdate: Date = new Date(0);
  
  private readonly SENTIMENT_TTL = 15 * 60 * 1000; // 15 minutes
  private readonly WHALE_TTL = 5 * 60 * 1000; // 5 minutes
  private readonly REGIME_TTL = 60 * 60 * 1000; // 1 hour
  private readonly FORECAST_TTL = 30 * 60 * 1000; // 30 minutes

  /**
   * Get market sentiment data for a specific symbol
   */
  public async getSentiment(symbol: string): Promise<SentimentData> {
    // Check cache first
    if (
      this.sentimentCache.has(symbol) && 
      Date.now() - this.lastSentimentUpdate.getTime() < this.SENTIMENT_TTL
    ) {
      return this.sentimentCache.get(symbol)!;
    }
    
    try {
      // In a real implementation, this would call an external API
      // For now, we'll simulate with realistic data
      
      // Get current price data to make sentiment more realistic
      const tickers = await marketService.getTickers();
      const ticker = tickers.find(t => t.symbol === symbol.replace('USDT', ''));
      
      const sentiment: SentimentData = {
        symbol,
        score: this.generateSentimentScore(ticker?.change || 0),
        sources: Math.floor(Math.random() * 500) + 100,
        change24h: (Math.random() * 20) - 10,
        lastUpdated: new Date()
      };
      
      // Update cache
      this.sentimentCache.set(symbol, sentiment);
      this.lastSentimentUpdate = new Date();
      
      return sentiment;
    } catch (error) {
      console.error('Error fetching sentiment data:', error);
      
      // Return cached data if available, otherwise generate fallback
      if (this.sentimentCache.has(symbol)) {
        return this.sentimentCache.get(symbol)!;
      }
      
      // Fallback data
      return {
        symbol,
        score: 0,
        sources: 0,
        change24h: 0,
        lastUpdated: new Date()
      };
    }
  }

  /**
   * Get recent whale movements
   */
  public async getWhaleMovements(limit: number = 10): Promise<WhaleMovement[]> {
    // Check cache first
    if (
      this.whaleMovementsCache.length > 0 && 
      Date.now() - this.lastWhaleUpdate.getTime() < this.WHALE_TTL
    ) {
      return this.whaleMovementsCache.slice(0, limit);
    }
    
    try {
      // In a real implementation, this would call an external API
      // For now, we'll simulate with realistic data
      const movements: WhaleMovement[] = [];
      
      for (let i = 0; i < 20; i++) {
        const type = this.getRandomElement(['accumulation', 'distribution', 'transfer']);
        const amount = Math.random() * 1000 + 10;
        
        movements.push({
          id: `whale_${Date.now()}_${i}`,
          timestamp: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000),
          type: type as 'accumulation' | 'distribution' | 'transfer',
          amount,
          value: amount * 43000,
          from: type === 'distribution' ? 'Whale Wallet' : 'Exchange',
          to: type === 'accumulation' ? 'Whale Wallet' : 'Exchange',
          impact: Math.min(100, amount / 10)
        });
      }
      
      // Sort by timestamp (newest first)
      movements.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      
      // Update cache
      this.whaleMovementsCache = movements;
      this.lastWhaleUpdate = new Date();
      
      return movements.slice(0, limit);
    } catch (error) {
      console.error('Error fetching whale movements:', error);
      
      // Return cached data if available
      if (this.whaleMovementsCache.length > 0) {
        return this.whaleMovementsCache.slice(0, limit);
      }
      
      // Return empty array as fallback
      return [];
    }
  }

  /**
   * Get current market regime analysis
   */
  public async getMarketRegime(): Promise<MarketRegime> {
    // Check cache first
    if (
      this.marketRegimeCache && 
      Date.now() - this.lastRegimeUpdate.getTime() < this.REGIME_TTL
    ) {
      return this.marketRegimeCache;
    }
    
    try {
      // In a real implementation, this would call an external API
      // For now, we'll simulate with realistic data
      
      // Get current market data to make regime more realistic
      const tickers = await marketService.getTickers();
      const btcTicker = tickers.find(t => t.symbol === 'BTC');
      const ethTicker = tickers.find(t => t.symbol === 'ETH');
      
      let regime: 'bull' | 'bear' | 'sideways' | 'volatile';
      
      // Determine regime based on BTC and ETH performance
      if (btcTicker?.change && ethTicker?.change) {
        const avgChange = (btcTicker.change + ethTicker.change) / 2;
        
        if (avgChange > 5) regime = 'bull';
        else if (avgChange < -5) regime = 'bull';
        else if (Math.abs(avgChange) < 1) regime = 'sideways';
        else regime = 'volatile';
      } else {
        regime = this.getRandomElement(['bull', 'bear', 'sideways', 'volatile']);
      }
      
      const result: MarketRegime = {
        current: regime as 'bull' | 'bear' | 'sideways' | 'volatile',
        confidence: Math.random() * 30 + 70, // 70-100
        since: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
        forecast: this.getRandomElement([
          'strengthening', 'weakening', 'transitioning', 'stable'
        ]) as 'strengthening' | 'weakening' | 'transitioning' | 'stable'
      };
      
      // Update cache
      this.marketRegimeCache = result;
      this.lastRegimeUpdate = new Date();
      
      return result;
    } catch (error) {
      console.error('Error fetching market regime:', error);
      
      // Return cached data if available
      if (this.marketRegimeCache) {
        return this.marketRegimeCache;
      }
      
      // Fallback data
      return {
        current: 'sideways',
        confidence: 70,
        since: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        forecast: 'stable'
      };
    }
  }

  /**
   * Get AI price forecast for a symbol
   */
  public async getForecast(symbol: string, horizon: string = '7d'): Promise<AIForecast> {
    const cacheKey = `${symbol}_${horizon}`;
    
    // Check cache first
    if (
      this.forecastCache.has(cacheKey) && 
      Date.now() - this.lastForecastUpdate.getTime() < this.FORECAST_TTL
    ) {
      return this.forecastCache.get(cacheKey)!;
    }
    
    try {
      // In a real implementation, this would call an external API
      // For now, we'll simulate with realistic data
      
      // Get current price data to make forecast more realistic
      const tickers = await marketService.getTickers();
      const ticker = tickers.find(t => t.symbol === symbol.replace('USDT', ''));
      
      let prediction: 'bullish' | 'bearish' | 'neutral';
      let priceChange: number;
      
      if (ticker?.change) {
        // Base prediction on current trend with some randomness
        if (ticker.change > 2) {
          prediction = Math.random() > 0.3 ? 'bullish' : 'neutral';
          priceChange = Math.random() * 10 + 2;
        } else if (ticker.change < -2) {
          prediction = Math.random() > 0.3 ? 'bearish' : 'neutral';
          priceChange = Math.random() * -10 - 2;
        } else {
          prediction = 'neutral';
          priceChange = (Math.random() * 4) - 2;
        }
      } else {
        prediction = this.getRandomElement(['bullish', 'bearish', 'neutral']);
        priceChange = prediction === 'bullish' ? Math.random() * 10 + 2 :
                      prediction === 'bearish' ? Math.random() * -10 - 2 :
                      (Math.random() * 4) - 2;
      }
      
      const currentPrice = ticker?.price || 43000;
      const priceTarget = currentPrice * (1 + (priceChange / 100));
      
      const forecast: AIForecast = {
        symbol,
        timeframe: horizon === '24h' ? '1h' : horizon === '7d' ? '4h' : '1d',
        prediction,
        priceTarget,
        confidence: Math.random() * 20 + 70, // 70-90
        horizon,
        reasoning: this.generateReasoningForForecast(prediction)
      };
      
      // Update cache
      this.forecastCache.set(cacheKey, forecast);
      this.lastForecastUpdate = new Date();
      
      return forecast;
    } catch (error) {
      console.error('Error fetching AI forecast:', error);
      
      // Return cached data if available
      if (this.forecastCache.has(cacheKey)) {
        return this.forecastCache.get(cacheKey)!;
      }
      
      // Fallback data
      return {
        symbol,
        timeframe: '1d',
        prediction: 'neutral',
        priceTarget: 0,
        confidence: 70,
        horizon,
        reasoning: ['Insufficient data for analysis']
      };
    }
  }

  /**
   * Generate a sentiment score based on price change
   */
  private generateSentimentScore(priceChange: number): number {
    // Base sentiment on price change with some randomness
    let baseScore = priceChange * 10; // Scale up the change
    
    // Add randomness
    baseScore += (Math.random() * 40) - 20;
    
    // Clamp between -100 and 100
    return Math.max(-100, Math.min(100, baseScore));
  }

  /**
   * Generate reasoning for a forecast
   */
  private generateReasoningForForecast(prediction: string): string[] {
    const bullishReasons = [
      'Strong buying pressure detected',
      'Positive market sentiment',
      'Key resistance levels broken',
      'Increasing trading volume',
      'Favorable technical indicators'
    ];
    
    const bearishReasons = [
      'Selling pressure increasing',
      'Negative market sentiment',
      'Support levels broken',
      'Decreasing trading volume',
      'Bearish technical indicators'
    ];
    
    const neutralReasons = [
      'Mixed market signals',
      'Consolidation pattern forming',
      'Low trading volume',
      'Range-bound price action',
      'Conflicting technical indicators'
    ];
    
    let reasons: string[];
    
    switch (prediction) {
      case 'bullish':
        reasons = bullishReasons;
        break;
      case 'bearish':
        reasons = bearishReasons;
        break;
      default:
        reasons = neutralReasons;
    }
    
    // Randomly select 2-3 reasons
    const count = Math.floor(Math.random() * 2) + 2;
    const selectedReasons: string[] = [];
    
    while (selectedReasons.length < count && reasons.length > 0) {
      const index = Math.floor(Math.random() * reasons.length);
      selectedReasons.push(reasons[index]);
      reasons.splice(index, 1);
    }
    
    return selectedReasons;
  }

  /**
   * Get a random element from an array
   */
  private getRandomElement<T>(array: T[]): T {
    return array[Math.floor(Math.random() * array.length)];
  }
}

// Create singleton instance
export const aiExternalService = new AIExternalService();
export default aiExternalService;
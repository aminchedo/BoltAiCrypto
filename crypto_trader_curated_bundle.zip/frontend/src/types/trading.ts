// Trading-related type definitions

export interface Portfolio {
  id?: string;
  totalValue: number;
  availableBalance: number;
  lockedBalance: number;
  usedMargin: number;
  freeMargin: number;
  marginLevel: number;
  positions: Position[];
  dailyPnl: number;
  totalPnl: number;
  equity: number;
  cash: number;
  lastUpdate: string;
  pnl: {
    total: number;
    realized: number;
    unrealized: number;
  };
  performance: {
    daily: number;
    weekly: number;
    monthly: number;
    allTime: number;
  };
  assets: Array<{
    asset: string;
    free: number;
    locked: number;
    total: number;
    btcValue: number;
    usdValue: number;
  }>;
}

export interface Position {
  id: string;
  symbol: string;
  exchange: string;
  side: 'LONG' | 'SHORT';
  type: 'LONG' | 'SHORT';
  size: number;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
  realizedPnl: number;
  pnl: number;
  pnlPercentage: number;
  percentage: number;
  margin: number;
  leverage: number;
  liquidationPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  timestamp: number;
  openedAt: string;
}

export interface Order {
  id: string;
  symbol: string;
  exchange: string;
  side: 'BUY' | 'SELL';
  type: 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'TAKE_PROFIT' | 'OCO' | 'ICEBERG';
  quantity: number;
  price?: number;
  stopPrice?: number;
  timeInForce: 'GTC' | 'IOC' | 'FOK';
  status: 'NEW' | 'FILLED' | 'PARTIALLY_FILLED' | 'CANCELLED' | 'REJECTED' | 'EXPIRED';
  executedQuantity: number;
  executedPrice?: number;
  commission: number;
  commissionAsset: string;
  timestamp: number;
  updateTime: number;
  createdAt: string;
  updatedAt: string;
  clientOrderId?: string;
}

export interface OrderRequest {
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'OCO' | 'ICEBERG';
  quantity: number;
  price?: number;
  stopPrice?: number;
  timeInForce?: 'GTC' | 'IOC' | 'FOK';
  exchange?: string;
  clientOrderId?: string;
  icebergQty?: number;
  stopLimitPrice?: number;
  stopLimitTimeInForce?: 'GTC' | 'IOC' | 'FOK';
}

export interface Exchange {
  id: string;
  name: string;
  isConnected: boolean;
  lastSynced?: string;
  apiKeyConfigured: boolean;
}

export interface ExchangeConfig {
  name: string;
  apiKey: string;
  secretKey: string;
  testnet: boolean;
  enabled: boolean;
  tradingFees: {
    maker: number;
    taker: number;
  };
  limits: {
    minOrderSize: number;
    maxOrderSize: number;
    minPrice: number;
    maxPrice: number;
  };
}

export interface TradeExecution {
  orderId: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  commission: number;
  commissionAsset: string;
  timestamp: number;
  isMaker: boolean;
  exchange: string;
}

export interface RiskMetrics {
  portfolioRisk: number;
  valueAtRisk: number;
  maxDrawdown: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  winRate: number;
  profitFactor: number;
  averageWin: number;
  averageLoss: number;
  largestWin: number;
  largestLoss: number;
  consecutiveWins: number;
  consecutiveLosses: number;
  totalTrades: number;
  correlation: Record<string, number>;
}

export interface TradeRequest {
  pair: string;
  amount: number;
  price: number;
  side: 'buy' | 'sell';
  exchange: string;
  orderType: 'market' | 'limit';
}

export interface TradeResult {
  status: 'success' | 'cancelled' | 'error';
  message?: string;
  orderId?: string;
  data?: any;
}

export interface TradeConfirmationData {
  title: string;
  details: string;
  confirmText: string;
  cancelText: string;
  trade: TradeRequest;
}

// Trade Signal Types (Basic - detailed ones in signals.ts)
export interface TradeSignal {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL' | 'HOLD';
  strength: number;
  confidence: number;
  price: number;
  timestamp: string;
  indicators: string[];
  reason: string;
}

// Enums
export enum SignalType {
  BUY = 'BUY',
  SELL = 'SELL',
  HOLD = 'HOLD'
}

export enum PositionType {
  LONG = 'LONG',
  SHORT = 'SHORT'
}

export enum OrderStatus {
  NEW = 'NEW',
  FILLED = 'FILLED',
  PARTIALLY_FILLED = 'PARTIALLY_FILLED',
  CANCELLED = 'CANCELLED',
  REJECTED = 'REJECTED',
  EXPIRED = 'EXPIRED'
}

export enum OrderSide {
  BUY = 'BUY',
  SELL = 'SELL'
}

export enum OrderType {
  MARKET = 'MARKET',
  LIMIT = 'LIMIT',
  STOP = 'STOP',
  STOP_LIMIT = 'STOP_LIMIT',
  TAKE_PROFIT = 'TAKE_PROFIT',
  OCO = 'OCO',
  ICEBERG = 'ICEBERG'
}

export enum TimeInForce {
  GTC = 'GTC', // Good Till Cancelled
  IOC = 'IOC', // Immediate Or Cancel
  FOK = 'FOK'  // Fill Or Kill
}
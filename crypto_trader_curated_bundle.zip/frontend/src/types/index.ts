// Main types index - Re-export all types from organized modules

// Market Types
export * from './market';
export type {
  Ticker,
  Candle,
  MarketData,
  MarketStats,
  SearchResult,
  RealTimePrice,
  OrderBookData,
  TradeData,
  TechnicalIndicators,
  MarketEvent,
  NewsItem,
  WhaleActivity,
  ChartTimeframe,
  TimeFrame,
  SymbolList,
  PriceHistory,
  TickerMap
} from './market';

// Trading Types
export * from './trading';
export type {
  Portfolio,
  Position,
  Order,
  OrderRequest,
  Exchange,
  ExchangeConfig,
  TradeExecution,
  RiskMetrics,
  TradeRequest,
  TradeResult,
  TradeConfirmationData,
  TradeSignal,
  SignalType,
  PositionType,
  OrderStatus,
  OrderSide,
  OrderType,
  TimeInForce
} from './trading';

// Signal Types
export * from './signals';
export type {
  Signal,
  HybridSignal,
  TradingSignal,
  Backtest,
  BacktestTrade,
  SmartMoneyData,
  PatternData,
  SentimentData,
  WhaleData,
  MLPrediction,
  TechnicalIndicator,
  SignalStatus,
  SignalDirection,
  MarketImpact,
  VolumeProfile,
  TrendDirection,
  PatternType
} from './signals';

// Common API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  error?: string;
  timestamp?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

// Specialized API Response Types
export interface MarketApiResponse extends ApiResponse<MarketData> {}
export interface TickerApiResponse extends ApiResponse<Ticker[]> {}
export interface SignalApiResponse extends ApiResponse<Signal[]> {}
export interface PortfolioApiResponse extends ApiResponse<Portfolio> {}
export interface OrderApiResponse extends ApiResponse<Order> {}

// WebSocket Types
export interface WebSocketMessage<T = any> {
  type: string;
  channel?: string;
  data: T;
  timestamp: number;
}

export interface WebSocketSubscription {
  channel: string;
  symbol?: string;
  interval?: string;
}

// Application State Types
export interface AppState {
  theme: Theme;
  user: User | null;
  isLoading: boolean;
  error: string | null;
}

export interface User {
  id: string;
  email: string;
  username: string;
  avatar?: string;
  createdAt: string;
  preferences: UserPreferences;
}

export interface UserPreferences {
  theme: Theme;
  defaultExchange: string;
  notifications: {
    signals: boolean;
    portfolio: boolean;
    news: boolean;
  };
  trading: {
    defaultOrderType: OrderType;
    defaultTimeInForce: TimeInForce;
    confirmOrders: boolean;
  };
}

// UI Types
export type Theme = 'light' | 'dark';

export interface ChartConfig {
  timeframe: ChartTimeframe;
  indicators: string[];
  showVolume: boolean;
  showGrid: boolean;
  theme: Theme;
}

export interface TableColumn<T> {
  key: keyof T;
  title: string;
  sortable?: boolean;
  render?: (value: any, record: T) => React.ReactNode;
}

export interface TableProps<T> {
  data: T[];
  columns: TableColumn<T>[];
  loading?: boolean;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    onChange: (page: number, pageSize: number) => void;
  };
}

// Error Types
export interface AppError {
  code: string;
  message: string;
  details?: any;
  timestamp: string;
}

export interface ValidationError {
  field: string;
  message: string;
  value?: any;
}

// Form Types
export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'checkbox' | 'date';
  required?: boolean;
  options?: Array<{ label: string; value: any }>;
  validation?: (value: any) => string | null;
}

// Notification Types
export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actions?: Array<{
    label: string;
    action: () => void;
  }>;
}

// Utility Types
export type Nullable<T> = T | null;
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

// Event Types
export interface BaseEvent {
  type: string;
  timestamp: number;
  source: string;
}

export interface PriceUpdateEvent extends BaseEvent {
  type: 'PRICE_UPDATE';
  symbol: string;
  price: number;
  change: number;
}

export interface SignalEvent extends BaseEvent {
  type: 'SIGNAL_GENERATED' | 'SIGNAL_EXECUTED' | 'SIGNAL_EXPIRED';
  signal: Signal;
}

export interface PortfolioEvent extends BaseEvent {
  type: 'PORTFOLIO_UPDATE' | 'POSITION_OPENED' | 'POSITION_CLOSED';
  portfolio: Portfolio;
}

export type AppEvent = PriceUpdateEvent | SignalEvent | PortfolioEvent;

// Legacy Types (for backward compatibility)
/** @deprecated Use MarketData from './market' instead */
export type LegacyMarketData = {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
  high24h: number;
  low24h: number;
  lastUpdated: string;
};

// Default Export for Common Types
export default {
  // Enums
  TimeFrame,
  SignalType,
  PositionType,
  OrderStatus,
  OrderSide,
  OrderType,
  TimeInForce,
  SignalStatus,
  SignalDirection,
  MarketImpact,
  VolumeProfile,
  TrendDirection,
  PatternType,
  
  // Common interfaces
  ApiResponse,
  PaginatedResponse,
  WebSocketMessage,
  AppError,
  Notification
};
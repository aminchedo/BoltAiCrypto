// Market-related type definitions

export interface Ticker {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  volume24h: number;
  marketCap: number;
  rank: number;
  high24h: number;
  low24h: number;
  ath: number;
  atl: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply: number;
  sparkline?: number[];
  lastUpdated?: string;
  exchange?: string;
}

export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface MarketData {
  symbol: string;
  ticker: Ticker;
  candles: Candle[];
  indicators?: TechnicalIndicators;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
  high24h: number;
  low24h: number;
  lastUpdated: string;
}

export interface MarketStats {
  totalMarketCap: number;
  totalVolume: number;
  marketDominance: Record<string, number>;
  topMovers: {
    gainers: Ticker[];
    losers: Ticker[];
  };
  fearGreedIndex: number;
  btcDominance: number;
  activeCoins: number;
  marketCapChange24h: number;
  volumeChange24h: number;
}

export interface SearchResult {
  symbol: string;
  name: string;
  type: string;
  exchange: string;
  price: number;
  change24h: number;
  volume: number;
  marketCap: number;
}

export interface RealTimePrice {
  symbol: string;
  price: number;
  change24h: number;
  changePercent24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  timestamp: number;
  exchange: string;
}

export interface OrderBookData {
  symbol: string;
  bids: Array<[number, number]>; // [price, quantity]
  asks: Array<[number, number]>; // [price, quantity]
  timestamp: number;
}

export interface TradeData {
  id: string;
  symbol: string;
  price: number;
  quantity: number;
  side: 'buy' | 'sell';
  timestamp: number;
  exchange: string;
}

export interface TechnicalIndicators {
  rsi: number;
  macd: {
    value: number;
    signal: number;
    histogram: number;
  };
  bollinger: {
    upper: number;
    middle: number;
    lower: number;
  };
  sma20: number;
  sma50: number;
  sma200: number;
  ema12: number;
  ema20: number;
  ema26: number;
  ema50: number;
  stochastic: {
    k: number;
    d: number;
  };
  atr: number;
  volume_sma: number;
}

// Market Event Types
export interface MarketEvent {
  id: string;
  type: 'PRICE_CHANGE' | 'VOLUME_SPIKE' | 'TREND_CHANGE';
  symbol: string;
  data: any;
  timestamp: string;
}

// Time frames
export type ChartTimeframe = '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d' | '1w' | '1M';

export enum TimeFrame {
  '1m' = '1m',
  '5m' = '5m',
  '15m' = '15m',
  '30m' = '30m',
  '1h' = '1h',
  '4h' = '4h',
  '1d' = '1d',
  '1w' = '1w',
  '1M' = '1M'
}

// News and Sentiment
export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  publishedAt: string;
  sentiment: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
  relevance: number;
  relatedAssets: string[];
}

export interface WhaleActivity {
  id: string;
  timestamp: string;
  amount: number;
  token: string;
  transactionType: 'DEPOSIT' | 'WITHDRAWAL' | 'TRANSFER';
  source?: string;
  destination?: string;
  transactionHash?: string;
}

// Utility Types
export type SymbolList = string[];
export type PriceHistory = { [symbol: string]: Candle[] };
export type TickerMap = { [symbol: string]: Ticker };
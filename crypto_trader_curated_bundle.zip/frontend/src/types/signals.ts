// Signal and AI-related type definitions

export interface Signal {
  id: string;
  symbol: string;
  direction: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entryPrice: number;
  stopLoss?: number;
  takeProfit?: number;
  riskRewardRatio?: number;
  timestamp: number;
  expiresAt: number;
  status: 'ACTIVE' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED';
  timeframe?: string;
  createdAt?: string;
}

export interface HybridSignal extends Signal {
  algorithmBreakdown: {
    technicalAnalysis: { score: number; weight: number; contribution: number };
    smartMoneyConcepts: { score: number; weight: number; contribution: number };
    patternRecognition: { score: number; weight: number; contribution: number };
    sentimentAnalysis: { score: number; weight: number; contribution: number };
    whaleIntelligence: { score: number; weight: number; contribution: number };
    mlPredictions: { score: number; weight: number; contribution: number };
    finalScore: number;
  };
  riskAssessment: {
    riskScore: number;
    maxLossAmount: number;
    positionSizeRecommendation: number;
    marketImpact: 'LOW' | 'MEDIUM' | 'HIGH';
  };
  marketConditions: {
    volatility: number;
    volumeProfile: 'HIGH' | 'MEDIUM' | 'LOW';
    trendStrength: number;
    supportResistance: { support: number; resistance: number };
  };
}

// Legacy compatibility for existing TradingSignal
export interface TradingSignal {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entryPrice: number;
  stopLoss?: number;
  takeProfit?: number;
  timeframe: string;
  createdAt: string;
  expiresAt: string;
  status: 'ACTIVE' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED';
  algorithmBreakdown: {
    technicalAnalysis: number;
    smartMoneyConcepts: number;
    patternRecognition: number;
    sentimentAnalysis: number;
    whaleMovements: number;
    mlPredictions: number;
  };
}

export interface Backtest {
  symbol: string;
  period: string;
  totalTrades: number;
  winRate: number;
  profitFactor: number;
  maxDrawdown: number;
  totalReturn: number;
  sharpeRatio: number;
  trades: BacktestTrade[];
  equity: Array<{ timestamp: number; value: number }>;
}

export interface BacktestTrade {
  entryTime: number;
  exitTime: number;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  side: 'BUY' | 'SELL';
  pnl: number;
  pnlPercent: number;
  reason: string;
}

export interface TechnicalIndicators {
  rsi: number;
  macd: { 
    macd: number; 
    signal: number; 
    histogram: number 
  };
  bollinger: { 
    upper: number; 
    middle: number; 
    lower: number 
  };
  ema20: number;
  ema50: number;
  sma200: number;
  stochastic: { 
    k: number; 
    d: number 
  };
  atr: number;
  volume_sma: number;
}

export interface SmartMoneyData {
  orderBlocks: Array<{ 
    price: number; 
    strength: number; 
    type: 'bullish' | 'bearish' 
  }>;
  fairValueGaps: Array<{ 
    high: number; 
    low: number; 
    strength: number 
  }>;
  liquidityZones: Array<{ 
    price: number; 
    volume: number; 
    type: 'buy' | 'sell' 
  }>;
  marketStructure: {
    trend: 'bullish' | 'bearish' | 'sideways';
    strength: number;
    breakOfStructure: boolean;
  };
  supplyDemand: {
    supply: Array<{ price: number; strength: number }>;
    demand: Array<{ price: number; strength: number }>;
  };
}

export interface PatternData {
  harmonicPatterns: Array<{
    type: 'butterfly' | 'bat' | 'gartley' | 'crab';
    confidence: number;
    target: number;
    stopLoss: number;
  }>;
  classicPatterns: Array<{
    type: 'head_shoulders' | 'double_top' | 'double_bottom' | 'triangle';
    confidence: number;
    target: number;
  }>;
  candlestickPatterns: Array<{
    type: string;
    confidence: number;
    bullish: boolean;
  }>;
}

export interface SentimentData {
  newsScore: number; // -1 to 1
  socialScore: number; // -1 to 1
  fearGreedIndex: number; // 0 to 100
  whaleActivity: number; // -1 to 1
  overallSentiment: number; // -1 to 1
}

export interface WhaleData {
  largeTransactions: Array<{
    amount: number;
    type: 'inflow' | 'outflow';
    exchange: string;
    timestamp: number;
  }>;
  exchangeFlows: {
    netFlow: number;
    inflowVolume: number;
    outflowVolume: number;
  };
  whaleScore: number; // -1 to 1
}

export interface MLPrediction {
  priceTarget1h: number;
  priceTarget4h: number;
  priceTarget24h: number;
  confidence: number;
  volatilityPrediction: number;
  trendPrediction: 'up' | 'down' | 'sideways';
}

// Technical Indicator Type for Individual Indicators
export interface TechnicalIndicator {
  name: string;
  value: number;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  timeframe: string;
}

// Signal Status Enums
export enum SignalStatus {
  ACTIVE = 'ACTIVE',
  EXECUTED = 'EXECUTED',
  EXPIRED = 'EXPIRED',
  CANCELLED = 'CANCELLED'
}

export enum SignalDirection {
  BUY = 'BUY',
  SELL = 'SELL',
  HOLD = 'HOLD'
}

export enum MarketImpact {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}

export enum VolumeProfile {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}

export enum TrendDirection {
  BULLISH = 'bullish',
  BEARISH = 'bearish',
  SIDEWAYS = 'sideways'
}

export enum PatternType {
  BUTTERFLY = 'butterfly',
  BAT = 'bat',
  GARTLEY = 'gartley',
  CRAB = 'crab',
  HEAD_SHOULDERS = 'head_shoulders',
  DOUBLE_TOP = 'double_top',
  DOUBLE_BOTTOM = 'double_bottom',
  TRIANGLE = 'triangle'
}
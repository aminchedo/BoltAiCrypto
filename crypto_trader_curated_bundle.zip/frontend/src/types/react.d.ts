/// <reference types="react" />
/// <reference types="react-dom" />

declare namespace JSX {
  interface IntrinsicElements {
    [elemName: string]: any;
  }
}

// Module declarations for asset imports
declare module '*.svg' {
  const content: React.FunctionComponent<React.SVGAttributes<SVGElement>>;
  export default content;
}

declare module '*.png' {
  const content: string;
  export default content;
}

declare module '*.jpg' {
  const content: string;
  export default content;
}

declare module '*.jpeg' {
  const content: string;
  export default content;
}

declare module '*.gif' {
  const content: string;
  export default content;
}

declare module '*.webp' {
  const content: string;
  export default content;
}

declare module '*.ico' {
  const content: string;
  export default content;
}

declare module '*.bmp' {
  const content: string;
  export default content;
}

// CSS Module declarations
declare module '*.module.css' {
  const classes: { [key: string]: string };
  export default classes;
}

declare module '*.module.scss' {
  const classes: { [key: string]: string };
  export default classes;
}

declare module '*.module.sass' {
  const classes: { [key: string]: string };
  export default classes;
}

// JSON module declarations
declare module '*.json' {
  const content: { [key: string]: any };
  export default content;
}

// Video and audio file declarations
declare module '*.mp4' {
  const content: string;
  export default content;
}

declare module '*.webm' {
  const content: string;
  export default content;
}

declare module '*.mp3' {
  const content: string;
  export default content;
}

declare module '*.wav' {
  const content: string;
  export default content;
}

// Font file declarations
declare module '*.woff' {
  const content: string;
  export default content;
}

declare module '*.woff2' {
  const content: string;
  export default content;
}

declare module '*.ttf' {
  const content: string;
  export default content;
}

declare module '*.eot' {
  const content: string;
  export default content;
}

// Text file declarations
declare module '*.txt' {
  const content: string;
  export default content;
}

declare module '*.md' {
  const content: string;
  export default content;
}

// Global type extensions
declare global {
  interface Window {
    // Add any custom window properties here
    gtag?: (...args: any[]) => void;
    dataLayer?: any[];
    webkitSpeechRecognition?: any;
    SpeechRecognition?: any;
    ethereum?: any;
    [key: string]: any;
  }

  namespace NodeJS {
    interface ProcessEnv {
      NODE_ENV: 'development' | 'production' | 'test';
      NEXT_PUBLIC_API_URL?: string;
      NEXT_PUBLIC_WS_URL?: string;
      NEXT_PUBLIC_APP_ENV?: string;
      [key: string]: string | undefined;
    }
  }

  // Custom React component props
  interface CustomComponentProps {
    className?: string;
    children?: React.ReactNode;
    style?: React.CSSProperties;
    id?: string;
  }
}

// Extend React types
declare module 'react' {
  interface CSSProperties {
    [key: `--${string}`]: string | number;
  }
  
  interface HTMLAttributes<T> extends AriaAttributes, DOMAttributes<T> {
    // Add custom data attributes
    [key: `data-${string}`]: any;
  }
}

// Chart.js type declarations (if using Chart.js)
declare module 'chart.js' {
  export * from 'chart.js/types';
}

// Trading View widget declarations (if using TradingView)
declare module 'tradingview-charting-library' {
  export * from 'tradingview-charting-library/charting_library';
}

// WebSocket type extensions
interface WebSocket {
  reconnect?: () => void;
  isReconnecting?: boolean;
}

// Custom event types
interface CustomEventMap {
  'theme-changed': CustomEvent<{ theme: 'light' | 'dark' }>;
  'user-login': CustomEvent<{ userId: string }>;
  'user-logout': CustomEvent;
  'price-update': CustomEvent<{ symbol: string; price: number }>;
  'signal-generated': CustomEvent<{ signal: any }>;
}

declare global {
  interface WindowEventMap extends CustomEventMap {}
}

// Type utilities for React components
export type ComponentWithChildren<P = {}> = React.ComponentType<P & { children?: React.ReactNode }>;
export type ComponentProps<T> = T extends React.ComponentType<infer P> ? P : never;
export type ElementProps<T extends keyof JSX.IntrinsicElements> = JSX.IntrinsicElements[T];

// Hook type utilities
export type UseStateReturnType<T> = [T, React.Dispatch<React.SetStateAction<T>>];
export type UseEffectDependencies = React.DependencyList | undefined;

// Context type utility
export type ContextValue<T> = T extends React.Context<infer V> ? V : never;

export {};
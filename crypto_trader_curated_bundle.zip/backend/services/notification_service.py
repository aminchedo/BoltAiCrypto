"""
Notification service for managing user notifications
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)

class NotificationType(str, Enum):
    SIGNAL = "signal"
    TRADE = "trade"
    ALERT = "alert"
    SYSTEM = "system"

class NotificationPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class NotificationService:
    """Service for notification management"""
    
    def __init__(self):
        # Mock storage for simplified version
        self.notifications = {}
        self.user_notifications = {}
    
    async def create_notification(
        self,
        user_id: int,
        title: str,
        message: str,
        notification_type: NotificationType,
        priority: NotificationPriority = NotificationPriority.MEDIUM,
        data: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create a new notification"""
        notification_id = str(uuid.uuid4())
        
        notification = {
            "id": notification_id,
            "user_id": user_id,
            "title": title,
            "message": message,
            "type": notification_type,
            "priority": priority,
            "data": data or {},
            "is_read": False,
            "created_at": datetime.now()
        }
        
        self.notifications[notification_id] = notification
        
        # Add to user's notifications
        if user_id not in self.user_notifications:
            self.user_notifications[user_id] = []
        self.user_notifications[user_id].append(notification_id)
        
        return notification_id
    
    async def get_user_notifications(
        self,
        user_id: int,
        unread_only: bool = False,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get notifications for a user"""
        user_notification_ids = self.user_notifications.get(user_id, [])
        notifications = []
        
        for notification_id in user_notification_ids[-limit:]:
            notification = self.notifications.get(notification_id)
            if notification:
                if not unread_only or not notification["is_read"]:
                    notifications.append(notification)
        
        return sorted(notifications, key=lambda x: x["created_at"], reverse=True)
    
    async def mark_as_read(self, notification_id: str, user_id: int) -> bool:
        """Mark a notification as read"""
        notification = self.notifications.get(notification_id)
        if notification and notification["user_id"] == user_id:
            notification["is_read"] = True
            return True
        return False
    
    async def mark_all_as_read(self, user_id: int) -> int:
        """Mark all notifications as read for a user"""
        count = 0
        user_notification_ids = self.user_notifications.get(user_id, [])
        
        for notification_id in user_notification_ids:
            notification = self.notifications.get(notification_id)
            if notification and not notification["is_read"]:
                notification["is_read"] = True
                count += 1
        
        return count
    
    async def delete_notification(self, notification_id: str, user_id: int) -> bool:
        """Delete a notification"""
        notification = self.notifications.get(notification_id)
        if notification and notification["user_id"] == user_id:
            del self.notifications[notification_id]
            if user_id in self.user_notifications:
                self.user_notifications[user_id].remove(notification_id)
            return True
        return False
    
    async def get_unread_count(self, user_id: int) -> int:
        """Get count of unread notifications"""
        user_notification_ids = self.user_notifications.get(user_id, [])
        count = 0
        
        for notification_id in user_notification_ids:
            notification = self.notifications.get(notification_id)
            if notification and not notification["is_read"]:
                count += 1
        
        return count
"""
Backtest service for strategy backtesting
"""

import logging
import random
from typing import Dict, Any, List
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class BacktestService:
    """Service for backtesting trading strategies"""
    
    async def run_backtest(self, strategy_id: int, start_date: datetime, end_date: datetime, initial_capital: float = 10000) -> Dict[str, Any]:
        """Run backtest for a strategy"""
        try:
            # Mock backtest results for simplified version
            duration_days = (end_date - start_date).days
            
            # Generate mock performance metrics
            total_return = random.uniform(-20, 50)  # -20% to +50%
            sharpe_ratio = random.uniform(0.5, 2.5)
            max_drawdown = random.uniform(5, 25)  # 5% to 25%
            win_rate = random.uniform(45, 75)  # 45% to 75%
            total_trades = random.randint(50, 200)
            
            result = {
                "strategy_id": strategy_id,
                "start_date": start_date,
                "end_date": end_date,
                "initial_capital": initial_capital,
                "final_capital": initial_capital * (1 + total_return / 100),
                "total_return": total_return,
                "sharpe_ratio": sharpe_ratio,
                "max_drawdown": max_drawdown,
                "win_rate": win_rate,
                "total_trades": total_trades,
                "avg_trade_return": total_return / total_trades if total_trades > 0 else 0,
                "duration_days": duration_days,
                "created_at": datetime.now()
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error running backtest: {e}")
            raise
    
    async def get_backtest_results(self, strategy_id: int) -> List[Dict[str, Any]]:
        """Get backtest results for a strategy"""
        # Mock results for simplified version
        return [
            {
                "id": 1,
                "strategy_id": strategy_id,
                "start_date": datetime.now() - timedelta(days=365),
                "end_date": datetime.now() - timedelta(days=1),
                "total_return": 25.5,
                "sharpe_ratio": 1.8,
                "max_drawdown": 12.3,
                "win_rate": 68.5,
                "total_trades": 145,
                "created_at": datetime.now() - timedelta(days=7)
            }
        ]
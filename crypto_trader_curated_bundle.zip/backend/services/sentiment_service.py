"""
Sentiment Analysis Service
Real-time sentiment analysis from news, social media, and market data
"""

import json
import logging
import re
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import statistics
import threading
from concurrent.futures import ThreadPoolExecutor
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SentimentType(Enum):
    """Types of sentiment sources"""
    NEWS = "news"
    SOCIAL_MEDIA = "social_media"
    ON_CHAIN = "on_chain"
    MARKET = "market"
    OVERALL = "overall"

class SentimentPolarity(Enum):
    """Sentiment polarity classifications"""
    VERY_BEARISH = "very_bearish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"
    BULLISH = "bullish"
    VERY_BULLISH = "very_bullish"

@dataclass
class SentimentResult:
    """Structure for sentiment analysis results"""
    source: str
    sentiment_type: str
    polarity: str
    score: float  # -100 to +100
    confidence: float  # 0 to 100
    timestamp: datetime
    text_sample: str
    keywords: List[str]
    impact_score: float
    volume: int

@dataclass
class NewsItem:
    """News item structure"""
    headline: str
    content: str
    source: str
    timestamp: datetime
    url: str
    sentiment_score: float
    impact_level: str
    keywords: List[str]

@dataclass
class SocialMediaPost:
    """Social media post structure"""
    platform: str
    content: str
    author: str
    timestamp: datetime
    engagement: int
    sentiment_score: float
    influence_score: float

class TextProcessor:
    """Natural Language Processing for sentiment analysis"""
    
    def __init__(self):
        # Crypto-specific sentiment lexicon
        self.positive_words = {
            'moon', 'bullish', 'pump', 'rally', 'surge', 'breakout', 'hodl',
            'diamond', 'hands', 'buy', 'accumulate', 'strong', 'support',
            'resistance', 'breakthrough', 'adoption', 'institutional', 'etf',
            'approval', 'partnership', 'upgrade', 'innovation', 'growth',
            'profit', 'gains', 'green', 'up', 'rise', 'increase', 'positive',
            'optimistic', 'confident', 'excited', 'amazing', 'great', 'excellent'
        }
        
        self.negative_words = {
            'crash', 'dump', 'bearish', 'fall', 'drop', 'decline', 'sell',
            'panic', 'fear', 'fud', 'regulation', 'ban', 'hack', 'scam',
            'bubble', 'overvalued', 'correction', 'resistance', 'rejection',
            'loss', 'losses', 'red', 'down', 'decrease', 'negative',
            'pessimistic', 'worried', 'concerned', 'terrible', 'bad', 'awful'
        }
        
        self.crypto_entities = {
            'bitcoin', 'btc', 'ethereum', 'eth', 'crypto', 'cryptocurrency',
            'blockchain', 'defi', 'nft', 'altcoin', 'satoshi', 'mining',
            'wallet', 'exchange', 'trading', 'hodl', 'dyor', 'fomo'
        }
        
        self.impact_multipliers = {
            'bitcoin': 1.0, 'btc': 1.0, 'ethereum': 0.8, 'eth': 0.8,
            'regulation': 1.2, 'etf': 1.3, 'institutional': 1.1,
            'hack': 1.4, 'ban': 1.3, 'adoption': 1.1
        }
    
    def analyze_text_sentiment(self, text: str) -> Dict[str, Any]:
        """Analyze sentiment of text content"""
        if not text:
            return {'score': 0, 'confidence': 0, 'keywords': [], 'polarity': 'neutral'}
        
        # Clean and tokenize text
        cleaned_text = self._clean_text(text)
        tokens = self._tokenize(cleaned_text)
        
        # Calculate sentiment score
        sentiment_score = self._calculate_sentiment_score(tokens)
        
        # Extract keywords
        keywords = self._extract_keywords(tokens)
        
        # Calculate confidence based on keyword density and text length
        confidence = self._calculate_confidence(tokens, keywords)
        
        # Determine polarity
        polarity = self._score_to_polarity(sentiment_score)
        
        return {
            'score': sentiment_score,
            'confidence': confidence,
            'keywords': keywords,
            'polarity': polarity
        }
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '', text)
        
        # Remove special characters but keep spaces
        text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text into words"""
        return [word.strip() for word in text.split() if len(word.strip()) > 2]
    
    def _calculate_sentiment_score(self, tokens: List[str]) -> float:
        """Calculate sentiment score from tokens"""
        positive_score = 0
        negative_score = 0
        total_words = len(tokens)
        
        if total_words == 0:
            return 0
        
        for token in tokens:
            # Check positive sentiment
            if token in self.positive_words:
                weight = self.impact_multipliers.get(token, 1.0)
                positive_score += weight
            
            # Check negative sentiment
            elif token in self.negative_words:
                weight = self.impact_multipliers.get(token, 1.0)
                negative_score += weight
        
        # Normalize score to -100 to +100 range
        net_score = positive_score - negative_score
        normalized_score = (net_score / max(total_words * 0.1, 1)) * 100
        
        # Clamp to valid range
        return max(-100, min(100, normalized_score))
    
    def _extract_keywords(self, tokens: List[str]) -> List[str]:
        """Extract relevant keywords from tokens"""
        keywords = []
        
        for token in tokens:
            if (token in self.positive_words or 
                token in self.negative_words or 
                token in self.crypto_entities):
                keywords.append(token)
        
        # Remove duplicates and limit to top 10
        return list(set(keywords))[:10]
    
    def _calculate_confidence(self, tokens: List[str], keywords: List[str]) -> float:
        """Calculate confidence score for sentiment analysis"""
        if not tokens:
            return 0
        
        # Base confidence on keyword density
        keyword_density = len(keywords) / len(tokens)
        
        # Adjust for text length (longer texts generally more reliable)
        length_factor = min(len(tokens) / 50, 1.0)
        
        # Combine factors
        confidence = (keyword_density * 70 + length_factor * 30)
        
        return min(confidence, 95)
    
    def _score_to_polarity(self, score: float) -> str:
        """Convert numerical score to polarity label"""
        if score >= 40:
            return "very_bullish"
        elif score >= 15:
            return "bullish"
        elif score <= -40:
            return "very_bearish"
        elif score <= -15:
            return "bearish"
        else:
            return "neutral"

class NewsAnalyzer:
    """Analyze news sentiment and impact"""
    
    def __init__(self):
        self.text_processor = TextProcessor()
        self.news_cache = {}
        
        # News source credibility weights
        self.source_weights = {
            'reuters': 1.0,
            'bloomberg': 1.0,
            'coindesk': 0.9,
            'cointelegraph': 0.8,
            'decrypt': 0.8,
            'the block': 0.9,
            'bitcoin magazine': 0.7,
            'crypto news': 0.6
        }
    
    def analyze_news_sentiment(self, news_items: List[NewsItem]) -> Dict[str, Any]:
        """Analyze sentiment from news articles"""
        if not news_items:
            return self._empty_sentiment_result()
        
        total_score = 0
        total_weight = 0
        sentiment_distribution = {'very_bearish': 0, 'bearish': 0, 'neutral': 0, 'bullish': 0, 'very_bullish': 0}
        high_impact_items = []
        all_keywords = []
        
        for news_item in news_items:
            # Analyze headline and content
            headline_analysis = self.text_processor.analyze_text_sentiment(news_item.headline)
            content_analysis = self.text_processor.analyze_text_sentiment(news_item.content[:500])  # First 500 chars
            
            # Combine headline and content sentiment (headline weighted more)
            combined_score = (headline_analysis['score'] * 0.7 + content_analysis['score'] * 0.3)
            combined_confidence = (headline_analysis['confidence'] * 0.7 + content_analysis['confidence'] * 0.3)
            
            # Apply source credibility weight
            source_weight = self.source_weights.get(news_item.source.lower(), 0.5)
            weighted_score = combined_score * source_weight
            
            # Update totals
            total_score += weighted_score * combined_confidence / 100
            total_weight += source_weight * combined_confidence / 100
            
            # Update distribution
            polarity = self.text_processor._score_to_polarity(combined_score)
            sentiment_distribution[polarity] += 1
            
            # Collect keywords
            all_keywords.extend(headline_analysis['keywords'])
            all_keywords.extend(content_analysis['keywords'])
            
            # Track high impact items
            if news_item.impact_level == 'high' or combined_confidence > 80:
                high_impact_items.append({
                    'headline': news_item.headline,
                    'score': combined_score,
                    'confidence': combined_confidence,
                    'source': news_item.source
                })
        
        # Calculate overall sentiment
        overall_score = total_score / total_weight if total_weight > 0 else 0
        overall_confidence = min(total_weight / len(news_items) * 100, 95)
        
        # Get top keywords
        keyword_counts = {}
        for keyword in all_keywords:
            keyword_counts[keyword] = keyword_counts.get(keyword, 0) + 1
        
        top_keywords = sorted(keyword_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            'overall_score': overall_score,
            'overall_confidence': overall_confidence,
            'polarity': self.text_processor._score_to_polarity(overall_score),
            'distribution': sentiment_distribution,
            'top_keywords': [kw[0] for kw in top_keywords],
            'high_impact_items': high_impact_items[:5],
            'total_articles': len(news_items)
        }
    
    def _empty_sentiment_result(self) -> Dict[str, Any]:
        """Return empty sentiment result"""
        return {
            'overall_score': 0,
            'overall_confidence': 0,
            'polarity': 'neutral',
            'distribution': {'very_bearish': 0, 'bearish': 0, 'neutral': 0, 'bullish': 0, 'very_bullish': 0},
            'top_keywords': [],
            'high_impact_items': [],
            'total_articles': 0
        }

class SocialMediaAnalyzer:
    """Analyze social media sentiment"""
    
    def __init__(self):
        self.text_processor = TextProcessor()
        
        # Platform influence weights
        self.platform_weights = {
            'twitter': 1.0,
            'reddit': 0.8,
            'telegram': 0.6,
            'discord': 0.5,
            'youtube': 0.7
        }
        
        # Influence thresholds
        self.influence_thresholds = {
            'high': 10000,
            'medium': 1000,
            'low': 100
        }
    
    def analyze_social_sentiment(self, posts: List[SocialMediaPost]) -> Dict[str, Any]:
        """Analyze sentiment from social media posts"""
        if not posts:
            return self._empty_social_result()
        
        platform_sentiment = {}
        total_weighted_score = 0
        total_weight = 0
        engagement_weighted_score = 0
        total_engagement = 0
        trending_topics = {}
        
        for post in posts:
            # Analyze post content
            analysis = self.text_processor.analyze_text_sentiment(post.content)
            
            # Calculate influence weight
            influence_weight = self._calculate_influence_weight(post)
            
            # Platform weight
            platform_weight = self.platform_weights.get(post.platform.lower(), 0.5)
            
            # Combined weight
            combined_weight = influence_weight * platform_weight * (analysis['confidence'] / 100)
            
            # Update totals
            total_weighted_score += analysis['score'] * combined_weight
            total_weight += combined_weight
            
            # Engagement-weighted sentiment
            engagement_weighted_score += analysis['score'] * post.engagement
            total_engagement += post.engagement
            
            # Platform-specific sentiment
            if post.platform not in platform_sentiment:
                platform_sentiment[post.platform] = {'scores': [], 'engagement': 0}
            
            platform_sentiment[post.platform]['scores'].append(analysis['score'])
            platform_sentiment[post.platform]['engagement'] += post.engagement
            
            # Track trending topics
            for keyword in analysis['keywords']:
                trending_topics[keyword] = trending_topics.get(keyword, 0) + post.engagement
        
        # Calculate overall metrics
        overall_score = total_weighted_score / total_weight if total_weight > 0 else 0
        engagement_score = engagement_weighted_score / total_engagement if total_engagement > 0 else 0
        
        # Platform summaries
        platform_summaries = {}
        for platform, data in platform_sentiment.items():
            if data['scores']:
                platform_summaries[platform] = {
                    'average_sentiment': statistics.mean(data['scores']),
                    'total_engagement': data['engagement'],
                    'post_count': len(data['scores'])
                }
        
        # Top trending topics
        top_trending = sorted(trending_topics.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            'overall_score': overall_score,
            'engagement_weighted_score': engagement_score,
            'polarity': self.text_processor._score_to_polarity(overall_score),
            'platform_sentiment': platform_summaries,
            'trending_topics': [topic[0] for topic in top_trending],
            'total_posts': len(posts),
            'total_engagement': total_engagement
        }
    
    def _calculate_influence_weight(self, post: SocialMediaPost) -> float:
        """Calculate influence weight for a post"""
        # Base weight from engagement
        engagement_weight = min(post.engagement / 1000, 2.0)
        
        # Author influence score
        influence_weight = min(post.influence_score / 100, 1.5)
        
        # Combine weights
        return min(engagement_weight + influence_weight, 3.0)
    
    def _empty_social_result(self) -> Dict[str, Any]:
        """Return empty social media result"""
        return {
            'overall_score': 0,
            'engagement_weighted_score': 0,
            'polarity': 'neutral',
            'platform_sentiment': {},
            'trending_topics': [],
            'total_posts': 0,
            'total_engagement': 0
        }

class OnChainAnalyzer:
    """Analyze on-chain metrics for sentiment"""
    
    def __init__(self):
        self.metrics_weights = {
            'active_addresses': 0.2,
            'transaction_volume': 0.25,
            'exchange_flows': 0.3,
            'whale_movements': 0.25
        }
    
    def analyze_onchain_sentiment(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze sentiment from on-chain metrics"""
        sentiment_scores = {}
        
        # Active addresses sentiment
        if 'active_addresses' in metrics:
            addr_change = metrics['active_addresses'].get('change_24h', 0)
            sentiment_scores['active_addresses'] = self._normalize_metric_change(addr_change, 0.1)
        
        # Transaction volume sentiment
        if 'transaction_volume' in metrics:
            vol_change = metrics['transaction_volume'].get('change_24h', 0)
            sentiment_scores['transaction_volume'] = self._normalize_metric_change(vol_change, 0.15)
        
        # Exchange flows sentiment
        if 'exchange_flows' in metrics:
            net_flow = metrics['exchange_flows'].get('net_flow', 0)
            # Negative flow (outflow) is bullish
            sentiment_scores['exchange_flows'] = -self._normalize_metric_change(net_flow, 0.05)
        
        # Whale movements sentiment
        if 'whale_movements' in metrics:
            whale_activity = metrics['whale_movements'].get('large_transactions', 0)
            baseline = metrics['whale_movements'].get('baseline', whale_activity)
            if baseline > 0:
                change = (whale_activity - baseline) / baseline
                sentiment_scores['whale_movements'] = self._normalize_metric_change(change, 0.2)
        
        # Calculate weighted overall score
        total_score = 0
        total_weight = 0
        
        for metric, score in sentiment_scores.items():
            weight = self.metrics_weights.get(metric, 0.1)
            total_score += score * weight
            total_weight += weight
        
        overall_score = total_score / total_weight if total_weight > 0 else 0
        
        return {
            'overall_score': overall_score,
            'polarity': self._score_to_polarity(overall_score),
            'metric_scores': sentiment_scores,
            'confidence': min(len(sentiment_scores) * 20, 80)  # More metrics = higher confidence
        }
    
    def _normalize_metric_change(self, change: float, volatility_threshold: float) -> float:
        """Normalize metric change to sentiment score"""
        # Clamp extreme values
        clamped_change = max(-volatility_threshold * 3, min(volatility_threshold * 3, change))
        
        # Convert to -100 to +100 scale
        normalized = (clamped_change / volatility_threshold) * 33.33
        
        return max(-100, min(100, normalized))
    
    def _score_to_polarity(self, score: float) -> str:
        """Convert score to polarity"""
        if score >= 30:
            return "bullish"
        elif score <= -30:
            return "bearish"
        else:
            return "neutral"

class FearGreedIndex:
    """Calculate Fear & Greed Index"""
    
    def __init__(self):
        self.component_weights = {
            'volatility': 0.25,
            'market_momentum': 0.25,
            'social_volume': 0.15,
            'surveys': 0.15,
            'dominance': 0.10,
            'trends': 0.10
        }
    
    def calculate_fear_greed_index(self, market_data: Dict[str, Any], 
                                 sentiment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate Fear & Greed Index from various components"""
        components = {}
        
        # Volatility component (inverted - high volatility = fear)
        if 'volatility' in market_data:
            vol_score = max(0, min(100, 100 - (market_data['volatility'] * 200)))
            components['volatility'] = vol_score
        
        # Market momentum component
        if 'price_change_7d' in market_data:
            momentum = market_data['price_change_7d']
            momentum_score = max(0, min(100, 50 + momentum * 2))
            components['market_momentum'] = momentum_score
        
        # Social volume component
        if 'social_sentiment' in sentiment_data:
            social_score = max(0, min(100, 50 + sentiment_data['social_sentiment']['overall_score'] / 2))
            components['social_volume'] = social_score
        
        # Surveys component (simulated)
        survey_score = 50 + (hash(str(int(time.time() / 86400))) % 40 - 20)  # Daily pseudo-random
        components['surveys'] = max(0, min(100, survey_score))
        
        # Market dominance component
        if 'btc_dominance' in market_data:
            dom_change = market_data.get('btc_dominance_change', 0)
            dom_score = max(0, min(100, 50 + dom_change * 10))
            components['dominance'] = dom_score
        
        # Google trends component (simulated)
        trends_score = 50 + (hash(str(int(time.time() / 3600))) % 30 - 15)  # Hourly pseudo-random
        components['trends'] = max(0, min(100, trends_score))
        
        # Calculate weighted average
        total_score = 0
        total_weight = 0
        
        for component, score in components.items():
            weight = self.component_weights.get(component, 0.1)
            total_score += score * weight
            total_weight += weight
        
        fear_greed_score = total_score / total_weight if total_weight > 0 else 50
        
        # Determine label
        if fear_greed_score >= 75:
            label = "Extreme Greed"
        elif fear_greed_score >= 55:
            label = "Greed"
        elif fear_greed_score >= 45:
            label = "Neutral"
        elif fear_greed_score >= 25:
            label = "Fear"
        else:
            label = "Extreme Fear"
        
        return {
            'score': round(fear_greed_score),
            'label': label,
            'components': components,
            'timestamp': datetime.now()
        }

class SentimentService:
    """Main Sentiment Analysis Service"""
    
    def __init__(self):
        self.text_processor = TextProcessor()
        self.news_analyzer = NewsAnalyzer()
        self.social_analyzer = SocialMediaAnalyzer()
        self.onchain_analyzer = OnChainAnalyzer()
        self.fear_greed_calculator = FearGreedIndex()
        
        self.sentiment_cache = {}
        self.trending_cache = {}
        self.lock = threading.Lock()
        
        logger.info("Sentiment Analysis Service initialized")
    
    def analyze_comprehensive_sentiment(self, asset: str, 
                                      news_items: List[NewsItem] = None,
                                      social_posts: List[SocialMediaPost] = None,
                                      onchain_metrics: Dict[str, Any] = None,
                                      market_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Perform comprehensive sentiment analysis"""
        try:
            cache_key = f"{asset}_{len(news_items or [])}_{len(social_posts or [])}_{hash(str(onchain_metrics))}"
            
            with self.lock:
                # Check cache
                if cache_key in self.sentiment_cache:
                    cached_result = self.sentiment_cache[cache_key]
                    if (datetime.now() - cached_result['timestamp']).seconds < 300:  # 5 min cache
                        return cached_result['data']
            
            results = {}
            
            # News sentiment analysis
            if news_items:
                results['news_sentiment'] = self.news_analyzer.analyze_news_sentiment(news_items)
            else:
                results['news_sentiment'] = self._generate_mock_news_sentiment()
            
            # Social media sentiment analysis
            if social_posts:
                results['social_sentiment'] = self.social_analyzer.analyze_social_sentiment(social_posts)
            else:
                results['social_sentiment'] = self._generate_mock_social_sentiment()
            
            # On-chain sentiment analysis
            if onchain_metrics:
                results['onchain_sentiment'] = self.onchain_analyzer.analyze_onchain_sentiment(onchain_metrics)
            else:
                results['onchain_sentiment'] = self._generate_mock_onchain_sentiment()
            
            # Calculate overall sentiment
            results['overall_sentiment'] = self._calculate_overall_sentiment(results)
            
            # Fear & Greed Index
            if market_data:
                results['fear_greed_index'] = self.fear_greed_calculator.calculate_fear_greed_index(
                    market_data, results)
            else:
                results['fear_greed_index'] = self._generate_mock_fear_greed()
            
            # Trending topics analysis
            results['trending_topics'] = self._analyze_trending_topics(results)
            
            # Sentiment change detection
            results['sentiment_changes'] = self._detect_sentiment_changes(asset, results)
            
            # Cache results
            with self.lock:
                self.sentiment_cache[cache_key] = {
                    'data': results,
                    'timestamp': datetime.now()
                }
            
            logger.info(f"Comprehensive sentiment analysis completed for {asset}")
            return results
            
        except Exception as e:
            logger.error(f"Error in comprehensive sentiment analysis: {str(e)}")
            return self._generate_fallback_sentiment()
    
    def _calculate_overall_sentiment(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall sentiment from all sources"""
        weights = {
            'news_sentiment': 0.4,
            'social_sentiment': 0.35,
            'onchain_sentiment': 0.25
        }
        
        total_score = 0
        total_weight = 0
        confidence_scores = []
        
        for source, weight in weights.items():
            if source in results and 'overall_score' in results[source]:
                score = results[source]['overall_score']
                confidence = results[source].get('overall_confidence', 
                                                results[source].get('confidence', 50))
                
                weighted_score = score * weight * (confidence / 100)
                total_score += weighted_score
                total_weight += weight * (confidence / 100)
                confidence_scores.append(confidence)
        
        overall_score = total_score / total_weight if total_weight > 0 else 0
        overall_confidence = statistics.mean(confidence_scores) if confidence_scores else 50
        
        return {
            'score': overall_score,
            'confidence': overall_confidence,
            'polarity': self.text_processor._score_to_polarity(overall_score),
            'component_weights': weights,
            'timestamp': datetime.now()
        }
    
    def _analyze_trending_topics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze trending topics across all sources"""
        all_topics = {}
        
        # Collect topics from news
        if 'news_sentiment' in results and 'top_keywords' in results['news_sentiment']:
            for topic in results['news_sentiment']['top_keywords']:
                all_topics[topic] = all_topics.get(topic, 0) + 3  # News topics weighted higher
        
        # Collect topics from social media
        if 'social_sentiment' in results and 'trending_topics' in results['social_sentiment']:
            for topic in results['social_sentiment']['trending_topics']:
                all_topics[topic] = all_topics.get(topic, 0) + 2
        
        # Sort by frequency
        sorted_topics = sorted(all_topics.items(), key=lambda x: x[1], reverse=True)
        
        return {
            'top_topics': [topic[0] for topic in sorted_topics[:10]],
            'topic_scores': dict(sorted_topics[:10]),
            'total_unique_topics': len(all_topics)
        }
    
    def _detect_sentiment_changes(self, asset: str, current_results: Dict[str, Any]) -> Dict[str, Any]:
        """Detect significant sentiment changes"""
        changes = {
            'significant_changes': [],
            'trend_direction': 'stable',
            'change_magnitude': 0
        }
        
        # Compare with cached previous results
        prev_key = f"{asset}_previous"
        if prev_key in self.sentiment_cache:
            prev_results = self.sentiment_cache[prev_key]['data']
            
            current_score = current_results.get('overall_sentiment', {}).get('score', 0)
            prev_score = prev_results.get('overall_sentiment', {}).get('score', 0)
            
            change = current_score - prev_score
            
            if abs(change) > 15:  # Significant change threshold
                changes['significant_changes'].append({
                    'type': 'overall_sentiment',
                    'change': change,
                    'from': prev_score,
                    'to': current_score
                })
                
                changes['trend_direction'] = 'improving' if change > 0 else 'deteriorating'
                changes['change_magnitude'] = abs(change)
        
        # Store current results for next comparison
        self.sentiment_cache[f"{asset}_previous"] = {
            'data': current_results,
            'timestamp': datetime.now()
        }
        
        return changes
    
    def _generate_mock_news_sentiment(self) -> Dict[str, Any]:
        """Generate mock news sentiment for testing"""
        base_score = (hash(str(int(time.time() / 3600))) % 80) - 40  # Hourly variation
        
        return {
            'overall_score': base_score,
            'overall_confidence': 75,
            'polarity': self.text_processor._score_to_polarity(base_score),
            'distribution': {
                'very_bearish': 1, 'bearish': 2, 'neutral': 4, 'bullish': 2, 'very_bullish': 1
            },
            'top_keywords': ['bitcoin', 'etf', 'regulation', 'adoption', 'institutional'],
            'high_impact_items': [
                {
                    'headline': 'Bitcoin ETF Sees Record Inflows',
                    'score': 65,
                    'confidence': 85,
                    'source': 'Bloomberg'
                }
            ],
            'total_articles': 10
        }
    
    def _generate_mock_social_sentiment(self) -> Dict[str, Any]:
        """Generate mock social media sentiment for testing"""
        base_score = (hash(str(int(time.time() / 1800))) % 60) - 30  # 30-min variation
        
        return {
            'overall_score': base_score,
            'engagement_weighted_score': base_score * 1.1,
            'polarity': self.text_processor._score_to_polarity(base_score),
            'platform_sentiment': {
                'twitter': {'average_sentiment': base_score + 5, 'total_engagement': 45200, 'post_count': 1250},
                'reddit': {'average_sentiment': base_score - 3, 'total_engagement': 12800, 'post_count': 340},
                'telegram': {'average_sentiment': base_score + 8, 'total_engagement': 8900, 'post_count': 180}
            },
            'trending_topics': ['bitcoin', 'hodl', 'moon', 'dip', 'buy'],
            'total_posts': 1770,
            'total_engagement': 66900
        }
    
    def _generate_mock_onchain_sentiment(self) -> Dict[str, Any]:
        """Generate mock on-chain sentiment for testing"""
        base_score = (hash(str(int(time.time() / 7200))) % 40) - 20  # 2-hour variation
        
        return {
            'overall_score': base_score,
            'polarity': self.onchain_analyzer._score_to_polarity(base_score),
            'metric_scores': {
                'active_addresses': base_score + 5,
                'transaction_volume': base_score - 2,
                'exchange_flows': base_score + 10,
                'whale_movements': base_score - 5
            },
            'confidence': 70
        }
    
    def _generate_mock_fear_greed(self) -> Dict[str, Any]:
        """Generate mock Fear & Greed Index for testing"""
        score = 50 + (hash(str(int(time.time() / 86400))) % 40) - 20  # Daily variation
        
        if score >= 75:
            label = "Extreme Greed"
        elif score >= 55:
            label = "Greed"
        elif score >= 45:
            label = "Neutral"
        elif score >= 25:
            label = "Fear"
        else:
            label = "Extreme Fear"
        
        return {
            'score': max(0, min(100, score)),
            'label': label,
            'components': {
                'volatility': score + 5,
                'market_momentum': score - 3,
                'social_volume': score + 8,
                'surveys': score - 2,
                'dominance': score + 1,
                'trends': score - 4
            },
            'timestamp': datetime.now()
        }
    
    def _generate_fallback_sentiment(self) -> Dict[str, Any]:
        """Generate fallback sentiment data on error"""
        return {
            'news_sentiment': self._generate_mock_news_sentiment(),
            'social_sentiment': self._generate_mock_social_sentiment(),
            'onchain_sentiment': self._generate_mock_onchain_sentiment(),
            'overall_sentiment': {
                'score': 0,
                'confidence': 50,
                'polarity': 'neutral',
                'timestamp': datetime.now()
            },
            'fear_greed_index': self._generate_mock_fear_greed(),
            'trending_topics': {
                'top_topics': ['bitcoin', 'crypto', 'trading'],
                'topic_scores': {'bitcoin': 10, 'crypto': 8, 'trading': 6},
                'total_unique_topics': 3
            },
            'sentiment_changes': {
                'significant_changes': [],
                'trend_direction': 'stable',
                'change_magnitude': 0
            }
        }
    
    def get_sentiment_summary(self, asset: str) -> Dict[str, Any]:
        """Get sentiment summary for an asset"""
        try:
            # Get comprehensive sentiment
            sentiment_data = self.analyze_comprehensive_sentiment(asset)
            
            # Create summary
            summary = {
                'asset': asset,
                'overall_score': sentiment_data['overall_sentiment']['score'],
                'overall_polarity': sentiment_data['overall_sentiment']['polarity'],
                'confidence': sentiment_data['overall_sentiment']['confidence'],
                'fear_greed_score': sentiment_data['fear_greed_index']['score'],
                'fear_greed_label': sentiment_data['fear_greed_index']['label'],
                'trending_topics': sentiment_data['trending_topics']['top_topics'][:5],
                'sentiment_breakdown': {
                    'news': sentiment_data['news_sentiment']['overall_score'],
                    'social': sentiment_data['social_sentiment']['overall_score'],
                    'onchain': sentiment_data['onchain_sentiment']['overall_score']
                },
                'recent_changes': sentiment_data['sentiment_changes']['trend_direction'],
                'timestamp': datetime.now()
            }
            
            return summary
            
        except Exception as e:
            logger.error(f"Error generating sentiment summary: {str(e)}")
            return {
                'asset': asset,
                'overall_score': 0,
                'overall_polarity': 'neutral',
                'confidence': 50,
                'error': str(e),
                'timestamp': datetime.now()
            }
    
    def get_correlation_analysis(self, sentiment_history: List[Dict], 
                               price_history: List[Dict]) -> Dict[str, Any]:
        """Analyze correlation between sentiment and price movements"""
        if len(sentiment_history) < 10 or len(price_history) < 10:
            return {'correlation': 0, 'confidence': 0, 'analysis': 'Insufficient data'}
        
        # Align data by timestamp and calculate correlation
        aligned_data = []
        
        for sentiment_point in sentiment_history[-30:]:  # Last 30 data points
            sentiment_time = sentiment_point['timestamp']
            
            # Find closest price point
            closest_price = None
            min_time_diff = float('inf')
            
            for price_point in price_history:
                time_diff = abs((price_point['timestamp'] - sentiment_time).total_seconds())
                if time_diff < min_time_diff:
                    min_time_diff = time_diff
                    closest_price = price_point
            
            if closest_price and min_time_diff < 3600:  # Within 1 hour
                aligned_data.append({
                    'sentiment': sentiment_point['score'],
                    'price_change': closest_price.get('change_24h', 0)
                })
        
        if len(aligned_data) < 5:
            return {'correlation': 0, 'confidence': 0, 'analysis': 'Insufficient aligned data'}
        
        # Calculate correlation coefficient
        sentiment_scores = [d['sentiment'] for d in aligned_data]
        price_changes = [d['price_change'] for d in aligned_data]
        
        correlation = self._calculate_correlation(sentiment_scores, price_changes)
        confidence = min(len(aligned_data) * 3, 90)
        
        # Analysis
        if abs(correlation) > 0.7:
            strength = "strong"
        elif abs(correlation) > 0.4:
            strength = "moderate"
        else:
            strength = "weak"
        
        direction = "positive" if correlation > 0 else "negative"
        
        analysis = f"{strength.title()} {direction} correlation between sentiment and price"
        
        return {
            'correlation': correlation,
            'confidence': confidence,
            'analysis': analysis,
            'data_points': len(aligned_data),
            'strength': strength,
            'direction': direction
        }
    
    def _calculate_correlation(self, x: List[float], y: List[float]) -> float:
        """Calculate Pearson correlation coefficient"""
        if len(x) != len(y) or len(x) < 2:
            return 0
        
        n = len(x)
        sum_x = sum(x)
        sum_y = sum(y)
        sum_xy = sum(x[i] * y[i] for i in range(n))
        sum_x2 = sum(xi * xi for xi in x)
        sum_y2 = sum(yi * yi for yi in y)
        
        numerator = n * sum_xy - sum_x * sum_y
        denominator = ((n * sum_x2 - sum_x * sum_x) * (n * sum_y2 - sum_y * sum_y)) ** 0.5
        
        if denominator == 0:
            return 0
        
        return numerator / denominator
    
    def health_check(self) -> Dict[str, Any]:
        """Service health check"""
        return {
            'status': 'healthy',
            'analyzers_loaded': 4,
            'cache_size': len(self.sentiment_cache),
            'text_processor_ready': bool(self.text_processor.positive_words),
            'timestamp': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize service
    sentiment_service = SentimentService()
    
    # Sample news items
    sample_news = [
        NewsItem(
            headline="Bitcoin ETF Sees Record Inflows as Institutional Adoption Grows",
            content="Major institutional investors continue to pour money into Bitcoin ETFs...",
            source="Bloomberg",
            timestamp=datetime.now() - timedelta(hours=2),
            url="https://example.com/news1",
            sentiment_score=0,
            impact_level="high",
            keywords=[]
        ),
        NewsItem(
            headline="Regulatory Concerns Mount as SEC Reviews Crypto Policies",
            content="The Securities and Exchange Commission is reviewing its cryptocurrency policies...",
            source="Reuters",
            timestamp=datetime.now() - timedelta(hours=4),
            url="https://example.com/news2",
            sentiment_score=0,
            impact_level="medium",
            keywords=[]
        )
    ]
    
    # Sample social media posts
    sample_posts = [
        SocialMediaPost(
            platform="twitter",
            content="Bitcoin to the moon! 🚀 This bull run is just getting started #BTC #HODL",
            author="crypto_trader_123",
            timestamp=datetime.now() - timedelta(minutes=30),
            engagement=1250,
            influence_score=75
        ),
        SocialMediaPost(
            platform="reddit",
            content="Concerned about the recent volatility. Might be time to take some profits.",
            author="cautious_investor",
            timestamp=datetime.now() - timedelta(hours=1),
            engagement=340,
            influence_score=45
        )
    ]
    
    # Sample on-chain metrics
    sample_onchain = {
        'active_addresses': {'current': 950000, 'change_24h': 0.05},
        'transaction_volume': {'current': 15000000000, 'change_24h': 0.12},
        'exchange_flows': {'net_flow': -50000000},
        'whale_movements': {'large_transactions': 145, 'baseline': 120}
    }
    
    # Sample market data
    sample_market = {
        'volatility': 0.25,
        'price_change_7d': 8.5,
        'btc_dominance': 52.3,
        'btc_dominance_change': 1.2
    }
    
    # Perform comprehensive analysis
    results = sentiment_service.analyze_comprehensive_sentiment(
        asset="BTC",
        news_items=sample_news,
        social_posts=sample_posts,
        onchain_metrics=sample_onchain,
        market_data=sample_market
    )
    
    print("Comprehensive Sentiment Analysis Results:")
    print("=" * 50)
    
    print(f"\nOVERALL SENTIMENT:")
    overall = results['overall_sentiment']
    print(f"Score: {overall['score']:.1f}")
    print(f"Polarity: {overall['polarity']}")
    print(f"Confidence: {overall['confidence']:.1f}%")
    
    print(f"\nFEAR & GREED INDEX:")
    fg = results['fear_greed_index']
    print(f"Score: {fg['score']}")
    print(f"Label: {fg['label']}")
    
    print(f"\nSENTIMENT BREAKDOWN:")
    print(f"News: {results['news_sentiment']['overall_score']:.1f}")
    print(f"Social: {results['social_sentiment']['overall_score']:.1f}")
    print(f"On-chain: {results['onchain_sentiment']['overall_score']:.1f}")
    
    print(f"\nTRENDING TOPICS:")
    for topic in results['trending_topics']['top_topics'][:5]:
        print(f"- {topic}")
    
    # Get sentiment summary
    summary = sentiment_service.get_sentiment_summary("BTC")
    print(f"\nSENTIMENT SUMMARY:")
    print(f"Overall: {summary['overall_polarity']} ({summary['overall_score']:.1f})")
    print(f"Fear & Greed: {summary['fear_greed_label']} ({summary['fear_greed_score']})")
    print(f"Recent trend: {summary['recent_changes']}")
    
    # Health check
    health = sentiment_service.health_check()
    print(f"\nService Health: {health}")
"""
Portfolio service for managing user portfolios and assets
"""

import logging
import uuid
import random
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class PortfolioService:
    """Service for portfolio management operations"""
    
    def __init__(self):
        # Mock storage for simplified version
        self.portfolios = {}
        self.portfolio_assets = {}
        self.user_portfolios = {}
    
    async def create_portfolio(
        self,
        user_id: int,
        name: str,
        description: Optional[str] = None,
        exchange: str = "binance",
        is_default: bool = False
    ) -> str:
        """Create a new portfolio"""
        try:
            portfolio_id = str(uuid.uuid4())
            
            portfolio = {
                "id": portfolio_id,
                "user_id": user_id,
                "name": name,
                "description": description,
                "exchange": exchange,
                "is_default": is_default,
                "created_at": datetime.now(),
                "updated_at": datetime.now(),
                "total_value": 0.0
            }
            
            self.portfolios[portfolio_id] = portfolio
            
            # Add to user's portfolios
            if user_id not in self.user_portfolios:
                self.user_portfolios[user_id] = []
            self.user_portfolios[user_id].append(portfolio_id)
            
            # Initialize empty assets
            self.portfolio_assets[portfolio_id] = {}
            
            return portfolio_id
            
        except Exception as e:
            logger.error(f"Error creating portfolio: {e}")
            raise
    
    async def get_user_portfolios(self, user_id: int) -> List[Dict[str, Any]]:
        """Get all portfolios for a user"""
        portfolio_ids = self.user_portfolios.get(user_id, [])
        portfolios = []
        
        for portfolio_id in portfolio_ids:
            portfolio = self.portfolios.get(portfolio_id)
            if portfolio:
                # Calculate current total value
                assets = self.portfolio_assets.get(portfolio_id, {})
                total_value = sum(asset.get("current_value", 0) for asset in assets.values())
                portfolio["total_value"] = total_value
                portfolios.append(portfolio)
        
        return portfolios
    
    async def get_portfolio(self, portfolio_id: str, user_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific portfolio"""
        portfolio = self.portfolios.get(portfolio_id)
        if portfolio and portfolio["user_id"] == user_id:
            # Calculate current total value
            assets = self.portfolio_assets.get(portfolio_id, {})
            total_value = sum(asset.get("current_value", 0) for asset in assets.values())
            portfolio["total_value"] = total_value
            return portfolio
        return None
    
    async def update_portfolio(
        self,
        portfolio_id: str,
        user_id: int,
        updates: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Update a portfolio"""
        try:
            portfolio = await self.get_portfolio(portfolio_id, user_id)
            if not portfolio:
                return None
            
            for key, value in updates.items():
                if key in portfolio and key not in ["id", "user_id", "created_at"]:
                    portfolio[key] = value
            
            portfolio["updated_at"] = datetime.now()
            return portfolio
            
        except Exception as e:
            logger.error(f"Error updating portfolio: {e}")
            return None
    
    async def delete_portfolio(self, portfolio_id: str, user_id: int) -> bool:
        """Delete a portfolio"""
        try:
            portfolio = await self.get_portfolio(portfolio_id, user_id)
            if not portfolio:
                return False
            
            # Remove from storage
            del self.portfolios[portfolio_id]
            if portfolio_id in self.portfolio_assets:
                del self.portfolio_assets[portfolio_id]
            
            # Remove from user's portfolios
            if user_id in self.user_portfolios:
                self.user_portfolios[user_id].remove(portfolio_id)
            
            return True
            
        except Exception as e:
            logger.error(f"Error deleting portfolio: {e}")
            return False
    
    async def get_portfolio_assets(self, portfolio_id: str) -> List[Dict[str, Any]]:
        """Get all assets in a portfolio"""
        assets = self.portfolio_assets.get(portfolio_id, {})
        return list(assets.values())
    
    async def update_asset(
        self,
        portfolio_id: str,
        symbol: str,
        balance: float,
        average_buy_price: Optional[float] = None
    ) -> Dict[str, Any]:
        """Add or update an asset in a portfolio"""
        try:
            if portfolio_id not in self.portfolio_assets:
                self.portfolio_assets[portfolio_id] = {}
            
            # Mock current price
            current_price = self._get_mock_price(symbol)
            current_value = balance * current_price
            
            asset = {
                "symbol": symbol,
                "balance": balance,
                "average_buy_price": average_buy_price or current_price,
                "current_price": current_price,
                "current_value": current_value,
                "pnl": current_value - (balance * (average_buy_price or current_price)),
                "pnl_percentage": ((current_price - (average_buy_price or current_price)) / (average_buy_price or current_price)) * 100 if average_buy_price else 0,
                "updated_at": datetime.now()
            }
            
            self.portfolio_assets[portfolio_id][symbol] = asset
            return asset
            
        except Exception as e:
            logger.error(f"Error updating asset: {e}")
            raise
    
    async def remove_asset(self, portfolio_id: str, symbol: str) -> bool:
        """Remove an asset from a portfolio"""
        try:
            if portfolio_id in self.portfolio_assets and symbol in self.portfolio_assets[portfolio_id]:
                del self.portfolio_assets[portfolio_id][symbol]
                return True
            return False
            
        except Exception as e:
            logger.error(f"Error removing asset: {e}")
            return False
    
    async def get_portfolio_performance(
        self,
        portfolio_id: str,
        start_date: datetime,
        end_date: datetime,
        interval: str = "1d"
    ) -> Dict[str, Any]:
        """Get performance metrics for a portfolio"""
        try:
            # Mock performance data for simplified version
            days = (end_date - start_date).days
            
            # Generate mock historical data
            historical_values = []
            current_date = start_date
            base_value = 10000
            
            while current_date <= end_date:
                # Add some random variation
                daily_change = random.uniform(-0.03, 0.03)  # -3% to +3%
                base_value *= (1 + daily_change)
                
                historical_values.append({
                    "date": current_date.isoformat(),
                    "value": round(base_value, 2),
                    "change": round(daily_change * 100, 2)
                })
                
                current_date += timedelta(days=1)
            
            # Calculate performance metrics
            initial_value = historical_values[0]["value"] if historical_values else 10000
            final_value = historical_values[-1]["value"] if historical_values else 10000
            total_return = ((final_value - initial_value) / initial_value) * 100
            
            return {
                "portfolio_id": portfolio_id,
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat(),
                "initial_value": initial_value,
                "final_value": final_value,
                "total_return": round(total_return, 2),
                "annualized_return": round(total_return * (365 / days) if days > 0 else 0, 2),
                "volatility": round(random.uniform(10, 30), 2),
                "sharpe_ratio": round(random.uniform(0.5, 2.0), 2),
                "max_drawdown": round(random.uniform(5, 20), 2),
                "historical_values": historical_values
            }
            
        except Exception as e:
            logger.error(f"Error calculating portfolio performance: {e}")
            raise
    
    async def get_portfolio_snapshots(self, portfolio_id: str, days: int = 30) -> List[Dict[str, Any]]:
        """Get historical snapshots of a portfolio"""
        snapshots = []
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        current_date = start_date
        base_value = 10000
        
        while current_date <= end_date:
            daily_change = random.uniform(-0.02, 0.02)
            base_value *= (1 + daily_change)
            
            snapshots.append({
                "date": current_date.isoformat(),
                "total_value": round(base_value, 2),
                "asset_count": random.randint(3, 8),
                "change_24h": round(daily_change * 100, 2)
            })
            
            current_date += timedelta(days=1)
        
        return snapshots
    
    async def sync_portfolio(self, portfolio_id: str, api_key_id: str) -> Dict[str, Any]:
        """Sync portfolio with exchange balances"""
        # Mock sync result for simplified version
        return {
            "updated": random.randint(2, 5),
            "added": random.randint(0, 2),
            "removed": random.randint(0, 1)
        }
    
    async def get_portfolio_summary(self, user_id: int) -> Dict[str, Any]:
        """Get summary of all portfolios for a user"""
        portfolios = await self.get_user_portfolios(user_id)
        
        total_value = sum(p.get("total_value", 0) for p in portfolios)
        total_change_24h = random.uniform(-5, 5)
        
        return {
            "total_portfolios": len(portfolios),
            "total_value": round(total_value, 2),
            "change_24h": round(total_change_24h, 2),
            "change_24h_percentage": round(total_change_24h / total_value * 100 if total_value > 0 else 0, 2),
            "top_performing_asset": "BTC",
            "worst_performing_asset": "ADA"
        }
    
    async def get_portfolio_allocation(self, user_id: int) -> Dict[str, Any]:
        """Get asset allocation across all portfolios"""
        # Mock allocation data for simplified version
        return {
            "allocation": [
                {"symbol": "BTC", "percentage": 45.2, "value": 4520},
                {"symbol": "ETH", "percentage": 30.1, "value": 3010},
                {"symbol": "BNB", "percentage": 15.3, "value": 1530},
                {"symbol": "SOL", "percentage": 9.4, "value": 940}
            ],
            "total_value": 10000,
            "diversification_score": 7.5
        }
    
    def _get_mock_price(self, symbol: str) -> float:
        """Get mock price for a symbol"""
        base_prices = {
            "BTC": 50000,
            "ETH": 3000,
            "BNB": 400,
            "SOL": 100,
            "ADA": 0.5,
            "XRP": 0.6,
            "DOGE": 0.1
        }
        
        base_price = base_prices.get(symbol.replace("USDT", ""), 100)
        # Add some random variation
        return base_price * (1 + random.uniform(-0.02, 0.02))
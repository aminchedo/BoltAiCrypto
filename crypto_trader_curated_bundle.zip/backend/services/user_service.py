"""
User service for user management operations
"""

import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import hashlib
import secrets

logger = logging.getLogger(__name__)

class UserService:
    """Service for user management operations"""
    
    def __init__(self):
        # Mock user storage for simplified version
        self.users = {}
        self.sessions = {}
    
    async def create_user(self, email: str, password: str, full_name: Optional[str] = None) -> Dict[str, Any]:
        """Create a new user"""
        try:
            if email in self.users:
                raise ValueError("User already exists")
            
            user_id = len(self.users) + 1
            hashed_password = self._hash_password(password)
            
            user = {
                "id": user_id,
                "email": email,
                "username": email.split("@")[0],
                "full_name": full_name,
                "hashed_password": hashed_password,
                "is_active": True,
                "is_verified": False,
                "created_at": datetime.now(),
                "last_login": None
            }
            
            self.users[email] = user
            return user
            
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            raise
    
    async def authenticate_user(self, email: str, password: str) -> Optional[Dict[str, Any]]:
        """Authenticate user with email and password"""
        try:
            user = self.users.get(email)
            if not user:
                return None
            
            if not self._verify_password(password, user["hashed_password"]):
                return None
            
            # Update last login
            user["last_login"] = datetime.now()
            return user
            
        except Exception as e:
            logger.error(f"Error authenticating user: {e}")
            return None
    
    async def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Get user by email"""
        return self.users.get(email)
    
    async def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get user by ID"""
        for user in self.users.values():
            if user["id"] == user_id:
                return user
        return None
    
    async def update_user(self, user_id: int, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update user information"""
        try:
            user = await self.get_user_by_id(user_id)
            if not user:
                return None
            
            for key, value in updates.items():
                if key in user and key != "id":
                    user[key] = value
            
            return user
            
        except Exception as e:
            logger.error(f"Error updating user: {e}")
            return None
    
    def _hash_password(self, password: str) -> str:
        """Hash password using SHA-256 (simplified for demo)"""
        salt = secrets.token_hex(16)
        return hashlib.sha256((password + salt).encode()).hexdigest() + ":" + salt
    
    def _verify_password(self, password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        try:
            hash_part, salt = hashed_password.split(":")
            return hashlib.sha256((password + salt).encode()).hexdigest() == hash_part
        except:
            return False
"""
Technical Analysis Service
Provides technical indicators and analysis for trading signals
"""

import logging
from typing import List, Dict, Any, Optional
import numpy as np
from datetime import datetime

logger = logging.getLogger(__name__)

class TechnicalAnalysisService:
    """Service for technical analysis calculations"""
    
    async def calculate_indicators(self, symbol: str, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate technical indicators for a symbol"""
        try:
            # Extract price data
            closes = [candle["close"] for candle in candles]
            highs = [candle["high"] for candle in candles]
            lows = [candle["low"] for candle in candles]
            volumes = [candle["volume"] for candle in candles]
            
            # Calculate RSI
            rsi = self.calculate_rsi(closes)
            
            # Calculate MACD
            macd_result = self.calculate_macd(closes)
            
            # Calculate moving averages
            sma_20 = self.calculate_sma(closes, 20)
            sma_50 = self.calculate_sma(closes, 50)
            sma_200 = self.calculate_sma(closes, 200)
            
            # Calculate Bollinger Bands
            bb = self.calculate_bollinger_bands(closes)
            
            # Calculate ATR
            atr = self.calculate_atr(highs, lows, closes)
            
            # Calculate OBV
            obv = self.calculate_obv(closes, volumes)
            
            return {
                "rsi": rsi,
                "macd": macd_result,
                "sma": {
                    "sma20": sma_20,
                    "sma50": sma_50,
                    "sma200": sma_200
                },
                "bollingerBands": bb,
                "atr": atr,
                "obv": obv,
                "timestamp": datetime.now().timestamp()
            }
            
        except Exception as e:
            logger.error(f"Error calculating indicators for {symbol}: {e}")
            return {
                "rsi": 50,
                "macd": {"macd": 0, "signal": 0, "histogram": 0},
                "sma": {"sma20": 0, "sma50": 0, "sma200": 0},
                "bollingerBands": {"upper": 0, "middle": 0, "lower": 0},
                "atr": 0,
                "obv": 0,
                "timestamp": datetime.now().timestamp()
            }
    
    def calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """Calculate Relative Strength Index"""
        try:
            if len(prices) < period + 1:
                return 50
            
            # Calculate price changes
            deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
            
            # Calculate gains and losses
            gains = [delta if delta > 0 else 0 for delta in deltas]
            losses = [-delta if delta < 0 else 0 for delta in deltas]
            
            # Calculate average gains and losses
            avg_gain = sum(gains[-period:]) / period
            avg_loss = sum(losses[-period:]) / period
            
            if avg_loss == 0:
                return 100
            
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            return round(rsi, 2)
            
        except Exception as e:
            logger.error(f"Error calculating RSI: {e}")
            return 50
    
    def calculate_macd(self, prices: List[float], fast_period: int = 12, slow_period: int = 26, signal_period: int = 9) -> Dict[str, float]:
        """Calculate Moving Average Convergence Divergence"""
        try:
            if len(prices) < slow_period + signal_period:
                return {"macd": 0, "signal": 0, "histogram": 0}
            
            # Calculate EMAs
            ema_fast = self.calculate_ema(prices, fast_period)
            ema_slow = self.calculate_ema(prices, slow_period)
            
            # Calculate MACD line
            macd_line = ema_fast - ema_slow
            
            # Calculate signal line (EMA of MACD line)
            macd_values = [0] * (len(prices) - slow_period)
            for i in range(len(prices) - slow_period):
                if i < slow_period - fast_period:
                    macd_values[i] = 0
                else:
                    fast_ema = self.calculate_ema(prices[:slow_period+i+1], fast_period)
                    slow_ema = self.calculate_ema(prices[:slow_period+i+1], slow_period)
                    macd_values[i] = fast_ema - slow_ema
            
            signal_line = self.calculate_ema(macd_values, signal_period)
            
            # Calculate histogram
            histogram = macd_line - signal_line
            
            return {
                "macd": round(macd_line, 4),
                "signal": round(signal_line, 4),
                "histogram": round(histogram, 4)
            }
            
        except Exception as e:
            logger.error(f"Error calculating MACD: {e}")
            return {"macd": 0, "signal": 0, "histogram": 0}
    
    def calculate_ema(self, prices: List[float], period: int) -> float:
        """Calculate Exponential Moving Average"""
        try:
            if len(prices) < period:
                return prices[-1] if prices else 0
            
            # Calculate multiplier
            multiplier = 2 / (period + 1)
            
            # Calculate initial SMA
            sma = sum(prices[-period:]) / period
            
            # Calculate EMA
            ema = sma
            for i in range(len(prices) - period):
                ema = (prices[-(i+1)] - ema) * multiplier + ema
            
            return ema
            
        except Exception as e:
            logger.error(f"Error calculating EMA: {e}")
            return prices[-1] if prices else 0
    
    def calculate_sma(self, prices: List[float], period: int) -> float:
        """Calculate Simple Moving Average"""
        try:
            if len(prices) < period:
                return prices[-1] if prices else 0
            
            return sum(prices[-period:]) / period
            
        except Exception as e:
            logger.error(f"Error calculating SMA: {e}")
            return prices[-1] if prices else 0
    
    def calculate_bollinger_bands(self, prices: List[float], period: int = 20, std_dev: float = 2.0) -> Dict[str, float]:
        """Calculate Bollinger Bands"""
        try:
            if len(prices) < period:
                price = prices[-1] if prices else 0
                return {"upper": price, "middle": price, "lower": price}
            
            # Calculate middle band (SMA)
            middle = self.calculate_sma(prices, period)
            
            # Calculate standard deviation
            recent_prices = prices[-period:]
            std = (sum([(price - middle) ** 2 for price in recent_prices]) / period) ** 0.5
            
            # Calculate upper and lower bands
            upper = middle + (std_dev * std)
            lower = middle - (std_dev * std)
            
            return {
                "upper": round(upper, 4),
                "middle": round(middle, 4),
                "lower": round(lower, 4)
            }
            
        except Exception as e:
            logger.error(f"Error calculating Bollinger Bands: {e}")
            price = prices[-1] if prices else 0
            return {"upper": price, "middle": price, "lower": price}
    
    def calculate_atr(self, highs: List[float], lows: List[float], closes: List[float], period: int = 14) -> float:
        """Calculate Average True Range"""
        try:
            if len(highs) < period + 1 or len(lows) < period + 1 or len(closes) < period + 1:
                return 0
            
            # Calculate True Range
            true_ranges = []
            for i in range(1, len(highs)):
                high = highs[i]
                low = lows[i]
                prev_close = closes[i-1]
                
                tr1 = high - low
                tr2 = abs(high - prev_close)
                tr3 = abs(low - prev_close)
                
                true_range = max(tr1, tr2, tr3)
                true_ranges.append(true_range)
            
            # Calculate ATR
            atr = sum(true_ranges[-period:]) / period
            return round(atr, 4)
            
        except Exception as e:
            logger.error(f"Error calculating ATR: {e}")
            return 0
    
    def calculate_obv(self, closes: List[float], volumes: List[float]) -> float:
        """Calculate On-Balance Volume"""
        try:
            if len(closes) < 2 or len(volumes) < 2:
                return 0
            
            obv = 0
            for i in range(1, len(closes)):
                if closes[i] > closes[i-1]:
                    obv += volumes[i]
                elif closes[i] < closes[i-1]:
                    obv -= volumes[i]
                # If prices are equal, OBV doesn't change
            
            return obv
            
        except Exception as e:
            logger.error(f"Error calculating OBV: {e}")
            return 0
"""
WebSocket Service
Handles WebSocket connections, real-time data streaming, and background tasks
"""

import asyncio
import json
import logging
import time
from typing import Dict, List, Any, Set, Optional
from datetime import datetime
import random
from fastapi import WebSocket, WebSocketDisconnect

# Import services
from .market_data_service import MarketDataService
from .signal_service import SignalService
from .simplified_signal_service import SimplifiedSignalService

logger = logging.getLogger(__name__)

class ConnectionManager:
    """WebSocket connection manager"""
    
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}
        self.user_connections: Dict[str, Set[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, client_id: str, user_id: Optional[str] = None):
        """Connect a new WebSocket client"""
        await websocket.accept()
        
        # Add to active connections
        if client_id not in self.active_connections:
            self.active_connections[client_id] = []
        self.active_connections[client_id].append(websocket)
        
        # Add to user connections if authenticated
        if user_id:
            if user_id not in self.user_connections:
                self.user_connections[user_id] = set()
            self.user_connections[user_id].add(websocket)
        
        logger.info(f"Client {client_id} connected. Total connections: {self.get_connection_count()}")
    
    def disconnect(self, websocket: WebSocket, client_id: str, user_id: Optional[str] = None):
        """Disconnect a WebSocket client"""
        # Remove from active connections
        if client_id in self.active_connections:
            if websocket in self.active_connections[client_id]:
                self.active_connections[client_id].remove(websocket)
            if not self.active_connections[client_id]:
                del self.active_connections[client_id]
        
        # Remove from user connections
        if user_id and user_id in self.user_connections:
            if websocket in self.user_connections[user_id]:
                self.user_connections[user_id].remove(websocket)
            if not self.user_connections[user_id]:
                del self.user_connections[user_id]
        
        logger.info(f"Client {client_id} disconnected. Total connections: {self.get_connection_count()}")
    
    async def send_personal_message(self, message: Dict[str, Any], websocket: WebSocket):
        """Send a message to a specific client"""
        try:
            await websocket.send_text(json.dumps(message, default=str))
        except Exception as e:
            logger.error(f"Failed to send personal message: {e}")
    
    async def broadcast(self, message: Dict[str, Any], client_id: str = None):
        """Broadcast a message to all clients or a specific client group"""
        if client_id:
            # Send to specific client group
            if client_id in self.active_connections:
                for connection in self.active_connections[client_id][:]:
                    try:
                        await connection.send_text(json.dumps(message, default=str))
                    except Exception as e:
                        logger.error(f"Failed to send to client {client_id}: {e}")
                        # Connection might be dead, remove it
                        self.active_connections[client_id].remove(connection)
        else:
            # Broadcast to all connections
            for client_id, connections in list(self.active_connections.items()):
                for connection in connections[:]:
                    try:
                        await connection.send_text(json.dumps(message, default=str))
                    except Exception as e:
                        logger.error(f"Failed to broadcast to client {client_id}: {e}")
                        # Connection might be dead, remove it
                        connections.remove(connection)
    
    async def broadcast_to_user(self, user_id: str, message: Dict[str, Any]):
        """Broadcast a message to all connections of a specific user"""
        if user_id in self.user_connections:
            for connection in list(self.user_connections[user_id]):
                try:
                    await connection.send_text(json.dumps(message, default=str))
                except Exception as e:
                    logger.error(f"Failed to send to user {user_id}: {e}")
                    # Connection might be dead, remove it
                    self.user_connections[user_id].remove(connection)
    
    def get_connection_count(self) -> int:
        """Get total number of active connections"""
        return sum(len(connections) for connections in self.active_connections.values())

class WebSocketManager:
    """WebSocket manager for handling real-time data and background tasks"""
    
    def __init__(self):
        self.connection_manager = ConnectionManager()
        self.market_data_service = MarketDataService()
        self.signal_service = SignalService()
        self.simplified_signal_service = SimplifiedSignalService()
        self.running = False
        self.status = "initializing"
        self.subscriptions: Dict[str, Set[str]] = {}  # client_id -> set of symbols
        self.user_subscriptions: Dict[str, Set[str]] = {}  # user_id -> set of subscription types
    
    async def initialize(self):
        """Initialize the WebSocket manager"""
        self.running = True
        self.status = "online"
        logger.info("WebSocket manager initialized")
    
    async def shutdown(self):
        """Shutdown the WebSocket manager"""
        self.running = False
        self.status = "offline"
        logger.info("WebSocket manager shutdown")
    
    async def handle_connection(self, websocket: WebSocket, client_id: str, user_id: Optional[str] = None):
        """Handle a WebSocket connection"""
        await self.connection_manager.connect(websocket, client_id, user_id)
        
        try:
            # Send welcome message
            await self.connection_manager.send_personal_message(
                {
                    "type": "connection_established",
                    "client_id": client_id,
                    "timestamp": datetime.now().isoformat(),
                    "message": "Connected to AiSmart Trader WebSocket"
                },
                websocket
            )
            
            # Handle messages
            while True:
                data = await websocket.receive_text()
                await self.handle_message(websocket, client_id, user_id, data)
                
        except WebSocketDisconnect:
            self.connection_manager.disconnect(websocket, client_id, user_id)
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            self.connection_manager.disconnect(websocket, client_id, user_id)
    
    async def handle_message(self, websocket: WebSocket, client_id: str, user_id: Optional[str], data: str):
        """Handle a WebSocket message"""
        try:
            message = json.loads(data)
            message_type = message.get("type")
            
            if message_type == "ping":
                # Respond to ping
                await self.connection_manager.send_personal_message(
                    {"type": "pong", "timestamp": datetime.now().isoformat()},
                    websocket
                )
            
            elif message_type == "subscribe":
                # Handle subscription
                await self.handle_subscription(websocket, client_id, user_id, message)
            
            elif message_type == "unsubscribe":
                # Handle unsubscription
                await self.handle_unsubscription(websocket, client_id, user_id, message)
            
            else:
                # Unknown message type
                await self.connection_manager.send_personal_message(
                    {"type": "error", "message": f"Unknown message type: {message_type}"},
                    websocket
                )
                
        except json.JSONDecodeError:
            await self.connection_manager.send_personal_message(
                {"type": "error", "message": "Invalid JSON"},
                websocket
            )
        except Exception as e:
            logger.error(f"Error handling message: {e}")
            await self.connection_manager.send_personal_message(
                {"type": "error", "message": f"Error: {str(e)}"},
                websocket
            )
    
    async def handle_subscription(self, websocket: WebSocket, client_id: str, user_id: Optional[str], message: Dict[str, Any]):
        """Handle a subscription request"""
        channel = message.get("channel")
        symbols = message.get("symbols", [])
        
        if not channel:
            await self.connection_manager.send_personal_message(
                {"type": "error", "message": "Missing channel in subscription"},
                websocket
            )
            return
        
        # Initialize client subscriptions if needed
        if client_id not in self.subscriptions:
            self.subscriptions[client_id] = set()
        
        # Add subscriptions
        if channel == "ticker":
            for symbol in symbols:
                subscription_key = f"ticker:{symbol}"
                self.subscriptions[client_id].add(subscription_key)
        
        elif channel == "kline":
            interval = message.get("interval", "1m")
            for symbol in symbols:
                subscription_key = f"kline:{symbol}:{interval}"
                self.subscriptions[client_id].add(subscription_key)
        
        elif channel == "orderbook":
            for symbol in symbols:
                subscription_key = f"orderbook:{symbol}"
                self.subscriptions[client_id].add(subscription_key)
        
        elif channel == "signals":
            if user_id:
                if user_id not in self.user_subscriptions:
                    self.user_subscriptions[user_id] = set()
                self.user_subscriptions[user_id].add("signals")
        
        elif channel == "portfolio":
            if user_id:
                if user_id not in self.user_subscriptions:
                    self.user_subscriptions[user_id] = set()
                self.user_subscriptions[user_id].add("portfolio")
        
        # Confirm subscription
        await self.connection_manager.send_personal_message(
            {
                "type": "subscription_success",
                "channel": channel,
                "symbols": symbols,
                "timestamp": datetime.now().isoformat()
            },
            websocket
        )
    
    async def handle_unsubscription(self, websocket: WebSocket, client_id: str, user_id: Optional[str], message: Dict[str, Any]):
        """Handle an unsubscription request"""
        channel = message.get("channel")
        symbols = message.get("symbols", [])
        
        if not channel:
            await self.connection_manager.send_personal_message(
                {"type": "error", "message": "Missing channel in unsubscription"},
                websocket
            )
            return
        
        # Remove subscriptions
        if client_id in self.subscriptions:
            if channel == "ticker":
                for symbol in symbols:
                    subscription_key = f"ticker:{symbol}"
                    if subscription_key in self.subscriptions[client_id]:
                        self.subscriptions[client_id].remove(subscription_key)
            
            elif channel == "kline":
                interval = message.get("interval", "1m")
                for symbol in symbols:
                    subscription_key = f"kline:{symbol}:{interval}"
                    if subscription_key in self.subscriptions[client_id]:
                        self.subscriptions[client_id].remove(subscription_key)
            
            elif channel == "orderbook":
                for symbol in symbols:
                    subscription_key = f"orderbook:{symbol}"
                    if subscription_key in self.subscriptions[client_id]:
                        self.subscriptions[client_id].remove(subscription_key)
        
        if channel == "signals" and user_id and user_id in self.user_subscriptions:
            if "signals" in self.user_subscriptions[user_id]:
                self.user_subscriptions[user_id].remove("signals")
        
        elif channel == "portfolio" and user_id and user_id in self.user_subscriptions:
            if "portfolio" in self.user_subscriptions[user_id]:
                self.user_subscriptions[user_id].remove("portfolio")
        
        # Confirm unsubscription
        await self.connection_manager.send_personal_message(
            {
                "type": "unsubscription_success",
                "channel": channel,
                "symbols": symbols,
                "timestamp": datetime.now().isoformat()
            },
            websocket
        )
    
    async def start_market_data_task(self):
        """Start the market data background task"""
        logger.info("Starting market data task")
        
        while self.running:
            try:
                # Get all subscribed symbols
                all_symbols = set()
                for subscriptions in self.subscriptions.values():
                    for subscription in subscriptions:
                        if subscription.startswith("ticker:"):
                            symbol = subscription.split(":")[1]
                            all_symbols.add(symbol)
                
                # Fetch and broadcast ticker data
                if all_symbols:
                    tickers = await self.market_data_service.get_tickers(list(all_symbols))
                    
                    for ticker in tickers:
                        symbol = ticker.get("symbol")
                        
                        # Find clients subscribed to this symbol
                        for client_id, subscriptions in self.subscriptions.items():
                            if f"ticker:{symbol}" in subscriptions:
                                await self.connection_manager.broadcast(
                                    {
                                        "type": "ticker_update",
                                        "data": ticker,
                                        "timestamp": datetime.now().isoformat()
                                    },
                                    client_id
                                )
                
                # Sleep before next update
                await asyncio.sleep(5)  # Update every 5 seconds
                
            except Exception as e:
                logger.error(f"Error in market data task: {e}")
                await asyncio.sleep(10)  # Wait longer on error
    
    async def start_signal_generation_task(self):
        """Start the signal generation background task"""
        logger.info("Starting signal generation task")
        
        while self.running:
            try:
                # Get all users subscribed to signals
                signal_users = [
                    user_id for user_id, subscriptions in self.user_subscriptions.items()
                    if "signals" in subscriptions
                ]
                
                # Generate and broadcast signals
                if signal_users:
                    # Get top symbols
                    top_symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT"]
                    
                    # Generate signals for each user
                    for user_id in signal_users:
                        # Generate simplified signals
                        signals = await self.simplified_signal_service.get_signals(
                            user_id=user_id,
                            symbols=top_symbols,
                            min_confidence=60
                        )
                        
                        if signals:
                            # Broadcast signals to user
                            await self.connection_manager.broadcast_to_user(
                                user_id,
                                {
                                    "type": "signal_update",
                                    "data": signals,
                                    "timestamp": datetime.now().isoformat()
                                }
                            )
                
                # Sleep before next update
                await asyncio.sleep(60)  # Update every minute
                
            except Exception as e:
                logger.error(f"Error in signal generation task: {e}")
                await asyncio.sleep(60)  # Wait longer on error
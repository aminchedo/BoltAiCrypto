"""
Simplified Signal Service
A non-AI version of the signal service that uses basic technical indicators
"""

import asyncio
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import random

# Import services
from .market_data_service import MarketDataService
from .technical_analysis_service import TechnicalAnalysisService

logger = logging.getLogger(__name__)

class SimplifiedSignalService:
    """Service for generating trading signals using basic technical analysis"""
    
    def __init__(self):
        self.market_service = MarketDataService()
        self.ta_service = TechnicalAnalysisService()
        
        # Signal cache
        self.signal_cache: Dict[str, Dict[str, Any]] = {}
        self.cache_expiry: Dict[str, datetime] = {}
        self.CACHE_DURATION = timedelta(minutes=5)
    
    async def get_signals(
        self, 
        user_id: str, 
        symbols: Optional[List[str]] = None,
        min_confidence: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """Get trading signals for multiple symbols"""
        if not symbols:
            # Default to top symbols
            symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT"]
        
        signals = []
        
        # Generate signals for each symbol
        for symbol in symbols:
            try:
                signal = await self.get_signal_for_symbol(user_id, symbol)
                if signal and (min_confidence is None or signal["confidence"] >= min_confidence):
                    signals.append(signal)
            except Exception as e:
                logger.error(f"Error generating signal for {symbol}: {e}")
        
        return signals
    
    async def get_signal_for_symbol(self, user_id: str, symbol: str) -> Optional[Dict[str, Any]]:
        """Get signal for a specific symbol"""
        # Check cache
        cache_key = f"{user_id}:{symbol}"
        if cache_key in self.signal_cache and datetime.now() < self.cache_expiry.get(cache_key, datetime.min):
            return self.signal_cache[cache_key]
        
        try:
            # Get historical data
            candles = await self.market_service.get_candles(
                symbol=symbol,
                interval="1h",
                limit=100
            )
            
            if not candles or len(candles) < 50:
                logger.warning(f"Insufficient data for {symbol}")
                return None
            
            # Calculate technical indicators
            ta_result = await self.ta_service.calculate_indicators(symbol, candles)
            
            # Extract key indicators
            rsi = ta_result.get("rsi", 50)
            macd = ta_result.get("macd", {"macd": 0, "signal": 0, "histogram": 0})
            
            # Calculate score based on indicators
            score = 0
            
            # RSI contribution
            if rsi < 30:
                score += 0.8  # Oversold - bullish
            elif rsi > 70:
                score -= 0.8  # Overbought - bearish
            elif rsi > 45 and rsi < 55:
                score += 0.2  # Neutral
            
            # MACD contribution
            if macd["histogram"] > 0 and macd["macd"] > macd["signal"]:
                score += 0.6  # Bullish
            elif macd["histogram"] < 0 and macd["macd"] < macd["signal"]:
                score -= 0.6  # Bearish
            
            # Normalize score to -1 to 1 range
            score = max(-1, min(1, score))
            
            # Determine signal direction and confidence
            direction = "BUY" if score > 0.1 else "SELL" if score < -0.1 else "HOLD"
            confidence = min(abs(score) * 100, 100)
            
            if confidence < 60:
                return None  # Don't generate low-confidence signals
            
            # Get current price
            current_price = candles[-1]["close"]
            
            # Calculate volatility for stop loss and take profit
            volatility = self.calculate_volatility(candles)
            
            # Calculate entry, stop loss, and take profit
            stop_loss_distance = volatility * 2
            take_profit_distance = volatility * 3
            
            stop_loss = current_price - stop_loss_distance if direction == "BUY" else current_price + stop_loss_distance
            take_profit = current_price + take_profit_distance if direction == "BUY" else current_price - take_profit_distance
            
            # Create signal
            signal = {
                "id": f"{symbol}_{int(datetime.now().timestamp())}",
                "symbol": symbol,
                "direction": direction,
                "confidence": round(confidence),
                "entryPrice": current_price,
                "stopLoss": stop_loss,
                "takeProfit": take_profit,
                "riskRewardRatio": take_profit_distance / stop_loss_distance,
                "timestamp": int(datetime.now().timestamp() * 1000),
                "expiresAt": int((datetime.now() + timedelta(hours=4)).timestamp() * 1000),
                "status": "ACTIVE",
                "technicalAnalysis": {
                    "rsi": rsi,
                    "macd": macd,
                    "score": score
                },
                "riskAssessment": {
                    "riskScore": 50,  # Default risk score
                    "maxLossAmount": stop_loss_distance,
                    "positionSizeRecommendation": 2.0,  # Default position size
                },
                "marketConditions": {
                    "volatility": (volatility / current_price) * 100,
                    "supportResistance": self.find_support_resistance(candles)
                }
            }
            
            # Cache signal
            self.signal_cache[cache_key] = signal
            self.cache_expiry[cache_key] = datetime.now() + self.CACHE_DURATION
            
            return signal
            
        except Exception as e:
            logger.error(f"Error generating signal for {symbol}: {e}")
            return None
    
    def calculate_volatility(self, candles: List[Dict[str, Any]]) -> float:
        """Calculate volatility using Average True Range (ATR)"""
        try:
            if len(candles) < 14:
                return 0
            
            # Calculate True Range
            true_ranges = []
            for i in range(1, len(candles)):
                high = candles[i]["high"]
                low = candles[i]["low"]
                prev_close = candles[i-1]["close"]
                
                tr1 = high - low
                tr2 = abs(high - prev_close)
                tr3 = abs(low - prev_close)
                
                true_range = max(tr1, tr2, tr3)
                true_ranges.append(true_range)
            
            # Calculate ATR (14-period)
            atr = sum(true_ranges[-14:]) / 14
            return atr
            
        except Exception as e:
            logger.error(f"Error calculating volatility: {e}")
            return 0
    
    def find_support_resistance(self, candles: List[Dict[str, Any]]) -> Dict[str, float]:
        """Find support and resistance levels"""
        try:
            highs = [c["high"] for c in candles]
            lows = [c["low"] for c in candles]
            
            # Simple support/resistance calculation
            recent_highs = highs[-20:]
            recent_lows = lows[-20:]
            
            resistance = max(recent_highs)
            support = min(recent_lows)
            
            return {"support": support, "resistance": resistance}
            
        except Exception as e:
            logger.error(f"Error finding support/resistance: {e}")
            return {"support": 0, "resistance": 0}
import logging
import random
import asyncio
import aiohttp
import json
import time
from typing import List, Dict, Any, Optional, Set
from datetime import datetime, timedelta
from functools import lru_cache
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
import pandas as pd
import numpy as np
from pydantic import BaseModel, ValidationError, Field
import redis.asyncio as redis
from prometheus_client import Counter, Histogram
from aiohttp import ClientSession, ClientWebSocketResponse

# ML Libraries
try:
    import tensorflow as tf
    from sklearn.model_selection import train_test_split, TimeSeriesSplit
    from sklearn.preprocessing import StandardScaler
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.metrics import mean_squared_error, r2_score
    import xgboost as xgb
    import joblib
    HAS_ML_LIBS = True
except ImportError:
    HAS_ML_LIBS = False
    logging.warning("ML libraries not available. Install tensorflow, scikit-learn, xgboost")

logger = logging.getLogger(__name__)

# Prometheus metrics
REQUESTS = Counter('market_data_requests_total', 'Total market data requests', ['endpoint'])
LATENCY = Histogram('market_data_latency_seconds', 'Request latency', ['endpoint'])

# Pydantic models for data validation
class TickerData(BaseModel):
    symbol: str
    price: float = Field(ge=0)
    priceChange: float
    priceChangePercent: float
    volume: float = Field(ge=0)
    high24h: float = Field(ge=0)
    low24h: float = Field(ge=0)
    timestamp: int = Field(ge=0)

class CandleData(BaseModel):
    timestamp: int = Field(ge=0)
    open: float = Field(ge=0)
    high: float = Field(ge=0)
    low: float = Field(ge=0)
    close: float = Field(ge=0)
    volume: float = Field(ge=0)

class OrderBookData(BaseModel):
    symbol: str
    bids: List[List[float]]
    asks: List[List[float]]
    timestamp: int = Field(ge=0)

class TradeData(BaseModel):
    id: str
    price: float = Field(ge=0)
    quantity: float = Field(ge=0)
    time: int = Field(ge=0)
    isBuyerMaker: bool
    isBestMatch: bool

@dataclass
class ExchangeConfig:
    name: str
    api_url: str
    ws_url: str
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    rate_limit_per_second: int = 10

class MarketDataService:
    """Enhanced service for fetching and streaming market data with ML integration"""

    def __init__(self, exchange_configs: List[ExchangeConfig] = None, redis_url: str = "redis://localhost:6379"):
        self.exchanges = exchange_configs or [
            ExchangeConfig(
                name="mock",
                api_url="https://api.mockexchange.com",
                ws_url="wss://ws.mockexchange.com",
                rate_limit_per_second=10
            )
        ]
        self.redis = redis.from_url(redis_url)
        self.session: Optional[ClientSession] = None
        self.ws_connections: Dict[str, Set[ClientWebSocketResponse]] = defaultdict(set)
        self.rate_limiter = defaultdict(lambda: asyncio.Semaphore(10))
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.subscriptions: Set[str] = set()
        self._initialize_session()

    def _initialize_session(self):
        """Initialize aiohttp session"""
        if not self.session:
            self.session = ClientSession()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Clean up resources"""
        if self.session:
            await self.session.close()
        for ws_set in self.ws_connections.values():
            for ws in ws_set:
                await ws.close()
        await self.redis.close()

    async def get_tickers(self, symbols: List[str], exchange: str = "mock") -> List[Dict[str, Any]]:
        """Get ticker data for multiple symbols"""
        with LATENCY.labels(endpoint='tickers').time():
            REQUESTS.labels(endpoint='tickers').inc()
            tickers = []
            async with self.rate_limiter[exchange]:
                for symbol in symbols:
                    try:
                        ticker = await self._get_ticker_with_retry(symbol, exchange)
                        tickers.append(ticker)
                    except Exception as e:
                        logger.error(f"Error fetching ticker for {symbol}: {e}")
            return tickers

    async def get_ticker(self, symbol: str, exchange: str = "mock") -> Optional[Dict[str, Any]]:
        """Get ticker data for a single symbol"""
        with LATENCY.labels(endpoint='ticker').time():
            REQUESTS.labels(endpoint='ticker').inc()
            try:
                cache_key = f"ticker:{exchange}:{symbol}"
                cached = await self.redis.get(cache_key)
                if cached:
                    return TickerData(**json.loads(cached)).dict()
                ticker = await self._get_ticker_with_retry(symbol, exchange)
                await self.redis.setex(cache_key, 300, json.dumps(ticker))
                return ticker
            except ValidationError as e:
                logger.error(f"Invalid ticker data for {symbol}: {e}")
                return None

    async def get_candles(
        self,
        symbol: str,
        exchange: str = "mock",
        interval: str = "1h",
        limit: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Get candlestick data for a symbol"""
        with LATENCY.labels(endpoint='candles').time():
            REQUESTS.labels(endpoint='candles').inc()
            try:
                cache_key = f"candles:{exchange}:{symbol}:{interval}:{limit}"
                cached = await self.redis.get(cache_key)
                if cached:
                    return [CandleData(**c).dict() for c in json.loads(cached)]
                candles = await self._get_candles_with_retry(symbol, exchange, interval, limit)
                await self.redis.setex(cache_key, 3600, json.dumps(candles))
                return candles
            except ValidationError as e:
                logger.error(f"Invalid candle data for {symbol}: {e}")
                return []

    async def get_orderbook(self, symbol: str, exchange: str = "mock", limit: int = 20) -> Dict[str, Any]:
        """Get orderbook data for a symbol"""
        with LATENCY.labels(endpoint='orderbook').time():
            REQUESTS.labels(endpoint='orderbook').inc()
            try:
                cache_key = f"orderbook:{exchange}:{symbol}:{limit}"
                cached = await self.redis.get(cache_key)
                if cached:
                    return OrderBookData(**json.loads(cached)).dict()
                orderbook = await self._get_orderbook_with_retry(symbol, exchange, limit)
                await self.redis.setex(cache_key, 300, json.dumps(orderbook))
                return orderbook
            except ValidationError as e:
                logger.error(f"Invalid orderbook data for {symbol}: {e}")
                return {"bids": [], "asks": []}

    async def get_recent_trades(self, symbol: str, exchange: str = "mock", limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent trades for a symbol"""
        with LATENCY.labels(endpoint='trades').time():
            REQUESTS.labels(endpoint='trades').inc()
            try:
                cache_key = f"trades:{exchange}:{symbol}:{limit}"
                cached = await self.redis.get(cache_key)
                if cached:
                    return [TradeData(**t).dict() for t in json.loads(cached)]
                trades = await self._get_trades_with_retry(symbol, exchange, limit)
                await self.redis.setex(cache_key, 300, json.dumps(trades))
                return trades
            except ValidationError as e:
                logger.error(f"Invalid trade data for {symbol}: {e}")
                return []

    async def subscribe_to_ticker(self, symbol: str, exchange: str = "mock", callback: callable = None) -> None:
        """Subscribe to real-time ticker updates"""
        async with self.rate_limiter[exchange]:
            ws = await self._get_websocket(exchange)
            self.subscriptions.add(f"{exchange}:{symbol}:ticker")
            try:
                await ws.send_json({"type": "subscribe", "symbol": symbol, "channel": "ticker"})
                async for msg in ws:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        data = json.loads(msg.data)
                        try:
                            validated = TickerData(**data).dict()
                            if callback:
                                await callback(validated)
                        except ValidationError as e:
                            logger.error(f"Invalid ticker data: {e}")
            except Exception as e:
                logger.error(f"WebSocket error for {symbol}: {e}")
                await self._reconnect_websocket(exchange)

    async def _get_ticker_with_retry(self, symbol: str, exchange: str, retries: int = 3) -> Dict[str, Any]:
        """Fetch ticker with retry logic"""
        for attempt in range(retries):
            try:
                if exchange == "mock":
                    ticker = self.generate_mock_ticker(symbol)
                    return TickerData(**ticker).dict()
                async with self.session.get(f"{self._get_exchange(exchange).api_url}/ticker/{symbol}") as resp:
                    data = await resp.json()
                    return TickerData(**data).dict()
            except Exception as e:
                if attempt == retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)
        return {}

    async def _get_candles_with_retry(self, symbol: str, exchange: str, interval: str, limit: int, retries: int = 3) -> List[Dict[str, Any]]:
        """Fetch candles with retry logic"""
        for attempt in range(retries):
            try:
                if exchange == "mock":
                    candles = self.generate_mock_candles(symbol, interval, limit)
                    return [CandleData(**c).dict() for c in candles]
                async with self.session.get(f"{self._get_exchange(exchange).api_url}/candles/{symbol}/{interval}?limit={limit}") as resp:
                    data = await resp.json()
                    return [CandleData(**c).dict() for c in data]
            except Exception as e:
                if attempt == retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)
        return []

    async def _get_orderbook_with_retry(self, symbol: str, exchange: str, limit: int, retries: int = 3) -> Dict[str, Any]:
        """Fetch orderbook with retry logic"""
        for attempt in range(retries):
            try:
                if exchange == "mock":
                    orderbook = self.generate_mock_orderbook(symbol, limit)
                    return OrderBookData(**orderbook).dict()
                async with self.session.get(f"{self._get_exchange(exchange).api_url}/orderbook/{symbol}?limit={limit}") as resp:
                    data = await resp.json()
                    return OrderBookData(**data).dict()
            except Exception as e:
                if attempt == retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)
        return {"bids": [], "asks": []}

    async def _get_trades_with_retry(self, symbol: str, exchange: str, limit: int, retries: int = 3) -> List[Dict[str, Any]]:
        """Fetch trades with retry logic"""
        for attempt in range(retries):
            try:
                if exchange == "mock":
                    trades = self.generate_mock_trades(symbol, limit)
                    return [TradeData(**t).dict() for t in trades]
                async with self.session.get(f"{self._get_exchange(exchange).api_url}/trades/{symbol}?limit={limit}") as resp:
                    data = await resp.json()
                    return [TradeData(**t).dict() for t in data]
            except Exception as e:
                if attempt == retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)
        return []

    async def _get_websocket(self, exchange: str) -> ClientWebSocketResponse:
        """Get or create WebSocket connection"""
        if exchange not in self.ws_connections or not self.ws_connections[exchange]:
            ws = await self.session.ws_connect(self._get_exchange(exchange).ws_url)
            self.ws_connections[exchange].add(ws)
        return next(iter(self.ws_connections[exchange]))

    async def _reconnect_websocket(self, exchange: str, max_attempts: int = 5):
        """Reconnect WebSocket with exponential backoff"""
        for attempt in range(max_attempts):
            try:
                ws = await self.session.ws_connect(self._get_exchange(exchange).ws_url)
                self.ws_connections[exchange].add(ws)
                logger.info(f"Reconnected WebSocket for {exchange}")
                return
            except Exception as e:
                logger.error(f"WebSocket reconnect attempt {attempt + 1} failed: {e}")
                await asyncio.sleep(2 ** attempt)
        logger.error(f"Failed to reconnect WebSocket for {exchange} after {max_attempts} attempts")

    def _get_exchange(self, exchange_name: str) -> ExchangeConfig:
        """Get exchange configuration"""
        for config in self.exchanges:
            if config.name == exchange_name:
                return config
        raise ValueError(f"Exchange {exchange_name} not found")

    @lru_cache(maxsize=100)
    def generate_mock_ticker(self, symbol: str) -> Dict[str, Any]:
        """Generate mock ticker data"""
        base_price = self.get_base_price_for_symbol(symbol)
        price_change = random.uniform(-2, 2) / 100
        price = base_price * (1 + price_change)
        volume = base_price * random.uniform(100, 1000)
        return {
            "symbol": symbol,
            "price": round(price, 2),
            "priceChange": round(price_change * 100, 2),
            "priceChangePercent": round(price_change * 100, 2),
            "volume": round(volume, 2),
            "high24h": round(price * (1 + random.uniform(0.005, 0.02)), 2),
            "low24h": round(price * (1 - random.uniform(0.005, 0.02)), 2),
            "timestamp": int(datetime.now().timestamp() * 1000)
        }

    @lru_cache(maxsize=100)
    def generate_mock_candles(self, symbol: str, interval: str, limit: int) -> List[Dict[str, Any]]:
        """Generate mock candlestick data"""
        base_price = self.get_base_price_for_symbol(symbol)
        candles = []
        interval_seconds = self.interval_to_seconds(interval)
        end_time = datetime.now()
        for i in range(limit):
            candle_time = end_time - timedelta(seconds=interval_seconds * (limit - i - 1))
            price_change = random.uniform(-1.5, 1.5) / 100
            close_price = base_price * (1 + price_change * (i / limit))
            open_price = close_price * (1 + random.uniform(-0.5, 0.5) / 100)
            high_price = max(open_price, close_price) * (1 + random.uniform(0.1, 0.5) / 100)
            low_price = min(open_price, close_price) * (1 - random.uniform(0.1, 0.5) / 100)
            volume = base_price * random.uniform(50, 500)
            candles.append({
                "timestamp": int(candle_time.timestamp() * 1000),
                "open": round(open_price, 2),
                "high": round(high_price, 2),
                "low": round(low_price, 2),
                "close": round(close_price, 2),
                "volume": round(volume, 2)
            })
            base_price = close_price
        return candles

    @lru_cache(maxsize=100)
    def generate_mock_orderbook(self, symbol: str, limit: int) -> Dict[str, Any]:
        """Generate mock orderbook data"""
        base_price = self.get_base_price_for_symbol(symbol)
        bids, asks = [], []
        for i in range(limit):
            bid_price = base_price * (1 - (i + 1) * 0.001)
            bid_quantity = random.uniform(0.1, 10) * (limit - i) / limit
            bids.append([round(bid_price, 2), round(bid_quantity, 4)])
            ask_price = base_price * (1 + (i + 1) * 0.001)
            ask_quantity = random.uniform(0.1, 10) * (limit - i) / limit
            asks.append([round(ask_price, 2), round(ask_quantity, 4)])
        return {
            "symbol": symbol,
            "bids": bids,
            "asks": asks,
            "timestamp": int(datetime.now().timestamp() * 1000)
        }

    @lru_cache(maxsize=100)
    def generate_mock_trades(self, symbol: str, limit: int) -> List[Dict[str, Any]]:
        """Generate mock trade data"""
        base_price = self.get_base_price_for_symbol(symbol)
        trades = []
        end_time = datetime.now()
        for i in range(limit):
            trade_time = end_time - timedelta(seconds=(limit - i) * 5)
            price_change = random.uniform(-0.5, 0.5) / 100
            price = base_price * (1 + price_change)
            quantity = random.uniform(0.01, 5)
            trades.append({
                "id": f"{symbol}_{int(trade_time.timestamp())}_{i}",
                "price": round(price, 2),
                "quantity": round(quantity, 4),
                "time": int(trade_time.timestamp() * 1000),
                "isBuyerMaker": random.choice([True, False]),
                "isBestMatch": random.choice([True, False])
            })
        return trades

    def get_base_price_for_symbol(self, symbol: str) -> float:
        """Get a base price for a symbol"""
        symbol_prices = {
            "BTCUSDT": 50000,
            "ETHUSDT": 3000,
            "BNBUSDT": 400,
            "SOLUSDT": 100,
            "ADAUSDT": 0.5,
            "XRPUSDT": 0.6,
            "DOGEUSDT": 0.1,
            "DOTUSDT": 15,
            "UNIUSDT": 10,
            "LINKUSDT": 20
        }
        return symbol_prices.get(symbol, 100)

    @lru_cache(maxsize=100)
    def interval_to_seconds(self, interval: str) -> int:
        """Convert interval string to seconds"""
        unit = interval[-1]
        value = int(interval[:-1])
        if unit == 's':
            return value
        elif unit == 'm':
            return value * 60
        elif unit == 'h':
            return value * 3600
        elif unit == 'd':
            return value * 24 * 3600
        elif unit == 'w':
            return value * 7 * 24 * 3600
        return 3600  # Default to 1 hour

class ModelTrainingService:
    """Service for automated ML model training and management"""

    def __init__(self, market_data_service: MarketDataService, models_dir: str = "models"):
        if not HAS_ML_LIBS:
            raise ImportError("ML libraries not available")
        self.market_service = market_data_service
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(exist_ok=True)
        self.model_registry: Dict[str, Dict[str, Any]] = {}
        self.scaler = StandardScaler()

    async def train_price_prediction_model(
        self,
        symbol: str,
        lookback_window: int = 60,
        prediction_horizon: int = 1,
        features: List[str] = None,
        train_ratio: float = 0.8
    ) -> Dict[str, Any]:
        """Train a price prediction model"""
        logger.info(f"Training price prediction model for {symbol}")
        start_time = time.time()

        # Fetch and prepare data
        candles = await self.market_service.get_candles(symbol, interval="1h", limit=2000)
        if not candles:
            raise ValueError("No data available for training")

        df = pd.DataFrame(candles)
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)

        # Feature engineering
        df = self._engineer_features(df)

        # Prepare features and target
        features = features or ['open', 'high', 'low', 'close', 'volume', 'rsi', 'macd']
        X = df[features].values
        y = df['close'].shift(-prediction_horizon).values

        # Remove NaN rows
        mask = ~np.isnan(X).any(axis=1) & ~np.isnan(y)
        X, y = X[mask], y[mask]

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, train_size=train_ratio, shuffle=False
        )

        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # Train model
        model = RandomForestRegressor(n_estimators=100, random_state=42)
        model.fit(X_train_scaled, y_train)

        # Evaluate model
        predictions = model.predict(X_test_scaled)
        mse = mean_squared_error(y_test, predictions)
        r2 = r2_score(y_test, predictions)

        # Save model
        model_id = f"{symbol}_{int(time.time())}"
        model_path = self.models_dir / f"{model_id}.joblib"
        joblib.dump(model, model_path)

        result = {
            "model_id": model_id,
            "model_type": "random_forest",
            "mse": mse,
            "r2": r2,
            "training_time": time.time() - start_time,
            "model_path": str(model_path)
        }
        self.model_registry[model_id] = result

        logger.info(f"Model trained: {model_id}, R2: {r2:.4f}")
        return result

    def _engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Engineer features for ML model"""
        # Technical indicators
        df['rsi'] = self._calculate_rsi(df['close'])
        df['macd'], df['macd_signal'], _ = self._calculate_macd(df['close'])
        
        # Price features
        df['return_1h'] = df['close'].pct_change()
        df['volatility_24h'] = df['return_1h'].rolling(24).std()
        
        # Lag features
        for lag in [1, 3, 6]:
            df[f'close_lag_{lag}'] = df['close'].shift(lag)
        
        return df.dropna()

    def _calculate_rsi(self, prices: pd.Series, periods: int = 14) -> pd.Series:
        """Calculate Relative Strength Index"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=periods).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=periods).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    def _calculate_macd(self, prices: pd.Series) -> tuple:
        """Calculate MACD indicator"""
        exp1 = prices.ewm(span=12, adjust=False).mean()
        exp2 = prices.ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        histogram = macd - signal
        return macd, signal, histogram

async def main():
    """Example usage"""
    async with MarketDataService() as service:
        # Fetch tickers
        tickers = await service.get_tickers(["BTCUSDT", "ETHUSDT"])
        logger.info(f"Tickers: {tickers}")

        # Subscribe to real-time ticker updates
        async def ticker_callback(data):
            logger.info(f"Received ticker update: {data}")
        
        await service.subscribe_to_ticker("BTCUSDT", callback=ticker_callback)

        # Train a model
        training_service = ModelTrainingService(service)
        result = await training_service.train_price_prediction_model("BTCUSDT")
        logger.info(f"Training result: {result}")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())

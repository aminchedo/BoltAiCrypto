"""
Portfolio Optimization Service
Implements Modern Portfolio Theory, risk management, and portfolio rebalancing
"""

import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import statistics
import math
import random

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OptimizationMethod(Enum):
    """Portfolio optimization methods"""
    MEAN_VARIANCE = "mean_variance"
    RISK_PARITY = "risk_parity"
    KELLY_CRITERION = "kelly_criterion"
    BLACK_LITTERMAN = "black_litterman"
    MINIMUM_VARIANCE = "minimum_variance"
    MAXIMUM_SHARPE = "maximum_sharpe"

class RebalanceFrequency(Enum):
    """Rebalancing frequency options"""
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    THRESHOLD_BASED = "threshold_based"

class RiskLevel(Enum):
    """Risk tolerance levels"""
    CONSERVATIVE = "conservative"
    MODERATE = "moderate"
    AGGRESSIVE = "aggressive"
    VERY_AGGRESSIVE = "very_aggressive"

@dataclass
class Asset:
    """Asset information"""
    symbol: str
    name: str
    asset_type: str
    current_price: float
    market_cap: float
    volume_24h: float
    volatility: float
    beta: float
    correlation_btc: float

@dataclass
class Position:
    """Portfolio position"""
    asset: Asset
    quantity: float
    value: float
    weight: float
    target_weight: float
    drift: float
    last_rebalance: datetime

@dataclass
class PortfolioMetrics:
    """Portfolio performance metrics"""
    total_value: float
    total_return: float
    annualized_return: float
    volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    var_95: float
    var_99: float
    beta: float
    alpha: float
    information_ratio: float
    calmar_ratio: float

@dataclass
class OptimizationResult:
    """Portfolio optimization result"""
    method: str
    optimal_weights: Dict[str, float]
    expected_return: float
    expected_volatility: float
    sharpe_ratio: float
    risk_contribution: Dict[str, float]
    diversification_ratio: float
    confidence: float
    constraints_satisfied: bool

class RiskCalculator:
    """Calculates various risk metrics"""
    
    def __init__(self):
        self.confidence_levels = [0.95, 0.99]
        self.risk_free_rate = 0.02  # 2% annual risk-free rate
    
    def calculate_portfolio_risk(self, weights: Dict[str, float], 
                               covariance_matrix: Dict[str, Dict[str, float]],
                               returns: Dict[str, List[float]]) -> Dict[str, float]:
        """Calculate comprehensive portfolio risk metrics"""
        assets = list(weights.keys())
        
        # Portfolio variance
        portfolio_variance = 0
        for i, asset1 in enumerate(assets):
            for j, asset2 in enumerate(assets):
                if asset1 in covariance_matrix and asset2 in covariance_matrix[asset1]:
                    portfolio_variance += (weights[asset1] * weights[asset2] * 
                                         covariance_matrix[asset1][asset2])
        
        portfolio_volatility = math.sqrt(max(portfolio_variance, 0))
        
        # Portfolio returns for additional metrics
        portfolio_returns = self._calculate_portfolio_returns(weights, returns)
        
        # Value at Risk
        var_95 = self._calculate_var(portfolio_returns, 0.95) if portfolio_returns else 0
        var_99 = self._calculate_var(portfolio_returns, 0.99) if portfolio_returns else 0
        
        # Maximum Drawdown
        max_drawdown = self._calculate_max_drawdown(portfolio_returns) if portfolio_returns else 0
        
        # Downside deviation for Sortino ratio
        downside_deviation = self._calculate_downside_deviation(portfolio_returns)
        
        return {
            'volatility': portfolio_volatility,
            'var_95': var_95,
            'var_99': var_99,
            'max_drawdown': max_drawdown,
            'downside_deviation': downside_deviation
        }
    
    def _calculate_portfolio_returns(self, weights: Dict[str, float], 
                                   returns: Dict[str, List[float]]) -> List[float]:
        """Calculate portfolio returns from asset returns and weights"""
        if not returns or not weights:
            return []
        
        # Find minimum length across all assets
        min_length = min(len(returns[asset]) for asset in weights.keys() if asset in returns)
        
        if min_length == 0:
            return []
        
        portfolio_returns = []
        for i in range(min_length):
            portfolio_return = sum(weights[asset] * returns[asset][i] 
                                 for asset in weights.keys() if asset in returns)
            portfolio_returns.append(portfolio_return)
        
        return portfolio_returns
    
    def _calculate_var(self, returns: List[float], confidence_level: float) -> float:
        """Calculate Value at Risk"""
        if not returns:
            return 0
        
        sorted_returns = sorted(returns)
        index = int((1 - confidence_level) * len(sorted_returns))
        return abs(sorted_returns[index]) if index < len(sorted_returns) else 0
    
    def _calculate_max_drawdown(self, returns: List[float]) -> float:
        """Calculate maximum drawdown"""
        if not returns:
            return 0
        
        cumulative_returns = [1]
        for ret in returns:
            cumulative_returns.append(cumulative_returns[-1] * (1 + ret))
        
        peak = cumulative_returns[0]
        max_drawdown = 0
        
        for value in cumulative_returns[1:]:
            if value > peak:
                peak = value
            else:
                drawdown = (peak - value) / peak
                max_drawdown = max(max_drawdown, drawdown)
        
        return max_drawdown
    
    def _calculate_downside_deviation(self, returns: List[float], 
                                    target_return: float = 0) -> float:
        """Calculate downside deviation"""
        if not returns:
            return 0
        
        downside_returns = [min(0, ret - target_return) for ret in returns]
        downside_variance = statistics.variance(downside_returns) if len(downside_returns) > 1 else 0
        
        return math.sqrt(downside_variance)

class CovarianceEstimator:
    """Estimates covariance matrices for portfolio optimization"""
    
    def __init__(self):
        self.min_observations = 30
        self.shrinkage_factor = 0.2
    
    def estimate_covariance_matrix(self, returns: Dict[str, List[float]]) -> Dict[str, Dict[str, float]]:
        """Estimate covariance matrix from historical returns"""
        assets = list(returns.keys())
        
        # Check if we have enough data
        min_length = min(len(returns[asset]) for asset in assets) if assets else 0
        
        if min_length < self.min_observations:
            return self._generate_default_covariance_matrix(assets)
        
        # Align return series
        aligned_returns = {}
        for asset in assets:
            aligned_returns[asset] = returns[asset][-min_length:]
        
        # Calculate sample covariance matrix
        covariance_matrix = {}
        for asset1 in assets:
            covariance_matrix[asset1] = {}
            for asset2 in assets:
                if asset1 == asset2:
                    # Variance
                    variance = statistics.variance(aligned_returns[asset1]) if len(aligned_returns[asset1]) > 1 else 0.04
                    covariance_matrix[asset1][asset2] = variance
                else:
                    # Covariance
                    covariance = self._calculate_covariance(
                        aligned_returns[asset1], aligned_returns[asset2])
                    covariance_matrix[asset1][asset2] = covariance
        
        # Apply shrinkage to improve estimation
        shrunk_matrix = self._apply_shrinkage(covariance_matrix, assets)
        
        return shrunk_matrix
    
    def _calculate_covariance(self, returns1: List[float], returns2: List[float]) -> float:
        """Calculate covariance between two return series"""
        if len(returns1) != len(returns2) or len(returns1) < 2:
            return 0
        
        mean1 = statistics.mean(returns1)
        mean2 = statistics.mean(returns2)
        
        covariance = sum((r1 - mean1) * (r2 - mean2) for r1, r2 in zip(returns1, returns2))
        covariance /= (len(returns1) - 1)
        
        return covariance
    
    def _apply_shrinkage(self, sample_cov: Dict[str, Dict[str, float]], 
                        assets: List[str]) -> Dict[str, Dict[str, float]]:
        """Apply shrinkage to covariance matrix"""
        # Simple shrinkage towards diagonal matrix
        shrunk_matrix = {}
        
        # Calculate average variance for shrinkage target
        variances = [sample_cov[asset][asset] for asset in assets]
        avg_variance = statistics.mean(variances) if variances else 0.04
        
        for asset1 in assets:
            shrunk_matrix[asset1] = {}
            for asset2 in assets:
                if asset1 == asset2:
                    # Shrink variance towards average
                    shrunk_variance = ((1 - self.shrinkage_factor) * sample_cov[asset1][asset2] + 
                                     self.shrinkage_factor * avg_variance)
                    shrunk_matrix[asset1][asset2] = shrunk_variance
                else:
                    # Shrink covariance towards zero
                    shrunk_covariance = (1 - self.shrinkage_factor) * sample_cov[asset1][asset2]
                    shrunk_matrix[asset1][asset2] = shrunk_covariance
        
        return shrunk_matrix
    
    def _generate_default_covariance_matrix(self, assets: List[str]) -> Dict[str, Dict[str, float]]:
        """Generate default covariance matrix when insufficient data"""
        default_variance = 0.04  # 20% annual volatility
        default_correlation = 0.3  # 30% correlation
        
        covariance_matrix = {}
        for asset1 in assets:
            covariance_matrix[asset1] = {}
            for asset2 in assets:
                if asset1 == asset2:
                    covariance_matrix[asset1][asset2] = default_variance
                else:
                    # Covariance = correlation * sqrt(var1) * sqrt(var2)
                    covariance = default_correlation * default_variance
                    covariance_matrix[asset1][asset2] = covariance
        
        return covariance_matrix

class MeanVarianceOptimizer:
    """Implements Mean-Variance Optimization (Markowitz)"""
    
    def __init__(self):
        self.max_iterations = 1000
        self.tolerance = 1e-6
    
    def optimize(self, expected_returns: Dict[str, float],
                covariance_matrix: Dict[str, Dict[str, float]],
                constraints: Dict[str, Any] = None) -> OptimizationResult:
        """Perform mean-variance optimization"""
        assets = list(expected_returns.keys())
        n_assets = len(assets)
        
        if n_assets == 0:
            return self._empty_optimization_result()
        
        # Default constraints
        if not constraints:
            constraints = {
                'min_weight': 0.0,
                'max_weight': 1.0,
                'target_return': None,
                'target_risk': None
            }
        
        # Use simplified optimization for demonstration
        optimal_weights = self._simplified_optimization(
            assets, expected_returns, covariance_matrix, constraints)
        
        # Calculate portfolio metrics
        portfolio_return = sum(optimal_weights[asset] * expected_returns[asset] 
                             for asset in assets)
        
        portfolio_variance = 0
        for asset1 in assets:
            for asset2 in assets:
                portfolio_variance += (optimal_weights[asset1] * optimal_weights[asset2] * 
                                     covariance_matrix[asset1][asset2])
        
        portfolio_volatility = math.sqrt(max(portfolio_variance, 0))
        sharpe_ratio = (portfolio_return - 0.02) / portfolio_volatility if portfolio_volatility > 0 else 0
        
        # Calculate risk contributions
        risk_contributions = self._calculate_risk_contributions(
            optimal_weights, covariance_matrix, portfolio_variance)
        
        return OptimizationResult(
            method=OptimizationMethod.MEAN_VARIANCE.value,
            optimal_weights=optimal_weights,
            expected_return=portfolio_return,
            expected_volatility=portfolio_volatility,
            sharpe_ratio=sharpe_ratio,
            risk_contribution=risk_contributions,
            diversification_ratio=self._calculate_diversification_ratio(
                optimal_weights, covariance_matrix),
            confidence=0.8,
            constraints_satisfied=True
        )
    
    def _simplified_optimization(self, assets: List[str], 
                               expected_returns: Dict[str, float],
                               covariance_matrix: Dict[str, Dict[str, float]],
                               constraints: Dict[str, Any]) -> Dict[str, float]:
        """Simplified optimization using heuristic approach"""
        # Start with equal weights
        weights = {asset: 1.0 / len(assets) for asset in assets}
        
        # Adjust weights based on expected returns and risk
        for _ in range(100):  # Simple iterative improvement
            # Calculate current portfolio metrics
            portfolio_return = sum(weights[asset] * expected_returns[asset] for asset in assets)
            
            # Adjust weights towards higher return/lower risk assets
            new_weights = {}
            total_adjustment = 0
            
            for asset in assets:
                # Simple adjustment based on return and individual risk
                asset_variance = covariance_matrix[asset][asset]
                asset_risk = math.sqrt(asset_variance) if asset_variance > 0 else 0.2
                
                # Risk-adjusted return
                risk_adj_return = expected_returns[asset] / max(asset_risk, 0.01)
                
                # Adjust weight
                adjustment = risk_adj_return * 0.01  # Small adjustment factor
                new_weight = max(constraints.get('min_weight', 0), 
                               min(constraints.get('max_weight', 1), 
                                   weights[asset] + adjustment))
                new_weights[asset] = new_weight
                total_adjustment += new_weight
            
            # Normalize weights
            if total_adjustment > 0:
                weights = {asset: weight / total_adjustment 
                          for asset, weight in new_weights.items()}
        
        return weights
    
    def _calculate_risk_contributions(self, weights: Dict[str, float],
                                    covariance_matrix: Dict[str, Dict[str, float]],
                                    portfolio_variance: float) -> Dict[str, float]:
        """Calculate risk contributions of each asset"""
        risk_contributions = {}
        
        if portfolio_variance <= 0:
            return {asset: 1.0 / len(weights) for asset in weights.keys()}
        
        for asset in weights.keys():
            # Marginal contribution to risk
            marginal_contrib = 0
            for other_asset in weights.keys():
                marginal_contrib += weights[other_asset] * covariance_matrix[asset][other_asset]
            
            # Risk contribution
            risk_contrib = weights[asset] * marginal_contrib / portfolio_variance
            risk_contributions[asset] = max(0, risk_contrib)
        
        # Normalize to sum to 1
        total_contrib = sum(risk_contributions.values())
        if total_contrib > 0:
            risk_contributions = {asset: contrib / total_contrib 
                                for asset, contrib in risk_contributions.items()}
        
        return risk_contributions
    
    def _calculate_diversification_ratio(self, weights: Dict[str, float],
                                       covariance_matrix: Dict[str, Dict[str, float]]) -> float:
        """Calculate diversification ratio"""
        # Weighted average of individual volatilities
        weighted_vol_sum = 0
        for asset in weights.keys():
            individual_vol = math.sqrt(covariance_matrix[asset][asset])
            weighted_vol_sum += weights[asset] * individual_vol
        
        # Portfolio volatility
        portfolio_variance = 0
        for asset1 in weights.keys():
            for asset2 in weights.keys():
                portfolio_variance += (weights[asset1] * weights[asset2] * 
                                     covariance_matrix[asset1][asset2])
        
        portfolio_vol = math.sqrt(max(portfolio_variance, 0))
        
        # Diversification ratio
        if portfolio_vol > 0:
            return weighted_vol_sum / portfolio_vol
        else:
            return 1.0
    
    def _empty_optimization_result(self) -> OptimizationResult:
        """Return empty optimization result"""
        return OptimizationResult(
            method=OptimizationMethod.MEAN_VARIANCE.value,
            optimal_weights={},
            expected_return=0,
            expected_volatility=0,
            sharpe_ratio=0,
            risk_contribution={},
            diversification_ratio=1,
            confidence=0,
            constraints_satisfied=False
        )

class RiskParityOptimizer:
    """Implements Risk Parity optimization"""
    
    def __init__(self):
        self.max_iterations = 1000
        self.tolerance = 1e-6
    
    def optimize(self, covariance_matrix: Dict[str, Dict[str, float]],
                target_risk_contributions: Dict[str, float] = None) -> OptimizationResult:
        """Perform risk parity optimization"""
        assets = list(covariance_matrix.keys())
        n_assets = len(assets)
        
        if n_assets == 0:
            return self._empty_optimization_result()
        
        # Default to equal risk contributions
        if not target_risk_contributions:
            target_risk_contributions = {asset: 1.0 / n_assets for asset in assets}
        
        # Use iterative approach to find risk parity weights
        weights = self._find_risk_parity_weights(covariance_matrix, target_risk_contributions)
        
        # Calculate portfolio metrics
        portfolio_variance = 0
        for asset1 in assets:
            for asset2 in assets:
                portfolio_variance += (weights[asset1] * weights[asset2] * 
                                     covariance_matrix[asset1][asset2])
        
        portfolio_volatility = math.sqrt(max(portfolio_variance, 0))
        
        # Calculate actual risk contributions
        risk_contributions = self._calculate_risk_contributions(
            weights, covariance_matrix, portfolio_variance)
        
        # Calculate diversification ratio
        diversification_ratio = self._calculate_diversification_ratio(weights, covariance_matrix)
        
        return OptimizationResult(
            method=OptimizationMethod.RISK_PARITY.value,
            optimal_weights=weights,
            expected_return=0.08,  # Placeholder
            expected_volatility=portfolio_volatility,
            sharpe_ratio=0.4,  # Placeholder
            risk_contribution=risk_contributions,
            diversification_ratio=diversification_ratio,
            confidence=0.85,
            constraints_satisfied=True
        )
    
    def _find_risk_parity_weights(self, covariance_matrix: Dict[str, Dict[str, float]],
                                target_risk_contributions: Dict[str, float]) -> Dict[str, float]:
        """Find weights that achieve target risk contributions"""
        assets = list(covariance_matrix.keys())
        
        # Start with inverse volatility weights
        weights = {}
        for asset in assets:
            individual_vol = math.sqrt(covariance_matrix[asset][asset])
            weights[asset] = 1.0 / max(individual_vol, 0.01)
        
        # Normalize weights
        total_weight = sum(weights.values())
        weights = {asset: weight / total_weight for asset, weight in weights.items()}
        
        # Iterative improvement
        for iteration in range(self.max_iterations):
            # Calculate current risk contributions
            portfolio_variance = sum(weights[asset1] * weights[asset2] * 
                                   covariance_matrix[asset1][asset2]
                                   for asset1 in assets for asset2 in assets)
            
            if portfolio_variance <= 0:
                break
            
            current_risk_contributions = self._calculate_risk_contributions(
                weights, covariance_matrix, portfolio_variance)
            
            # Adjust weights based on risk contribution errors
            new_weights = {}
            for asset in assets:
                target_contrib = target_risk_contributions[asset]
                current_contrib = current_risk_contributions.get(asset, 0)
                
                # Adjustment factor
                if current_contrib > 0:
                    adjustment = target_contrib / current_contrib
                    new_weights[asset] = weights[asset] * adjustment
                else:
                    new_weights[asset] = weights[asset]
            
            # Normalize weights
            total_weight = sum(new_weights.values())
            if total_weight > 0:
                new_weights = {asset: weight / total_weight 
                             for asset, weight in new_weights.items()}
            
            # Check convergence
            weight_change = sum(abs(new_weights[asset] - weights[asset]) for asset in assets)
            if weight_change < self.tolerance:
                break
            
            weights = new_weights
        
        return weights
    
    def _calculate_risk_contributions(self, weights: Dict[str, float],
                                    covariance_matrix: Dict[str, Dict[str, float]],
                                    portfolio_variance: float) -> Dict[str, float]:
        """Calculate risk contributions of each asset"""
        risk_contributions = {}
        
        if portfolio_variance <= 0:
            return {asset: 1.0 / len(weights) for asset in weights.keys()}
        
        for asset in weights.keys():
            # Marginal contribution to risk
            marginal_contrib = sum(weights[other_asset] * covariance_matrix[asset][other_asset]
                                 for other_asset in weights.keys())
            
            # Risk contribution
            risk_contrib = weights[asset] * marginal_contrib / portfolio_variance
            risk_contributions[asset] = max(0, risk_contrib)
        
        return risk_contributions
    
    def _calculate_diversification_ratio(self, weights: Dict[str, float],
                                       covariance_matrix: Dict[str, Dict[str, float]]) -> float:
        """Calculate diversification ratio"""
        # Weighted average of individual volatilities
        weighted_vol_sum = sum(weights[asset] * math.sqrt(covariance_matrix[asset][asset])
                              for asset in weights.keys())
        
        # Portfolio volatility
        portfolio_variance = sum(weights[asset1] * weights[asset2] * 
                               covariance_matrix[asset1][asset2]
                               for asset1 in weights.keys() for asset2 in weights.keys())
        
        portfolio_vol = math.sqrt(max(portfolio_variance, 0))
        
        return weighted_vol_sum / portfolio_vol if portfolio_vol > 0 else 1.0
    
    def _empty_optimization_result(self) -> OptimizationResult:
        """Return empty optimization result"""
        return OptimizationResult(
            method=OptimizationMethod.RISK_PARITY.value,
            optimal_weights={},
            expected_return=0,
            expected_volatility=0,
            sharpe_ratio=0,
            risk_contribution={},
            diversification_ratio=1,
            confidence=0,
            constraints_satisfied=False
        )

class KellyCriterionOptimizer:
    """Implements Kelly Criterion for position sizing"""
    
    def __init__(self):
        self.max_kelly_fraction = 0.25  # Cap Kelly fraction at 25%
        self.min_win_rate = 0.51  # Minimum win rate for Kelly
    
    def optimize(self, expected_returns: Dict[str, float],
                win_rates: Dict[str, float],
                avg_win_loss_ratio: Dict[str, float]) -> OptimizationResult:
        """Calculate Kelly optimal position sizes"""
        assets = list(expected_returns.keys())
        
        if not assets:
            return self._empty_optimization_result()
        
        kelly_fractions = {}
        total_kelly = 0
        
        for asset in assets:
            win_rate = win_rates.get(asset, 0.55)  # Default 55% win rate
            win_loss_ratio = avg_win_loss_ratio.get(asset, 1.5)  # Default 1.5:1 ratio
            
            # Kelly fraction = (bp - q) / b
            # where b = odds received (win_loss_ratio), p = win_rate, q = loss_rate
            if win_rate >= self.min_win_rate and win_loss_ratio > 1:
                kelly_fraction = (win_loss_ratio * win_rate - (1 - win_rate)) / win_loss_ratio
                kelly_fraction = max(0, min(kelly_fraction, self.max_kelly_fraction))
            else:
                kelly_fraction = 0
            
            kelly_fractions[asset] = kelly_fraction
            total_kelly += kelly_fraction
        
        # Normalize if total exceeds 100%
        if total_kelly > 1:
            kelly_fractions = {asset: fraction / total_kelly 
                             for asset, fraction in kelly_fractions.items()}
            total_kelly = 1
        
        # If total Kelly is less than 100%, allocate remainder to cash or equal weights
        if total_kelly < 1:
            remaining = 1 - total_kelly
            equal_allocation = remaining / len(assets)
            kelly_fractions = {asset: fraction + equal_allocation 
                             for asset, fraction in kelly_fractions.items()}
        
        # Calculate expected portfolio return
        portfolio_return = sum(kelly_fractions[asset] * expected_returns[asset] 
                             for asset in assets)
        
        return OptimizationResult(
            method=OptimizationMethod.KELLY_CRITERION.value,
            optimal_weights=kelly_fractions,
            expected_return=portfolio_return,
            expected_volatility=0.15,  # Placeholder
            sharpe_ratio=portfolio_return / 0.15 if portfolio_return > 0 else 0,
            risk_contribution={asset: kelly_fractions[asset] for asset in assets},
            diversification_ratio=1.2,  # Placeholder
            confidence=0.75,
            constraints_satisfied=True
        )
    
    def _empty_optimization_result(self) -> OptimizationResult:
        """Return empty optimization result"""
        return OptimizationResult(
            method=OptimizationMethod.KELLY_CRITERION.value,
            optimal_weights={},
            expected_return=0,
            expected_volatility=0,
            sharpe_ratio=0,
            risk_contribution={},
            diversification_ratio=1,
            confidence=0,
            constraints_satisfied=False
        )

class RebalancingEngine:
    """Handles portfolio rebalancing logic"""
    
    def __init__(self):
        self.default_threshold = 0.05  # 5% drift threshold
        self.transaction_cost = 0.001  # 0.1% transaction cost
        self.min_trade_size = 100  # Minimum trade size in USD
    
    def calculate_rebalancing_trades(self, current_positions: List[Position],
                                   target_weights: Dict[str, float],
                                   total_portfolio_value: float) -> List[Dict[str, Any]]:
        """Calculate trades needed for rebalancing"""
        trades = []
        
        # Calculate current weights
        current_weights = {}
        for position in current_positions:
            current_weights[position.asset.symbol] = position.weight
        
        # Calculate required trades
        for asset_symbol, target_weight in target_weights.items():
            current_weight = current_weights.get(asset_symbol, 0)
            weight_diff = target_weight - current_weight
            
            # Check if rebalancing is needed
            if abs(weight_diff) > self.default_threshold:
                # Calculate trade amount
                trade_value = weight_diff * total_portfolio_value
                
                # Skip small trades
                if abs(trade_value) < self.min_trade_size:
                    continue
                
                # Find current position
                current_position = next((p for p in current_positions 
                                       if p.asset.symbol == asset_symbol), None)
                
                if current_position:
                    trade_quantity = trade_value / current_position.asset.current_price
                    
                    trades.append({
                        'asset_symbol': asset_symbol,
                        'action': 'buy' if weight_diff > 0 else 'sell',
                        'quantity': abs(trade_quantity),
                        'value': abs(trade_value),
                        'current_weight': current_weight,
                        'target_weight': target_weight,
                        'weight_diff': weight_diff,
                        'estimated_cost': abs(trade_value) * self.transaction_cost
                    })
        
        return trades
    
    def should_rebalance(self, current_positions: List[Position],
                        target_weights: Dict[str, float],
                        rebalance_frequency: RebalanceFrequency,
                        last_rebalance: datetime = None) -> bool:
        """Determine if portfolio should be rebalanced"""
        
        # Time-based rebalancing
        if last_rebalance:
            time_since_rebalance = datetime.now() - last_rebalance
            
            if rebalance_frequency == RebalanceFrequency.DAILY:
                return time_since_rebalance.days >= 1
            elif rebalance_frequency == RebalanceFrequency.WEEKLY:
                return time_since_rebalance.days >= 7
            elif rebalance_frequency == RebalanceFrequency.MONTHLY:
                return time_since_rebalance.days >= 30
            elif rebalance_frequency == RebalanceFrequency.QUARTERLY:
                return time_since_rebalance.days >= 90
        
        # Threshold-based rebalancing
        if rebalance_frequency == RebalanceFrequency.THRESHOLD_BASED:
            for position in current_positions:
                target_weight = target_weights.get(position.asset.symbol, 0)
                drift = abs(position.weight - target_weight)
                
                if drift > self.default_threshold:
                    return True
        
        return False
    
    def estimate_rebalancing_cost(self, trades: List[Dict[str, Any]]) -> Dict[str, float]:
        """Estimate total cost of rebalancing"""
        total_trade_value = sum(trade['value'] for trade in trades)
        total_transaction_cost = sum(trade['estimated_cost'] for trade in trades)
        
        # Market impact cost (simplified)
        market_impact_cost = total_trade_value * 0.0005  # 0.05% market impact
        
        return {
            'transaction_costs': total_transaction_cost,
            'market_impact_costs': market_impact_cost,
            'total_costs': total_transaction_cost + market_impact_cost,
            'cost_percentage': (total_transaction_cost + market_impact_cost) / total_trade_value if total_trade_value > 0 else 0
        }

class PerformanceAnalyzer:
    """Analyzes portfolio performance"""
    
    def __init__(self):
        self.risk_free_rate = 0.02
        self.benchmark_return = 0.10  # 10% benchmark return
        self.trading_days_per_year = 252
    
    def calculate_portfolio_metrics(self, portfolio_returns: List[float],
                                  benchmark_returns: List[float] = None) -> PortfolioMetrics:
        """Calculate comprehensive portfolio metrics"""
        if not portfolio_returns:
            return self._empty_metrics()
        
        # Basic return metrics
        total_return = sum(portfolio_returns)
        annualized_return = (1 + total_return) ** (self.trading_days_per_year / len(portfolio_returns)) - 1
        
        # Risk metrics
        volatility = statistics.stdev(portfolio_returns) * math.sqrt(self.trading_days_per_year) if len(portfolio_returns) > 1 else 0
        
        # Sharpe ratio
        excess_return = annualized_return - self.risk_free_rate
        sharpe_ratio = excess_return / volatility if volatility > 0 else 0
        
        # Sortino ratio
        downside_returns = [min(0, ret) for ret in portfolio_returns]
        downside_deviation = statistics.stdev(downside_returns) * math.sqrt(self.trading_days_per_year) if len(downside_returns) > 1 else 0
        sortino_ratio = excess_return / downside_deviation if downside_deviation > 0 else 0
        
        # Maximum drawdown
        max_drawdown = self._calculate_max_drawdown(portfolio_returns)
        
        # Value at Risk
        var_95 = self._calculate_var(portfolio_returns, 0.95)
        var_99 = self._calculate_var(portfolio_returns, 0.99)
        
        # Beta and Alpha (if benchmark provided)
        beta = 1.0
        alpha = 0.0
        information_ratio = 0.0
        
        if benchmark_returns and len(benchmark_returns) == len(portfolio_returns):
            beta = self._calculate_beta(portfolio_returns, benchmark_returns)
            alpha = annualized_return - (self.risk_free_rate + beta * (self.benchmark_return - self.risk_free_rate))
            
            # Information ratio
            active_returns = [p - b for p, b in zip(portfolio_returns, benchmark_returns)]
            tracking_error = statistics.stdev(active_returns) * math.sqrt(self.trading_days_per_year) if len(active_returns) > 1 else 0
            information_ratio = statistics.mean(active_returns) / tracking_error if tracking_error > 0 else 0
        
        # Calmar ratio
        calmar_ratio = annualized_return / abs(max_drawdown) if max_drawdown != 0 else 0
        
        return PortfolioMetrics(
            total_value=100000,  # Placeholder
            total_return=total_return,
            annualized_return=annualized_return,
            volatility=volatility,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            var_95=var_95,
            var_99=var_99,
            beta=beta,
            alpha=alpha,
            information_ratio=information_ratio,
            calmar_ratio=calmar_ratio
        )
    
    def _calculate_max_drawdown(self, returns: List[float]) -> float:
        """Calculate maximum drawdown"""
        if not returns:
            return 0
        
        cumulative_returns = [1]
        for ret in returns:
            cumulative_returns.append(cumulative_returns[-1] * (1 + ret))
        
        peak = cumulative_returns[0]
        max_drawdown = 0
        
        for value in cumulative_returns[1:]:
            if value > peak:
                peak = value
            else:
                drawdown = (peak - value) / peak
                max_drawdown = max(max_drawdown, drawdown)
        
        return max_drawdown
    
    def _calculate_var(self, returns: List[float], confidence_level: float) -> float:
        """Calculate Value at Risk"""
        if not returns:
            return 0
        
        sorted_returns = sorted(returns)
        index = int((1 - confidence_level) * len(sorted_returns))
        return abs(sorted_returns[index]) if index < len(sorted_returns) else 0
    
    def _calculate_beta(self, portfolio_returns: List[float], 
                       benchmark_returns: List[float]) -> float:
        """Calculate portfolio beta"""
        if len(portfolio_returns) != len(benchmark_returns) or len(portfolio_returns) < 2:
            return 1.0
        
        # Calculate covariance and variance
        portfolio_mean = statistics.mean(portfolio_returns)
        benchmark_mean = statistics.mean(benchmark_returns)
        
        covariance = sum((p - portfolio_mean) * (b - benchmark_mean) 
                        for p, b in zip(portfolio_returns, benchmark_returns))
        covariance /= (len(portfolio_returns) - 1)
        
        benchmark_variance = statistics.variance(benchmark_returns)
        
        return covariance / benchmark_variance if benchmark_variance > 0 else 1.0
    
    def _empty_metrics(self) -> PortfolioMetrics:
        """Return empty portfolio metrics"""
        return PortfolioMetrics(
            total_value=0, total_return=0, annualized_return=0, volatility=0,
            sharpe_ratio=0, sortino_ratio=0, max_drawdown=0, var_95=0, var_99=0,
            beta=1, alpha=0, information_ratio=0, calmar_ratio=0
        )

class PortfolioOptimizationService:
    """Main Portfolio Optimization Service"""
    
    def __init__(self):
        self.risk_calculator = RiskCalculator()
        self.covariance_estimator = CovarianceEstimator()
        self.mv_optimizer = MeanVarianceOptimizer()
        self.rp_optimizer = RiskParityOptimizer()
        self.kelly_optimizer = KellyCriterionOptimizer()
        self.rebalancing_engine = RebalancingEngine()
        self.performance_analyzer = PerformanceAnalyzer()
        
        self.optimization_cache = {}
        
        logger.info("Portfolio Optimization Service initialized")
    
    def optimize_portfolio(self, assets: List[Asset],
                         historical_returns: Dict[str, List[float]],
                         optimization_method: OptimizationMethod = OptimizationMethod.MEAN_VARIANCE,
                         risk_level: RiskLevel = RiskLevel.MODERATE,
                         constraints: Dict[str, Any] = None) -> OptimizationResult:
        """Optimize portfolio allocation"""
        try:
            cache_key = f"{optimization_method.value}_{risk_level.value}_{len(assets)}"
            
            # Check cache
            if cache_key in self.optimization_cache:
                cached_result = self.optimization_cache[cache_key]
                if (datetime.now() - cached_result['timestamp']).seconds < 3600:  # 1 hour cache
                    return cached_result['result']
            
            # Use mock data if not provided
            if not historical_returns:
                historical_returns = self._generate_mock_returns(assets)
            
            # Calculate expected returns
            expected_returns = self._calculate_expected_returns(historical_returns)
            
            # Estimate covariance matrix
            covariance_matrix = self.covariance_estimator.estimate_covariance_matrix(historical_returns)
            
            # Perform optimization based on method
            if optimization_method == OptimizationMethod.MEAN_VARIANCE:
                result = self.mv_optimizer.optimize(expected_returns, covariance_matrix, constraints)
            elif optimization_method == OptimizationMethod.RISK_PARITY:
                result = self.rp_optimizer.optimize(covariance_matrix)
            elif optimization_method == OptimizationMethod.KELLY_CRITERION:
                win_rates = {asset.symbol: 0.55 + random.uniform(-0.1, 0.1) for asset in assets}
                win_loss_ratios = {asset.symbol: 1.5 + random.uniform(-0.3, 0.5) for asset in assets}
                result = self.kelly_optimizer.optimize(expected_returns, win_rates, win_loss_ratios)
            else:
                result = self.mv_optimizer.optimize(expected_returns, covariance_matrix, constraints)
            
            # Apply risk level adjustments
            result = self._apply_risk_level_adjustments(result, risk_level)
            
            # Cache result
            self.optimization_cache[cache_key] = {
                'result': result,
                'timestamp': datetime.now()
            }
            
            logger.info(f"Portfolio optimization completed using {optimization_method.value}")
            return result
            
        except Exception as e:
            logger.error(f"Error in portfolio optimization: {str(e)}")
            return self._generate_fallback_optimization()
    
    def analyze_portfolio_performance(self, positions: List[Position],
                                    historical_returns: Dict[str, List[float]]) -> PortfolioMetrics:
        """Analyze current portfolio performance"""
        try:
            # Calculate portfolio returns
            portfolio_returns = self._calculate_portfolio_returns(positions, historical_returns)
            
            # Generate benchmark returns (simplified)
            benchmark_returns = self._generate_benchmark_returns(len(portfolio_returns))
            
            # Calculate metrics
            metrics = self.performance_analyzer.calculate_portfolio_metrics(
                portfolio_returns, benchmark_returns)
            
            # Update total value
            total_value = sum(position.value for position in positions)
            metrics.total_value = total_value
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error analyzing portfolio performance: {str(e)}")
            return self.performance_analyzer._empty_metrics()
    
    def generate_rebalancing_recommendations(self, current_positions: List[Position],
                                           target_weights: Dict[str, float],
                                           rebalance_frequency: RebalanceFrequency = RebalanceFrequency.MONTHLY) -> Dict[str, Any]:
        """Generate rebalancing recommendations"""
        try:
            total_value = sum(position.value for position in current_positions)
            
            # Check if rebalancing is needed
            should_rebalance = self.rebalancing_engine.should_rebalance(
                current_positions, target_weights, rebalance_frequency)
            
            if not should_rebalance:
                return {
                    'should_rebalance': False,
                    'reason': 'No rebalancing needed at this time',
                    'trades': [],
                    'estimated_costs': {'total_costs': 0}
                }
            
            # Calculate required trades
            trades = self.rebalancing_engine.calculate_rebalancing_trades(
                current_positions, target_weights, total_value)
            
            # Estimate costs
            costs = self.rebalancing_engine.estimate_rebalancing_cost(trades)
            
            return {
                'should_rebalance': True,
                'reason': f'Drift threshold exceeded or {rebalance_frequency.value} rebalancing due',
                'trades': trades,
                'estimated_costs': costs,
                'total_trade_value': sum(trade['value'] for trade in trades),
                'number_of_trades': len(trades)
            }
            
        except Exception as e:
            logger.error(f"Error generating rebalancing recommendations: {str(e)}")
            return {
                'should_rebalance': False,
                'reason': f'Error: {str(e)}',
                'trades': [],
                'estimated_costs': {'total_costs': 0}
            }
    
    def calculate_risk_metrics(self, positions: List[Position],
                             historical_returns: Dict[str, List[float]]) -> Dict[str, Any]:
        """Calculate comprehensive risk metrics for portfolio"""
        try:
            # Extract weights and returns
            weights = {position.asset.symbol: position.weight for position in positions}
            
            # Estimate covariance matrix
            covariance_matrix = self.covariance_estimator.estimate_covariance_matrix(historical_returns)
            
            # Calculate risk metrics
            risk_metrics = self.risk_calculator.calculate_portfolio_risk(
                weights, covariance_matrix, historical_returns)
            
            # Add additional risk metrics
            total_value = sum(position.value for position in positions)
            
            # Concentration risk
            max_weight = max(position.weight for position in positions) if positions else 0
            concentration_risk = max_weight > 0.4  # Flag if any position > 40%
            
            # Correlation risk
            avg_correlation = self._calculate_average_correlation(covariance_matrix)
            correlation_risk = avg_correlation > 0.7  # Flag if high correlation
            
            risk_metrics.update({
                'total_portfolio_value': total_value,
                'concentration_risk': concentration_risk,
                'max_position_weight': max_weight,
                'correlation_risk': correlation_risk,
                'average_correlation': avg_correlation,
                'number_of_positions': len(positions)
            })
            
            return risk_metrics
            
        except Exception as e:
            logger.error(f"Error calculating risk metrics: {str(e)}")
            return {
                'volatility': 0.2,
                'var_95': 0.05,
                'var_99': 0.08,
                'max_drawdown': 0.15,
                'concentration_risk': False,
                'correlation_risk': False
            }
    
    def _calculate_expected_returns(self, historical_returns: Dict[str, List[float]]) -> Dict[str, float]:
        """Calculate expected returns from historical data"""
        expected_returns = {}
        
        for asset, returns in historical_returns.items():
            if returns:
                # Simple mean return
                mean_return = statistics.mean(returns)
                # Annualize if needed (assuming daily returns)
                annualized_return = (1 + mean_return) ** 252 - 1
                expected_returns[asset] = annualized_return
            else:
                expected_returns[asset] = 0.08  # Default 8% expected return
        
        return expected_returns
    
    def _apply_risk_level_adjustments(self, result: OptimizationResult, 
                                    risk_level: RiskLevel) -> OptimizationResult:
        """Apply risk level adjustments to optimization result"""
        risk_multipliers = {
            RiskLevel.CONSERVATIVE: 0.6,
            RiskLevel.MODERATE: 1.0,
            RiskLevel.AGGRESSIVE: 1.4,
            RiskLevel.VERY_AGGRESSIVE: 1.8
        }
        
        multiplier = risk_multipliers.get(risk_level, 1.0)
        
        # Adjust expected return and volatility
        result.expected_return *= multiplier
        result.expected_volatility *= multiplier
        
        # Recalculate Sharpe ratio
        excess_return = result.expected_return - 0.02
        result.sharpe_ratio = excess_return / result.expected_volatility if result.expected_volatility > 0 else 0
        
        return result
    
    def _calculate_portfolio_returns(self, positions: List[Position],
                                   historical_returns: Dict[str, List[float]]) -> List[float]:
        """Calculate historical portfolio returns"""
        if not positions or not historical_returns:
            return []
        
        # Find minimum length across all assets
        min_length = min(len(historical_returns.get(pos.asset.symbol, [])) for pos in positions)
        
        if min_length == 0:
            return []
        
        portfolio_returns = []
        for i in range(min_length):
            portfolio_return = 0
            for position in positions:
                asset_returns = historical_returns.get(position.asset.symbol, [])
                if i < len(asset_returns):
                    portfolio_return += position.weight * asset_returns[i]
            portfolio_returns.append(portfolio_return)
        
        return portfolio_returns
    
    def _generate_benchmark_returns(self, length: int) -> List[float]:
        """Generate benchmark returns for comparison"""
        # Simple benchmark: 10% annual return with 15% volatility
        annual_return = 0.10
        annual_volatility = 0.15
        
        daily_return = annual_return / 252
        daily_volatility = annual_volatility / math.sqrt(252)
        
        benchmark_returns = []
        for i in range(length):
            # Add some randomness
            noise = (hash(f"benchmark_{i}") % 200 - 100) / 10000
            daily_ret = daily_return + daily_volatility * noise
            benchmark_returns.append(daily_ret)
        
        return benchmark_returns
    
    def _calculate_average_correlation(self, covariance_matrix: Dict[str, Dict[str, float]]) -> float:
        """Calculate average correlation from covariance matrix"""
        assets = list(covariance_matrix.keys())
        correlations = []
        
        for i, asset1 in enumerate(assets):
            for j, asset2 in enumerate(assets):
                if i < j:  # Avoid double counting
                    var1 = covariance_matrix[asset1][asset1]
                    var2 = covariance_matrix[asset2][asset2]
                    cov = covariance_matrix[asset1][asset2]
                    
                    if var1 > 0 and var2 > 0:
                        correlation = cov / math.sqrt(var1 * var2)
                        correlations.append(abs(correlation))
        
        return statistics.mean(correlations) if correlations else 0
    
    def _generate_mock_returns(self, assets: List[Asset]) -> Dict[str, List[float]]:
        """Generate mock historical returns for testing"""
        returns = {}
        
        for asset in assets:
            asset_returns = []
            for i in range(252):  # 1 year of daily returns
                # Base return with some asset-specific characteristics
                base_return = 0.0003 + (hash(asset.symbol) % 100 - 50) / 1000000
                
                # Add volatility
                volatility_factor = asset.volatility / math.sqrt(252)
                noise = (hash(f"{asset.symbol}_{i}") % 200 - 100) / 10000
                
                daily_return = base_return + volatility_factor * noise
                asset_returns.append(daily_return)
            
            returns[asset.symbol] = asset_returns
        
        return returns
    
    def _generate_fallback_optimization(self) -> OptimizationResult:
        """Generate fallback optimization result"""
        return OptimizationResult(
            method=OptimizationMethod.MEAN_VARIANCE.value,
            optimal_weights={'BTC': 0.4, 'ETH': 0.3, 'SOL': 0.2, 'AVAX': 0.1},
            expected_return=0.12,
            expected_volatility=0.25,
            sharpe_ratio=0.4,
            risk_contribution={'BTC': 0.35, 'ETH': 0.30, 'SOL': 0.20, 'AVAX': 0.15},
            diversification_ratio=1.3,
            confidence=0.6,
            constraints_satisfied=True
        )
    
    def get_optimization_summary(self, assets: List[Asset], 
                               optimization_method: OptimizationMethod = OptimizationMethod.MEAN_VARIANCE) -> Dict[str, Any]:
        """Get portfolio optimization summary"""
        try:
            # Generate mock historical returns
            historical_returns = self._generate_mock_returns(assets)
            
            # Optimize portfolio
            result = self.optimize_portfolio(assets, historical_returns, optimization_method)
            
            return {
                'optimization_method': result.method,
                'optimal_weights': result.optimal_weights,
                'expected_return': f"{result.expected_return:.1%}",
                'expected_volatility': f"{result.expected_volatility:.1%}",
                'sharpe_ratio': f"{result.sharpe_ratio:.2f}",
                'diversification_ratio': f"{result.diversification_ratio:.2f}",
                'confidence': f"{result.confidence:.1%}",
                'top_allocations': sorted(result.optimal_weights.items(), 
                                        key=lambda x: x[1], reverse=True)[:3],
                'timestamp': datetime.now()
            }
            
        except Exception as e:
            logger.error(f"Error generating optimization summary: {str(e)}")
            return {
                'optimization_method': optimization_method.value,
                'error': str(e),
                'timestamp': datetime.now()
            }
    
    def health_check(self) -> Dict[str, Any]:
        """Service health check"""
        return {
            'status': 'healthy',
            'optimizers_loaded': 3,
            'cache_size': len(self.optimization_cache),
            'supported_methods': [method.value for method in OptimizationMethod],
            'timestamp': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize service
    portfolio_service = PortfolioOptimizationService()
    
    # Create sample assets
    sample_assets = [
        Asset('BTC', 'Bitcoin', 'crypto', 43000, 850000000000, 25000000000, 0.6, 1.0, 1.0),
        Asset('ETH', 'Ethereum', 'crypto', 2600, 320000000000, 12000000000, 0.7, 1.2, 0.8),
        Asset('SOL', 'Solana', 'crypto', 100, 45000000000, 2000000000, 0.9, 1.5, 0.6),
        Asset('AVAX', 'Avalanche', 'crypto', 35, 13000000000, 800000000, 1.0, 1.3, 0.5)
    ]
    
    # Test portfolio optimization
    optimization_result = portfolio_service.optimize_portfolio(
        assets=sample_assets,
        historical_returns=None,  # Will use mock data
        optimization_method=OptimizationMethod.MEAN_VARIANCE,
        risk_level=RiskLevel.MODERATE
    )
    
    print("Portfolio Optimization Results:")
    print("=" * 50)
    
    print(f"\nOPTIMIZATION METHOD: {optimization_result.method}")
    print(f"Expected Return: {optimization_result.expected_return:.1%}")
    print(f"Expected Volatility: {optimization_result.expected_volatility:.1%}")
    print(f"Sharpe Ratio: {optimization_result.sharpe_ratio:.2f}")
    print(f"Diversification Ratio: {optimization_result.diversification_ratio:.2f}")
    
    print(f"\nOPTIMAL WEIGHTS:")
    for asset, weight in optimization_result.optimal_weights.items():
        print(f"{asset}: {weight:.1%}")
    
    print(f"\nRISK CONTRIBUTIONS:")
    for asset, risk_contrib in optimization_result.risk_contribution.items():
        print(f"{asset}: {risk_contrib:.1%}")
    
    # Test risk parity optimization
    rp_result = portfolio_service.optimize_portfolio(
        assets=sample_assets,
        historical_returns=None,
        optimization_method=OptimizationMethod.RISK_PARITY
    )
    
    print(f"\nRISK PARITY OPTIMIZATION:")
    print(f"Expected Volatility: {rp_result.expected_volatility:.1%}")
    print(f"Diversification Ratio: {rp_result.diversification_ratio:.2f}")
    
    print(f"\nRisk Parity Weights:")
    for asset, weight in rp_result.optimal_weights.items():
        print(f"{asset}: {weight:.1%}")
    
    # Test Kelly Criterion
    kelly_result = portfolio_service.optimize_portfolio(
        assets=sample_assets,
        historical_returns=None,
        optimization_method=OptimizationMethod.KELLY_CRITERION
    )
    
    print(f"\nKELLY CRITERION OPTIMIZATION:")
    print(f"Expected Return: {kelly_result.expected_return:.1%}")
    
    print(f"\nKelly Weights:")
    for asset, weight in kelly_result.optimal_weights.items():
        print(f"{asset}: {weight:.1%}")
    
    # Create sample positions for rebalancing test
    sample_positions = [
        Position(sample_assets[0], 0.5, 50000, 0.5, 0.4, 0.1, datetime.now() - timedelta(days=30)),
        Position(sample_assets[1], 12, 31200, 0.312, 0.3, 0.012, datetime.now() - timedelta(days=30)),
        Position(sample_assets[2], 150, 15000, 0.15, 0.2, -0.05, datetime.now() - timedelta(days=30)),
        Position(sample_assets[3], 100, 3500, 0.035, 0.1, -0.065, datetime.now() - timedelta(days=30))
    ]
    
    # Test rebalancing recommendations
    rebalancing_rec = portfolio_service.generate_rebalancing_recommendations(
        current_positions=sample_positions,
        target_weights=optimization_result.optimal_weights,
        rebalance_frequency=RebalanceFrequency.MONTHLY
    )
    
    print(f"\nREBALANCING RECOMMENDATIONS:")
    print(f"Should Rebalance: {rebalancing_rec['should_rebalance']}")
    print(f"Reason: {rebalancing_rec['reason']}")
    print(f"Number of Trades: {rebalancing_rec.get('number_of_trades', 0)}")
    
    if rebalancing_rec['trades']:
        print(f"\nRequired Trades:")
        for trade in rebalancing_rec['trades'][:3]:  # Show first 3 trades
            print(f"- {trade['action'].upper()} {trade['quantity']:.2f} {trade['asset_symbol']}")
            print(f"  Value: ${trade['value']:,.2f}")
            print(f"  Weight: {trade['current_weight']:.1%} → {trade['target_weight']:.1%}")
    
    # Test performance analysis
    performance_metrics = portfolio_service.analyze_portfolio_performance(
        positions=sample_positions,
        historical_returns=None  # Will use mock data
    )
    
    print(f"\nPORTFOLIO PERFORMANCE:")
    print(f"Total Value: ${performance_metrics.total_value:,.2f}")
    print(f"Annualized Return: {performance_metrics.annualized_return:.1%}")
    print(f"Volatility: {performance_metrics.volatility:.1%}")
    print(f"Sharpe Ratio: {performance_metrics.sharpe_ratio:.2f}")
    print(f"Max Drawdown: {performance_metrics.max_drawdown:.1%}")
    print(f"VaR (95%): {performance_metrics.var_95:.1%}")
    
    # Get optimization summary
    summary = portfolio_service.get_optimization_summary(sample_assets)
    print(f"\nOPTIMIZATION SUMMARY:")
    print(f"Method: {summary['optimization_method']}")
    print(f"Expected Return: {summary['expected_return']}")
    print(f"Sharpe Ratio: {summary['sharpe_ratio']}")
    print(f"Top Allocations: {summary['top_allocations']}")
    
    # Health check
    health = portfolio_service.health_check()
    print(f"\nService Health: {health}")
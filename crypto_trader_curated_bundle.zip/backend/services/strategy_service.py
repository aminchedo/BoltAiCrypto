"""
Strategy service for managing trading strategies
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class StrategyService:
    """Service for strategy management operations"""
    
    def __init__(self):
        # Mock strategy storage for simplified version
        self.strategies = {}
        self.next_id = 1
    
    async def create_strategy(self, user_id: int, strategy_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new strategy"""
        try:
            strategy = {
                "id": self.next_id,
                "user_id": user_id,
                "name": strategy_data.get("name"),
                "description": strategy_data.get("description"),
                "strategy_type": strategy_data.get("strategy_type"),
                "parameters": strategy_data.get("parameters", {}),
                "symbols": strategy_data.get("symbols", []),
                "is_active": strategy_data.get("is_active", True),
                "status": "INACTIVE",
                "created_at": datetime.now(),
                "updated_at": datetime.now()
            }
            
            self.strategies[self.next_id] = strategy
            self.next_id += 1
            
            return strategy
            
        except Exception as e:
            logger.error(f"Error creating strategy: {e}")
            raise
    
    async def get_user_strategies(self, user_id: int) -> List[Dict[str, Any]]:
        """Get all strategies for a user"""
        return [s for s in self.strategies.values() if s["user_id"] == user_id]
    
    async def get_strategy(self, strategy_id: int, user_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific strategy"""
        strategy = self.strategies.get(strategy_id)
        if strategy and strategy["user_id"] == user_id:
            return strategy
        return None
    
    async def update_strategy(self, strategy_id: int, user_id: int, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a strategy"""
        try:
            strategy = await self.get_strategy(strategy_id, user_id)
            if not strategy:
                return None
            
            for key, value in updates.items():
                if key in strategy and key not in ["id", "user_id", "created_at"]:
                    strategy[key] = value
            
            strategy["updated_at"] = datetime.now()
            return strategy
            
        except Exception as e:
            logger.error(f"Error updating strategy: {e}")
            return None
    
    async def delete_strategy(self, strategy_id: int, user_id: int) -> bool:
        """Delete a strategy"""
        try:
            strategy = await self.get_strategy(strategy_id, user_id)
            if not strategy:
                return False
            
            del self.strategies[strategy_id]
            return True
            
        except Exception as e:
            logger.error(f"Error deleting strategy: {e}")
            return False
"""
Whale Movement Analysis Service
Monitors large transactions, exchange flows, and whale behavior patterns
"""

import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import statistics
import threading
from concurrent.futures import ThreadPoolExecutor
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TransactionType(Enum):
    """Types of whale transactions"""
    EXCHANGE_INFLOW = "exchange_inflow"
    EXCHANGE_OUTFLOW = "exchange_outflow"
    WALLET_TO_WALLET = "wallet_to_wallet"
    UNKNOWN = "unknown"

class WalletType(Enum):
    """Types of wallet classifications"""
    EXCHANGE = "exchange"
    WHALE = "whale"
    INSTITUTIONAL = "institutional"
    MINING_POOL = "mining_pool"
    UNKNOWN = "unknown"

class ImpactLevel(Enum):
    """Impact levels for whale movements"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class WhaleTransaction:
    """Structure for whale transaction data"""
    tx_hash: str
    amount: float
    asset: str
    from_address: str
    to_address: str
    timestamp: datetime
    transaction_type: str
    from_wallet_type: str
    to_wallet_type: str
    exchange_name: Optional[str]
    impact_level: str
    confidence_score: float
    usd_value: float

@dataclass
class WalletCluster:
    """Wallet cluster information"""
    cluster_id: str
    addresses: List[str]
    total_balance: float
    wallet_type: str
    label: str
    first_seen: datetime
    last_activity: datetime
    transaction_count: int
    risk_score: float

@dataclass
class ExchangeFlow:
    """Exchange flow data"""
    exchange: str
    inflow_24h: float
    outflow_24h: float
    net_flow_24h: float
    inflow_7d: float
    outflow_7d: float
    net_flow_7d: float
    large_transactions: int
    avg_transaction_size: float

class BlockchainAnalyzer:
    """Analyze blockchain transactions for whale activity"""
    
    def __init__(self):
        self.whale_threshold = {
            'BTC': 100,  # 100+ BTC
            'ETH': 1000,  # 1000+ ETH
            'SOL': 50000,  # 50k+ SOL
            'AVAX': 100000  # 100k+ AVAX
        }
        
        self.exchange_addresses = {
            'binance': ['1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2'],
            'coinbase': ['3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy', '3FupnQyzu1J3SYHjPDTm9jNhWYJJirmqMJ'],
            'kraken': ['3BMEXqGpG4qxWDfCDFHMJWxTeWAJqMVaD3', '3QJmV3qfvL9SuYo34YihAf3sRCW3qSinyC'],
            'bitfinex': ['3D2oetdNuZUqQHPJmcMDDHYoqkyNVsFk9r', '3E37jhgXPn5f3oUk2JT2QcpQRYhFXqUHe9']
        }
        
        self.institutional_addresses = {
            'microstrategy': ['1P5ZEDWTKTFGxQjZphgWPQUpe554WKDfHQ'],
            'tesla': ['1FeexV6bAHb8ybZjqQMjJrcCrHGW9sb6uF'],
            'grayscale': ['3FKjN1x7548ZgTXF8W5nKaGGFnJhKNxLuF']
        }
    
    def detect_whale_transactions(self, transactions: List[Dict]) -> List[WhaleTransaction]:
        """Detect whale transactions from blockchain data"""
        whale_transactions = []
        
        for tx in transactions:
            try:
                amount = float(tx.get('amount', 0))
                asset = tx.get('asset', 'BTC').upper()
                
                # Check if transaction meets whale threshold
                threshold = self.whale_threshold.get(asset, 100)
                if amount >= threshold:
                    whale_tx = self._analyze_transaction(tx)
                    if whale_tx:
                        whale_transactions.append(whale_tx)
                        
            except Exception as e:
                logger.error(f"Error analyzing transaction {tx.get('hash', 'unknown')}: {str(e)}")
        
        return sorted(whale_transactions, key=lambda x: x.usd_value, reverse=True)
    
    def _analyze_transaction(self, tx: Dict) -> Optional[WhaleTransaction]:
        """Analyze individual transaction for whale characteristics"""
        try:
            from_addr = tx.get('from_address', '')
            to_addr = tx.get('to_address', '')
            amount = float(tx.get('amount', 0))
            asset = tx.get('asset', 'BTC').upper()
            
            # Classify wallet types
            from_wallet_type = self._classify_wallet(from_addr)
            to_wallet_type = self._classify_wallet(to_addr)
            
            # Determine transaction type
            tx_type = self._determine_transaction_type(from_wallet_type, to_wallet_type)
            
            # Calculate impact level
            impact_level = self._calculate_impact_level(amount, asset, tx_type)
            
            # Calculate confidence score
            confidence = self._calculate_confidence_score(tx, from_wallet_type, to_wallet_type)
            
            # Estimate USD value (simplified)
            usd_value = self._estimate_usd_value(amount, asset)
            
            # Determine exchange name if applicable
            exchange_name = None
            if from_wallet_type == WalletType.EXCHANGE.value:
                exchange_name = self._get_exchange_name(from_addr)
            elif to_wallet_type == WalletType.EXCHANGE.value:
                exchange_name = self._get_exchange_name(to_addr)
            
            return WhaleTransaction(
                tx_hash=tx.get('hash', ''),
                amount=amount,
                asset=asset,
                from_address=from_addr,
                to_address=to_addr,
                timestamp=tx.get('timestamp', datetime.now()),
                transaction_type=tx_type.value,
                from_wallet_type=from_wallet_type.value,
                to_wallet_type=to_wallet_type.value,
                exchange_name=exchange_name,
                impact_level=impact_level.value,
                confidence_score=confidence,
                usd_value=usd_value
            )
            
        except Exception as e:
            logger.error(f"Error in transaction analysis: {str(e)}")
            return None
    
    def _classify_wallet(self, address: str) -> WalletType:
        """Classify wallet type based on address"""
        if not address:
            return WalletType.UNKNOWN
        
        # Check exchange addresses
        for exchange, addresses in self.exchange_addresses.items():
            if address in addresses:
                return WalletType.EXCHANGE
        
        # Check institutional addresses
        for institution, addresses in self.institutional_addresses.items():
            if address in addresses:
                return WalletType.INSTITUTIONAL
        
        # Simple heuristics for classification
        address_hash = int(hashlib.md5(address.encode()).hexdigest()[:8], 16)
        
        if address_hash % 10 < 2:  # 20% chance
            return WalletType.EXCHANGE
        elif address_hash % 10 < 3:  # 10% chance
            return WalletType.INSTITUTIONAL
        elif address_hash % 10 < 4:  # 10% chance
            return WalletType.MINING_POOL
        elif address_hash % 10 < 7:  # 30% chance
            return WalletType.WHALE
        else:
            return WalletType.UNKNOWN
    
    def _determine_transaction_type(self, from_type: WalletType, to_type: WalletType) -> TransactionType:
        """Determine transaction type based on wallet types"""
        if from_type == WalletType.EXCHANGE and to_type != WalletType.EXCHANGE:
            return TransactionType.EXCHANGE_OUTFLOW
        elif from_type != WalletType.EXCHANGE and to_type == WalletType.EXCHANGE:
            return TransactionType.EXCHANGE_INFLOW
        elif from_type != WalletType.EXCHANGE and to_type != WalletType.EXCHANGE:
            return TransactionType.WALLET_TO_WALLET
        else:
            return TransactionType.UNKNOWN
    
    def _calculate_impact_level(self, amount: float, asset: str, tx_type: TransactionType) -> ImpactLevel:
        """Calculate impact level of transaction"""
        threshold = self.whale_threshold.get(asset, 100)
        
        # Base impact on amount relative to threshold
        if amount >= threshold * 10:
            base_impact = ImpactLevel.CRITICAL
        elif amount >= threshold * 5:
            base_impact = ImpactLevel.HIGH
        elif amount >= threshold * 2:
            base_impact = ImpactLevel.MEDIUM
        else:
            base_impact = ImpactLevel.LOW
        
        # Adjust based on transaction type
        if tx_type in [TransactionType.EXCHANGE_INFLOW, TransactionType.EXCHANGE_OUTFLOW]:
            # Exchange flows have higher impact
            if base_impact == ImpactLevel.LOW:
                return ImpactLevel.MEDIUM
            elif base_impact == ImpactLevel.MEDIUM:
                return ImpactLevel.HIGH
        
        return base_impact
    
    def _calculate_confidence_score(self, tx: Dict, from_type: WalletType, to_type: WalletType) -> float:
        """Calculate confidence score for whale classification"""
        confidence = 50.0  # Base confidence
        
        # Higher confidence for known wallet types
        if from_type != WalletType.UNKNOWN:
            confidence += 15
        if to_type != WalletType.UNKNOWN:
            confidence += 15
        
        # Higher confidence for exchange transactions
        if from_type == WalletType.EXCHANGE or to_type == WalletType.EXCHANGE:
            confidence += 10
        
        # Higher confidence for institutional wallets
        if from_type == WalletType.INSTITUTIONAL or to_type == WalletType.INSTITUTIONAL:
            confidence += 15
        
        # Transaction metadata quality
        if tx.get('confirmations', 0) > 6:
            confidence += 5
        
        return min(confidence, 95.0)
    
    def _estimate_usd_value(self, amount: float, asset: str) -> float:
        """Estimate USD value of transaction (simplified)"""
        # Simplified price estimates
        prices = {
            'BTC': 43000,
            'ETH': 2600,
            'SOL': 100,
            'AVAX': 35
        }
        
        price = prices.get(asset, 1)
        return amount * price
    
    def _get_exchange_name(self, address: str) -> Optional[str]:
        """Get exchange name from address"""
        for exchange, addresses in self.exchange_addresses.items():
            if address in addresses:
                return exchange
        return None

class ExchangeFlowAnalyzer:
    """Analyze exchange inflows and outflows"""
    
    def __init__(self):
        self.flow_cache = {}
        self.alert_thresholds = {
            'large_inflow': 1000,  # BTC equivalent
            'large_outflow': 1000,
            'unusual_activity': 2.0  # 2x normal volume
        }
    
    def analyze_exchange_flows(self, whale_transactions: List[WhaleTransaction]) -> Dict[str, ExchangeFlow]:
        """Analyze exchange flows from whale transactions"""
        exchange_data = {}
        
        # Group transactions by exchange
        for tx in whale_transactions:
            if tx.exchange_name:
                if tx.exchange_name not in exchange_data:
                    exchange_data[tx.exchange_name] = {
                        'inflows': [], 'outflows': [], 'transactions': []
                    }
                
                exchange_data[tx.exchange_name]['transactions'].append(tx)
                
                if tx.transaction_type == TransactionType.EXCHANGE_INFLOW.value:
                    exchange_data[tx.exchange_name]['inflows'].append(tx)
                elif tx.transaction_type == TransactionType.EXCHANGE_OUTFLOW.value:
                    exchange_data[tx.exchange_name]['outflows'].append(tx)
        
        # Calculate flow metrics for each exchange
        flows = {}
        for exchange, data in exchange_data.items():
            flows[exchange] = self._calculate_exchange_metrics(exchange, data)
        
        return flows
    
    def _calculate_exchange_metrics(self, exchange: str, data: Dict) -> ExchangeFlow:
        """Calculate metrics for a specific exchange"""
        now = datetime.now()
        day_ago = now - timedelta(days=1)
        week_ago = now - timedelta(days=7)
        
        # Filter transactions by time
        inflows_24h = [tx for tx in data['inflows'] if tx.timestamp >= day_ago]
        outflows_24h = [tx for tx in data['outflows'] if tx.timestamp >= day_ago]
        inflows_7d = [tx for tx in data['inflows'] if tx.timestamp >= week_ago]
        outflows_7d = [tx for tx in data['outflows'] if tx.timestamp >= week_ago]
        
        # Calculate totals (convert to BTC equivalent for comparison)
        inflow_24h = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in inflows_24h)
        outflow_24h = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in outflows_24h)
        inflow_7d = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in inflows_7d)
        outflow_7d = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in outflows_7d)
        
        # Calculate average transaction size
        all_amounts = [self._to_btc_equivalent(tx.amount, tx.asset) for tx in data['transactions']]
        avg_tx_size = statistics.mean(all_amounts) if all_amounts else 0
        
        # Count large transactions
        large_tx_count = len([tx for tx in data['transactions'] 
                             if self._to_btc_equivalent(tx.amount, tx.asset) >= 100])
        
        return ExchangeFlow(
            exchange=exchange,
            inflow_24h=inflow_24h,
            outflow_24h=outflow_24h,
            net_flow_24h=inflow_24h - outflow_24h,
            inflow_7d=inflow_7d,
            outflow_7d=outflow_7d,
            net_flow_7d=inflow_7d - outflow_7d,
            large_transactions=large_tx_count,
            avg_transaction_size=avg_tx_size
        )
    
    def _to_btc_equivalent(self, amount: float, asset: str) -> float:
        """Convert amount to BTC equivalent for comparison"""
        # Simplified conversion rates
        rates = {
            'BTC': 1.0,
            'ETH': 0.06,  # ~1 ETH = 0.06 BTC
            'SOL': 0.0023,  # ~1 SOL = 0.0023 BTC
            'AVAX': 0.0008  # ~1 AVAX = 0.0008 BTC
        }
        
        rate = rates.get(asset, 0.001)
        return amount * rate
    
    def detect_unusual_flows(self, current_flows: Dict[str, ExchangeFlow], 
                           historical_flows: Dict[str, List[ExchangeFlow]]) -> List[Dict[str, Any]]:
        """Detect unusual exchange flows"""
        alerts = []
        
        for exchange, current_flow in current_flows.items():
            # Get historical data for comparison
            historical = historical_flows.get(exchange, [])
            
            if len(historical) < 7:  # Need at least a week of data
                continue
            
            # Calculate historical averages
            hist_inflow_avg = statistics.mean([f.inflow_24h for f in historical])
            hist_outflow_avg = statistics.mean([f.outflow_24h for f in historical])
            hist_net_avg = statistics.mean([f.net_flow_24h for f in historical])
            
            # Check for unusual activity
            inflow_ratio = current_flow.inflow_24h / hist_inflow_avg if hist_inflow_avg > 0 else 1
            outflow_ratio = current_flow.outflow_24h / hist_outflow_avg if hist_outflow_avg > 0 else 1
            
            # Large inflow alert
            if (current_flow.inflow_24h >= self.alert_thresholds['large_inflow'] and 
                inflow_ratio >= self.alert_thresholds['unusual_activity']):
                alerts.append({
                    'type': 'large_inflow',
                    'exchange': exchange,
                    'amount': current_flow.inflow_24h,
                    'ratio': inflow_ratio,
                    'severity': 'high' if inflow_ratio >= 3.0 else 'medium'
                })
            
            # Large outflow alert
            if (current_flow.outflow_24h >= self.alert_thresholds['large_outflow'] and 
                outflow_ratio >= self.alert_thresholds['unusual_activity']):
                alerts.append({
                    'type': 'large_outflow',
                    'exchange': exchange,
                    'amount': current_flow.outflow_24h,
                    'ratio': outflow_ratio,
                    'severity': 'high' if outflow_ratio >= 3.0 else 'medium'
                })
            
            # Net flow change alert
            net_change = abs(current_flow.net_flow_24h - hist_net_avg)
            if net_change >= self.alert_thresholds['large_inflow']:
                alerts.append({
                    'type': 'net_flow_change',
                    'exchange': exchange,
                    'current_net': current_flow.net_flow_24h,
                    'historical_avg': hist_net_avg,
                    'change': net_change,
                    'severity': 'high' if net_change >= 2000 else 'medium'
                })
        
        return sorted(alerts, key=lambda x: x.get('amount', x.get('change', 0)), reverse=True)

class WhaleBehaviorAnalyzer:
    """Analyze whale behavior patterns"""
    
    def __init__(self):
        self.behavior_patterns = {}
        self.accumulation_threshold = 0.8  # 80% of transactions are accumulation
        self.distribution_threshold = 0.8  # 80% of transactions are distribution
    
    def analyze_whale_behavior(self, whale_transactions: List[WhaleTransaction], 
                             timeframe_hours: int = 24) -> Dict[str, Any]:
        """Analyze whale behavior patterns"""
        if not whale_transactions:
            return self._empty_behavior_result()
        
        cutoff_time = datetime.now() - timedelta(hours=timeframe_hours)
        recent_transactions = [tx for tx in whale_transactions if tx.timestamp >= cutoff_time]
        
        if not recent_transactions:
            return self._empty_behavior_result()
        
        # Analyze accumulation vs distribution
        accumulation_distribution = self._analyze_accumulation_distribution(recent_transactions)
        
        # Analyze transaction timing patterns
        timing_patterns = self._analyze_timing_patterns(recent_transactions)
        
        # Analyze size distribution
        size_analysis = self._analyze_transaction_sizes(recent_transactions)
        
        # Analyze exchange vs non-exchange activity
        exchange_analysis = self._analyze_exchange_activity(recent_transactions)
        
        # Determine overall behavior
        overall_behavior = self._determine_overall_behavior(
            accumulation_distribution, exchange_analysis, size_analysis)
        
        return {
            'timeframe_hours': timeframe_hours,
            'total_transactions': len(recent_transactions),
            'total_volume_btc': sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in recent_transactions),
            'accumulation_distribution': accumulation_distribution,
            'timing_patterns': timing_patterns,
            'size_analysis': size_analysis,
            'exchange_analysis': exchange_analysis,
            'overall_behavior': overall_behavior,
            'confidence': self._calculate_behavior_confidence(recent_transactions)
        }
    
    def _analyze_accumulation_distribution(self, transactions: List[WhaleTransaction]) -> Dict[str, Any]:
        """Analyze accumulation vs distribution patterns"""
        accumulation_count = 0
        distribution_count = 0
        accumulation_volume = 0
        distribution_volume = 0
        
        for tx in transactions:
            volume_btc = self._to_btc_equivalent(tx.amount, tx.asset)
            
            if tx.transaction_type == TransactionType.EXCHANGE_OUTFLOW.value:
                # Outflow from exchange = accumulation
                accumulation_count += 1
                accumulation_volume += volume_btc
            elif tx.transaction_type == TransactionType.EXCHANGE_INFLOW.value:
                # Inflow to exchange = distribution
                distribution_count += 1
                distribution_volume += volume_btc
        
        total_count = accumulation_count + distribution_count
        total_volume = accumulation_volume + distribution_volume
        
        if total_count == 0:
            return {'pattern': 'neutral', 'confidence': 0}
        
        acc_ratio = accumulation_count / total_count
        dist_ratio = distribution_count / total_count
        
        # Determine pattern
        if acc_ratio >= self.accumulation_threshold:
            pattern = 'strong_accumulation'
        elif acc_ratio >= 0.6:
            pattern = 'accumulation'
        elif dist_ratio >= self.distribution_threshold:
            pattern = 'strong_distribution'
        elif dist_ratio >= 0.6:
            pattern = 'distribution'
        else:
            pattern = 'mixed'
        
        return {
            'pattern': pattern,
            'accumulation_ratio': acc_ratio,
            'distribution_ratio': dist_ratio,
            'accumulation_volume': accumulation_volume,
            'distribution_volume': distribution_volume,
            'net_volume': accumulation_volume - distribution_volume
        }
    
    def _analyze_timing_patterns(self, transactions: List[WhaleTransaction]) -> Dict[str, Any]:
        """Analyze timing patterns of whale transactions"""
        if not transactions:
            return {}
        
        # Group by hour of day
        hourly_distribution = {}
        for tx in transactions:
            hour = tx.timestamp.hour
            hourly_distribution[hour] = hourly_distribution.get(hour, 0) + 1
        
        # Find peak activity hours
        if hourly_distribution:
            peak_hour = max(hourly_distribution.items(), key=lambda x: x[1])
            avg_per_hour = len(transactions) / 24
            
            # Check for clustering
            clustering_score = max(hourly_distribution.values()) / avg_per_hour if avg_per_hour > 0 else 1
        else:
            peak_hour = (0, 0)
            clustering_score = 1
        
        # Analyze transaction intervals
        sorted_txs = sorted(transactions, key=lambda x: x.timestamp)
        intervals = []
        for i in range(1, len(sorted_txs)):
            interval = (sorted_txs[i].timestamp - sorted_txs[i-1].timestamp).total_seconds() / 3600
            intervals.append(interval)
        
        avg_interval = statistics.mean(intervals) if intervals else 0
        
        return {
            'peak_hour': peak_hour[0],
            'peak_hour_count': peak_hour[1],
            'clustering_score': clustering_score,
            'avg_interval_hours': avg_interval,
            'hourly_distribution': hourly_distribution
        }
    
    def _analyze_transaction_sizes(self, transactions: List[WhaleTransaction]) -> Dict[str, Any]:
        """Analyze transaction size patterns"""
        if not transactions:
            return {}
        
        sizes_btc = [self._to_btc_equivalent(tx.amount, tx.asset) for tx in transactions]
        
        # Calculate statistics
        avg_size = statistics.mean(sizes_btc)
        median_size = statistics.median(sizes_btc)
        max_size = max(sizes_btc)
        min_size = min(sizes_btc)
        std_dev = statistics.stdev(sizes_btc) if len(sizes_btc) > 1 else 0
        
        # Size categories
        small_count = len([s for s in sizes_btc if s < 100])
        medium_count = len([s for s in sizes_btc if 100 <= s < 500])
        large_count = len([s for s in sizes_btc if 500 <= s < 1000])
        huge_count = len([s for s in sizes_btc if s >= 1000])
        
        return {
            'avg_size_btc': avg_size,
            'median_size_btc': median_size,
            'max_size_btc': max_size,
            'min_size_btc': min_size,
            'std_deviation': std_dev,
            'size_distribution': {
                'small': small_count,
                'medium': medium_count,
                'large': large_count,
                'huge': huge_count
            }
        }
    
    def _analyze_exchange_activity(self, transactions: List[WhaleTransaction]) -> Dict[str, Any]:
        """Analyze exchange-related activity"""
        exchange_txs = [tx for tx in transactions if tx.exchange_name]
        non_exchange_txs = [tx for tx in transactions if not tx.exchange_name]
        
        exchange_volume = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in exchange_txs)
        non_exchange_volume = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in non_exchange_txs)
        
        # Exchange breakdown
        exchange_breakdown = {}
        for tx in exchange_txs:
            exchange = tx.exchange_name
            if exchange not in exchange_breakdown:
                exchange_breakdown[exchange] = {'count': 0, 'volume': 0}
            
            exchange_breakdown[exchange]['count'] += 1
            exchange_breakdown[exchange]['volume'] += self._to_btc_equivalent(tx.amount, tx.asset)
        
        total_volume = exchange_volume + non_exchange_volume
        exchange_ratio = exchange_volume / total_volume if total_volume > 0 else 0
        
        return {
            'exchange_transaction_count': len(exchange_txs),
            'non_exchange_transaction_count': len(non_exchange_txs),
            'exchange_volume_btc': exchange_volume,
            'non_exchange_volume_btc': non_exchange_volume,
            'exchange_volume_ratio': exchange_ratio,
            'exchange_breakdown': exchange_breakdown
        }
    
    def _determine_overall_behavior(self, acc_dist: Dict, exchange: Dict, size: Dict) -> Dict[str, Any]:
        """Determine overall whale behavior"""
        behavior_score = 0  # -100 (bearish) to +100 (bullish)
        confidence = 0
        
        # Accumulation/Distribution impact
        if acc_dist.get('pattern') == 'strong_accumulation':
            behavior_score += 40
            confidence += 30
        elif acc_dist.get('pattern') == 'accumulation':
            behavior_score += 20
            confidence += 20
        elif acc_dist.get('pattern') == 'strong_distribution':
            behavior_score -= 40
            confidence += 30
        elif acc_dist.get('pattern') == 'distribution':
            behavior_score -= 20
            confidence += 20
        else:
            confidence += 10
        
        # Exchange activity impact
        exchange_ratio = exchange.get('exchange_volume_ratio', 0)
        if exchange_ratio > 0.7:  # High exchange activity
            if acc_dist.get('accumulation_ratio', 0) > 0.5:
                behavior_score += 15  # Buying from exchanges
            else:
                behavior_score -= 15  # Selling to exchanges
            confidence += 15
        
        # Size analysis impact
        avg_size = size.get('avg_size_btc', 0)
        if avg_size > 500:  # Large average transaction size
            behavior_score += 10  # Large moves often indicate conviction
            confidence += 10
        
        # Determine behavior label
        if behavior_score >= 30:
            behavior_label = 'strongly_bullish'
        elif behavior_score >= 10:
            behavior_label = 'bullish'
        elif behavior_score <= -30:
            behavior_label = 'strongly_bearish'
        elif behavior_score <= -10:
            behavior_label = 'bearish'
        else:
            behavior_label = 'neutral'
        
        return {
            'behavior_score': behavior_score,
            'behavior_label': behavior_label,
            'confidence': min(confidence, 95)
        }
    
    def _calculate_behavior_confidence(self, transactions: List[WhaleTransaction]) -> float:
        """Calculate confidence in behavior analysis"""
        base_confidence = 30
        
        # More transactions = higher confidence
        tx_confidence = min(len(transactions) * 5, 40)
        
        # Higher confidence for known wallet types
        known_wallets = len([tx for tx in transactions 
                           if tx.from_wallet_type != WalletType.UNKNOWN.value or 
                              tx.to_wallet_type != WalletType.UNKNOWN.value])
        wallet_confidence = (known_wallets / len(transactions)) * 20 if transactions else 0
        
        # Higher confidence for high-impact transactions
        high_impact = len([tx for tx in transactions if tx.impact_level in ['high', 'critical']])
        impact_confidence = (high_impact / len(transactions)) * 10 if transactions else 0
        
        total_confidence = base_confidence + tx_confidence + wallet_confidence + impact_confidence
        return min(total_confidence, 95)
    
    def _to_btc_equivalent(self, amount: float, asset: str) -> float:
        """Convert amount to BTC equivalent"""
        rates = {'BTC': 1.0, 'ETH': 0.06, 'SOL': 0.0023, 'AVAX': 0.0008}
        return amount * rates.get(asset, 0.001)
    
    def _empty_behavior_result(self) -> Dict[str, Any]:
        """Return empty behavior analysis result"""
        return {
            'timeframe_hours': 24,
            'total_transactions': 0,
            'total_volume_btc': 0,
            'accumulation_distribution': {'pattern': 'neutral', 'confidence': 0},
            'timing_patterns': {},
            'size_analysis': {},
            'exchange_analysis': {},
            'overall_behavior': {'behavior_score': 0, 'behavior_label': 'neutral', 'confidence': 0},
            'confidence': 0
        }

class WhaleAnalysisService:
    """Main Whale Analysis Service"""
    
    def __init__(self):
        self.blockchain_analyzer = BlockchainAnalyzer()
        self.flow_analyzer = ExchangeFlowAnalyzer()
        self.behavior_analyzer = WhaleBehaviorAnalyzer()
        
        self.transaction_cache = {}
        self.flow_history = {}
        self.alert_cache = {}
        self.lock = threading.Lock()
        
        logger.info("Whale Analysis Service initialized")
    
    def analyze_whale_activity(self, asset: str, transactions: List[Dict] = None, 
                             timeframe_hours: int = 24) -> Dict[str, Any]:
        """Comprehensive whale activity analysis"""
        try:
            cache_key = f"{asset}_{timeframe_hours}_{len(transactions or [])}"
            
            with self.lock:
                # Check cache
                if cache_key in self.transaction_cache:
                    cached_result = self.transaction_cache[cache_key]
                    if (datetime.now() - cached_result['timestamp']).seconds < 600:  # 10 min cache
                        return cached_result['data']
            
            # Use mock data if no transactions provided
            if not transactions:
                transactions = self._generate_mock_transactions(asset, timeframe_hours)
            
            # Detect whale transactions
            whale_transactions = self.blockchain_analyzer.detect_whale_transactions(transactions)
            
            # Analyze exchange flows
            exchange_flows = self.flow_analyzer.analyze_exchange_flows(whale_transactions)
            
            # Analyze whale behavior
            behavior_analysis = self.behavior_analyzer.analyze_whale_behavior(
                whale_transactions, timeframe_hours)
            
            # Detect unusual flows
            historical_flows = self.flow_history.get(asset, {})
            unusual_flows = self.flow_analyzer.detect_unusual_flows(exchange_flows, historical_flows)
            
            # Calculate concentration metrics
            concentration_metrics = self._calculate_concentration_metrics(whale_transactions)
            
            # Generate alerts
            alerts = self._generate_whale_alerts(whale_transactions, unusual_flows, behavior_analysis)
            
            # Compile results
            results = {
                'asset': asset,
                'timeframe_hours': timeframe_hours,
                'whale_transactions': {
                    'count': len(whale_transactions),
                    'total_volume_btc': sum(self._to_btc_equivalent(tx.amount, tx.asset) 
                                          for tx in whale_transactions),
                    'largest_transaction': max(whale_transactions, 
                                             key=lambda x: x.usd_value) if whale_transactions else None,
                    'by_impact': self._group_by_impact(whale_transactions),
                    'recent_transactions': whale_transactions[:10]  # Top 10 recent
                },
                'exchange_flows': exchange_flows,
                'behavior_analysis': behavior_analysis,
                'concentration_metrics': concentration_metrics,
                'unusual_activity': unusual_flows,
                'alerts': alerts,
                'summary': self._generate_summary(whale_transactions, behavior_analysis, unusual_flows)
            }
            
            # Update flow history
            self._update_flow_history(asset, exchange_flows)
            
            # Cache results
            with self.lock:
                self.transaction_cache[cache_key] = {
                    'data': results,
                    'timestamp': datetime.now()
                }
            
            logger.info(f"Whale analysis completed for {asset}: {len(whale_transactions)} transactions")
            return results
            
        except Exception as e:
            logger.error(f"Error in whale analysis for {asset}: {str(e)}")
            return self._generate_fallback_analysis(asset, timeframe_hours)
    
    def _generate_mock_transactions(self, asset: str, timeframe_hours: int) -> List[Dict]:
        """Generate mock transaction data for testing"""
        transactions = []
        now = datetime.now()
        
        # Generate 20-50 transactions
        tx_count = 20 + (hash(asset) % 30)
        
        for i in range(tx_count):
            # Random transaction timing within timeframe
            hours_ago = (hash(f"{asset}_{i}") % (timeframe_hours * 60)) / 60
            timestamp = now - timedelta(hours=hours_ago)
            
            # Random amount (some whale-sized)
            amount_hash = hash(f"{asset}_{i}_amount")
            if amount_hash % 10 < 3:  # 30% whale transactions
                if asset == 'BTC':
                    amount = 100 + (amount_hash % 500)
                elif asset == 'ETH':
                    amount = 1000 + (amount_hash % 5000)
                else:
                    amount = 50000 + (amount_hash % 200000)
            else:
                if asset == 'BTC':
                    amount = 1 + (amount_hash % 50)
                elif asset == 'ETH':
                    amount = 10 + (amount_hash % 500)
                else:
                    amount = 1000 + (amount_hash % 20000)
            
            # Random addresses
            from_addr = f"addr_{hash(f'{asset}_{i}_from') % 10000:04d}"
            to_addr = f"addr_{hash(f'{asset}_{i}_to') % 10000:04d}"
            
            transactions.append({
                'hash': f"tx_{hash(f'{asset}_{i}'):08x}",
                'amount': amount,
                'asset': asset,
                'from_address': from_addr,
                'to_address': to_addr,
                'timestamp': timestamp,
                'confirmations': 6 + (hash(f"{asset}_{i}_conf") % 10)
            })
        
        return transactions
    
    def _group_by_impact(self, whale_transactions: List[WhaleTransaction]) -> Dict[str, int]:
        """Group whale transactions by impact level"""
        impact_groups = {'low': 0, 'medium': 0, 'high': 0, 'critical': 0}
        
        for tx in whale_transactions:
            impact_groups[tx.impact_level] += 1
        
        return impact_groups
    
    def _calculate_concentration_metrics(self, whale_transactions: List[WhaleTransaction]) -> Dict[str, Any]:
        """Calculate whale concentration metrics"""
        if not whale_transactions:
            return {'concentration_score': 0, 'top_wallets': [], 'distribution': {}}
        
        # Group by wallet addresses
        wallet_volumes = {}
        for tx in whale_transactions:
            volume_btc = self._to_btc_equivalent(tx.amount, tx.asset)
            
            # Count both from and to addresses
            wallet_volumes[tx.from_address] = wallet_volumes.get(tx.from_address, 0) + volume_btc
            wallet_volumes[tx.to_address] = wallet_volumes.get(tx.to_address, 0) + volume_btc
        
        # Sort by volume
        sorted_wallets = sorted(wallet_volumes.items(), key=lambda x: x[1], reverse=True)
        
        # Calculate concentration
        total_volume = sum(wallet_volumes.values())
        top_10_volume = sum(volume for _, volume in sorted_wallets[:10])
        top_100_volume = sum(volume for _, volume in sorted_wallets[:100])
        
        concentration_score = (top_10_volume / total_volume * 100) if total_volume > 0 else 0
        
        return {
            'concentration_score': concentration_score,
            'total_unique_wallets': len(wallet_volumes),
            'top_10_share': (top_10_volume / total_volume * 100) if total_volume > 0 else 0,
            'top_100_share': (top_100_volume / total_volume * 100) if total_volume > 0 else 0,
            'top_wallets': [{'address': addr, 'volume_btc': vol} 
                           for addr, vol in sorted_wallets[:10]]
        }
    
    def _generate_whale_alerts(self, whale_transactions: List[WhaleTransaction], 
                             unusual_flows: List[Dict], behavior_analysis: Dict) -> List[Dict[str, Any]]:
        """Generate whale activity alerts"""
        alerts = []
        
        # Large transaction alerts
        for tx in whale_transactions:
            if tx.impact_level in ['high', 'critical']:
                alerts.append({
                    'type': 'large_transaction',
                    'severity': tx.impact_level,
                    'message': f"Large {tx.asset} transaction: {tx.amount:.2f} {tx.asset} "
                              f"({tx.transaction_type})",
                    'amount': tx.amount,
                    'asset': tx.asset,
                    'usd_value': tx.usd_value,
                    'timestamp': tx.timestamp
                })
        
        # Unusual flow alerts
        for flow_alert in unusual_flows:
            alerts.append({
                'type': 'unusual_flow',
                'severity': flow_alert['severity'],
                'message': f"Unusual {flow_alert['type']} on {flow_alert['exchange']}: "
                          f"{flow_alert.get('amount', flow_alert.get('change', 0)):.0f} BTC",
                'exchange': flow_alert['exchange'],
                'timestamp': datetime.now()
            })
        
        # Behavior alerts
        behavior = behavior_analysis.get('overall_behavior', {})
        if behavior.get('confidence', 0) > 70:
            if behavior.get('behavior_label') in ['strongly_bullish', 'strongly_bearish']:
                alerts.append({
                    'type': 'behavior_change',
                    'severity': 'high',
                    'message': f"Strong whale behavior signal: {behavior['behavior_label']}",
                    'behavior': behavior['behavior_label'],
                    'confidence': behavior['confidence'],
                    'timestamp': datetime.now()
                })
        
        # Sort by severity and timestamp
        severity_order = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
        alerts.sort(key=lambda x: (severity_order.get(x['severity'], 0), x['timestamp']), reverse=True)
        
        return alerts[:20]  # Limit to top 20 alerts
    
    def _generate_summary(self, whale_transactions: List[WhaleTransaction], 
                         behavior_analysis: Dict, unusual_flows: List[Dict]) -> Dict[str, Any]:
        """Generate whale activity summary"""
        total_volume = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in whale_transactions)
        
        # Exchange activity
        exchange_txs = [tx for tx in whale_transactions if tx.exchange_name]
        inflows = [tx for tx in exchange_txs if tx.transaction_type == TransactionType.EXCHANGE_INFLOW.value]
        outflows = [tx for tx in exchange_txs if tx.transaction_type == TransactionType.EXCHANGE_OUTFLOW.value]
        
        inflow_volume = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in inflows)
        outflow_volume = sum(self._to_btc_equivalent(tx.amount, tx.asset) for tx in outflows)
        net_flow = inflow_volume - outflow_volume
        
        # Overall sentiment
        behavior = behavior_analysis.get('overall_behavior', {})
        behavior_score = behavior.get('behavior_score', 0)
        
        if behavior_score > 20:
            sentiment = 'bullish'
        elif behavior_score < -20:
            sentiment = 'bearish'
        else:
            sentiment = 'neutral'
        
        return {
            'total_whale_transactions': len(whale_transactions),
            'total_volume_btc': total_volume,
            'exchange_inflow_btc': inflow_volume,
            'exchange_outflow_btc': outflow_volume,
            'net_exchange_flow_btc': net_flow,
            'whale_sentiment': sentiment,
            'behavior_confidence': behavior.get('confidence', 0),
            'unusual_activity_count': len(unusual_flows),
            'high_impact_transactions': len([tx for tx in whale_transactions 
                                           if tx.impact_level in ['high', 'critical']])
        }
    
    def _update_flow_history(self, asset: str, current_flows: Dict[str, ExchangeFlow]):
        """Update historical flow data"""
        if asset not in self.flow_history:
            self.flow_history[asset] = {}
        
        for exchange, flow in current_flows.items():
            if exchange not in self.flow_history[asset]:
                self.flow_history[asset][exchange] = []
            
            # Add current flow to history
            self.flow_history[asset][exchange].append(flow)
            
            # Keep only last 30 days of data
            if len(self.flow_history[asset][exchange]) > 30:
                self.flow_history[asset][exchange] = self.flow_history[asset][exchange][-30:]
    
    def _to_btc_equivalent(self, amount: float, asset: str) -> float:
        """Convert amount to BTC equivalent"""
        rates = {'BTC': 1.0, 'ETH': 0.06, 'SOL': 0.0023, 'AVAX': 0.0008}
        return amount * rates.get(asset, 0.001)
    
    def _generate_fallback_analysis(self, asset: str, timeframe_hours: int) -> Dict[str, Any]:
        """Generate fallback analysis on error"""
        return {
            'asset': asset,
            'timeframe_hours': timeframe_hours,
            'whale_transactions': {
                'count': 0,
                'total_volume_btc': 0,
                'largest_transaction': None,
                'by_impact': {'low': 0, 'medium': 0, 'high': 0, 'critical': 0},
                'recent_transactions': []
            },
            'exchange_flows': {},
            'behavior_analysis': self.behavior_analyzer._empty_behavior_result(),
            'concentration_metrics': {'concentration_score': 0, 'top_wallets': [], 'distribution': {}},
            'unusual_activity': [],
            'alerts': [],
            'summary': {
                'total_whale_transactions': 0,
                'total_volume_btc': 0,
                'whale_sentiment': 'neutral',
                'behavior_confidence': 0,
                'unusual_activity_count': 0,
                'high_impact_transactions': 0
            },
            'error': 'Fallback data due to analysis error'
        }
    
    def get_whale_summary(self, asset: str) -> Dict[str, Any]:
        """Get whale activity summary for an asset"""
        try:
            analysis = self.analyze_whale_activity(asset)
            
            summary = {
                'asset': asset,
                'whale_transactions_24h': analysis['whale_transactions']['count'],
                'total_volume_btc': analysis['whale_transactions']['total_volume_btc'],
                'net_exchange_flow': analysis['summary']['net_exchange_flow_btc'],
                'whale_sentiment': analysis['summary']['whale_sentiment'],
                'concentration_score': analysis['concentration_metrics']['concentration_score'],
                'high_impact_count': analysis['summary']['high_impact_transactions'],
                'alerts_count': len(analysis['alerts']),
                'timestamp': datetime.now()
            }
            
            return summary
            
        except Exception as e:
            logger.error(f"Error generating whale summary: {str(e)}")
            return {
                'asset': asset,
                'error': str(e),
                'timestamp': datetime.now()
            }
    
    def health_check(self) -> Dict[str, Any]:
        """Service health check"""
        return {
            'status': 'healthy',
            'analyzers_loaded': 3,
            'cache_size': len(self.transaction_cache),
            'flow_history_assets': len(self.flow_history),
            'timestamp': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize service
    whale_service = WhaleAnalysisService()
    
    # Analyze whale activity for BTC
    analysis = whale_service.analyze_whale_activity("BTC", timeframe_hours=24)
    
    print("Whale Analysis Results:")
    print("=" * 50)
    
    print(f"\nWHALE TRANSACTIONS:")
    whale_txs = analysis['whale_transactions']
    print(f"Count: {whale_txs['count']}")
    print(f"Total Volume: {whale_txs['total_volume_btc']:.2f} BTC")
    print(f"Impact Distribution: {whale_txs['by_impact']}")
    
    print(f"\nEXCHANGE FLOWS:")
    for exchange, flow in analysis['exchange_flows'].items():
        print(f"{exchange.title()}:")
        print(f"  Net Flow 24h: {flow.net_flow_24h:.2f} BTC")
        print(f"  Large Transactions: {flow.large_transactions}")
    
    print(f"\nBEHAVIOR ANALYSIS:")
    behavior = analysis['behavior_analysis']['overall_behavior']
    print(f"Behavior: {behavior['behavior_label']}")
    print(f"Score: {behavior['behavior_score']}")
    print(f"Confidence: {behavior['confidence']:.1f}%")
    
    print(f"\nCONCENTRATION METRICS:")
    concentration = analysis['concentration_metrics']
    print(f"Concentration Score: {concentration['concentration_score']:.1f}%")
    print(f"Unique Wallets: {concentration['total_unique_wallets']}")
    
    print(f"\nALERTS ({len(analysis['alerts'])}):")
    for alert in analysis['alerts'][:3]:
        print(f"- {alert['severity'].upper()}: {alert['message']}")
    
    print(f"\nSUMMARY:")
    summary = analysis['summary']
    print(f"Whale Sentiment: {summary['whale_sentiment']}")
    print(f"High Impact Transactions: {summary['high_impact_transactions']}")
    print(f"Unusual Activity: {summary['unusual_activity_count']} events")
    
    # Get whale summary
    whale_summary = whale_service.get_whale_summary("BTC")
    print(f"\nWHALE SUMMARY:")
    print(f"24h Transactions: {whale_summary['whale_transactions_24h']}")
    print(f"Net Exchange Flow: {whale_summary['net_exchange_flow']:.2f} BTC")
    print(f"Sentiment: {whale_summary['whale_sentiment']}")
    
    # Health check
    health = whale_service.health_check()
    print(f"\nService Health: {health}")
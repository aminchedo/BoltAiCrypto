# گزارش جامع تحلیل پروژه

تاریخ تولید گزارش: 2025-07-20T11:17:37.907120 UTC

## 1. ساختار کلی پوشه‌ها و فایل‌ها

```
  Ai-trade-kiro/
    .env.example
    Dockerfile
    README.md
    aismart-trader-kiro-spec.md
    aismart-trader-task-board.md
    docker-build.sh
    docker-compose.yml
    next-env.d.ts
    next.config.js
    package.json
    setup-typescript.bat
    setup-typescript.sh
    setup.sh
    tailwind.config.js
    task-automation.bat
    task-manager.bat
    tasks.md
    tasks_reorganized.md
    tsconfig.json
    updated_tasks.md
    workspace.code-workspace
    .github/
      CODEOWNERS
      PULL_REQUEST_TEMPLATE.md
      README.md
      dependabot.yml
      lighthouse-config.json
      ISSUE_TEMPLATE/
        bug_report.md
        config.yml
        feature_request.md
        security_vulnerability.md
      workflows/
        ci-cd.yml
        code-quality.yml
        dependency-updates.yml
        docker-scan.yml
        documentation.yml
        e2e-tests.yml
        license-compliance.yml
        performance-tests.yml
        release.yml
        security-scan.yml
        stale.yml
    backend/
      .env.example
      Dockerfile
      Dockerfile.prod
      README.md
      SIMPLIFIED_VERSION.md
      alembic.ini
      huggingface_requirements.txt
      main.py
      ml_model_project.py
      ml_service.py
      package.json
      pyproject.toml
      requirements.txt
      tsconfig.json
      vite.config.ts
      __pycache__/
        main.cpython-311.pyc
      alembic/
        __init__.py
        env.py
        script.py.mako
        versions/
          initial_migration.py
      analytics/
        usage_analytics.py
      api/
        advanced_chart.py
        advanced_indicators.py
        auth_router.py
        chart_themes.py
        crypto_multi_source_manager.py
        exchange_router.py
        exchange_settings.py
        main_api.py
        market_data.py
        market_data_router.py
        ml_router.py
        model_storage_api.py
        order_book.py
        pattern_recognition.py
        portfolio_router.py
        position_tracking.py
        real_trading_api.py
        signal_router.py
        strategy_router.py
        strategy_watchlist.py
        trading.py
        webhook_router.py
      app/
        __init__.py
        main.py
        api/
          __init__.py
          router.py
          endpoints/
            __init__.py
            health.py
            market_data.py
          v1/
            __init__.py
            api.py
            endpoints/
              __init__.py
              auth.py
              health.py
              strategies.py
              users.py
        core/
          __init__.py
          config.py
          db_config.py
          dependencies.py
        db/
          __init__.py
          session.py
        models/
          __init__.py
          base.py
          market_data.py
          strategy.py
          user.py
        repositories/
          __init__.py
          market_data.py
          strategy_repository.py
        schemas/
          __init__.py
          base.py
          market_data.py
          strategy.py
          token.py
          user.py
        services/
          __init__.py
          backtesting_service.py
          historical_data.py
          ml_service.py
          normalization.py
          pattern_recognition.py
          smart_money.py
          strategy_executor.py
          strategy_service.py
          technical_indicators.py
          trading_automation_service.py
          exchange/
            README.md
            __init__.py
            base.py
            binance.py
            coinbase.py
        utils/
          __init__.py
          security.py
      back_temp/
        auth_system.py
        binance_api.py
        ci_cd_pipeline.txt
        data_processing_services.py
        database_models.py
        docker_configuration.txt
        exchange_router.py
        kubernetes_deployment.txt
        ml_models_production.py
        project_readme_docs.txt
        react_app_main.ts
        react_components_continuation.ts
        react_hooks_store.ts
        react_main_pages.ts
        react_trading_dashboard.ts
        webhook_notification_system.py
        ai_components/
      config/
        data_sources.py
      logs/
      middleware/
        auth_middleware.py
        logging_middleware.py
        rate_limiter.py
        request_logger.py
      models/
        __init__.py
        signal.py
        strategy.py
        user.py
      monitoring/
        error_tracker.py
        health_check.py
        health_checks.py
        performance_dashboard.py
        performance_monitor.py
      services/
        alert_service.py
        backtest_service.py
        backtesting_service.py
        hybrid_signal_service.py
        market_data_service.py
        market_regime_service.py
        ml_prediction_service.py
        ml_service.py
        model_training_service.py
        notification_service.py
        pattern_recognition_service.py
        portfolio_optimization_service.py
        portfolio_service.py
        security_service.py
        sentiment_service.py
        signal_service.py
        simplified_signal_service.py
        strategy_service.py
        technical_analysis_service.py
        user_service.py
        webhook_service.py
        websocket_service.py
        whale_analysis_service.py
        __pycache__/
          hybrid_signal_service.cpython-311.pyc
          model_training_service.cpython-311.pyc
      storage/
        model_manager.py
      tests/
        __init__.py
        conftest.py
        test_db_connection.py
        test_health.py
        test_normalization.py
      websocket/
        data_streamer.py
        mobile_optimization.py
        position_updates.py
    database/
      README.md
      init.sql
      postgresql.conf
      redis-master.conf
      redis-replica.conf
      timescale_init.sql
      timescaledb.conf
    monitoring/
      README.md
      prometheus.yml
      grafana/
        dashboards/
          aismart-overview.json
        provisioning/
          dashboards/
            dashboards.yml
          datasources/
            datasource.yml
    project/
      .gitignore
      eslint.config.js
      index.html
      package-lock.json
      package.json
      postcss.config.js
      tailwind.config.js
      tsconfig.app.json
      tsconfig.json
      tsconfig.node.json
      vite.config.ts
      .bolt/
        config.json
        prompt
      backend/
        config/
        models/
        services/
          hybrid_signal_service.py
        utils/
      src/
        App.tsx
        index.css
        main.tsx
        vite-env.d.ts
        components/
          AISignalCard.tsx
          Chart.tsx
          Dashboard.tsx
          Header.tsx
          MetricCard.tsx
          PatternRecognition.tsx
          Portfolio.tsx
          PredictionPanel.tsx
          SentimentAnalysis.tsx
          Sidebar.tsx
          WhaleAnalysis.tsx
    src/
      app/
        404.tsx
        globals.css
        layout.tsx
        page.tsx
        api/
          markets/
            [symbol]/
              history/
                route.ts
        chart-demo/
          page.tsx
        strategy-builder/
          page.tsx
        trading/
          page.tsx
      components/
        ai/
          AIAnalyticsModule.tsx
          AdvancedAITab.tsx
          CloudBackupTab.tsx
          LivePredictionsTab.tsx
          ModelStorageTab.tsx
          index.ts
        analytics/
          Analytics.tsx
          Analytics/
            __CandleChart.tsx
        dashboard/
          AIBacktestingModule.tsx
          AIIntegration.tsx
          AIModelConfigurationModule.tsx
          AINotifications.tsx
          AIStrategyBuilderWidget.tsx
          Dashboard.tsx
          Header.tsx
          LiveSignals.tsx
          MainContent.tsx
          MarketOverview.tsx
          Markets.tsx
          Preview.tsx
          Settings.tsx
          Sidebar.tsx
          Signals.tsx
          TradingChart.tsx
          index.ts
          __skeletons/
            MetricCardSkeleton.tsx
            TableSkeleton.tsx
          charts/
            CandlestickRenderer.ts
            ChartEngine.ts
            TradingChart.tsx
            TradingChartWithCandlesticks.tsx
            __tests__/
              CandlestickRenderer.test.ts
              ChartEngine.test.ts
          data/
            aiModels.ts
          Settings/
            DashboardSettings.tsx
            GeneralSettings.tsx
            SecuritySettings.tsx
            TradingSettings.tsx
            index.tsx
          shared/
            ExchangeAPICard.tsx
            ExchangeSVGIcons.tsx
            NotificationSettings.tsx
            PortfolioSettings.tsx
            SecuritySettings.tsx
            ThemeToggle.tsx
            ToggleSetting.tsx
            TradingConfirmation.tsx
            TradingSetupTab.tsx
            settings/
              SelectDropdown.tsx
              SettingGroup.tsx
              SliderControl.tsx
              ToggleSwitch.tsx
          trading/
            LiveOrderBook.tsx
          widgets/
            AIMarketInsightWidget.tsx
            AIModelPerformanceWidget.tsx
            AISignalMiniWidget.tsx
            AISignalsWidget.tsx
            AIStrategyWidget.tsx
            AITradingAutomationWidget.tsx
            MarketOverviewWidget.tsx
            NewsWidget.tsx
            OrderBookWidget.tsx
            PerformanceWidget.tsx
            PortfolioWidget.tsx
            QuickTradeWidget.tsx
            RiskManagerWidget.tsx
            SettingsWidget.tsx
            TechnicalAnalysisWidget.tsx
            TradingChartWidget.tsx
            WhaleTrackerWidget.tsx
        layout/
          Header.tsx
          Sidebar.tsx
        portfolio/
          AdvancedPortfolio.tsx
          PortfolioSummary.tsx
        providers/
          index.tsx
        strategy-builder/
          StrategyBuilder.tsx
          controls/
            StrategyControls.tsx
          modals/
            LoadStrategyModal.tsx
            SaveStrategyModal.tsx
          nodes/
            ActionNode.tsx
            ComponentNode.tsx
            ConditionNode.tsx
            OperatorNode.tsx
          panels/
            BacktestPanel.tsx
            ComponentPanel.tsx
        trading/
          CryptoTradingDashboard.tsx
          HybridSignalWidget.tsx
          MarketOverview.tsx
          OrderBook.tsx
          OrderEntryForm.tsx
          OrderForm.tsx
          OrderHistory.tsx
          OrderPreview.tsx
          PortfolioSummary.tsx
          PriceDisplay.tsx
          SignalCard.tsx
          TradingViewChart.tsx
          advanced_crypto_trading.tsx
        ui/
          Alert.tsx
          Badge.tsx
          Button.tsx
          Card.tsx
          ConnectionStatus.tsx
          Dialog.tsx
          Input.tsx
          Select.tsx
          Skeleton.tsx
          Spinner.tsx
          Switch.tsx
          Tabs.tsx
          ThemeToggle.tsx
          Toast.tsx
          ToastContainer.tsx
          Tooltip.tsx
      hooks/
        useChartData.ts
        useDashboard.ts
        useLocalStorage.ts
        useMarketData.ts
        useMediaQuery.ts
        useToast.ts
        useTrading.ts
        useWebSocket.ts
      lib/
        config.ts
        api/
          index.ts
        auth/
          biometric.ts
          deviceFingerprint.ts
          encryption.ts
          jwt.ts
          rateLimiter.ts
          twoFactor.ts
          types.ts
        stores/
          marketStore.ts
          portfolioStore.ts
          signalStore.ts
        trading/
          apiService.ts
        utils/
          cn.ts
          index.ts
          indicators.ts
        websocket/
          index.ts
      pages/
        ai-signals.tsx
      services/
        aiAnalyticsService.ts
        aiExternalService.ts
        aiNotificationService.ts
        aiTradingAutomationService.ts
        api.ts
        apiService.ts
        comprehensive-dashboard-service.ts
        dashboardService.ts
        hybridSignalService.ts
        hybridTradingService.ts
        marketService.ts
        mlService.ts
        mockApiService.ts
        newsService.ts
        notificationService.ts
        portfolioService.ts
        realDataService.ts
        realTimeService.ts
        signalService.ts
        strategyApiService.ts
        strategyBuilderService.ts
        tradeExecutionService.ts
        tradingService.ts
        market/
      types/
        index.ts
        market.ts
        react.d.ts
        signals.ts
        trading.ts
    temp_components/
      MarketOverview_trading_backup.tsx
      PortfolioSummary_trading_backup.tsx
```

## 2. آمار کلی

- تعداد کل فایل‌ها: 419
- تعداد فایل‌های Python: 134
- تعداد فایل‌های JS/TS: 204
- فایل‌های requirements*: 1
- package.json: 3

## 3. فایل‌های Python و اجزای آن‌ها

### Ai-trade-kiro/backend/main.py
- خطوط: 168 | اندازه: 4704 بایت
- Imports:
  - خط 6: os
  - خط 7: logging
  - خط 8: fastapi (from ...)
  - خط 9: fastapi.middleware.cors (from ...)
  - خط 10: fastapi.responses (from ...)
  - خط 11: uvicorn
  - خط 12: asyncio
  - خط 13: time
  - خط 14: datetime (from ...)
  - خط 15: redis
  - خط 16: typing (from ...)
  - خط 19: api.main_api (from ...)
  - خط 20: api.auth_router (from ...)
  - خط 21: api.strategy_router (from ...)
  - خط 22: api.market_data_router (from ...)
  - خط 23: api.signal_router (from ...)
  - خط 25: api.portfolio_router (from ...)
  - خط 26: api.webhook_router (from ...)
  - خط 29: middleware.auth_middleware (from ...)
  - خط 30: middleware.rate_limiter (from ...)
  - خط 31: middleware.logging_middleware (from ...)
  - خط 32: services.websocket_service (from ...)
  - خط 33: services.simplified_signal_service (from ...)
- انتساب‌های سطح بالا:
  - خط 45: logger
  - خط 48: app
  - خط 75: websocket_manager

### Ai-trade-kiro/backend/ml_model_project.py
- خطوط: 109 | اندازه: 3846 بایت
- Imports:
  - خط 1: os
  - خط 2: pickle
  - خط 3: numpy
  - خط 4: pandas
  - خط 5: sklearn.linear_model (from ...)
  - خط 6: datetime (from ...)
  - خط 7: logging
- کلاس‌ها:
  - خط 16: class MLModel (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger
  - خط 13: DATA_CSV
  - خط 14: MODEL_PATH
  - خط 109: MODEL

### Ai-trade-kiro/backend/ml_service.py
- خطوط: 425 | اندازه: 15503 بایت
- Imports:
  - خط 8: json
  - خط 9: math
  - خط 10: datetime (from ...)
  - خط 11: typing (from ...)
  - خط 12: asyncio
  - خط 13: dataclasses (from ...)
  - خط 14: enum (from ...)
  - خط 15: logging
  - خط 16: random
- توابع:
  - خط 316: def get_ai_analytics_prediction(2 args)
  - خط 347: def generate_final_trading_signal(1 args)
- کلاس‌ها:
  - خط 22: class PredictionType (Bases: Enum)
  - خط 28: class MLPrediction (Bases: -)
  - خط 39: class ModelStatus (Bases: -)
  - خط 49: class MLModelManager (Bases: -)
- انتساب‌های سطح بالا:
  - خط 20: logger
  - خط 313: ml_manager

### Ai-trade-kiro/backend/alembic/__init__.py
- خطوط: 1 | اندازه: 20 بایت

### Ai-trade-kiro/backend/alembic/env.py
- خطوط: 93 | اندازه: 2755 بایت
- Imports:
  - خط 1: asyncio
  - خط 2: logging.config (from ...)
  - خط 4: sqlalchemy (from ...)
  - خط 5: sqlalchemy.engine (from ...)
  - خط 6: sqlalchemy.ext.asyncio (from ...)
  - خط 8: alembic (from ...)
  - خط 23: app.models.base (from ...)
  - خط 24: app.models.user (from ...)
  - خط 25: app.models.market_data (from ...)
  - خط 26: app.models.strategy (from ...)
  - خط 35: app.core.config (from ...)
- توابع:
  - خط 40: def run_migrations_offline(0 args)
  - خط 64: def do_run_migrations(1 args)
- انتساب‌های سطح بالا:
  - خط 12: config
  - خط 28: target_metadata

### Ai-trade-kiro/backend/alembic/versions/initial_migration.py
- خطوط: 198 | اندازه: 9305 بایت
- Imports:
  - خط 8: alembic (from ...)
  - خط 9: sqlalchemy
  - خط 10: sqlalchemy.dialects.postgresql (from ...)
- توابع:
  - خط 20: def upgrade(0 args)
  - خط 165: def downgrade(0 args)
- انتساب‌های سطح بالا:
  - خط 14: revision
  - خط 15: down_revision
  - خط 16: branch_labels
  - خط 17: depends_on

### Ai-trade-kiro/backend/analytics/usage_analytics.py
- خطوط: 31 | اندازه: 943 بایت
- Imports:
  - خط 3: __future__ (from ...)
  - خط 5: logging
  - خط 6: time
  - خط 7: typing (from ...)
- کلاس‌ها:
  - خط 11: class UsageAnalytics (Bases: -)
- انتساب‌های سطح بالا:
  - خط 9: logger

### Ai-trade-kiro/backend/api/advanced_chart.py
- خطوط: 7 | اندازه: 160 بایت
- Imports:
  - خط 1: fastapi (from ...)
- انتساب‌های سطح بالا:
  - خط 3: router

### Ai-trade-kiro/backend/api/advanced_indicators.py
- خطوط: 90 | اندازه: 2934 بایت
- Imports:
  - خط 1: typing (from ...)
  - خط 2: pandas
  - خط 3: fastapi (from ...)
  - خط 4: pydantic (from ...)
- توابع:
  - خط 19: def calculate_bollinger_bands(3 args)
  - خط 40: def _rolling_midpoint(2 args)
  - خط 48: def calculate_ichimoku_cloud(4 args)
- کلاس‌ها:
  - خط 8: class Candle (Bases: BaseModel)
  - خط 15: class CloseSeries (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 6: router

### Ai-trade-kiro/backend/api/auth_router.py
- خطوط: 326 | اندازه: 11109 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: fastapi.security (from ...)
  - خط 8: typing (from ...)
  - خط 9: pydantic (from ...)
  - خط 10: re
  - خط 11: datetime (from ...)
  - خط 12: logging
  - خط 15: services.user_service (from ...)
  - خط 16: services.security_service (from ...)
  - خط 17: middleware.auth_middleware (from ...)
  - خط 18: models.user (from ...)
- کلاس‌ها:
  - خط 24: class LoginRequest (Bases: BaseModel)
  - خط 29: class PasswordResetRequest (Bases: BaseModel)
  - خط 32: class PasswordResetConfirm (Bases: BaseModel)
  - خط 42: class PasswordChangeRequest (Bases: BaseModel)
  - خط 52: class RefreshTokenRequest (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 20: logger
  - خط 21: security
  - خط 56: auth_router

### Ai-trade-kiro/backend/api/chart_themes.py
- خطوط: 18 | اندازه: 525 بایت
- Imports:
  - خط 1: fastapi (from ...)
- انتساب‌های سطح بالا:
  - خط 3: router
  - خط 5: THEMES

### Ai-trade-kiro/backend/api/crypto_multi_source_manager.py
- خطوط: 482 | اندازه: 19623 بایت
- Imports:
  - خط 1: os
  - خط 1: re
  - خط 1: requests
  - خط 1: datetime
  - خط 2: typing (from ...)
  - خط 3: bs4 (from ...)
  - خط 4: random
  - خط 5: time
- توابع:
  - خط 31: def _get_json(1 args)
  - خط 129: def get_price(2 args)
  - خط 163: def get_sentiment(0 args)
  - خط 206: def get_fundamental(2 args)
  - خط 265: def _scrape_coingecko(1 args)
  - خط 299: def get_news(2 args)
  - خط 350: def comprehensive_crypto_analysis(1 args)
  - خط 408: def display_results(1 args)
- کلاس‌ها:
  - خط 43: class PriceSourceSwitcher (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: CMC_KEY
  - خط 12: ND_KEY
  - خط 15: CMC_KEY
  - خط 16: ND_KEY
  - خط 19: FIN_KEY
  - خط 20: CP_KEY
  - خط 21: MS_KEY
  - خط 22: LC_KEY
  - خط 24: HEAD_CMC
  - خط 26: TIMEOUT

### Ai-trade-kiro/backend/api/exchange_router.py
- خطوط: 97 | اندازه: 3076 بایت
- Imports:
  - خط 5: fastapi (from ...)
  - خط 6: typing (from ...)
  - خط 7: pydantic (from ...)
  - خط 8: datetime (from ...)
  - خط 9: logging
- کلاس‌ها:
  - خط 14: class ExchangeCredentials (Bases: BaseModel)
  - خط 20: class MarketDataRequest (Bases: BaseModel)
  - خط 26: class ExchangeInfoResponse (Bases: BaseModel)
  - خط 32: class TickerResponse (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 11: logger
  - خط 41: router

### Ai-trade-kiro/backend/api/exchange_settings.py
- خطوط: 467 | اندازه: 15608 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: pydantic (from ...)
  - خط 8: typing (from ...)
  - خط 9: json
  - خط 10: os
  - خط 11: datetime (from ...)
  - خط 12: asyncio
- کلاس‌ها:
  - خط 17: class ExchangeCredentials (Bases: BaseModel)
  - خط 23: class ValidationResponse (Bases: BaseModel)
  - خط 33: class ExchangeConfig (Bases: BaseModel)
  - خط 40: class ExchangeStatus (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 15: router
  - خط 49: EXCHANGE_CONFIGS

### Ai-trade-kiro/backend/api/main_api.py
- خطوط: 111 | اندازه: 3622 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: logging
  - خط 9: datetime (from ...)
  - خط 12: exchange_router (from ...)
  - خط 13: auth_router (from ...)
  - خط 14: strategy_router (from ...)
  - خط 15: market_data_router (from ...)
  - خط 16: portfolio_router (from ...)
  - خط 17: signal_router (from ...)
  - خط 18: webhook_router (from ...)
  - خط 19: ml_router (from ...)
  - خط 22: middleware.auth_middleware (from ...)
  - خط 23: models.user (from ...)
- انتساب‌های سطح بالا:
  - خط 25: logger
  - خط 28: api_router

### Ai-trade-kiro/backend/api/market_data.py
- خطوط: 24 | اندازه: 801 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: src.api.multi_source_manager (from ...)
- انتساب‌های سطح بالا:
  - خط 4: router

### Ai-trade-kiro/backend/api/market_data_router.py
- خطوط: 210 | اندازه: 7275 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: pydantic (from ...)
  - خط 9: datetime (from ...)
  - خط 10: logging
  - خط 13: models.user (from ...)
  - خط 14: services.market_data_service (from ...)
  - خط 15: middleware.auth_middleware (from ...)
- کلاس‌ها:
  - خط 22: class MarketOverview (Bases: BaseModel)
  - خط 31: class Ticker (Bases: BaseModel)
  - خط 41: class Candle (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 17: logger
  - خط 19: router

### Ai-trade-kiro/backend/api/ml_router.py
- خطوط: 173 | اندازه: 5835 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: pydantic (from ...)
  - خط 9: datetime (from ...)
  - خط 10: logging
  - خط 13: models.user (from ...)
  - خط 14: services.ml_service (from ...)
  - خط 15: services.sentiment_service (from ...)
  - خط 16: services.pattern_recognition_service (from ...)
  - خط 17: middleware.auth_middleware (from ...)
- کلاس‌ها:
  - خط 24: class PredictionRequest (Bases: BaseModel)
  - خط 30: class SentimentRequest (Bases: BaseModel)
  - خط 33: class SentimentBatchRequest (Bases: BaseModel)
  - خط 36: class PatternRequest (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 19: logger
  - خط 21: router

### Ai-trade-kiro/backend/api/model_storage_api.py
- خطوط: 391 | اندازه: 12454 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: fastapi.responses (from ...)
  - خط 3: typing (from ...)
  - خط 4: json
  - خط 5: os
  - خط 6: tempfile
  - خط 7: uuid
  - خط 8: pathlib (from ...)
  - خط 11: sys
  - خط 13: storage.model_manager (from ...)
- انتساب‌های سطح بالا:
  - خط 16: router
  - خط 19: model_storage

### Ai-trade-kiro/backend/api/order_book.py
- خطوط: 7 | اندازه: 160 بایت
- Imports:
  - خط 1: fastapi (from ...)
- انتساب‌های سطح بالا:
  - خط 3: router

### Ai-trade-kiro/backend/api/pattern_recognition.py
- خطوط: 30 | اندازه: 870 بایت
- Imports:
  - خط 1: typing (from ...)
  - خط 2: pandas
  - خط 3: fastapi (from ...)
  - خط 4: pydantic (from ...)
  - خط 5: src.analytics.patterns (from ...)
- کلاس‌ها:
  - خط 9: class Candle (Bases: BaseModel)
  - خط 16: class PatternRequest (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 7: router

### Ai-trade-kiro/backend/api/portfolio_router.py
- خطوط: 270 | اندازه: 9809 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: pydantic (from ...)
  - خط 9: datetime (from ...)
  - خط 10: logging
  - خط 13: models.user (from ...)
  - خط 14: services.portfolio_service (from ...)
  - خط 15: middleware.auth_middleware (from ...)
- کلاس‌ها:
  - خط 22: class PortfolioCreate (Bases: BaseModel)
  - خط 28: class PortfolioUpdate (Bases: BaseModel)
  - خط 33: class AssetUpdate (Bases: BaseModel)
  - خط 37: class PerformanceRequest (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 17: logger
  - خط 19: router

### Ai-trade-kiro/backend/api/position_tracking.py
- خطوط: 7 | اندازه: 159 بایت
- Imports:
  - خط 1: fastapi (from ...)
- انتساب‌های سطح بالا:
  - خط 3: router

### Ai-trade-kiro/backend/api/real_trading_api.py
- خطوط: 78 | اندازه: 3435 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: pydantic (from ...)
  - خط 3: typing (from ...)
  - خط 5: src.real_trading.binance_real_connector (from ...)
  - خط 6: src.real_trading.paper_trading_engine (from ...)
  - خط 7: src.real_trading.order_management (from ...)
- کلاس‌ها:
  - خط 14: class OrderRequest (Bases: BaseModel)
  - خط 21: class TradingMode (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 9: router
  - خط 12: order_manager

### Ai-trade-kiro/backend/api/signal_router.py
- خطوط: 164 | اندازه: 5830 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: pydantic (from ...)
  - خط 9: datetime (from ...)
  - خط 10: logging
  - خط 13: models.user (from ...)
  - خط 14: models.signal (from ...)
  - خط 15: services.signal_service (from ...)
  - خط 16: services.hybrid_signal_service (from ...)
  - خط 17: middleware.auth_middleware (from ...)
- کلاس‌ها:
  - خط 24: class SignalFilter (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 19: logger
  - خط 21: router

### Ai-trade-kiro/backend/api/strategy_router.py
- خطوط: 227 | اندازه: 8160 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: pydantic (from ...)
  - خط 9: datetime (from ...)
  - خط 10: logging
  - خط 11: json
  - خط 12: uuid
  - خط 15: models.user (from ...)
  - خط 16: models.strategy (from ...)
  - خط 17: services.strategy_service (from ...)
  - خط 18: services.backtest_service (from ...)
  - خط 19: middleware.auth_middleware (from ...)
- کلاس‌ها:
  - خط 26: class BacktestRequest (Bases: BaseModel)
  - خط 33: class DeployRequest (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 21: logger
  - خط 23: router

### Ai-trade-kiro/backend/api/strategy_watchlist.py
- خطوط: 151 | اندازه: 5577 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: src.api.multi_source_manager (from ...)
  - خط 3: src.analytics.indicators (from ...)
  - خط 4: src.analytics.core_algorithm (from ...)
  - خط 5: src.analytics.smc (from ...)
  - خط 6: typing (from ...)
  - خط 7: pandas
  - خط 10: src.api.crypto_multi_source_manager (from ...)
- توابع:
  - خط 15: def get_major_crypto_symbols(1 args)
  - خط 43: def calculate_core_score(1 args)
  - خط 50: def calculate_smc_score(1 args)
  - خط 61: def get_trading_recommendation(1 args)
  - خط 73: def passes_strategy_filters(5 args)
- انتساب‌های سطح بالا:
  - خط 12: router

### Ai-trade-kiro/backend/api/trading.py
- خطوط: 420 | اندازه: 14006 بایت
- Imports:
  - خط 1: flask (from ...)
  - خط 2: flask_cors (from ...)
  - خط 3: json
  - خط 4: uuid
  - خط 5: datetime (from ...)
  - خط 6: typing (from ...)
  - خط 7: logging
  - خط 8: dataclasses (from ...)
  - خط 9: enum (from ...)
- توابع:
  - خط 107: def place_order(0 args)
  - خط 176: def confirm_order(1 args)
  - خط 194: def cancel_order(1 args)
  - خط 218: def get_orders(0 args)
  - خط 246: def get_user_settings(0 args)
  - خط 259: def update_user_settings(0 args)
  - خط 285: def create_backup(0 args)
  - خط 329: def restore_backup(0 args)
  - خط 350: def get_exchanges(0 args)
  - خط 369: def execute_order_immediately(1 args)
- کلاس‌ها:
  - خط 18: class OrderStatus (Bases: Enum)
  - خط 24: class OrderSide (Bases: Enum)
  - خط 28: class OrderType (Bases: Enum)
  - خط 33: class TradeOrder (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: app
  - خط 16: logger
  - خط 75: EXCHANGE_CONFIGS

### Ai-trade-kiro/backend/api/webhook_router.py
- خطوط: 316 | اندازه: 10771 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: typing (from ...)
  - خط 8: pydantic (from ...)
  - خط 9: datetime (from ...)
  - خط 10: logging
  - خط 11: uuid
  - خط 12: hmac
  - خط 13: hashlib
  - خط 14: json
  - خط 17: models.user (from ...)
  - خط 18: services.webhook_service (from ...)
  - خط 19: services.notification_service (from ...)
  - خط 20: services.alert_service (from ...)
  - خط 21: middleware.auth_middleware (from ...)
- کلاس‌ها:
  - خط 30: class WebhookSubscription (Bases: BaseModel)
  - خط 48: class WebhookEvent (Bases: BaseModel)
  - خط 53: class NotificationRequest (Bases: BaseModel)
  - خط 60: class AlertRule (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 23: logger
  - خط 26: webhook_router
  - خط 27: notification_router

### Ai-trade-kiro/backend/app/__init__.py
- خطوط: 1 | اندازه: 13 بایت

### Ai-trade-kiro/backend/app/main.py
- خطوط: 64 | اندازه: 1698 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: fastapi.middleware.cors (from ...)
  - خط 3: contextlib (from ...)
  - خط 4: logging
  - خط 6: app.api.v1.api (from ...)
  - خط 7: app.core.config (from ...)
  - خط 8: app.services.trading_automation_service (from ...)
  - خط 9: app.core.dependencies (from ...)
- انتساب‌های سطح بالا:
  - خط 13: logger
  - خط 39: app

### Ai-trade-kiro/backend/app/api/__init__.py
- خطوط: 1 | اندازه: 5 بایت

### Ai-trade-kiro/backend/app/api/router.py
- خطوط: 17 | اندازه: 333 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 8: app.api.endpoints (from ...)
- انتساب‌های سطح بالا:
  - خط 10: api_router

### Ai-trade-kiro/backend/app/api/endpoints/__init__.py
- خطوط: 5 | اندازه: 98 بایت

### Ai-trade-kiro/backend/app/api/endpoints/health.py
- خطوط: 64 | اندازه: 1790 بایت
- Imports:
  - خط 4: fastapi (from ...)
  - خط 5: typing (from ...)
  - خط 7: app.core.db_config (from ...)
- انتساب‌های سطح بالا:
  - خط 9: router

### Ai-trade-kiro/backend/app/api/endpoints/market_data.py
- خطوط: 207 | اندازه: 6486 بایت
- Imports:
  - خط 6: datetime (from ...)
  - خط 7: typing (from ...)
  - خط 8: fastapi (from ...)
  - خط 9: sqlalchemy.ext.asyncio (from ...)
  - خط 11: app.core.dependencies (from ...)
  - خط 12: app.services.normalization (from ...)
  - خط 13: app.repositories.market_data (from ...)
  - خط 14: app.schemas.market_data (from ...)
- انتساب‌های سطح بالا:
  - خط 24: router
  - خط 25: normalization_service
  - خط 26: market_data_repository

### Ai-trade-kiro/backend/app/api/v1/__init__.py
- خطوط: 1 | اندازه: 8 بایت

### Ai-trade-kiro/backend/app/api/v1/api.py
- خطوط: 8 | اندازه: 361 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 3: app.api.v1.endpoints (from ...)
- انتساب‌های سطح بالا:
  - خط 5: api_router

### Ai-trade-kiro/backend/app/api/v1/endpoints/__init__.py
- خطوط: 1 | اندازه: 15 بایت

### Ai-trade-kiro/backend/app/api/v1/endpoints/auth.py
- خطوط: 108 | اندازه: 3315 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: fastapi.security (from ...)
  - خط 3: sqlalchemy.ext.asyncio (from ...)
  - خط 4: sqlalchemy.future (from ...)
  - خط 5: jose (from ...)
  - خط 7: app.core.dependencies (from ...)
  - خط 8: app.models.user (from ...)
  - خط 9: app.schemas.token (from ...)
  - خط 10: app.utils.security (from ...)
  - خط 15: app.core.config (from ...)
- انتساب‌های سطح بالا:
  - خط 17: router

### Ai-trade-kiro/backend/app/api/v1/endpoints/health.py
- خطوط: 24 | اندازه: 561 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: sqlalchemy.ext.asyncio (from ...)
  - خط 4: app.core.dependencies (from ...)
- انتساب‌های سطح بالا:
  - خط 6: router

### Ai-trade-kiro/backend/app/api/v1/endpoints/strategies.py
- خطوط: 210 | اندازه: 7756 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: sqlalchemy.ext.asyncio (from ...)
  - خط 3: typing (from ...)
  - خط 5: app.core.dependencies (from ...)
  - خط 6: app.models.user (from ...)
  - خط 7: app.schemas.strategy (from ...)
  - خط 11: app.services.strategy_service (from ...)
  - خط 12: app.services.backtesting_service (from ...)
- انتساب‌های سطح بالا:
  - خط 14: router
  - خط 15: strategy_service
  - خط 16: backtesting_service

### Ai-trade-kiro/backend/app/api/v1/endpoints/users.py
- خطوط: 143 | اندازه: 3784 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: sqlalchemy.ext.asyncio (from ...)
  - خط 3: sqlalchemy.future (from ...)
  - خط 4: typing (from ...)
  - خط 6: app.core.dependencies (from ...)
  - خط 11: app.models.user (from ...)
  - خط 12: app.schemas.user (from ...)
  - خط 13: app.utils.security (from ...)
- انتساب‌های سطح بالا:
  - خط 15: router

### Ai-trade-kiro/backend/app/core/__init__.py
- خطوط: 1 | اندازه: 6 بایت

### Ai-trade-kiro/backend/app/core/config.py
- خطوط: 88 | اندازه: 2936 بایت
- Imports:
  - خط 1: typing (from ...)
  - خط 2: pydantic (from ...)
- کلاس‌ها:
  - خط 5: class Settings (Bases: BaseSettings)
- انتساب‌های سطح بالا:
  - خط 88: settings

### Ai-trade-kiro/backend/app/core/db_config.py
- خطوط: 401 | اندازه: 13379 بایت
- Imports:
  - خط 5: os
  - خط 6: typing (from ...)
  - خط 7: asyncio
  - خط 8: contextlib (from ...)
  - خط 10: redis
  - خط 11: redis.cluster (from ...)
  - خط 12: redis.sentinel (from ...)
  - خط 13: aioredis
  - خط 14: sqlalchemy (from ...)
  - خط 15: sqlalchemy.ext.asyncio (from ...)
  - خط 16: sqlalchemy.ext.declarative (from ...)
  - خط 17: sqlalchemy.orm (from ...)
  - خط 18: sqlalchemy.pool (from ...)
- توابع:
  - خط 133: def get_sync_postgres_session(0 args)
  - خط 137: def get_sync_timescale_session(0 args)
  - خط 141: def get_redis_client(0 args)
- کلاس‌ها:
  - خط 227: class RedisCache (Bases: -)
  - خط 317: class TimeseriesDB (Bases: -)
- انتساب‌های سطح بالا:
  - خط 21: Base
  - خط 24: POSTGRES_URL
  - خط 25: TIMESCALE_URL
  - خط 26: REDIS_URL
  - خط 29: ASYNC_POSTGRES_URL
  - خط 30: ASYNC_TIMESCALE_URL
  - خط 33: postgres_engine
  - خط 43: timescale_engine
  - خط 54: async_postgres_engine
  - خط 64: async_timescale_engine
  - ... (7 مورد دیگر)

### Ai-trade-kiro/backend/app/core/dependencies.py
- خطوط: 80 | اندازه: 2258 بایت
- Imports:
  - خط 1: fastapi (from ...)
  - خط 2: fastapi.security (from ...)
  - خط 3: jose (from ...)
  - خط 4: sqlalchemy.ext.asyncio (from ...)
  - خط 5: typing (from ...)
  - خط 7: app.core.config (from ...)
  - خط 8: app.db.session (from ...)
  - خط 9: app.models.user (from ...)
  - خط 10: app.schemas.token (from ...)
  - خط 11: app.utils.security (from ...)
- انتساب‌های سطح بالا:
  - خط 13: oauth2_scheme

### Ai-trade-kiro/backend/app/db/__init__.py
- خطوط: 1 | اندازه: 10 بایت

### Ai-trade-kiro/backend/app/db/session.py
- خطوط: 16 | اندازه: 414 بایت
- Imports:
  - خط 1: sqlalchemy.ext.asyncio (from ...)
  - خط 2: sqlalchemy.orm (from ...)
  - خط 4: app.core.config (from ...)
- انتساب‌های سطح بالا:
  - خط 7: engine
  - خط 14: async_session

### Ai-trade-kiro/backend/app/models/__init__.py
- خطوط: 1 | اندازه: 8 بایت

### Ai-trade-kiro/backend/app/models/base.py
- خطوط: 17 | اندازه: 360 بایت
- Imports:
  - خط 1: sqlalchemy.ext.declarative (from ...)
  - خط 2: sqlalchemy.orm (from ...)
- کلاس‌ها:
  - خط 5: class Base (Bases: -)
- انتساب‌های سطح بالا:
  - خط 17: Base

### Ai-trade-kiro/backend/app/models/market_data.py
- خطوط: 53 | اندازه: 1524 بایت
- Imports:
  - خط 1: sqlalchemy (from ...)
  - خط 2: datetime (from ...)
  - خط 4: app.models.base (from ...)
- کلاس‌ها:
  - خط 7: class MarketDataBase (Bases: Base)
  - خط 20: class OHLCV (Bases: MarketDataBase)
  - خط 34: class OrderBook (Bases: MarketDataBase)
  - خط 44: class Trade (Bases: MarketDataBase)

### Ai-trade-kiro/backend/app/models/strategy.py
- خطوط: 91 | اندازه: 3749 بایت
- Imports:
  - خط 1: sqlalchemy (from ...)
  - خط 2: sqlalchemy.orm (from ...)
  - خط 3: datetime (from ...)
  - خط 5: app.models.base (from ...)
- کلاس‌ها:
  - خط 7: class Strategy (Bases: Base)
  - خط 31: class BacktestResult (Bases: Base)
  - خط 51: class TradingSession (Bases: Base)
  - خط 70: class Trade (Bases: Base)

### Ai-trade-kiro/backend/app/models/user.py
- خطوط: 24 | اندازه: 858 بایت
- Imports:
  - خط 1: sqlalchemy (from ...)
  - خط 2: sqlalchemy.orm (from ...)
  - خط 3: datetime (from ...)
  - خط 5: app.models.base (from ...)
- کلاس‌ها:
  - خط 8: class User (Bases: Base)

### Ai-trade-kiro/backend/app/repositories/__init__.py
- خطوط: 1 | اندازه: 14 بایت

### Ai-trade-kiro/backend/app/repositories/market_data.py
- خطوط: 185 | اندازه: 4975 بایت
- Imports:
  - خط 1: sqlalchemy.ext.asyncio (from ...)
  - خط 2: sqlalchemy.future (from ...)
  - خط 3: sqlalchemy (from ...)
  - خط 4: typing (from ...)
  - خط 5: datetime (from ...)
  - خط 7: app.models.market_data (from ...)
- کلاس‌ها:
  - خط 10: class MarketDataRepository (Bases: -)

### Ai-trade-kiro/backend/app/repositories/strategy_repository.py
- خطوط: 306 | اندازه: 8975 بایت
- Imports:
  - خط 1: sqlalchemy.ext.asyncio (from ...)
  - خط 2: sqlalchemy.future (from ...)
  - خط 3: sqlalchemy (from ...)
  - خط 4: typing (from ...)
  - خط 6: app.models.strategy (from ...)
- کلاس‌ها:
  - خط 9: class StrategyRepository (Bases: -)

### Ai-trade-kiro/backend/app/schemas/__init__.py
- خطوط: 1 | اندازه: 9 بایت

### Ai-trade-kiro/backend/app/schemas/base.py
- خطوط: 16 | اندازه: 257 بایت
- Imports:
  - خط 1: pydantic (from ...)
- کلاس‌ها:
  - خط 4: class BaseSchema (Bases: BaseModel)
  - خط 12: class BaseAPISchema (Bases: BaseModel)

### Ai-trade-kiro/backend/app/schemas/market_data.py
- خطوط: 217 | اندازه: 4916 بایت
- Imports:
  - خط 1: pydantic (from ...)
  - خط 2: typing (from ...)
  - خط 3: datetime (from ...)
  - خط 5: app.schemas.base (from ...)
- کلاس‌ها:
  - خط 8: class OHLCVBase (Bases: BaseModel)
  - خط 37: class OHLCVCreate (Bases: OHLCVBase)
  - خط 44: class OHLCV (Bases: OHLCVBase, BaseSchema)
  - خط 52: class OrderBookEntry (Bases: BaseModel)
  - خط 60: class OrderBookBase (Bases: BaseModel)
  - خط 145: class OrderBookCreate (Bases: OrderBookBase)
  - خط 152: class OrderBook (Bases: OrderBookBase, BaseSchema)
  - خط 160: class TradeBase (Bases: BaseModel)
  - خط 173: class TradeCreate (Bases: TradeBase)
  - خط 180: class Trade (Bases: TradeBase, BaseSchema)
  - خط 188: class SymbolInfo (Bases: BaseModel)
  - خط 203: class ExchangeInfo (Bases: BaseModel)
  - خط 212: class Config (Bases: BaseModel)

### Ai-trade-kiro/backend/app/schemas/strategy.py
- خطوط: 149 | اندازه: 3368 بایت
- Imports:
  - خط 1: pydantic (from ...)
  - خط 2: typing (from ...)
  - خط 3: datetime (from ...)
  - خط 4: enum (from ...)
  - خط 6: app.schemas.base (from ...)
- کلاس‌ها:
  - خط 9: class ComponentType (Bases: str, Enum)
  - خط 22: class Position (Bases: BaseModel)
  - خط 27: class ComponentBase (Bases: BaseModel)
  - خط 36: class ConnectionBase (Bases: BaseModel)
  - خط 44: class StrategyBase (Bases: BaseModel)
  - خط 53: class StrategyCreate (Bases: StrategyBase)
  - خط 57: class StrategyUpdate (Bases: BaseModel)
  - خط 67: class TradeBase (Bases: BaseModel)
  - خط 79: class BacktestMetrics (Bases: BaseModel)
  - خط 94: class BacktestResultBase (Bases: BaseModel)
  - خط 103: class BacktestRequest (Bases: BaseModel)
  - خط 110: class BacktestResult (Bases: BacktestResultBase, BaseSchema)
  - خط 116: class TradingSessionBase (Bases: BaseModel)
  - خط 124: class TradingSession (Bases: TradingSessionBase, BaseSchema)
  - خط 129: class TradeCreate (Bases: TradeBase)
  - خط 135: class Trade (Bases: TradeBase, BaseSchema)
  - خط 142: class Strategy (Bases: StrategyBase, BaseSchema)

### Ai-trade-kiro/backend/app/schemas/token.py
- خطوط: 26 | اندازه: 390 بایت
- Imports:
  - خط 1: pydantic (from ...)
- کلاس‌ها:
  - خط 4: class Token (Bases: BaseModel)
  - خط 13: class TokenPayload (Bases: BaseModel)
  - خط 22: class RefreshToken (Bases: BaseModel)

### Ai-trade-kiro/backend/app/schemas/user.py
- خطوط: 47 | اندازه: 824 بایت
- Imports:
  - خط 1: pydantic (from ...)
  - خط 2: typing (from ...)
  - خط 4: app.schemas.base (from ...)
- کلاس‌ها:
  - خط 7: class UserBase (Bases: BaseModel)
  - خط 17: class UserCreate (Bases: UserBase)
  - خط 25: class UserUpdate (Bases: UserBase)
  - خط 32: class UserInDB (Bases: UserBase)
  - خط 43: class User (Bases: UserBase, BaseSchema)

### Ai-trade-kiro/backend/app/services/__init__.py
- خطوط: 1 | اندازه: 10 بایت

### Ai-trade-kiro/backend/app/services/backtesting_service.py
- خطوط: 282 | اندازه: 12070 بایت
- Imports:
  - خط 1: datetime (from ...)
  - خط 2: typing (from ...)
  - خط 3: sqlalchemy.ext.asyncio (from ...)
  - خط 4: pandas
  - خط 5: numpy
  - خط 7: app.models.strategy (from ...)
  - خط 8: app.repositories.market_data (from ...)
  - خط 9: app.services.strategy_executor (from ...)
- کلاس‌ها:
  - خط 12: class BacktestingService (Bases: -)

### Ai-trade-kiro/backend/app/services/historical_data.py
- خطوط: 320 | اندازه: 12281 بایت
- Imports:
  - خط 6: datetime (from ...)
  - خط 7: logging
  - خط 8: typing (from ...)
  - خط 9: asyncio
  - خط 10: math
  - خط 12: sqlalchemy.ext.asyncio (from ...)
  - خط 14: app.services.exchange.base (from ...)
  - خط 15: app.services.normalization (from ...)
  - خط 16: app.repositories.market_data (from ...)
  - خط 17: app.schemas.market_data (from ...)
  - خط 18: app.models.market_data (from ...)
- کلاس‌ها:
  - خط 20: class HistoricalDataService (Bases: -)

### Ai-trade-kiro/backend/app/services/ml_service.py
- خطوط: 310 | اندازه: 10259 بایت
- Imports:
  - خط 1: numpy
  - خط 2: pandas
  - خط 3: typing (from ...)
  - خط 4: datetime (from ...)
- توابع:
  - خط 224: def get_ai_analytics_prediction(2 args)
  - خط 262: def generate_final_trading_signal(1 args)
- کلاس‌ها:
  - خط 7: class MLService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 221: ml_service

### Ai-trade-kiro/backend/app/services/normalization.py
- خطوط: 188 | اندازه: 6885 بایت
- Imports:
  - خط 6: datetime (from ...)
  - خط 7: typing (from ...)
  - خط 8: logging
  - خط 10: app.services.exchange.base (from ...)
  - خط 11: app.services.exchange.binance (from ...)
  - خط 12: app.services.exchange.coinbase (from ...)
  - خط 13: app.schemas.market_data (from ...)
- کلاس‌ها:
  - خط 21: class NormalizationService (Bases: -)

### Ai-trade-kiro/backend/app/services/pattern_recognition.py
- خطوط: 378 | اندازه: 16493 بایت
- Imports:
  - خط 1: pandas
  - خط 2: numpy
  - خط 3: typing (from ...)
- کلاس‌ها:
  - خط 6: class PatternRecognitionService (Bases: -)

### Ai-trade-kiro/backend/app/services/smart_money.py
- خطوط: 378 | اندازه: 14788 بایت
- Imports:
  - خط 1: pandas
  - خط 2: numpy
  - خط 3: typing (from ...)
- کلاس‌ها:
  - خط 6: class SmartMoneyService (Bases: -)

### Ai-trade-kiro/backend/app/services/strategy_executor.py
- خطوط: 458 | اندازه: 18969 بایت
- Imports:
  - خط 1: pandas
  - خط 2: numpy
  - خط 3: typing (from ...)
  - خط 4: datetime (from ...)
  - خط 6: app.services.technical_indicators (from ...)
  - خط 7: app.services.pattern_recognition (from ...)
  - خط 8: app.services.smart_money (from ...)
  - خط 9: app.services.ml_service (from ...)
- کلاس‌ها:
  - خط 12: class StrategyExecutor (Bases: -)

### Ai-trade-kiro/backend/app/services/strategy_service.py
- خطوط: 244 | اندازه: 7235 بایت
- Imports:
  - خط 1: sqlalchemy.ext.asyncio (from ...)
  - خط 2: typing (from ...)
  - خط 4: app.models.strategy (from ...)
  - خط 5: app.schemas.strategy (from ...)
  - خط 6: app.repositories.strategy_repository (from ...)
- کلاس‌ها:
  - خط 9: class StrategyService (Bases: -)

### Ai-trade-kiro/backend/app/services/technical_indicators.py
- خطوط: 340 | اندازه: 12476 بایت
- Imports:
  - خط 1: pandas
  - خط 2: numpy
  - خط 3: typing (from ...)
- کلاس‌ها:
  - خط 6: class TechnicalIndicatorService (Bases: -)

### Ai-trade-kiro/backend/app/services/trading_automation_service.py
- خطوط: 315 | اندازه: 11981 بایت
- Imports:
  - خط 1: sqlalchemy.ext.asyncio (from ...)
  - خط 2: typing (from ...)
  - خط 3: datetime (from ...)
  - خط 4: asyncio
  - خط 5: logging
  - خط 7: app.models.strategy (from ...)
  - خط 8: app.repositories.strategy_repository (from ...)
  - خط 9: app.repositories.market_data (from ...)
  - خط 10: app.services.strategy_executor (from ...)
- کلاس‌ها:
  - خط 17: class TradingAutomationService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 14: logger
  - خط 315: trading_automation_service

### Ai-trade-kiro/backend/app/services/exchange/__init__.py
- خطوط: 5 | اندازه: 128 بایت

### Ai-trade-kiro/backend/app/services/exchange/base.py
- خطوط: 117 | اندازه: 3595 بایت
- Imports:
  - خط 6: abc (from ...)
  - خط 7: datetime (from ...)
  - خط 8: typing (from ...)
  - خط 10: app.schemas.market_data (from ...)
- کلاس‌ها:
  - خط 18: class ExchangeAdapter (Bases: ABC)

### Ai-trade-kiro/backend/app/services/exchange/binance.py
- خطوط: 310 | اندازه: 11311 بایت
- Imports:
  - خط 6: datetime (from ...)
  - خط 7: typing (from ...)
  - خط 9: app.services.exchange.base (from ...)
  - خط 10: app.schemas.market_data (from ...)
- کلاس‌ها:
  - خط 17: class BinanceAdapter (Bases: ExchangeAdapter)

### Ai-trade-kiro/backend/app/services/exchange/coinbase.py
- خطوط: 253 | اندازه: 9132 بایت
- Imports:
  - خط 6: datetime (from ...)
  - خط 7: typing (from ...)
  - خط 9: app.services.exchange.base (from ...)
  - خط 10: app.schemas.market_data (from ...)
- کلاس‌ها:
  - خط 17: class CoinbaseAdapter (Bases: ExchangeAdapter)

### Ai-trade-kiro/backend/app/utils/__init__.py
- خطوط: 1 | اندازه: 11 بایت

### Ai-trade-kiro/backend/app/utils/security.py
- خطوط: 70 | اندازه: 1705 بایت
- Imports:
  - خط 1: datetime (from ...)
  - خط 2: typing (from ...)
  - خط 3: jose (from ...)
  - خط 4: passlib.context (from ...)
  - خط 5: app.core.config (from ...)
- توابع:
  - خط 11: def create_access_token(1 args)
  - خط 22: def create_refresh_token(1 args)
  - خط 33: def create_token(3 args)
  - خط 59: def verify_password(2 args)
  - خط 66: def get_password_hash(1 args)
- انتساب‌های سطح بالا:
  - خط 8: pwd_context

### Ai-trade-kiro/backend/back_temp/auth_system.py
- خطوط: 571 | اندازه: 19664 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: hashlib
  - خط 8: secrets
  - خط 9: jwt
  - خط 10: datetime (from ...)
  - خط 11: typing (from ...)
  - خط 12: passlib.context (from ...)
  - خط 13: fastapi (from ...)
  - خط 14: fastapi.security (from ...)
  - خط 15: pydantic (from ...)
  - خط 16: redis
  - خط 17: logging
  - خط 18: email_validator (from ...)
  - خط 19: re
- کلاس‌ها:
  - خط 39: class UserRegistration (Bases: BaseModel)
  - خط 57: class UserLogin (Bases: BaseModel)
  - خط 62: class PasswordReset (Bases: BaseModel)
  - خط 65: class PasswordResetConfirm (Bases: BaseModel)
  - خط 75: class PasswordChange (Bases: BaseModel)
  - خط 79: class TokenResponse (Bases: BaseModel)
  - خط 85: class UserProfile (Bases: BaseModel)
  - خط 95: class User (Bases: BaseModel)
  - خط 111: class SecurityService (Bases: -)
  - خط 207: class UserService (Bases: -)
  - خط 360: class RateLimiter (Bases: -)
- انتساب‌های سطح بالا:
  - خط 21: logger
  - خط 24: SECRET_KEY
  - خط 25: ALGORITHM
  - خط 26: ACCESS_TOKEN_EXPIRE_MINUTES
  - خط 27: REFRESH_TOKEN_EXPIRE_DAYS
  - خط 28: REDIS_URL
  - خط 31: pwd_context
  - خط 32: security
  - خط 33: oauth2_scheme
  - خط 36: redis_client
  - ... (1 مورد دیگر)

### Ai-trade-kiro/backend/back_temp/binance_api.py
- خطوط: 509 | اندازه: 20074 بایت
- Imports:
  - خط 7: asyncio
  - خط 8: hashlib
  - خط 9: hmac
  - خط 10: time
  - خط 11: base64
  - خط 12: abc (from ...)
  - خط 13: typing (from ...)
  - خط 14: aiohttp
  - خط 15: json
  - خط 16: decimal (from ...)
  - خط 17: datetime (from ...)
  - خط 18: logging
  - خط 19: urllib.parse (from ...)
- کلاس‌ها:
  - خط 23: class BaseExchange (Bases: ABC)
  - خط 94: class BinanceAPI (Bases: BaseExchange)
  - خط 162: class CoinbaseAPI (Bases: BaseExchange)
  - خط 219: class OKXAPI (Bases: BaseExchange)
  - خط 279: class BybitAPI (Bases: BaseExchange)
  - خط 333: class KrakenAPI (Bases: BaseExchange)
  - خط 385: class KuCoinAPI (Bases: BaseExchange)
  - خط 446: class ExchangeFactory (Bases: -)
- انتساب‌های سطح بالا:
  - خط 21: logger

### Ai-trade-kiro/backend/back_temp/data_processing_services.py
- خطوط: 674 | اندازه: 23123 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: pandas
  - خط 8: numpy
  - خط 9: typing (from ...)
  - خط 10: datetime (from ...)
  - خط 11: decimal (from ...)
  - خط 12: json
  - خط 13: logging
  - خط 14: dataclasses (from ...)
  - خط 15: abc (from ...)
  - خط 16: aioredis
  - خط 17: pydantic (from ...)
  - خط 18: enum (from ...)
  - خط 19: math
- کلاس‌ها:
  - خط 24: class TimeFrame (Bases: str, Enum)
  - خط 34: class DataType (Bases: str, Enum)
  - خط 42: class OHLCV (Bases: -)
  - خط 81: class MarketData (Bases: -)
  - خط 95: class OrderBookLevel (Bases: BaseModel)
  - خط 100: class OrderBook (Bases: BaseModel)
  - خط 123: class DataNormalizationService (Bases: -)
  - خط 232: class DataValidationService (Bases: -)
  - خط 348: class DataAggregationService (Bases: -)
  - خط 473: class DataProcessingService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 21: logger

### Ai-trade-kiro/backend/back_temp/database_models.py
- خطوط: 508 | اندازه: 18774 بایت
- Imports:
  - خط 6: sqlalchemy (from ...)
  - خط 10: sqlalchemy.ext.declarative (from ...)
  - خط 11: sqlalchemy.orm (from ...)
  - خط 12: sqlalchemy.sql (from ...)
  - خط 13: datetime (from ...)
  - خط 14: enum (from ...)
  - خط 15: uuid
- کلاس‌ها:
  - خط 20: class OrderSide (Bases: str, Enum)
  - خط 24: class OrderType (Bases: str, Enum)
  - خط 32: class OrderStatus (Bases: str, Enum)
  - خط 40: class TradeStatus (Bases: str, Enum)
  - خط 45: class AlertLevel (Bases: str, Enum)
  - خط 51: class StrategyStatus (Bases: str, Enum)
  - خط 58: class User (Bases: Base)
  - خط 90: class APIKey (Bases: Base)
  - خط 119: class Portfolio (Bases: Base)
  - خط 149: class PortfolioAsset (Bases: Base)
  - خط 177: class PortfolioSnapshot (Bases: Base)
  - خط 199: class Order (Bases: Base)
  - خط 250: class Trade (Bases: Base)
  - خط 287: class Strategy (Bases: Base)
  - خط 330: class BacktestResult (Bases: Base)
  - خط 374: class Alert (Bases: Base)
  - خط 412: class Notification (Bases: Base)
  - خط 448: class MarketData (Bases: Base)
  - خط 480: class AuditLog (Bases: Base)
- انتساب‌های سطح بالا:
  - خط 17: Base

### Ai-trade-kiro/backend/back_temp/exchange_router.py
- خطوط: 413 | اندازه: 16291 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: fastapi.security (from ...)
  - خط 8: typing (from ...)
  - خط 9: pydantic (from ...)
  - خط 10: asyncio
  - خط 11: json
  - خط 12: datetime (from ...)
  - خط 13: logging
  - خط 15: exchanges.exchange_apis (from ...)
  - خط 16: middleware.auth_middleware (from ...)
  - خط 17: services.user_service (from ...)
  - خط 18: models.user (from ...)
  - خط 19: models.trading (from ...)
- کلاس‌ها:
  - خط 25: class ExchangeCredentials (Bases: BaseModel)
  - خط 31: class MarketDataRequest (Bases: BaseModel)
  - خط 37: class OrderRequest (Bases: BaseModel)
  - خط 46: class ExchangeInfoResponse (Bases: BaseModel)
  - خط 52: class TickerResponse (Bases: BaseModel)
  - خط 60: class OrderBookResponse (Bases: BaseModel)
  - خط 67: class OrderResponse (Bases: BaseModel)
- انتساب‌های سطح بالا:
  - خط 21: logger
  - خط 22: security
  - خط 79: router

### Ai-trade-kiro/backend/back_temp/ml_models_production.py
- خطوط: 994 | اندازه: 40438 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: numpy
  - خط 8: pandas
  - خط 9: typing (from ...)
  - خط 10: datetime (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: pickle
  - خط 13: joblib
  - خط 14: abc (from ...)
  - خط 15: logging
  - خط 16: sklearn.preprocessing (from ...)
  - خط 17: sklearn.ensemble (from ...)
  - خط 18: sklearn.model_selection (from ...)
  - خط 19: sklearn.metrics (from ...)
  - خط 20: xgboost
  - خط 21: lightgbm
  - خط 22: textblob (from ...)
  - خط 23: re
  - خط 24: requests
  - خط 25: transformers (from ...)
  - خط 26: torch
  - خط 27: talib
  - خط 28: warnings
- کلاس‌ها:
  - خط 35: class PredictionResult (Bases: -)
  - خط 46: class SentimentResult (Bases: -)
  - خط 56: class PatternResult (Bases: -)
  - خط 67: class BaseMLModel (Bases: ABC)
  - خط 105: class FeatureEngineer (Bases: -)
  - خط 238: class PricePredictionModel (Bases: BaseMLModel)
  - خط 453: class SentimentAnalysisModel (Bases: BaseMLModel)
  - خط 587: class PatternRecognitionModel (Bases: BaseMLModel)
  - خط 868: class ModelTrainingPipeline (Bases: -)
- انتساب‌های سطح بالا:
  - خط 31: logger

### Ai-trade-kiro/backend/back_temp/webhook_notification_system.py
- خطوط: 979 | اندازه: 34964 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: json
  - خط 8: smtplib
  - خط 9: email.mime.text (from ...)
  - خط 10: email.mime.multipart (from ...)
  - خط 11: typing (from ...)
  - خط 12: datetime (from ...)
  - خط 13: dataclasses (from ...)
  - خط 14: abc (from ...)
  - خط 15: fastapi (from ...)
  - خط 16: pydantic (from ...)
  - خط 17: aiohttp
  - خط 18: logging
  - خط 19: enum (from ...)
  - خط 20: redis
  - خط 21: celery (from ...)
  - خط 22: telegram
  - خط 23: discord
  - خط 24: slack_sdk.web.async_client (from ...)
  - خط 25: smtplib
  - خط 26: email.mime.text (from ...)
  - خط 27: email.mime.multipart (from ...)
  - خط 28: requests
  - خط 29: hashlib
  - خط 30: hmac
- توابع:
  - خط 787: def send_scheduled_notification(1 args)
  - خط 808: def process_webhook_event(1 args)
- کلاس‌ها:
  - خط 43: class NotificationType (Bases: str, Enum)
  - خط 52: class AlertLevel (Bases: str, Enum)
  - خط 58: class WebhookStatus (Bases: str, Enum)
  - خط 66: class NotificationMessage (Bases: -)
  - خط 86: class WebhookEvent (Bases: -)
  - خط 102: class WebhookSubscription (Bases: -)
  - خط 120: class NotificationRequest (Bases: BaseModel)
  - خط 129: class WebhookSubscriptionRequest (Bases: BaseModel)
  - خط 142: class AlertRule (Bases: BaseModel)
  - خط 152: class BaseNotificationProvider (Bases: ABC)
  - خط 167: class EmailProvider (Bases: BaseNotificationProvider)
  - خط 222: class TelegramProvider (Bases: BaseNotificationProvider)
  - خط 260: class DiscordProvider (Bases: BaseNotificationProvider)
  - خط 323: class SlackProvider (Bases: BaseNotificationProvider)
  - خط 403: class WebhookProvider (Bases: BaseNotificationProvider)
  - خط 456: class NotificationService (Bases: -)
  - خط 560: class WebhookService (Bases: -)
  - خط 686: class AlertEngine (Bases: -)
- انتساب‌های سطح بالا:
  - خط 32: logger
  - خط 35: REDIS_URL
  - خط 36: CELERY_BROKER
  - خط 37: CELERY_BACKEND
  - خط 40: celery_app
  - خط 826: webhook_router
  - خط 827: notification_router
  - خط 830: notification_service
  - خط 831: webhook_service
  - خط 832: alert_engine

### Ai-trade-kiro/backend/config/data_sources.py
- خطوط: 20 | اندازه: 610 بایت
- Imports:
  - خط 1: os
  - خط 2: pydantic (from ...)
- کلاس‌ها:
  - خط 4: class DataSourceSettings (Bases: BaseSettings)
- انتساب‌های سطح بالا:
  - خط 20: settings

### Ai-trade-kiro/backend/middleware/auth_middleware.py
- خطوط: 162 | اندازه: 5717 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: fastapi.security (from ...)
  - خط 8: typing (from ...)
  - خط 9: jwt
  - خط 10: datetime (from ...)
  - خط 11: logging
  - خط 12: redis
  - خط 13: os
- توابع:
  - خط 148: def verify_token(1 args)
- کلاس‌ها:
  - خط 29: class AuthenticationMiddleware (Bases: -)
- انتساب‌های سطح بالا:
  - خط 15: logger
  - خط 18: SECRET_KEY
  - خط 19: ALGORITHM
  - خط 20: REDIS_URL

### Ai-trade-kiro/backend/middleware/logging_middleware.py
- خطوط: 92 | اندازه: 3223 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: time
  - خط 8: logging
  - خط 9: json
  - خط 10: typing (from ...)
  - خط 11: uuid
- کلاس‌ها:
  - خط 15: class LoggingMiddleware (Bases: -)
- انتساب‌های سطح بالا:
  - خط 13: logger

### Ai-trade-kiro/backend/middleware/rate_limiter.py
- خطوط: 156 | اندازه: 5935 بایت
- Imports:
  - خط 6: fastapi (from ...)
  - خط 7: time
  - خط 8: logging
  - خط 9: redis
  - خط 10: os
  - خط 11: typing (from ...)
- کلاس‌ها:
  - خط 27: class RateLimiterMiddleware (Bases: -)
- انتساب‌های سطح بالا:
  - خط 13: logger
  - خط 16: REDIS_URL
  - خط 17: DEFAULT_RATE_LIMIT
  - خط 18: DEFAULT_WINDOW

### Ai-trade-kiro/backend/middleware/request_logger.py
- خطوط: 152 | اندازه: 5509 بایت
- Imports:
  - خط 6: time
  - خط 7: json
  - خط 8: logging
  - خط 9: typing (from ...)
  - خط 10: fastapi (from ...)
  - خط 11: datetime (from ...)
  - خط 12: uuid
- کلاس‌ها:
  - خط 21: class RequestLogger (Bases: -)
- انتساب‌های سطح بالا:
  - خط 19: logger

### Ai-trade-kiro/backend/models/__init__.py
- خطوط: 1 | اندازه: 16 بایت

### Ai-trade-kiro/backend/models/signal.py
- خطوط: 36 | اندازه: 984 بایت
- Imports:
  - خط 5: pydantic (from ...)
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
  - خط 8: enum (from ...)
- کلاس‌ها:
  - خط 10: class SignalDirection (Bases: str, Enum)
  - خط 15: class SignalStatus (Bases: str, Enum)
  - خط 21: class Signal (Bases: BaseModel)
  - خط 33: class HybridSignal (Bases: Signal)

### Ai-trade-kiro/backend/models/strategy.py
- خطوط: 59 | اندازه: 1579 بایت
- Imports:
  - خط 5: pydantic (from ...)
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
  - خط 8: enum (from ...)
- کلاس‌ها:
  - خط 10: class StrategyStatus (Bases: str, Enum)
  - خط 16: class StrategyType (Bases: str, Enum)
  - خط 22: class StrategyBase (Bases: BaseModel)
  - خط 30: class StrategyCreate (Bases: StrategyBase)
  - خط 33: class StrategyUpdate (Bases: BaseModel)
  - خط 40: class Strategy (Bases: StrategyBase)
  - خط 50: class BacktestResult (Bases: BaseModel)

### Ai-trade-kiro/backend/models/user.py
- خطوط: 34 | اندازه: 810 بایت
- Imports:
  - خط 5: pydantic (from ...)
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
- کلاس‌ها:
  - خط 9: class UserBase (Bases: BaseModel)
  - خط 15: class UserCreate (Bases: UserBase)
  - خط 18: class UserUpdate (Bases: UserBase)
  - خط 21: class User (Bases: UserBase)
  - خط 30: class TokenResponse (Bases: BaseModel)

### Ai-trade-kiro/backend/monitoring/error_tracker.py
- خطوط: 21 | اندازه: 525 بایت
- Imports:
  - خط 3: __future__ (from ...)
  - خط 5: logging
  - خط 6: typing (from ...)
- کلاس‌ها:
  - خط 10: class ErrorTracker (Bases: -)
- انتساب‌های سطح بالا:
  - خط 8: logger

### Ai-trade-kiro/backend/monitoring/health_check.py
- خطوط: 20 | اندازه: 383 بایت
- Imports:
  - خط 3: __future__ (from ...)

### Ai-trade-kiro/backend/monitoring/health_checks.py
- خطوط: 627 | اندازه: 23025 بایت
- Imports:
  - خط 7: os
  - خط 8: asyncio
  - خط 9: aiohttp
  - خط 10: redis
  - خط 11: psycopg2
  - خط 12: boto3
  - خط 13: json
  - خط 14: time
  - خط 15: datetime (from ...)
  - خط 16: typing (from ...)
  - خط 17: logging
  - خط 18: dataclasses (from ...)
  - خط 19: fastapi (from ...)
  - خط 20: fastapi.responses (from ...)
- کلاس‌ها:
  - خط 27: class HealthStatus (Bases: -)
  - خط 36: class HealthCheckManager (Bases: -)
- انتساب‌های سطح بالا:
  - خط 24: logger
  - خط 533: health_manager
  - خط 536: health_router
  - خط 622: __all__

### Ai-trade-kiro/backend/monitoring/performance_dashboard.py
- خطوط: 438 | اندازه: 16741 بایت
- Imports:
  - خط 7: os
  - خط 8: time
  - خط 9: psutil
  - خط 10: asyncio
  - خط 11: aiohttp
  - خط 12: redis
  - خط 13: psycopg2
  - خط 14: datetime (from ...)
  - خط 15: typing (from ...)
  - خط 16: json
  - خط 17: logging
  - خط 18: dataclasses (from ...)
  - خط 19: collections (from ...)
  - خط 20: threading
  - خط 21: queue
- توابع:
  - خط 411: def get_performance_dashboard_data(0 args)
- کلاس‌ها:
  - خط 28: class PerformanceMetrics (Bases: -)
  - خط 43: class PerformanceMonitor (Bases: -)
- انتساب‌های سطح بالا:
  - خط 25: logger
  - خط 409: performance_monitor

### Ai-trade-kiro/backend/monitoring/performance_monitor.py
- خطوط: 69 | اندازه: 2636 بایت
- Imports:
  - خط 3: __future__ (from ...)
  - خط 5: logging
  - خط 6: time
  - خط 7: typing (from ...)
- کلاس‌ها:
  - خط 16: class PerformanceMonitor (Bases: -)
- انتساب‌های سطح بالا:
  - خط 14: logger

### Ai-trade-kiro/backend/services/alert_service.py
- خطوط: 144 | اندازه: 4671 بایت
- Imports:
  - خط 5: logging
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
  - خط 8: enum (from ...)
  - خط 9: uuid
- کلاس‌ها:
  - خط 13: class AlertType (Bases: str, Enum)
  - خط 19: class AlertCondition (Bases: str, Enum)
  - خط 25: class AlertStatus (Bases: str, Enum)
  - خط 31: class AlertService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger

### Ai-trade-kiro/backend/services/backtest_service.py
- خطوط: 66 | اندازه: 2566 بایت
- Imports:
  - خط 5: logging
  - خط 6: random
  - خط 7: typing (from ...)
  - خط 8: datetime (from ...)
- کلاس‌ها:
  - خط 12: class BacktestService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 10: logger

### Ai-trade-kiro/backend/services/backtesting_service.py
- خطوط: 783 | اندازه: 29385 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: logging
  - خط 8: pandas
  - خط 9: numpy
  - خط 10: typing (from ...)
  - خط 11: datetime (from ...)
  - خط 12: dataclasses (from ...)
  - خط 13: enum (from ...)
  - خط 14: json
  - خط 15: copy
  - خط 18: market_data_service (from ...)
  - خط 19: hybrid_signal_service (from ...)
  - خط 20: portfolio_optimization_service (from ...)
- کلاس‌ها:
  - خط 24: class OrderType (Bases: Enum)
  - خط 30: class OrderSide (Bases: Enum)
  - خط 34: class OrderStatus (Bases: Enum)
  - خط 41: class Order (Bases: -)
  - خط 56: class Position (Bases: -)
  - خط 65: class Trade (Bases: -)
  - خط 76: class BacktestResult (Bases: -)
  - خط 103: class BacktestingEngine (Bases: -)
- انتساب‌های سطح بالا:
  - خط 22: logger

### Ai-trade-kiro/backend/services/hybrid_signal_service.py
- خطوط: 611 | اندازه: 25414 بایت
- Imports:
  - خط 12: asyncio
  - خط 13: logging
  - خط 14: typing (from ...)
  - خط 15: datetime (from ...)
  - خط 16: numpy
  - خط 17: json
  - خط 18: os
  - خط 19: random
  - خط 22: market_data_service (from ...)
  - خط 23: technical_analysis_service (from ...)
  - خط 24: sentiment_service (from ...)
  - خط 25: pattern_recognition_service (from ...)
  - خط 26: ml_service (from ...)
- کلاس‌ها:
  - خط 30: class HybridSignalService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 28: logger

### Ai-trade-kiro/backend/services/market_regime_service.py
- خطوط: 1130 | اندازه: 45770 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: statistics
  - خط 14: math
- کلاس‌ها:
  - خط 20: class TrendRegime (Bases: Enum)
  - خط 28: class VolatilityRegime (Bases: Enum)
  - خط 36: class CorrelationRegime (Bases: Enum)
  - خط 44: class LiquidityRegime (Bases: Enum)
  - خط 52: class MarketCycle (Bases: Enum)
  - خط 60: class RegimeMetrics (Bases: -)
  - خط 72: class RegimeDetection (Bases: -)
  - خط 85: class TrendAnalyzer (Bases: -)
  - خط 203: class VolatilityAnalyzer (Bases: -)
  - خط 333: class CorrelationAnalyzer (Bases: -)
  - خط 442: class LiquidityAnalyzer (Bases: -)
  - خط 565: class MarketCycleDetector (Bases: -)
  - خط 699: class AdaptiveParameterManager (Bases: -)
  - خط 811: class MarketRegimeService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 18: logger

### Ai-trade-kiro/backend/services/ml_prediction_service.py
- خطوط: 669 | اندازه: 25658 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: math
  - خط 14: statistics
  - خط 15: threading
  - خط 16: concurrent.futures (from ...)
- کلاس‌ها:
  - خط 22: class TimeFrame (Bases: Enum)
  - خط 29: class ModelType (Bases: Enum)
  - خط 37: class PredictionResult (Bases: -)
  - خط 51: class ModelPerformance (Bases: -)
  - خط 63: class FeatureEngineer (Bases: -)
  - خط 266: class AnomalyDetector (Bases: -)
  - خط 304: class EnsembleModel (Bases: -)
  - خط 427: class MLPredictionService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 20: logger

### Ai-trade-kiro/backend/services/ml_service.py
- خطوط: 208 | اندازه: 8067 بایت
- Imports:
  - خط 5: logging
  - خط 6: random
  - خط 7: asyncio
  - خط 8: typing (from ...)
  - خط 9: datetime (from ...)
  - خط 10: json
- کلاس‌ها:
  - خط 14: class MLService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 12: logger

### Ai-trade-kiro/backend/services/model_training_service.py
- خطوط: 568 | اندازه: 24101 بایت
- Imports:
  - خط 1: logging
  - خط 2: random
  - خط 3: asyncio
  - خط 4: aiohttp
  - خط 5: json
  - خط 6: time
  - خط 7: typing (from ...)
  - خط 8: datetime (from ...)
  - خط 9: functools (from ...)
  - خط 10: collections (from ...)
  - خط 11: concurrent.futures (from ...)
  - خط 12: dataclasses (from ...)
  - خط 13: pathlib (from ...)
  - خط 14: pandas
  - خط 15: numpy
  - خط 16: pydantic (from ...)
  - خط 17: redis.asyncio
  - خط 18: prometheus_client (from ...)
  - خط 19: aiohttp (from ...)
- کلاس‌ها:
  - خط 42: class TickerData (Bases: BaseModel)
  - خط 52: class CandleData (Bases: BaseModel)
  - خط 60: class OrderBookData (Bases: BaseModel)
  - خط 66: class TradeData (Bases: BaseModel)
  - خط 75: class ExchangeConfig (Bases: -)
  - خط 83: class MarketDataService (Bases: -)
  - خط 434: class ModelTrainingService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 35: logger
  - خط 38: REQUESTS
  - خط 39: LATENCY

### Ai-trade-kiro/backend/services/notification_service.py
- خطوط: 125 | اندازه: 4312 بایت
- Imports:
  - خط 5: logging
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
  - خط 8: enum (from ...)
  - خط 9: uuid
- کلاس‌ها:
  - خط 13: class NotificationType (Bases: str, Enum)
  - خط 19: class NotificationPriority (Bases: str, Enum)
  - خط 25: class NotificationService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger

### Ai-trade-kiro/backend/services/pattern_recognition_service.py
- خطوط: 1086 | اندازه: 42767 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: math
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: statistics
- کلاس‌ها:
  - خط 19: class PatternType (Bases: Enum)
  - خط 27: class HarmonicPattern (Bases: Enum)
  - خط 35: class ElliottWave (Bases: Enum)
  - خط 46: class CandlestickPattern (Bases: Enum)
  - خط 60: class PatternResult (Bases: -)
  - خط 76: class SupportResistanceLevel (Bases: -)
  - خط 86: class FractalAnalysis (Bases: -)
  - خط 225: class HarmonicPatternDetector (Bases: -)
  - خط 394: class ElliottWaveDetector (Bases: -)
  - خط 641: class CandlestickPatternDetector (Bases: -)
  - خط 866: class PatternRecognitionService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 17: logger

### Ai-trade-kiro/backend/services/portfolio_optimization_service.py
- خطوط: 1400 | اندازه: 58943 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: statistics
  - خط 14: math
  - خط 15: random
- کلاس‌ها:
  - خط 21: class OptimizationMethod (Bases: Enum)
  - خط 30: class RebalanceFrequency (Bases: Enum)
  - خط 38: class RiskLevel (Bases: Enum)
  - خط 46: class Asset (Bases: -)
  - خط 59: class Position (Bases: -)
  - خط 70: class PortfolioMetrics (Bases: -)
  - خط 87: class OptimizationResult (Bases: -)
  - خط 99: class RiskCalculator (Bases: -)
  - خط 204: class CovarianceEstimator (Bases: -)
  - خط 302: class MeanVarianceOptimizer (Bases: -)
  - خط 467: class RiskParityOptimizer (Bases: -)
  - خط 624: class KellyCriterionOptimizer (Bases: -)
  - خط 701: class RebalancingEngine (Bases: -)
  - خط 799: class PerformanceAnalyzer (Bases: -)
  - خط 925: class PortfolioOptimizationService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 19: logger

### Ai-trade-kiro/backend/services/portfolio_service.py
- خطوط: 315 | اندازه: 12159 بایت
- Imports:
  - خط 5: logging
  - خط 6: uuid
  - خط 7: random
  - خط 8: typing (from ...)
  - خط 9: datetime (from ...)
- کلاس‌ها:
  - خط 13: class PortfolioService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger

### Ai-trade-kiro/backend/services/security_service.py
- خطوط: 57 | اندازه: 1989 بایت
- Imports:
  - خط 5: logging
  - خط 6: secrets
  - خط 7: jwt
  - خط 8: datetime (from ...)
  - خط 9: typing (from ...)
- کلاس‌ها:
  - خط 13: class SecurityService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger

### Ai-trade-kiro/backend/services/sentiment_service.py
- خطوط: 1113 | اندازه: 43076 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: re
  - خط 9: time
  - خط 10: datetime (from ...)
  - خط 11: typing (from ...)
  - خط 12: dataclasses (from ...)
  - خط 13: enum (from ...)
  - خط 14: statistics
  - خط 15: threading
  - خط 16: concurrent.futures (from ...)
  - خط 17: hashlib
- کلاس‌ها:
  - خط 23: class SentimentType (Bases: Enum)
  - خط 31: class SentimentPolarity (Bases: Enum)
  - خط 40: class SentimentResult (Bases: -)
  - خط 54: class NewsItem (Bases: -)
  - خط 66: class SocialMediaPost (Bases: -)
  - خط 76: class TextProcessor (Bases: -)
  - خط 227: class NewsAnalyzer (Bases: -)
  - خط 324: class SocialMediaAnalyzer (Bases: -)
  - خط 440: class OnChainAnalyzer (Bases: -)
  - خط 516: class FearGreedIndex (Bases: -)
  - خط 594: class SentimentService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 21: logger

### Ai-trade-kiro/backend/services/signal_service.py
- خطوط: 1052 | اندازه: 42434 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: statistics
  - خط 14: threading
  - خط 15: concurrent.futures (from ...)
  - خط 16: math
- کلاس‌ها:
  - خط 22: class SignalStrength (Bases: Enum)
  - خط 30: class SignalDirection (Bases: Enum)
  - خط 38: class MarketRegime (Bases: Enum)
  - خط 47: class ComponentSignal (Bases: -)
  - خط 58: class HybridSignal (Bases: -)
  - خط 75: class SignalWeightManager (Bases: -)
  - خط 179: class CorrelationFilter (Bases: -)
  - خط 243: class ConflictResolver (Bases: -)
  - خط 346: class RiskManager (Bases: -)
  - خط 480: class MarketRegimeDetector (Bases: -)
  - خط 514: class HybridSignalService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 20: logger

### Ai-trade-kiro/backend/services/simplified_signal_service.py
- خطوط: 204 | اندازه: 8055 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: logging
  - خط 8: typing (from ...)
  - خط 9: datetime (from ...)
  - خط 10: random
  - خط 13: market_data_service (from ...)
  - خط 14: technical_analysis_service (from ...)
- کلاس‌ها:
  - خط 18: class SimplifiedSignalService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 16: logger

### Ai-trade-kiro/backend/services/strategy_service.py
- خطوط: 86 | اندازه: 3182 بایت
- Imports:
  - خط 5: logging
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
- کلاس‌ها:
  - خط 11: class StrategyService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 9: logger

### Ai-trade-kiro/backend/services/technical_analysis_service.py
- خطوط: 248 | اندازه: 9436 بایت
- Imports:
  - خط 6: logging
  - خط 7: typing (from ...)
  - خط 8: numpy
  - خط 9: datetime (from ...)
- کلاس‌ها:
  - خط 13: class TechnicalAnalysisService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger

### Ai-trade-kiro/backend/services/user_service.py
- خطوط: 106 | اندازه: 3633 بایت
- Imports:
  - خط 5: logging
  - خط 6: typing (from ...)
  - خط 7: datetime (from ...)
  - خط 8: hashlib
  - خط 9: secrets
- کلاس‌ها:
  - خط 13: class UserService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 11: logger

### Ai-trade-kiro/backend/services/webhook_service.py
- خطوط: 88 | اندازه: 3042 بایت
- Imports:
  - خط 5: logging
  - خط 6: asyncio
  - خط 7: aiohttp
  - خط 8: typing (from ...)
  - خط 9: datetime (from ...)
  - خط 10: uuid
- کلاس‌ها:
  - خط 14: class WebhookService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 12: logger

### Ai-trade-kiro/backend/services/websocket_service.py
- خطوط: 391 | اندازه: 17384 بایت
- Imports:
  - خط 6: asyncio
  - خط 7: json
  - خط 8: logging
  - خط 9: time
  - خط 10: typing (from ...)
  - خط 11: datetime (from ...)
  - خط 12: random
  - خط 13: fastapi (from ...)
  - خط 16: market_data_service (from ...)
  - خط 17: signal_service (from ...)
  - خط 18: simplified_signal_service (from ...)
- کلاس‌ها:
  - خط 22: class ConnectionManager (Bases: -)
  - خط 109: class WebSocketManager (Bases: -)
- انتساب‌های سطح بالا:
  - خط 20: logger

### Ai-trade-kiro/backend/services/whale_analysis_service.py
- خطوط: 1133 | اندازه: 47716 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: statistics
  - خط 14: threading
  - خط 15: concurrent.futures (from ...)
  - خط 16: hashlib
- کلاس‌ها:
  - خط 22: class TransactionType (Bases: Enum)
  - خط 29: class WalletType (Bases: Enum)
  - خط 37: class ImpactLevel (Bases: Enum)
  - خط 45: class WhaleTransaction (Bases: -)
  - خط 62: class WalletCluster (Bases: -)
  - خط 75: class ExchangeFlow (Bases: -)
  - خط 87: class BlockchainAnalyzer (Bases: -)
  - خط 291: class ExchangeFlowAnalyzer (Bases: -)
  - خط 436: class WhaleBehaviorAnalyzer (Bases: -)
  - خط 729: class WhaleAnalysisService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 20: logger

### Ai-trade-kiro/backend/storage/model_manager.py
- خطوط: 468 | اندازه: 17809 بایت
- Imports:
  - خط 1: os
  - خط 2: json
  - خط 3: pickle
  - خط 4: joblib
  - خط 5: boto3
  - خط 6: hashlib
  - خط 7: datetime (from ...)
  - خط 8: pathlib (from ...)
  - خط 9: typing (from ...)
  - خط 10: logging
  - خط 11: dataclasses (from ...)
  - خط 12: shutil
- کلاس‌ها:
  - خط 15: class ModelMetadata (Bases: -)
  - خط 30: class ModelStorageManager (Bases: -)

### Ai-trade-kiro/backend/tests/__init__.py
- خطوط: 1 | اندازه: 15 بایت

### Ai-trade-kiro/backend/tests/conftest.py
- خطوط: 77 | اندازه: 2190 بایت
- Imports:
  - خط 1: asyncio
  - خط 2: pytest
  - خط 3: typing (from ...)
  - خط 4: fastapi.testclient (from ...)
  - خط 5: sqlalchemy.ext.asyncio (from ...)
  - خط 6: sqlalchemy.orm (from ...)
  - خط 7: sqlalchemy.pool (from ...)
  - خط 9: app.core.config (from ...)
  - خط 10: app.db.session (from ...)
  - خط 11: app.main (from ...)
  - خط 12: app.core.dependencies (from ...)
- توابع:
  - خط 34: def event_loop(0 args)
- انتساب‌های سطح بالا:
  - خط 15: TEST_DATABASE_URL
  - خط 18: test_engine
  - خط 25: TestingSessionLocal

### Ai-trade-kiro/backend/tests/test_db_connection.py
- خطوط: 150 | اندازه: 4196 بایت
- Imports:
  - خط 4: asyncio
  - خط 5: pytest
  - خط 6: datetime (from ...)
  - خط 7: json
  - خط 9: app.core.db_config (from ...)

### Ai-trade-kiro/backend/tests/test_health.py
- خطوط: 21 | اندازه: 634 بایت
- Imports:
  - خط 1: pytest
  - خط 2: fastapi.testclient (from ...)
- توابع:
  - خط 4: def test_health_check(1 args)

### Ai-trade-kiro/backend/tests/test_normalization.py
- خطوط: 191 | اندازه: 6885 بایت
- Imports:
  - خط 6: pytest
  - خط 7: datetime (from ...)
  - خط 8: app.services.normalization (from ...)
  - خط 9: app.services.exchange.binance (from ...)
  - خط 10: app.services.exchange.coinbase (from ...)
- توابع:
  - خط 13: def normalization_service(0 args)
  - خط 18: def binance_adapter(0 args)
  - خط 23: def coinbase_adapter(0 args)

### Ai-trade-kiro/backend/websocket/data_streamer.py
- خطوط: 150 | اندازه: 5645 بایت
- Imports:
  - خط 3: __future__ (from ...)
  - خط 5: asyncio
  - خط 6: json
  - خط 7: logging
  - خط 8: datetime (from ...)
  - خط 9: typing (from ...)
  - خط 11: fastapi (from ...)
  - خط 12: redis.asyncio
- کلاس‌ها:
  - خط 20: class ConnectionManager (Bases: -)
- انتساب‌های سطح بالا:
  - خط 15: logger
  - خط 17: router
  - خط 124: manager

### Ai-trade-kiro/backend/websocket/mobile_optimization.py
- خطوط: 14 | اندازه: 362 بایت
- Imports:
  - خط 1: asyncio
  - خط 2: fastapi (from ...)
- انتساب‌های سطح بالا:
  - خط 4: router

### Ai-trade-kiro/backend/websocket/position_updates.py
- خطوط: 188 | اندازه: 6826 بایت
- Imports:
  - خط 3: __future__ (from ...)
  - خط 5: asyncio
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 12: fastapi (from ...)
  - خط 13: redis.asyncio
- کلاس‌ها:
  - خط 20: class PositionManager (Bases: -)
- انتساب‌های سطح بالا:
  - خط 15: logger
  - خط 17: router
  - خط 157: manager

### Ai-trade-kiro/project/backend/services/hybrid_signal_service.py
- خطوط: 1052 | اندازه: 41383 بایت
- Imports:
  - خط 6: json
  - خط 7: logging
  - خط 8: time
  - خط 9: datetime (from ...)
  - خط 10: typing (from ...)
  - خط 11: dataclasses (from ...)
  - خط 12: enum (from ...)
  - خط 13: statistics
  - خط 14: threading
  - خط 15: concurrent.futures (from ...)
  - خط 16: math
- کلاس‌ها:
  - خط 22: class SignalStrength (Bases: Enum)
  - خط 30: class SignalDirection (Bases: Enum)
  - خط 38: class MarketRegime (Bases: Enum)
  - خط 47: class ComponentSignal (Bases: -)
  - خط 58: class HybridSignal (Bases: -)
  - خط 75: class SignalWeightManager (Bases: -)
  - خط 179: class CorrelationFilter (Bases: -)
  - خط 243: class ConflictResolver (Bases: -)
  - خط 346: class RiskManager (Bases: -)
  - خط 480: class MarketRegimeDetector (Bases: -)
  - خط 514: class HybridSignalService (Bases: -)
- انتساب‌های سطح بالا:
  - خط 20: logger

## 4. وابستگی‌های Python

### فایل‌های requirements

- Ai-trade-kiro/backend/requirements.txt

### ماژول‌های Third-Party استفاده‌شده (بر اساس import) ولی احتمالاً استاندارد نیستند:
- __future__
- abc
- aiohttp
- aioredis
- alembic
- api
- app
- auth_router
- base64
- boto3
- bs4
- celery
- concurrent
- decimal
- discord
- email_validator
- exchange_router
- exchanges
- fastapi
- flask
- flask_cors
- hmac
- hybrid_signal_service
- joblib
- jose
- jwt
- lightgbm
- market_data_router
- market_data_service
- middleware
- ml_router
- ml_service
- models
- numpy
- pandas
- passlib
- pattern_recognition_service
- pickle
- portfolio_optimization_service
- portfolio_router
- prometheus_client
- psutil
- psycopg2
- pydantic
- pytest
- redis
- requests
- secrets
- sentiment_service
- services
- signal_router
- signal_service
- simplified_signal_service
- sklearn
- slack_sdk
- smtplib
- sqlalchemy
- src
- storage
- strategy_router
- talib
- technical_analysis_service
- telegram
- textblob
- torch
- transformers
- uuid
- uvicorn
- webhook_router
- xgboost

### ماژول‌های استفاده‌شده ولی در requirements ذکر نشده‌اند:
- __future__  → **افزودن به requirements.txt**
- abc  → **افزودن به requirements.txt**
- aiohttp  → **افزودن به requirements.txt**
- aioredis  → **افزودن به requirements.txt**
- api  → **افزودن به requirements.txt**
- app  → **افزودن به requirements.txt**
- auth_router  → **افزودن به requirements.txt**
- base64  → **افزودن به requirements.txt**
- boto3  → **افزودن به requirements.txt**
- bs4  → **افزودن به requirements.txt**
- celery  → **افزودن به requirements.txt**
- concurrent  → **افزودن به requirements.txt**
- decimal  → **افزودن به requirements.txt**
- discord  → **افزودن به requirements.txt**
- email_validator  → **افزودن به requirements.txt**
- exchange_router  → **افزودن به requirements.txt**
- exchanges  → **افزودن به requirements.txt**
- flask  → **افزودن به requirements.txt**
- flask_cors  → **افزودن به requirements.txt**
- hmac  → **افزودن به requirements.txt**
- hybrid_signal_service  → **افزودن به requirements.txt**
- jose  → **افزودن به requirements.txt**
- jwt  → **افزودن به requirements.txt**
- lightgbm  → **افزودن به requirements.txt**
- market_data_router  → **افزودن به requirements.txt**
- market_data_service  → **افزودن به requirements.txt**
- middleware  → **افزودن به requirements.txt**
- ml_router  → **افزودن به requirements.txt**
- ml_service  → **افزودن به requirements.txt**
- models  → **افزودن به requirements.txt**
- pattern_recognition_service  → **افزودن به requirements.txt**
- pickle  → **افزودن به requirements.txt**
- portfolio_optimization_service  → **افزودن به requirements.txt**
- portfolio_router  → **افزودن به requirements.txt**
- prometheus_client  → **افزودن به requirements.txt**
- psutil  → **افزودن به requirements.txt**
- psycopg2  → **افزودن به requirements.txt**
- requests  → **افزودن به requirements.txt**
- secrets  → **افزودن به requirements.txt**
- sentiment_service  → **افزودن به requirements.txt**
- services  → **افزودن به requirements.txt**
- signal_router  → **افزودن به requirements.txt**
- signal_service  → **افزودن به requirements.txt**
- simplified_signal_service  → **افزودن به requirements.txt**
- sklearn  → **افزودن به requirements.txt**
- slack_sdk  → **افزودن به requirements.txt**
- smtplib  → **افزودن به requirements.txt**
- src  → **افزودن به requirements.txt**
- storage  → **افزودن به requirements.txt**
- strategy_router  → **افزودن به requirements.txt**
- talib  → **افزودن به requirements.txt**
- technical_analysis_service  → **افزودن به requirements.txt**
- telegram  → **افزودن به requirements.txt**
- textblob  → **افزودن به requirements.txt**
- torch  → **افزودن به requirements.txt**
- transformers  → **افزودن به requirements.txt**
- uuid  → **افزودن به requirements.txt**
- webhook_router  → **افزودن به requirements.txt**
- xgboost  → **افزودن به requirements.txt**

## 5. وابستگی‌های JS/TS

### package.json ها:
- Ai-trade-kiro/package.json [dependencies] next: ^14.0.0
- Ai-trade-kiro/package.json [dependencies] react: ^18.2.0
- Ai-trade-kiro/package.json [dependencies] react-dom: ^18.2.0
- Ai-trade-kiro/package.json [dependencies] typescript: ^5.0.0
- Ai-trade-kiro/package.json [dependencies] @types/react: ^18.2.0
- Ai-trade-kiro/package.json [dependencies] @types/react-dom: ^18.2.0
- Ai-trade-kiro/package.json [dependencies] @types/node: ^20.0.0
- Ai-trade-kiro/package.json [dependencies] tailwindcss: ^3.3.0
- Ai-trade-kiro/package.json [dependencies] autoprefixer: ^10.4.0
- Ai-trade-kiro/package.json [dependencies] postcss: ^8.4.0
- Ai-trade-kiro/package.json [dependencies] zustand: ^4.4.0
- Ai-trade-kiro/package.json [dependencies] @tanstack/react-query: ^5.0.0
- Ai-trade-kiro/package.json [dependencies] @tanstack/react-query-devtools: ^5.0.0
- Ai-trade-kiro/package.json [dependencies] framer-motion: ^10.16.0
- Ai-trade-kiro/package.json [dependencies] lucide-react: ^0.290.0
- Ai-trade-kiro/package.json [dependencies] react-grid-layout: ^1.4.0
- Ai-trade-kiro/package.json [dependencies] recharts: ^2.8.0
- Ai-trade-kiro/package.json [dependencies] socket.io-client: ^4.7.0
- Ai-trade-kiro/package.json [dependencies] decimal.js: ^10.4.0
- Ai-trade-kiro/package.json [dependencies] date-fns: ^2.30.0
- Ai-trade-kiro/package.json [dependencies] react-hook-form: ^7.47.0
- Ai-trade-kiro/package.json [dependencies] @hookform/resolvers: ^3.3.0
- Ai-trade-kiro/package.json [dependencies] zod: ^3.22.0
- Ai-trade-kiro/package.json [dependencies] react-hot-toast: ^2.4.0
- Ai-trade-kiro/package.json [dependencies] react-intersection-observer: ^9.5.0
- Ai-trade-kiro/package.json [dependencies] next-themes: ^0.2.1
- Ai-trade-kiro/package.json [dependencies] class-variance-authority: ^0.7.0
- Ai-trade-kiro/package.json [dependencies] clsx: ^2.0.0
- Ai-trade-kiro/package.json [dependencies] tailwind-merge: ^2.0.0
- Ai-trade-kiro/package.json [dependencies] lightweight-charts: ^4.1.0
- Ai-trade-kiro/package.json [dependencies] @tailwindcss/forms: ^0.5.6
- Ai-trade-kiro/package.json [dependencies] @tailwindcss/typography: ^0.5.10
- Ai-trade-kiro/package.json [dependencies] reactflow: ^11.10.0
- Ai-trade-kiro/package.json [dependencies] uuid: ^9.0.1
- Ai-trade-kiro/package.json [dependencies] @types/uuid: ^9.0.7
- Ai-trade-kiro/package.json [dependencies] @headlessui/react: ^1.7.17
- Ai-trade-kiro/package.json [devDependencies] eslint: ^8.0.0
- Ai-trade-kiro/package.json [devDependencies] eslint-config-next: ^14.0.0
- Ai-trade-kiro/package.json [devDependencies] @typescript-eslint/eslint-plugin: ^6.0.0
- Ai-trade-kiro/package.json [devDependencies] @typescript-eslint/parser: ^6.0.0
- Ai-trade-kiro/package.json [devDependencies] prettier: ^3.0.0
- Ai-trade-kiro/package.json [devDependencies] vitest: ^0.34.0
- Ai-trade-kiro/package.json [devDependencies] @vitejs/plugin-react: ^4.0.0
- Ai-trade-kiro/package.json [devDependencies] playwright: ^1.39.0
- Ai-trade-kiro/package.json [devDependencies] @playwright/test: ^1.39.0
- Ai-trade-kiro/package.json [devDependencies] husky: ^8.0.0
- Ai-trade-kiro/package.json [devDependencies] lint-staged: ^15.0.0
- Ai-trade-kiro/package.json [devDependencies] @types/next: ^9.0.0
- Ai-trade-kiro/backend/package.json [dependencies] @tanstack/react-query: ^5.59.0
- Ai-trade-kiro/backend/package.json [dependencies] axios: ^1.7.7
- Ai-trade-kiro/backend/package.json [dependencies] clsx: ^2.1.1
- Ai-trade-kiro/backend/package.json [dependencies] framer-motion: ^11.11.17
- Ai-trade-kiro/backend/package.json [dependencies] lucide-react: ^0.456.0
- Ai-trade-kiro/backend/package.json [dependencies] react: ^18.3.1
- Ai-trade-kiro/backend/package.json [dependencies] react-dom: ^18.3.1
- Ai-trade-kiro/backend/package.json [dependencies] react-error-boundary: ^4.0.13
- Ai-trade-kiro/backend/package.json [dependencies] react-hook-form: ^7.53.2
- Ai-trade-kiro/backend/package.json [dependencies] react-hot-toast: ^2.4.1
- Ai-trade-kiro/backend/package.json [dependencies] react-router-dom: ^6.28.0
- Ai-trade-kiro/backend/package.json [dependencies] react-window: ^1.8.11
- Ai-trade-kiro/backend/package.json [dependencies] recharts: ^2.12.7
- Ai-trade-kiro/backend/package.json [dependencies] zustand: ^4.5.5
- Ai-trade-kiro/backend/package.json [devDependencies] @eslint/js: ^9.13.0
- Ai-trade-kiro/backend/package.json [devDependencies] @testing-library/jest-dom: ^6.6.3
- Ai-trade-kiro/backend/package.json [devDependencies] @testing-library/react: ^16.0.1
- Ai-trade-kiro/backend/package.json [devDependencies] @testing-library/user-event: ^14.5.2
- Ai-trade-kiro/backend/package.json [devDependencies] @types/node: ^22.16.3
- Ai-trade-kiro/backend/package.json [devDependencies] @types/react: ^18.3.12
- Ai-trade-kiro/backend/package.json [devDependencies] @types/react-dom: ^18.3.1
- Ai-trade-kiro/backend/package.json [devDependencies] @types/react-window: ^1.8.8
- Ai-trade-kiro/backend/package.json [devDependencies] @typescript-eslint/eslint-plugin: ^8.12.2
- Ai-trade-kiro/backend/package.json [devDependencies] @typescript-eslint/parser: ^8.12.2
- Ai-trade-kiro/backend/package.json [devDependencies] @vitejs/plugin-react: ^4.6.0
- Ai-trade-kiro/backend/package.json [devDependencies] @vitest/coverage-v8: ^2.1.4
- Ai-trade-kiro/backend/package.json [devDependencies] @vitest/ui: ^2.1.4
- Ai-trade-kiro/backend/package.json [devDependencies] autoprefixer: ^10.4.20
- Ai-trade-kiro/backend/package.json [devDependencies] eslint: ^9.13.0
- Ai-trade-kiro/backend/package.json [devDependencies] eslint-plugin-react: ^7.37.2
- Ai-trade-kiro/backend/package.json [devDependencies] eslint-plugin-react-hooks: ^5.0.0
- Ai-trade-kiro/backend/package.json [devDependencies] eslint-plugin-react-refresh: ^0.4.14
- Ai-trade-kiro/backend/package.json [devDependencies] jsdom: ^25.0.1
- Ai-trade-kiro/backend/package.json [devDependencies] postcss: ^8.4.47
- Ai-trade-kiro/backend/package.json [devDependencies] tailwindcss: ^3.4.14
- Ai-trade-kiro/backend/package.json [devDependencies] typescript: ^5.6.3
- Ai-trade-kiro/backend/package.json [devDependencies] vite: ^5.4.19
- Ai-trade-kiro/backend/package.json [devDependencies] vite-bundle-analyzer: ^0.11.0
- Ai-trade-kiro/backend/package.json [devDependencies] vitest: ^2.1.4
- Ai-trade-kiro/project/package.json [dependencies] lucide-react: ^0.344.0
- Ai-trade-kiro/project/package.json [dependencies] react: ^18.3.1
- Ai-trade-kiro/project/package.json [dependencies] react-dom: ^18.3.1
- Ai-trade-kiro/project/package.json [devDependencies] @eslint/js: ^9.9.1
- Ai-trade-kiro/project/package.json [devDependencies] @types/react: ^18.3.5
- Ai-trade-kiro/project/package.json [devDependencies] @types/react-dom: ^18.3.0
- Ai-trade-kiro/project/package.json [devDependencies] @vitejs/plugin-react: ^4.3.1
- Ai-trade-kiro/project/package.json [devDependencies] autoprefixer: ^10.4.18
- Ai-trade-kiro/project/package.json [devDependencies] eslint: ^9.9.1
- Ai-trade-kiro/project/package.json [devDependencies] eslint-plugin-react-hooks: ^5.1.0-rc.0
- Ai-trade-kiro/project/package.json [devDependencies] eslint-plugin-react-refresh: ^0.4.11
- Ai-trade-kiro/project/package.json [devDependencies] globals: ^15.9.0
- Ai-trade-kiro/project/package.json [devDependencies] postcss: ^8.4.35
- Ai-trade-kiro/project/package.json [devDependencies] tailwindcss: ^3.4.1
- Ai-trade-kiro/project/package.json [devDependencies] typescript: ^5.5.3
- Ai-trade-kiro/project/package.json [devDependencies] typescript-eslint: ^8.3.0
- Ai-trade-kiro/project/package.json [devDependencies] vite: ^5.4.2

### پکیج‌های import شده ولی در package.json نیستند:
- path → افزودن به dependencies
- @tailwindcss → افزودن به dependencies
- @vitejs → افزودن به dependencies
- react-redux → افزودن به dependencies
- @mui → افزودن به dependencies
- @reduxjs → افزودن به dependencies
- @eslint → افزودن به dependencies
- @ → افزودن به dependencies
- @tanstack → افزودن به dependencies
- @hookform → افزودن به dependencies
- @headlessui → افزودن به dependencies
- crypto → افزودن به dependencies
- bcrypt → افزودن به dependencies
- jsonwebtoken → افزودن به dependencies
- speakeasy → افزودن به dependencies
- qrcode → افزودن به dependencies
- events → افزودن به dependencies

## 6. خطاهای نحوی / مشکلات پارس

- Ai-trade-kiro/backend/services/market_data_service.py (خط 56, ستون 14): unindent does not match any outer indentation level

## 7. تحلیل ریسک و بوهای کد (Heuristics)

### Ai-trade-kiro/backend/back_temp/ml_models_production.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/back_temp/webhook_notification_system.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/services/market_regime_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/services/pattern_recognition_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/services/portfolio_optimization_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/services/sentiment_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/services/signal_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/backend/services/whale_analysis_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.
### Ai-trade-kiro/project/backend/services/hybrid_signal_service.py
- طول زیاد (>800 خط) → پیشنهاد تقسیم.

## 8. پیشنهادهای اصلاح و اقدامات بعدی

1. **تنظیم محیط Python**: نصب پکیج‌های لازم (بخش 4) و ایجاد فایل `requirements.txt` اگر وجود ندارد.
2. **اضافه کردن مدیریت نسخه**: اطمینان از pin کردن نسخه‌ها (مثلاً `package==1.2.3`).
3. **ساختاردهی ماژولار**: در صورت طولانی بودن فایل‌ها، تقسیم بر اساس مسئولیت (SRP).
4. **بررسی امنیت**: حذف یا ایمن‌سازی هر الگوی کلید/API که در گزارش آمده.
5. **افزودن تست‌ها**: ایجاد پوشه `tests/` و نوشتن تست واحد برای توابع اصلی.
6. **اتوماتیک‌سازی کیفیت کد**: اضافه کردن ابزارهای `flake8`, `black`, `isort`, و pipeline CI.
7. **مستندسازی**: افزودن `README.md` حاوی دستور اجرای پروژه، پیش‌نیازها، و مثال استفاده.
8. **محیط توسعه**: ایجاد `.env.example` و استفاده از متغیرهای محیطی بجای مقادیر حساس.
9. **بررسی imports شکسته**: در صورت وجود ماژول‌های import شده‌ای که فایل متناظر ندارند، پوشه‌ها یا نام‌ها را هماهنگ کنید.
10. **Version Control Ignore**: افزودن `.gitignore` مناسب (venv، __pycache__).

## 9. لیست کامل فایل‌ها با اندازه

```

Ai-trade-kiro/.env.example  (542 bytes)
Ai-trade-kiro/.github/CODEOWNERS  (793 bytes)
Ai-trade-kiro/.github/ISSUE_TEMPLATE/bug_report.md  (812 bytes)
Ai-trade-kiro/.github/ISSUE_TEMPLATE/config.yml  (370 bytes)
Ai-trade-kiro/.github/ISSUE_TEMPLATE/feature_request.md  (789 bytes)
Ai-trade-kiro/.github/ISSUE_TEMPLATE/security_vulnerability.md  (704 bytes)
Ai-trade-kiro/.github/PULL_REQUEST_TEMPLATE.md  (1486 bytes)
Ai-trade-kiro/.github/README.md  (2326 bytes)
Ai-trade-kiro/.github/dependabot.yml  (2287 bytes)
Ai-trade-kiro/.github/lighthouse-config.json  (996 bytes)
Ai-trade-kiro/.github/workflows/ci-cd.yml  (8073 bytes)
Ai-trade-kiro/.github/workflows/code-quality.yml  (2863 bytes)
Ai-trade-kiro/.github/workflows/dependency-updates.yml  (1543 bytes)
Ai-trade-kiro/.github/workflows/docker-scan.yml  (3259 bytes)
Ai-trade-kiro/.github/workflows/documentation.yml  (1554 bytes)
Ai-trade-kiro/.github/workflows/e2e-tests.yml  (2502 bytes)
Ai-trade-kiro/.github/workflows/license-compliance.yml  (2409 bytes)
Ai-trade-kiro/.github/workflows/performance-tests.yml  (3531 bytes)
Ai-trade-kiro/.github/workflows/release.yml  (3186 bytes)
Ai-trade-kiro/.github/workflows/security-scan.yml  (4330 bytes)
Ai-trade-kiro/.github/workflows/stale.yml  (1042 bytes)
Ai-trade-kiro/Dockerfile  (1669 bytes)
Ai-trade-kiro/README.md  (3277 bytes)
Ai-trade-kiro/aismart-trader-kiro-spec.md  (32100 bytes)
Ai-trade-kiro/aismart-trader-task-board.md  (13619 bytes)
Ai-trade-kiro/backend/.env.example  (560 bytes)
Ai-trade-kiro/backend/Dockerfile  (784 bytes)
Ai-trade-kiro/backend/Dockerfile.prod  (1441 bytes)
Ai-trade-kiro/backend/README.md  (1585 bytes)
Ai-trade-kiro/backend/SIMPLIFIED_VERSION.md  (1946 bytes)
Ai-trade-kiro/backend/__pycache__/main.cpython-311.pyc  (6954 bytes)
Ai-trade-kiro/backend/alembic.ini  (3035 bytes)
Ai-trade-kiro/backend/alembic/__init__.py  (20 bytes)
Ai-trade-kiro/backend/alembic/env.py  (2755 bytes)
Ai-trade-kiro/backend/alembic/script.py.mako  (532 bytes)
Ai-trade-kiro/backend/alembic/versions/initial_migration.py  (9305 bytes)
Ai-trade-kiro/backend/analytics/usage_analytics.py  (943 bytes)
Ai-trade-kiro/backend/api/advanced_chart.py  (160 bytes)
Ai-trade-kiro/backend/api/advanced_indicators.py  (2934 bytes)
Ai-trade-kiro/backend/api/auth_router.py  (11109 bytes)
Ai-trade-kiro/backend/api/chart_themes.py  (525 bytes)
Ai-trade-kiro/backend/api/crypto_multi_source_manager.py  (19623 bytes)
Ai-trade-kiro/backend/api/exchange_router.py  (3076 bytes)
Ai-trade-kiro/backend/api/exchange_settings.py  (15608 bytes)
Ai-trade-kiro/backend/api/main_api.py  (3622 bytes)
Ai-trade-kiro/backend/api/market_data.py  (801 bytes)
Ai-trade-kiro/backend/api/market_data_router.py  (7275 bytes)
Ai-trade-kiro/backend/api/ml_router.py  (5835 bytes)
Ai-trade-kiro/backend/api/model_storage_api.py  (12454 bytes)
Ai-trade-kiro/backend/api/order_book.py  (160 bytes)
Ai-trade-kiro/backend/api/pattern_recognition.py  (870 bytes)
Ai-trade-kiro/backend/api/portfolio_router.py  (9809 bytes)
Ai-trade-kiro/backend/api/position_tracking.py  (159 bytes)
Ai-trade-kiro/backend/api/real_trading_api.py  (3435 bytes)
Ai-trade-kiro/backend/api/signal_router.py  (5830 bytes)
Ai-trade-kiro/backend/api/strategy_router.py  (8160 bytes)
Ai-trade-kiro/backend/api/strategy_watchlist.py  (5577 bytes)
Ai-trade-kiro/backend/api/trading.py  (14006 bytes)
Ai-trade-kiro/backend/api/webhook_router.py  (10771 bytes)
Ai-trade-kiro/backend/app/__init__.py  (13 bytes)
Ai-trade-kiro/backend/app/api/__init__.py  (5 bytes)
Ai-trade-kiro/backend/app/api/endpoints/__init__.py  (98 bytes)
Ai-trade-kiro/backend/app/api/endpoints/health.py  (1790 bytes)
Ai-trade-kiro/backend/app/api/endpoints/market_data.py  (6486 bytes)
Ai-trade-kiro/backend/app/api/router.py  (333 bytes)
Ai-trade-kiro/backend/app/api/v1/__init__.py  (8 bytes)
Ai-trade-kiro/backend/app/api/v1/api.py  (361 bytes)
Ai-trade-kiro/backend/app/api/v1/endpoints/__init__.py  (15 bytes)
Ai-trade-kiro/backend/app/api/v1/endpoints/auth.py  (3315 bytes)
Ai-trade-kiro/backend/app/api/v1/endpoints/health.py  (561 bytes)
Ai-trade-kiro/backend/app/api/v1/endpoints/strategies.py  (7756 bytes)
Ai-trade-kiro/backend/app/api/v1/endpoints/users.py  (3784 bytes)
Ai-trade-kiro/backend/app/core/__init__.py  (6 bytes)
Ai-trade-kiro/backend/app/core/config.py  (2936 bytes)
Ai-trade-kiro/backend/app/core/db_config.py  (13379 bytes)
Ai-trade-kiro/backend/app/core/dependencies.py  (2258 bytes)
Ai-trade-kiro/backend/app/db/__init__.py  (10 bytes)
Ai-trade-kiro/backend/app/db/session.py  (414 bytes)
Ai-trade-kiro/backend/app/main.py  (1698 bytes)
Ai-trade-kiro/backend/app/models/__init__.py  (8 bytes)
Ai-trade-kiro/backend/app/models/base.py  (360 bytes)
Ai-trade-kiro/backend/app/models/market_data.py  (1524 bytes)
Ai-trade-kiro/backend/app/models/strategy.py  (3749 bytes)
Ai-trade-kiro/backend/app/models/user.py  (858 bytes)
Ai-trade-kiro/backend/app/repositories/__init__.py  (14 bytes)
Ai-trade-kiro/backend/app/repositories/market_data.py  (4975 bytes)
Ai-trade-kiro/backend/app/repositories/strategy_repository.py  (8975 bytes)
Ai-trade-kiro/backend/app/schemas/__init__.py  (9 bytes)
Ai-trade-kiro/backend/app/schemas/base.py  (257 bytes)
Ai-trade-kiro/backend/app/schemas/market_data.py  (4916 bytes)
Ai-trade-kiro/backend/app/schemas/strategy.py  (3368 bytes)
Ai-trade-kiro/backend/app/schemas/token.py  (390 bytes)
Ai-trade-kiro/backend/app/schemas/user.py  (824 bytes)
Ai-trade-kiro/backend/app/services/__init__.py  (10 bytes)
Ai-trade-kiro/backend/app/services/backtesting_service.py  (12070 bytes)
Ai-trade-kiro/backend/app/services/exchange/README.md  (2377 bytes)
Ai-trade-kiro/backend/app/services/exchange/__init__.py  (128 bytes)
Ai-trade-kiro/backend/app/services/exchange/base.py  (3595 bytes)
Ai-trade-kiro/backend/app/services/exchange/binance.py  (11311 bytes)
Ai-trade-kiro/backend/app/services/exchange/coinbase.py  (9132 bytes)
Ai-trade-kiro/backend/app/services/historical_data.py  (12281 bytes)
Ai-trade-kiro/backend/app/services/ml_service.py  (10259 bytes)
Ai-trade-kiro/backend/app/services/normalization.py  (6885 bytes)
Ai-trade-kiro/backend/app/services/pattern_recognition.py  (16493 bytes)
Ai-trade-kiro/backend/app/services/smart_money.py  (14788 bytes)
Ai-trade-kiro/backend/app/services/strategy_executor.py  (18969 bytes)
Ai-trade-kiro/backend/app/services/strategy_service.py  (7235 bytes)
Ai-trade-kiro/backend/app/services/technical_indicators.py  (12476 bytes)
Ai-trade-kiro/backend/app/services/trading_automation_service.py  (11981 bytes)
Ai-trade-kiro/backend/app/utils/__init__.py  (11 bytes)
Ai-trade-kiro/backend/app/utils/security.py  (1705 bytes)
Ai-trade-kiro/backend/back_temp/auth_system.py  (19664 bytes)
Ai-trade-kiro/backend/back_temp/binance_api.py  (20074 bytes)
Ai-trade-kiro/backend/back_temp/ci_cd_pipeline.txt  (23571 bytes)
Ai-trade-kiro/backend/back_temp/data_processing_services.py  (23123 bytes)
Ai-trade-kiro/backend/back_temp/database_models.py  (18774 bytes)
Ai-trade-kiro/backend/back_temp/docker_configuration.txt  (18397 bytes)
Ai-trade-kiro/backend/back_temp/exchange_router.py  (16291 bytes)
Ai-trade-kiro/backend/back_temp/kubernetes_deployment.txt  (23377 bytes)
Ai-trade-kiro/backend/back_temp/ml_models_production.py  (40438 bytes)
Ai-trade-kiro/backend/back_temp/project_readme_docs.txt  (4060 bytes)
Ai-trade-kiro/backend/back_temp/react_app_main.ts  (22669 bytes)
Ai-trade-kiro/backend/back_temp/react_components_continuation.ts  (33405 bytes)
Ai-trade-kiro/backend/back_temp/react_hooks_store.ts  (24199 bytes)
Ai-trade-kiro/backend/back_temp/react_main_pages.ts  (46306 bytes)
Ai-trade-kiro/backend/back_temp/react_trading_dashboard.ts  (26348 bytes)
Ai-trade-kiro/backend/back_temp/webhook_notification_system.py  (34964 bytes)
Ai-trade-kiro/backend/config/data_sources.py  (610 bytes)
Ai-trade-kiro/backend/huggingface_requirements.txt  (1212 bytes)
Ai-trade-kiro/backend/main.py  (4704 bytes)
Ai-trade-kiro/backend/middleware/auth_middleware.py  (5717 bytes)
Ai-trade-kiro/backend/middleware/logging_middleware.py  (3223 bytes)
Ai-trade-kiro/backend/middleware/rate_limiter.py  (5935 bytes)
Ai-trade-kiro/backend/middleware/request_logger.py  (5509 bytes)
Ai-trade-kiro/backend/ml_model_project.py  (3846 bytes)
Ai-trade-kiro/backend/ml_service.py  (15503 bytes)
Ai-trade-kiro/backend/models/__init__.py  (16 bytes)
Ai-trade-kiro/backend/models/signal.py  (984 bytes)
Ai-trade-kiro/backend/models/strategy.py  (1579 bytes)
Ai-trade-kiro/backend/models/user.py  (810 bytes)
Ai-trade-kiro/backend/monitoring/error_tracker.py  (525 bytes)
Ai-trade-kiro/backend/monitoring/health_check.py  (383 bytes)
Ai-trade-kiro/backend/monitoring/health_checks.py  (23025 bytes)
Ai-trade-kiro/backend/monitoring/performance_dashboard.py  (16741 bytes)
Ai-trade-kiro/backend/monitoring/performance_monitor.py  (2636 bytes)
Ai-trade-kiro/backend/package.json  (2210 bytes)
Ai-trade-kiro/backend/pyproject.toml  (908 bytes)
Ai-trade-kiro/backend/requirements.txt  (937 bytes)
Ai-trade-kiro/backend/services/__pycache__/hybrid_signal_service.cpython-311.pyc  (26689 bytes)
Ai-trade-kiro/backend/services/__pycache__/model_training_service.cpython-311.pyc  (45622 bytes)
Ai-trade-kiro/backend/services/alert_service.py  (4671 bytes)
Ai-trade-kiro/backend/services/backtest_service.py  (2566 bytes)
Ai-trade-kiro/backend/services/backtesting_service.py  (29385 bytes)
Ai-trade-kiro/backend/services/hybrid_signal_service.py  (25414 bytes)
Ai-trade-kiro/backend/services/market_data_service.py  (67916 bytes)
Ai-trade-kiro/backend/services/market_regime_service.py  (45770 bytes)
Ai-trade-kiro/backend/services/ml_prediction_service.py  (25658 bytes)
Ai-trade-kiro/backend/services/ml_service.py  (8067 bytes)
Ai-trade-kiro/backend/services/model_training_service.py  (24101 bytes)
Ai-trade-kiro/backend/services/notification_service.py  (4312 bytes)
Ai-trade-kiro/backend/services/pattern_recognition_service.py  (42767 bytes)
Ai-trade-kiro/backend/services/portfolio_optimization_service.py  (58943 bytes)
Ai-trade-kiro/backend/services/portfolio_service.py  (12159 bytes)
Ai-trade-kiro/backend/services/security_service.py  (1989 bytes)
Ai-trade-kiro/backend/services/sentiment_service.py  (43076 bytes)
Ai-trade-kiro/backend/services/signal_service.py  (42434 bytes)
Ai-trade-kiro/backend/services/simplified_signal_service.py  (8055 bytes)
Ai-trade-kiro/backend/services/strategy_service.py  (3182 bytes)
Ai-trade-kiro/backend/services/technical_analysis_service.py  (9436 bytes)
Ai-trade-kiro/backend/services/user_service.py  (3633 bytes)
Ai-trade-kiro/backend/services/webhook_service.py  (3042 bytes)
Ai-trade-kiro/backend/services/websocket_service.py  (17384 bytes)
Ai-trade-kiro/backend/services/whale_analysis_service.py  (47716 bytes)
Ai-trade-kiro/backend/storage/model_manager.py  (17809 bytes)
Ai-trade-kiro/backend/tests/__init__.py  (15 bytes)
Ai-trade-kiro/backend/tests/conftest.py  (2190 bytes)
Ai-trade-kiro/backend/tests/test_db_connection.py  (4196 bytes)
Ai-trade-kiro/backend/tests/test_health.py  (634 bytes)
Ai-trade-kiro/backend/tests/test_normalization.py  (6885 bytes)
Ai-trade-kiro/backend/tsconfig.json  (878 bytes)
Ai-trade-kiro/backend/vite.config.ts  (4789 bytes)
Ai-trade-kiro/backend/websocket/data_streamer.py  (5645 bytes)
Ai-trade-kiro/backend/websocket/mobile_optimization.py  (362 bytes)
Ai-trade-kiro/backend/websocket/position_updates.py  (6826 bytes)
Ai-trade-kiro/database/README.md  (1858 bytes)
Ai-trade-kiro/database/init.sql  (7998 bytes)
Ai-trade-kiro/database/postgresql.conf  (3565 bytes)
Ai-trade-kiro/database/redis-master.conf  (1191 bytes)
Ai-trade-kiro/database/redis-replica.conf  (1214 bytes)
Ai-trade-kiro/database/timescale_init.sql  (3310 bytes)
Ai-trade-kiro/database/timescaledb.conf  (551 bytes)
Ai-trade-kiro/docker-build.sh  (1069 bytes)
Ai-trade-kiro/docker-compose.yml  (5047 bytes)
Ai-trade-kiro/monitoring/README.md  (1571 bytes)
Ai-trade-kiro/monitoring/grafana/dashboards/aismart-overview.json  (10107 bytes)
Ai-trade-kiro/monitoring/grafana/provisioning/dashboards/dashboards.yml  (197 bytes)
Ai-trade-kiro/monitoring/grafana/provisioning/datasources/datasource.yml  (490 bytes)
Ai-trade-kiro/monitoring/prometheus.yml  (697 bytes)
Ai-trade-kiro/next-env.d.ts  (205 bytes)
Ai-trade-kiro/next.config.js  (1533 bytes)
Ai-trade-kiro/package.json  (2176 bytes)
Ai-trade-kiro/project/.bolt/config.json  (39 bytes)
Ai-trade-kiro/project/.bolt/prompt  (401 bytes)
Ai-trade-kiro/project/.gitignore  (258 bytes)
Ai-trade-kiro/project/backend/services/hybrid_signal_service.py  (41383 bytes)
Ai-trade-kiro/project/eslint.config.js  (739 bytes)
Ai-trade-kiro/project/index.html  (378 bytes)
Ai-trade-kiro/project/package-lock.json  (142953 bytes)
Ai-trade-kiro/project/package.json  (810 bytes)
Ai-trade-kiro/project/postcss.config.js  (81 bytes)
Ai-trade-kiro/project/src/App.tsx  (1730 bytes)
Ai-trade-kiro/project/src/components/AISignalCard.tsx  (2121 bytes)
Ai-trade-kiro/project/src/components/Chart.tsx  (2495 bytes)
Ai-trade-kiro/project/src/components/Dashboard.tsx  (3340 bytes)
Ai-trade-kiro/project/src/components/Header.tsx  (1446 bytes)
Ai-trade-kiro/project/src/components/MetricCard.tsx  (1031 bytes)
Ai-trade-kiro/project/src/components/PatternRecognition.tsx  (7315 bytes)
Ai-trade-kiro/project/src/components/Portfolio.tsx  (11155 bytes)
Ai-trade-kiro/project/src/components/PredictionPanel.tsx  (6967 bytes)
Ai-trade-kiro/project/src/components/SentimentAnalysis.tsx  (8065 bytes)
Ai-trade-kiro/project/src/components/Sidebar.tsx  (2475 bytes)
Ai-trade-kiro/project/src/components/WhaleAnalysis.tsx  (9861 bytes)
Ai-trade-kiro/project/src/index.css  (59 bytes)
Ai-trade-kiro/project/src/main.tsx  (234 bytes)
Ai-trade-kiro/project/src/vite-env.d.ts  (38 bytes)
Ai-trade-kiro/project/tailwind.config.js  (170 bytes)
Ai-trade-kiro/project/tsconfig.app.json  (552 bytes)
Ai-trade-kiro/project/tsconfig.json  (119 bytes)
Ai-trade-kiro/project/tsconfig.node.json  (479 bytes)
Ai-trade-kiro/project/vite.config.ts  (220 bytes)
Ai-trade-kiro/setup-typescript.bat  (741 bytes)
Ai-trade-kiro/setup-typescript.sh  (696 bytes)
Ai-trade-kiro/setup.sh  (8889 bytes)
Ai-trade-kiro/src/app/404.tsx  (1822 bytes)
Ai-trade-kiro/src/app/api/markets/[symbol]/history/route.ts  (2585 bytes)
Ai-trade-kiro/src/app/chart-demo/page.tsx  (5027 bytes)
Ai-trade-kiro/src/app/globals.css  (2839 bytes)
Ai-trade-kiro/src/app/layout.tsx  (1990 bytes)
Ai-trade-kiro/src/app/page.tsx  (467 bytes)
Ai-trade-kiro/src/app/strategy-builder/page.tsx  (427 bytes)
Ai-trade-kiro/src/app/trading/page.tsx  (3849 bytes)
Ai-trade-kiro/src/components/ai/AIAnalyticsModule.tsx  (21711 bytes)
Ai-trade-kiro/src/components/ai/AdvancedAITab.tsx  (13158 bytes)
Ai-trade-kiro/src/components/ai/CloudBackupTab.tsx  (12511 bytes)
Ai-trade-kiro/src/components/ai/LivePredictionsTab.tsx  (14256 bytes)
Ai-trade-kiro/src/components/ai/ModelStorageTab.tsx  (14813 bytes)
Ai-trade-kiro/src/components/ai/index.ts  (1597 bytes)
Ai-trade-kiro/src/components/analytics/Analytics.tsx  (11592 bytes)
Ai-trade-kiro/src/components/analytics/Analytics/__CandleChart.tsx  (4001 bytes)
Ai-trade-kiro/src/components/dashboard/AIBacktestingModule.tsx  (39806 bytes)
Ai-trade-kiro/src/components/dashboard/AIIntegration.tsx  (8103 bytes)
Ai-trade-kiro/src/components/dashboard/AIModelConfigurationModule.tsx  (21454 bytes)
Ai-trade-kiro/src/components/dashboard/AINotifications.tsx  (8608 bytes)
Ai-trade-kiro/src/components/dashboard/AIStrategyBuilderWidget.tsx  (4162 bytes)
Ai-trade-kiro/src/components/dashboard/Dashboard.tsx  (16679 bytes)
Ai-trade-kiro/src/components/dashboard/Header.tsx  (21261 bytes)
Ai-trade-kiro/src/components/dashboard/LiveSignals.tsx  (28571 bytes)
Ai-trade-kiro/src/components/dashboard/MainContent.tsx  (24235 bytes)
Ai-trade-kiro/src/components/dashboard/MarketOverview.tsx  (34329 bytes)
Ai-trade-kiro/src/components/dashboard/Markets.tsx  (8767 bytes)
Ai-trade-kiro/src/components/dashboard/Preview.tsx  (26351 bytes)
Ai-trade-kiro/src/components/dashboard/Settings.tsx  (146 bytes)
Ai-trade-kiro/src/components/dashboard/Settings/DashboardSettings.tsx  (8868 bytes)
Ai-trade-kiro/src/components/dashboard/Settings/GeneralSettings.tsx  (7651 bytes)
Ai-trade-kiro/src/components/dashboard/Settings/SecuritySettings.tsx  (10746 bytes)
Ai-trade-kiro/src/components/dashboard/Settings/TradingSettings.tsx  (11881 bytes)
Ai-trade-kiro/src/components/dashboard/Settings/index.tsx  (8166 bytes)
Ai-trade-kiro/src/components/dashboard/Sidebar.tsx  (20640 bytes)
Ai-trade-kiro/src/components/dashboard/Signals.tsx  (11481 bytes)
Ai-trade-kiro/src/components/dashboard/TradingChart.tsx  (48895 bytes)
Ai-trade-kiro/src/components/dashboard/__skeletons/MetricCardSkeleton.tsx  (645 bytes)
Ai-trade-kiro/src/components/dashboard/__skeletons/TableSkeleton.tsx  (1144 bytes)
Ai-trade-kiro/src/components/dashboard/charts/CandlestickRenderer.ts  (17837 bytes)
Ai-trade-kiro/src/components/dashboard/charts/ChartEngine.ts  (22465 bytes)
Ai-trade-kiro/src/components/dashboard/charts/TradingChart.tsx  (48717 bytes)
Ai-trade-kiro/src/components/dashboard/charts/TradingChartWithCandlesticks.tsx  (9949 bytes)
Ai-trade-kiro/src/components/dashboard/charts/__tests__/CandlestickRenderer.test.ts  (17505 bytes)
Ai-trade-kiro/src/components/dashboard/charts/__tests__/ChartEngine.test.ts  (0 bytes)
Ai-trade-kiro/src/components/dashboard/data/aiModels.ts  (6889 bytes)
Ai-trade-kiro/src/components/dashboard/index.ts  (8595 bytes)
Ai-trade-kiro/src/components/dashboard/shared/ExchangeAPICard.tsx  (14961 bytes)
Ai-trade-kiro/src/components/dashboard/shared/ExchangeSVGIcons.tsx  (4186 bytes)
Ai-trade-kiro/src/components/dashboard/shared/NotificationSettings.tsx  (4525 bytes)
Ai-trade-kiro/src/components/dashboard/shared/PortfolioSettings.tsx  (6815 bytes)
Ai-trade-kiro/src/components/dashboard/shared/SecuritySettings.tsx  (4847 bytes)
Ai-trade-kiro/src/components/dashboard/shared/ThemeToggle.tsx  (915 bytes)
Ai-trade-kiro/src/components/dashboard/shared/ToggleSetting.tsx  (1584 bytes)
Ai-trade-kiro/src/components/dashboard/shared/TradingConfirmation.tsx  (4554 bytes)
Ai-trade-kiro/src/components/dashboard/shared/TradingSetupTab.tsx  (10282 bytes)
Ai-trade-kiro/src/components/dashboard/shared/settings/SelectDropdown.tsx  (2351 bytes)
Ai-trade-kiro/src/components/dashboard/shared/settings/SettingGroup.tsx  (1054 bytes)
Ai-trade-kiro/src/components/dashboard/shared/settings/SliderControl.tsx  (3049 bytes)
Ai-trade-kiro/src/components/dashboard/shared/settings/ToggleSwitch.tsx  (2501 bytes)
Ai-trade-kiro/src/components/dashboard/trading/LiveOrderBook.tsx  (6098 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/AIMarketInsightWidget.tsx  (11050 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/AIModelPerformanceWidget.tsx  (6480 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/AISignalMiniWidget.tsx  (6527 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/AISignalsWidget.tsx  (31421 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/AIStrategyWidget.tsx  (10472 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/AITradingAutomationWidget.tsx  (9481 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/MarketOverviewWidget.tsx  (22979 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/NewsWidget.tsx  (9824 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/OrderBookWidget.tsx  (6589 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/PerformanceWidget.tsx  (8698 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/PortfolioWidget.tsx  (31264 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/QuickTradeWidget.tsx  (19525 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/RiskManagerWidget.tsx  (8416 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/SettingsWidget.tsx  (10007 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/TechnicalAnalysisWidget.tsx  (7898 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/TradingChartWidget.tsx  (15956 bytes)
Ai-trade-kiro/src/components/dashboard/widgets/WhaleTrackerWidget.tsx  (10028 bytes)
Ai-trade-kiro/src/components/layout/Header.tsx  (21824 bytes)
Ai-trade-kiro/src/components/layout/Sidebar.tsx  (21210 bytes)
Ai-trade-kiro/src/components/portfolio/AdvancedPortfolio.tsx  (88439 bytes)
Ai-trade-kiro/src/components/portfolio/PortfolioSummary.tsx  (23117 bytes)
Ai-trade-kiro/src/components/providers/index.tsx  (2347 bytes)
Ai-trade-kiro/src/components/strategy-builder/StrategyBuilder.tsx  (16161 bytes)
Ai-trade-kiro/src/components/strategy-builder/controls/StrategyControls.tsx  (1601 bytes)
Ai-trade-kiro/src/components/strategy-builder/modals/LoadStrategyModal.tsx  (7244 bytes)
Ai-trade-kiro/src/components/strategy-builder/modals/SaveStrategyModal.tsx  (2579 bytes)
Ai-trade-kiro/src/components/strategy-builder/nodes/ActionNode.tsx  (1511 bytes)
Ai-trade-kiro/src/components/strategy-builder/nodes/ComponentNode.tsx  (2288 bytes)
Ai-trade-kiro/src/components/strategy-builder/nodes/ConditionNode.tsx  (1616 bytes)
Ai-trade-kiro/src/components/strategy-builder/nodes/OperatorNode.tsx  (1516 bytes)
Ai-trade-kiro/src/components/strategy-builder/panels/BacktestPanel.tsx  (9542 bytes)
Ai-trade-kiro/src/components/strategy-builder/panels/ComponentPanel.tsx  (3733 bytes)
Ai-trade-kiro/src/components/trading/CryptoTradingDashboard.tsx  (19198 bytes)
Ai-trade-kiro/src/components/trading/HybridSignalWidget.tsx  (15448 bytes)
Ai-trade-kiro/src/components/trading/MarketOverview.tsx  (5342 bytes)
Ai-trade-kiro/src/components/trading/OrderBook.tsx  (5680 bytes)
Ai-trade-kiro/src/components/trading/OrderEntryForm.tsx  (17203 bytes)
Ai-trade-kiro/src/components/trading/OrderForm.tsx  (9985 bytes)
Ai-trade-kiro/src/components/trading/OrderHistory.tsx  (9251 bytes)
Ai-trade-kiro/src/components/trading/OrderPreview.tsx  (4902 bytes)
Ai-trade-kiro/src/components/trading/PortfolioSummary.tsx  (8164 bytes)
Ai-trade-kiro/src/components/trading/PriceDisplay.tsx  (2426 bytes)
Ai-trade-kiro/src/components/trading/SignalCard.tsx  (5568 bytes)
Ai-trade-kiro/src/components/trading/TradingViewChart.tsx  (17063 bytes)
Ai-trade-kiro/src/components/trading/advanced_crypto_trading.tsx  (65757 bytes)
Ai-trade-kiro/src/components/ui/Alert.tsx  (2706 bytes)
Ai-trade-kiro/src/components/ui/Badge.tsx  (1170 bytes)
Ai-trade-kiro/src/components/ui/Button.tsx  (2418 bytes)
Ai-trade-kiro/src/components/ui/Card.tsx  (2236 bytes)
Ai-trade-kiro/src/components/ui/ConnectionStatus.tsx  (2214 bytes)
Ai-trade-kiro/src/components/ui/Dialog.tsx  (3663 bytes)
Ai-trade-kiro/src/components/ui/Input.tsx  (1642 bytes)
Ai-trade-kiro/src/components/ui/Select.tsx  (1676 bytes)
Ai-trade-kiro/src/components/ui/Skeleton.tsx  (335 bytes)
Ai-trade-kiro/src/components/ui/Spinner.tsx  (907 bytes)
Ai-trade-kiro/src/components/ui/Switch.tsx  (2106 bytes)
Ai-trade-kiro/src/components/ui/Tabs.tsx  (2807 bytes)
Ai-trade-kiro/src/components/ui/ThemeToggle.tsx  (733 bytes)
Ai-trade-kiro/src/components/ui/Toast.tsx  (2135 bytes)
Ai-trade-kiro/src/components/ui/ToastContainer.tsx  (764 bytes)
Ai-trade-kiro/src/components/ui/Tooltip.tsx  (3850 bytes)
Ai-trade-kiro/src/hooks/useChartData.ts  (4023 bytes)
Ai-trade-kiro/src/hooks/useDashboard.ts  (6295 bytes)
Ai-trade-kiro/src/hooks/useLocalStorage.ts  (2063 bytes)
Ai-trade-kiro/src/hooks/useMarketData.ts  (2977 bytes)
Ai-trade-kiro/src/hooks/useMediaQuery.ts  (1411 bytes)
Ai-trade-kiro/src/hooks/useToast.ts  (1078 bytes)
Ai-trade-kiro/src/hooks/useTrading.ts  (15360 bytes)
Ai-trade-kiro/src/hooks/useWebSocket.ts  (14608 bytes)
Ai-trade-kiro/src/lib/api/index.ts  (4926 bytes)
Ai-trade-kiro/src/lib/auth/biometric.ts  (9343 bytes)
Ai-trade-kiro/src/lib/auth/deviceFingerprint.ts  (11287 bytes)
Ai-trade-kiro/src/lib/auth/encryption.ts  (8636 bytes)
Ai-trade-kiro/src/lib/auth/jwt.ts  (4765 bytes)
Ai-trade-kiro/src/lib/auth/rateLimiter.ts  (9346 bytes)
Ai-trade-kiro/src/lib/auth/twoFactor.ts  (6422 bytes)
Ai-trade-kiro/src/lib/auth/types.ts  (4784 bytes)
Ai-trade-kiro/src/lib/config.ts  (4806 bytes)
Ai-trade-kiro/src/lib/stores/marketStore.ts  (1974 bytes)
Ai-trade-kiro/src/lib/stores/portfolioStore.ts  (3444 bytes)
Ai-trade-kiro/src/lib/stores/signalStore.ts  (1873 bytes)
Ai-trade-kiro/src/lib/trading/apiService.ts  (0 bytes)
Ai-trade-kiro/src/lib/utils/cn.ts  (225 bytes)
Ai-trade-kiro/src/lib/utils/index.ts  (4070 bytes)
Ai-trade-kiro/src/lib/utils/indicators.ts  (5951 bytes)
Ai-trade-kiro/src/lib/websocket/index.ts  (5386 bytes)
Ai-trade-kiro/src/pages/ai-signals.tsx  (6230 bytes)
Ai-trade-kiro/src/services/aiAnalyticsService.ts  (6372 bytes)
Ai-trade-kiro/src/services/aiExternalService.ts  (12571 bytes)
Ai-trade-kiro/src/services/aiNotificationService.ts  (6837 bytes)
Ai-trade-kiro/src/services/aiTradingAutomationService.ts  (18473 bytes)
Ai-trade-kiro/src/services/api.ts  (5524 bytes)
Ai-trade-kiro/src/services/apiService.ts  (5790 bytes)
Ai-trade-kiro/src/services/comprehensive-dashboard-service.ts  (20117 bytes)
Ai-trade-kiro/src/services/dashboardService.ts  (11926 bytes)
Ai-trade-kiro/src/services/hybridSignalService.ts  (4875 bytes)
Ai-trade-kiro/src/services/hybridTradingService.ts  (31856 bytes)
Ai-trade-kiro/src/services/marketService.ts  (15278 bytes)
Ai-trade-kiro/src/services/mlService.ts  (729 bytes)
Ai-trade-kiro/src/services/mockApiService.ts  (7 bytes)
Ai-trade-kiro/src/services/newsService.ts  (810 bytes)
Ai-trade-kiro/src/services/notificationService.ts  (9967 bytes)
Ai-trade-kiro/src/services/portfolioService.ts  (1223 bytes)
Ai-trade-kiro/src/services/realDataService.ts  (19336 bytes)
Ai-trade-kiro/src/services/realTimeService.ts  (17431 bytes)
Ai-trade-kiro/src/services/signalService.ts  (31070 bytes)
Ai-trade-kiro/src/services/strategyApiService.ts  (6539 bytes)
Ai-trade-kiro/src/services/strategyBuilderService.ts  (25046 bytes)
Ai-trade-kiro/src/services/tradeExecutionService.ts  (9274 bytes)
Ai-trade-kiro/src/services/tradingService.ts  (22430 bytes)
Ai-trade-kiro/src/types/index.ts  (2953 bytes)
Ai-trade-kiro/src/types/market.ts  (1696 bytes)
Ai-trade-kiro/src/types/react.d.ts  (755 bytes)
Ai-trade-kiro/src/types/signals.ts  (3941 bytes)
Ai-trade-kiro/src/types/trading.ts  (3814 bytes)
Ai-trade-kiro/tailwind.config.js  (2898 bytes)
Ai-trade-kiro/task-automation.bat  (49 bytes)
Ai-trade-kiro/task-manager.bat  (61 bytes)
Ai-trade-kiro/tasks.md  (48112 bytes)
Ai-trade-kiro/tasks_reorganized.md  (19136 bytes)
Ai-trade-kiro/temp_components/MarketOverview_trading_backup.tsx  (5342 bytes)
Ai-trade-kiro/temp_components/PortfolioSummary_trading_backup.tsx  (8164 bytes)
Ai-trade-kiro/tsconfig.json  (1230 bytes)
Ai-trade-kiro/updated_tasks.md  (9453 bytes)
Ai-trade-kiro/workspace.code-workspace  (43 bytes)
```

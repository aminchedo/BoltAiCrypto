"""
Hybrid Signal Service
Implements the AI Hybrid Trading System with weighted components:
- RSI + MACD Analysis (40%)
- Smart Money Concepts (25%)
- Pattern Recognition (20%)
- Sentiment Analysis (7%)
- Whale Movements (3%)
- ML Predictions (5%)
"""

import asyncio
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import numpy as np
import json
import os
import random

# Import services
from .market_data_service import MarketDataService
from .technical_analysis_service import TechnicalAnalysisService
from .sentiment_service import SentimentService
from .pattern_recognition_service import PatternRecognitionService
from .ml_service import MLService

logger = logging.getLogger(__name__)

class HybridSignalService:
    """Service for generating hybrid trading signals"""
    
    def __init__(self):
        self.market_service = MarketDataService()
        self.ta_service = TechnicalAnalysisService()
        self.sentiment_service = SentimentService()
        self.pattern_service = PatternRecognitionService()
        self.ml_service = MLService()
        
        # Component weights
        self.TECHNICAL_ANALYSIS_WEIGHT = 0.40
        self.SMART_MONEY_WEIGHT = 0.25
        self.PATTERN_RECOGNITION_WEIGHT = 0.20
        self.SENTIMENT_ANALYSIS_WEIGHT = 0.07
        self.WHALE_MOVEMENT_WEIGHT = 0.03
        self.ML_PREDICTION_WEIGHT = 0.05
        
        # Signal cache
        self.signal_cache: Dict[str, Dict[str, Any]] = {}
        self.cache_expiry: Dict[str, datetime] = {}
        self.CACHE_DURATION = timedelta(minutes=5)
    
    async def get_hybrid_signals(
        self, 
        user_id: str, 
        symbols: Optional[List[str]] = None,
        min_confidence: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """Get hybrid trading signals for multiple symbols"""
        if not symbols:
            # Default to top symbols
            symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT"]
        
        signals = []
        
        # Generate signals for each symbol
        for symbol in symbols:
            try:
                signal = await self.get_signal_for_symbol(user_id, symbol)
                if signal and (min_confidence is None or signal["confidence"] >= min_confidence):
                    signals.append(signal)
            except Exception as e:
                logger.error(f"Error generating signal for {symbol}: {e}")
        
        return signals
    
    async def get_signal_for_symbol(self, user_id: str, symbol: str) -> Optional[Dict[str, Any]]:
        """Get hybrid signal for a specific symbol"""
        # Check cache
        cache_key = f"{user_id}:{symbol}"
        if cache_key in self.signal_cache and datetime.now() < self.cache_expiry.get(cache_key, datetime.min):
            return self.signal_cache[cache_key]
        
        try:
            # Get historical data
            candles = await self.market_service.get_candles(
                symbol=symbol,
                interval="1h",
                limit=100
            )
            
            if not candles or len(candles) < 50:
                logger.warning(f"Insufficient data for {symbol}")
                return None
            
            # Calculate all components in parallel
            technical_task = asyncio.create_task(self.calculate_technical_analysis(symbol, candles))
            smart_money_task = asyncio.create_task(self.analyze_smart_money(symbol, candles))
            pattern_task = asyncio.create_task(self.recognize_patterns(symbol, candles))
            sentiment_task = asyncio.create_task(self.analyze_sentiment(symbol))
            whale_task = asyncio.create_task(self.analyze_whale_movement(symbol))
            ml_task = asyncio.create_task(self.generate_ml_prediction(symbol, candles))
            
            # Wait for all tasks to complete
            technical_result = await technical_task
            smart_money_result = await smart_money_task
            pattern_result = await pattern_task
            sentiment_result = await sentiment_task
            whale_result = await whale_task
            ml_result = await ml_task
            
            # Calculate weighted final score
            final_score = (
                technical_result["score"] * self.TECHNICAL_ANALYSIS_WEIGHT +
                smart_money_result["score"] * self.SMART_MONEY_WEIGHT +
                pattern_result["score"] * self.PATTERN_RECOGNITION_WEIGHT +
                sentiment_result["score"] * self.SENTIMENT_ANALYSIS_WEIGHT +
                whale_result["score"] * self.WHALE_MOVEMENT_WEIGHT +
                ml_result["score"] * self.ML_PREDICTION_WEIGHT
            )
            
            # Determine signal direction and confidence
            direction = "BUY" if final_score > 0.1 else "SELL" if final_score < -0.1 else "HOLD"
            confidence = min(abs(final_score) * 100, 100)
            
            if confidence < 60:
                return None  # Don't generate low-confidence signals
            
            # Get current price
            current_price = candles[-1]["close"]
            
            # Calculate volatility for stop loss and take profit
            volatility = self.calculate_volatility(candles)
            
            # Calculate entry, stop loss, and take profit
            stop_loss_distance = volatility * 2
            take_profit_distance = volatility * 3
            
            stop_loss = current_price - stop_loss_distance if direction == "BUY" else current_price + stop_loss_distance
            take_profit = current_price + take_profit_distance if direction == "BUY" else current_price - take_profit_distance
            
            # Create signal
            signal = {
                "id": f"{symbol}_{int(datetime.now().timestamp())}",
                "symbol": symbol,
                "direction": direction,
                "confidence": round(confidence),
                "entryPrice": current_price,
                "stopLoss": stop_loss,
                "takeProfit": take_profit,
                "riskRewardRatio": take_profit_distance / stop_loss_distance,
                "timestamp": int(datetime.now().timestamp() * 1000),
                "expiresAt": int((datetime.now() + timedelta(hours=4)).timestamp() * 1000),
                "status": "ACTIVE",
                "algorithmBreakdown": {
                    "technicalAnalysis": {
                        "score": technical_result["score"],
                        "weight": self.TECHNICAL_ANALYSIS_WEIGHT,
                        "contribution": technical_result["score"] * self.TECHNICAL_ANALYSIS_WEIGHT
                    },
                    "smartMoneyConcepts": {
                        "score": smart_money_result["score"],
                        "weight": self.SMART_MONEY_WEIGHT,
                        "contribution": smart_money_result["score"] * self.SMART_MONEY_WEIGHT
                    },
                    "patternRecognition": {
                        "score": pattern_result["score"],
                        "weight": self.PATTERN_RECOGNITION_WEIGHT,
                        "contribution": pattern_result["score"] * self.PATTERN_RECOGNITION_WEIGHT
                    },
                    "sentimentAnalysis": {
                        "score": sentiment_result["score"],
                        "weight": self.SENTIMENT_ANALYSIS_WEIGHT,
                        "contribution": sentiment_result["score"] * self.SENTIMENT_ANALYSIS_WEIGHT
                    },
                    "whaleIntelligence": {
                        "score": whale_result["score"],
                        "weight": self.WHALE_MOVEMENT_WEIGHT,
                        "contribution": whale_result["score"] * self.WHALE_MOVEMENT_WEIGHT
                    },
                    "mlPredictions": {
                        "score": ml_result["score"],
                        "weight": self.ML_PREDICTION_WEIGHT,
                        "contribution": ml_result["score"] * self.ML_PREDICTION_WEIGHT
                    },
                    "finalScore": final_score
                },
                "riskAssessment": {
                    "riskScore": self.calculate_risk_score(candles, smart_money_result),
                    "maxLossAmount": stop_loss_distance,
                    "positionSizeRecommendation": self.calculate_position_size(confidence, stop_loss_distance),
                    "marketImpact": self.assess_market_impact(candles)
                },
                "marketConditions": {
                    "volatility": (volatility / current_price) * 100,
                    "volumeProfile": self.assess_volume_profile(candles),
                    "trendStrength": abs(technical_result["score"]) * 100,
                    "supportResistance": self.find_support_resistance(candles)
                }
            }
            
            # Cache signal
            self.signal_cache[cache_key] = signal
            self.cache_expiry[cache_key] = datetime.now() + self.CACHE_DURATION
            
            return signal
            
        except Exception as e:
            logger.error(f"Error generating hybrid signal for {symbol}: {e}")
            return None
    
    async def calculate_technical_analysis(self, symbol: str, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate technical analysis indicators (RSI + MACD)"""
        try:
            # Use technical analysis service
            ta_result = await self.ta_service.calculate_indicators(symbol, candles)
            
            # Extract key indicators
            rsi = ta_result.get("rsi", 50)
            macd = ta_result.get("macd", {"macd": 0, "signal": 0, "histogram": 0})
            
            # Calculate score based on indicators
            score = 0
            
            # RSI contribution
            if rsi < 30:
                score += 0.8  # Oversold - bullish
            elif rsi > 70:
                score -= 0.8  # Overbought - bearish
            elif rsi > 45 and rsi < 55:
                score += 0.2  # Neutral
            
            # MACD contribution
            if macd["histogram"] > 0 and macd["macd"] > macd["signal"]:
                score += 0.6  # Bullish
            elif macd["histogram"] < 0 and macd["macd"] < macd["signal"]:
                score -= 0.6  # Bearish
            
            # Normalize score to -1 to 1 range
            score = max(-1, min(1, score))
            
            return {
                "rsi": rsi,
                "macd": macd,
                "score": score,
                "details": ta_result
            }
            
        except Exception as e:
            logger.error(f"Error calculating technical analysis: {e}")
            return {
                "rsi": 50,
                "macd": {"macd": 0, "signal": 0, "histogram": 0},
                "score": 0,
                "details": {}
            }
    
    async def analyze_smart_money(self, symbol: str, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze smart money concepts"""
        try:
            # Use pattern recognition service for smart money analysis
            smc_result = await self.pattern_service.analyze_smart_money_concepts(symbol, candles)
            
            # Extract key components
            market_structure = smc_result.get("marketStructure", {
                "trend": "sideways",
                "strength": 0,
                "breakOfStructure": False
            })
            
            # Calculate score based on smart money concepts
            score = 0
            
            # Market structure contribution
            if market_structure["trend"] == "bullish":
                score += 0.4
            elif market_structure["trend"] == "bearish":
                score -= 0.4
            
            # Break of structure contribution
            if market_structure.get("breakOfStructure", False):
                score += 0.3 if market_structure["trend"] == "bullish" else -0.3
            
            # Order blocks contribution
            order_blocks = smc_result.get("orderBlocks", [])
            bullish_blocks = len([b for b in order_blocks if b.get("type") == "bullish"])
            bearish_blocks = len([b for b in order_blocks if b.get("type") == "bearish"])
            score += (bullish_blocks - bearish_blocks) * 0.1
            
            # Normalize score to -1 to 1 range
            score = max(-1, min(1, score))
            
            return {
                "marketStructure": market_structure,
                "orderBlocks": smc_result.get("orderBlocks", []),
                "fairValueGaps": smc_result.get("fairValueGaps", []),
                "liquidityZones": smc_result.get("liquidityZones", []),
                "score": score,
                "details": smc_result
            }
            
        except Exception as e:
            logger.error(f"Error analyzing smart money concepts: {e}")
            return {
                "marketStructure": {"trend": "sideways", "strength": 0, "breakOfStructure": False},
                "orderBlocks": [],
                "fairValueGaps": [],
                "liquidityZones": [],
                "score": 0,
                "details": {}
            }
    
    async def recognize_patterns(self, symbol: str, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Recognize chart and candlestick patterns"""
        try:
            # Use pattern recognition service
            pattern_result = await self.pattern_service.detect_patterns(symbol, candles)
            
            # Extract key patterns
            harmonic_patterns = pattern_result.get("harmonicPatterns", [])
            classic_patterns = pattern_result.get("classicPatterns", [])
            candlestick_patterns = pattern_result.get("candlestickPatterns", [])
            
            # Calculate score based on patterns
            score = 0
            weight = 0
            
            # Harmonic patterns contribution
            for pattern in harmonic_patterns:
                pattern_score = (pattern.get("confidence", 0) / 100) * 0.8
                score += pattern_score
                weight += 0.8
            
            # Classic patterns contribution
            for pattern in classic_patterns:
                pattern_score = (pattern.get("confidence", 0) / 100) * 0.6
                score += pattern_score
                weight += 0.6
            
            # Candlestick patterns contribution
            for pattern in candlestick_patterns:
                pattern_score = (pattern.get("confidence", 0) / 100) * (0.4 if pattern.get("bullish", False) else -0.4)
                score += pattern_score
                weight += 0.4
            
            # Normalize score
            if weight > 0:
                score = score / weight
            
            # Ensure score is in -1 to 1 range
            score = max(-1, min(1, score))
            
            return {
                "harmonicPatterns": harmonic_patterns,
                "classicPatterns": classic_patterns,
                "candlestickPatterns": candlestick_patterns,
                "score": score,
                "details": pattern_result
            }
            
        except Exception as e:
            logger.error(f"Error recognizing patterns: {e}")
            return {
                "harmonicPatterns": [],
                "classicPatterns": [],
                "candlestickPatterns": [],
                "score": 0,
                "details": {}
            }
    
    async def analyze_sentiment(self, symbol: str) -> Dict[str, Any]:
        """Analyze market sentiment from news and social media"""
        try:
            # Use sentiment analysis service
            sentiment_result = await self.sentiment_service.analyze_market_sentiment(symbol)
            
            # Extract key sentiment metrics
            news_score = sentiment_result.get("newsScore", 0)
            social_score = sentiment_result.get("socialScore", 0)
            fear_greed_index = sentiment_result.get("fearGreedIndex", 50)
            
            # Calculate overall sentiment score
            overall_sentiment = news_score * 0.6 + social_score * 0.4
            
            return {
                "newsScore": news_score,
                "socialScore": social_score,
                "fearGreedIndex": fear_greed_index,
                "overallSentiment": overall_sentiment,
                "score": overall_sentiment,
                "details": sentiment_result
            }
            
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return {
                "newsScore": 0,
                "socialScore": 0,
                "fearGreedIndex": 50,
                "overallSentiment": 0,
                "score": 0,
                "details": {}
            }
    
    async def analyze_whale_movement(self, symbol: str) -> Dict[str, Any]:
        """Analyze whale movements and large transactions"""
        try:
            # Use whale analysis service (part of sentiment service)
            whale_result = await self.sentiment_service.analyze_whale_activity(symbol)
            
            # Extract key whale metrics
            whale_score = whale_result.get("whaleScore", 0)
            
            return {
                "largeTransactions": whale_result.get("largeTransactions", []),
                "exchangeFlows": whale_result.get("exchangeFlows", {
                    "netFlow": 0,
                    "inflowVolume": 0,
                    "outflowVolume": 0
                }),
                "whaleScore": whale_score,
                "score": whale_score,
                "details": whale_result
            }
            
        except Exception as e:
            logger.error(f"Error analyzing whale movements: {e}")
            return {
                "largeTransactions": [],
                "exchangeFlows": {
                    "netFlow": 0,
                    "inflowVolume": 0,
                    "outflowVolume": 0
                },
                "whaleScore": 0,
                "score": 0,
                "details": {}
            }
    
    async def generate_ml_prediction(self, symbol: str, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate ML-based price predictions"""
        try:
            # Use ML service
            ml_result = await self.ml_service.predict_price(symbol, "1h", "24h")
            
            # Extract key prediction metrics
            current_price = candles[-1]["close"]
            predicted_price = ml_result.get("predictedPrice", current_price)
            confidence = ml_result.get("confidence", 0)
            
            # Calculate price change percentage
            price_change = (predicted_price - current_price) / current_price
            
            # Calculate score based on predicted direction and confidence
            score = price_change * (confidence / 100)
            
            return {
                "predictedPrice": predicted_price,
                "priceChange": price_change,
                "confidence": confidence,
                "score": score,
                "details": ml_result
            }
            
        except Exception as e:
            logger.error(f"Error generating ML prediction: {e}")
            return {
                "predictedPrice": 0,
                "priceChange": 0,
                "confidence": 0,
                "score": 0,
                "details": {}
            }
    
    def calculate_volatility(self, candles: List[Dict[str, Any]]) -> float:
        """Calculate volatility using Average True Range (ATR)"""
        try:
            if len(candles) < 14:
                return 0
            
            # Calculate True Range
            true_ranges = []
            for i in range(1, len(candles)):
                high = candles[i]["high"]
                low = candles[i]["low"]
                prev_close = candles[i-1]["close"]
                
                tr1 = high - low
                tr2 = abs(high - prev_close)
                tr3 = abs(low - prev_close)
                
                true_range = max(tr1, tr2, tr3)
                true_ranges.append(true_range)
            
            # Calculate ATR (14-period)
            atr = sum(true_ranges[-14:]) / 14
            return atr
            
        except Exception as e:
            logger.error(f"Error calculating volatility: {e}")
            return 0
    
    def calculate_risk_score(self, candles: List[Dict[str, Any]], smart_money_result: Dict[str, Any]) -> float:
        """Calculate risk score"""
        try:
            risk_score = 50  # Base risk score
            
            # Volatility risk
            volatility = self.calculate_volatility(candles)
            current_price = candles[-1]["close"]
            volatility_risk = (volatility / current_price) * 100
            risk_score += volatility_risk * 10
            
            # Market structure risk
            market_structure = smart_money_result.get("marketStructure", {})
            if market_structure.get("breakOfStructure", False):
                risk_score += 20
            
            # Trend strength risk
            risk_score += market_structure.get("strength", 0) * 0.2
            
            return max(0, min(100, risk_score))
            
        except Exception as e:
            logger.error(f"Error calculating risk score: {e}")
            return 50
    
    def calculate_position_size(self, confidence: float, stop_loss_distance: float) -> float:
        """Calculate recommended position size"""
        try:
            # Kelly Criterion simplified
            win_rate = confidence / 100
            avg_win = 2  # Assume 2:1 reward ratio
            avg_loss = 1
            
            kelly_percent = (win_rate * avg_win - (1 - win_rate) * avg_loss) / avg_win
            
            # Conservative position sizing (max 5% of portfolio)
            return max(0.5, min(5, kelly_percent * 100))
            
        except Exception as e:
            logger.error(f"Error calculating position size: {e}")
            return 1
    
    def assess_market_impact(self, candles: List[Dict[str, Any]]) -> str:
        """Assess market impact"""
        try:
            volumes = [c["volume"] for c in candles]
            avg_volume = sum(volumes) / len(volumes)
            recent_volume = volumes[-1]
            
            volume_ratio = recent_volume / avg_volume
            
            if volume_ratio > 2:
                return "HIGH"
            elif volume_ratio > 1.5:
                return "MEDIUM"
            else:
                return "LOW"
                
        except Exception as e:
            logger.error(f"Error assessing market impact: {e}")
            return "MEDIUM"
    
    def assess_volume_profile(self, candles: List[Dict[str, Any]]) -> str:
        """Assess volume profile"""
        try:
            volumes = [c["volume"] for c in candles]
            avg_volume = sum(volumes) / len(volumes)
            recent_avg_volume = sum(volumes[-5:]) / 5
            
            ratio = recent_avg_volume / avg_volume
            
            if ratio > 1.5:
                return "HIGH"
            elif ratio > 0.8:
                return "MEDIUM"
            else:
                return "LOW"
                
        except Exception as e:
            logger.error(f"Error assessing volume profile: {e}")
            return "MEDIUM"
    
    def find_support_resistance(self, candles: List[Dict[str, Any]]) -> Dict[str, float]:
        """Find support and resistance levels"""
        try:
            highs = [c["high"] for c in candles]
            lows = [c["low"] for c in candles]
            
            # Simple support/resistance calculation
            recent_highs = highs[-20:]
            recent_lows = lows[-20:]
            
            resistance = max(recent_highs)
            support = min(recent_lows)
            
            return {"support": support, "resistance": resistance}
            
        except Exception as e:
            logger.error(f"Error finding support/resistance: {e}")
            return {"support": 0, "resistance": 0}
    
    async def get_algorithm_breakdown(self, user_id: str, symbol: str) -> Optional[Dict[str, Any]]:
        """Get detailed breakdown of algorithm components for a symbol"""
        signal = await self.get_signal_for_symbol(user_id, symbol)
        
        if not signal:
            return None
        
        return signal.get("algorithmBreakdown", {})
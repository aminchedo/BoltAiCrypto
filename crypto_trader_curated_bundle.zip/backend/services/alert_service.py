"""
Alert service for managing price alerts and trading alerts
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)

class AlertType(str, Enum):
    PRICE = "price"
    VOLUME = "volume"
    TECHNICAL = "technical"
    NEWS = "news"

class AlertCondition(str, Enum):
    ABOVE = "above"
    BELOW = "below"
    CROSSES_ABOVE = "crosses_above"
    CROSSES_BELOW = "crosses_below"

class AlertStatus(str, Enum):
    ACTIVE = "active"
    TRIGGERED = "triggered"
    EXPIRED = "expired"
    CANCELLED = "cancelled"

class AlertService:
    """Service for alert management"""
    
    def __init__(self):
        # Mock storage for simplified version
        self.alerts = {}
        self.user_alerts = {}
    
    async def create_alert(
        self,
        user_id: int,
        symbol: str,
        alert_type: AlertType,
        condition: AlertCondition,
        value: float,
        message: Optional[str] = None,
        expires_at: Optional[datetime] = None
    ) -> str:
        """Create a new alert"""
        alert_id = str(uuid.uuid4())
        
        alert = {
            "id": alert_id,
            "user_id": user_id,
            "symbol": symbol,
            "type": alert_type,
            "condition": condition,
            "value": value,
            "message": message,
            "status": AlertStatus.ACTIVE,
            "created_at": datetime.now(),
            "expires_at": expires_at,
            "triggered_at": None
        }
        
        self.alerts[alert_id] = alert
        
        # Add to user's alerts
        if user_id not in self.user_alerts:
            self.user_alerts[user_id] = []
        self.user_alerts[user_id].append(alert_id)
        
        return alert_id
    
    async def get_user_alerts(
        self,
        user_id: int,
        status: Optional[AlertStatus] = None
    ) -> List[Dict[str, Any]]:
        """Get alerts for a user"""
        user_alert_ids = self.user_alerts.get(user_id, [])
        alerts = []
        
        for alert_id in user_alert_ids:
            alert = self.alerts.get(alert_id)
            if alert:
                if not status or alert["status"] == status:
                    alerts.append(alert)
        
        return sorted(alerts, key=lambda x: x["created_at"], reverse=True)
    
    async def update_alert(
        self,
        alert_id: str,
        user_id: int,
        updates: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Update an alert"""
        alert = self.alerts.get(alert_id)
        if not alert or alert["user_id"] != user_id:
            return None
        
        for key, value in updates.items():
            if key in alert and key not in ["id", "user_id", "created_at"]:
                alert[key] = value
        
        return alert
    
    async def delete_alert(self, alert_id: str, user_id: int) -> bool:
        """Delete an alert"""
        alert = self.alerts.get(alert_id)
        if alert and alert["user_id"] == user_id:
            del self.alerts[alert_id]
            if user_id in self.user_alerts:
                self.user_alerts[user_id].remove(alert_id)
            return True
        return False
    
    async def trigger_alert(self, alert_id: str) -> bool:
        """Trigger an alert"""
        alert = self.alerts.get(alert_id)
        if alert and alert["status"] == AlertStatus.ACTIVE:
            alert["status"] = AlertStatus.TRIGGERED
            alert["triggered_at"] = datetime.now()
            return True
        return False
    
    async def check_alerts(self, symbol: str, current_price: float):
        """Check if any alerts should be triggered for a symbol"""
        for alert in self.alerts.values():
            if (alert["symbol"] == symbol and 
                alert["status"] == AlertStatus.ACTIVE and
                alert["type"] == AlertType.PRICE):
                
                should_trigger = False
                
                if alert["condition"] == AlertCondition.ABOVE and current_price > alert["value"]:
                    should_trigger = True
                elif alert["condition"] == AlertCondition.BELOW and current_price < alert["value"]:
                    should_trigger = True
                
                if should_trigger:
                    await self.trigger_alert(alert["id"])
                    logger.info(f"Alert triggered: {alert['id']} for {symbol} at {current_price}")
"""
Machine Learning Prediction Service
Provides time-series forecasting using LSTM/GRU neural networks with ensemble methods
"""

import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import math
import statistics
import threading
from concurrent.futures import ThreadPoolExecutor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TimeFrame(Enum):
    """Supported prediction timeframes"""
    ONE_HOUR = "1h"
    FOUR_HOUR = "4h"
    ONE_DAY = "1d"
    ONE_WEEK = "1w"

class ModelType(Enum):
    """Available model types"""
    LSTM = "lstm"
    GRU = "gru"
    TRANSFORMER = "transformer"
    ENSEMBLE = "ensemble"

@dataclass
class PredictionResult:
    """Structure for prediction results"""
    asset: str
    timeframe: str
    direction: str
    confidence: float
    target_price: float
    stop_loss: float
    timestamp: datetime
    model_version: str
    features_used: List[str]
    risk_score: float

@dataclass
class ModelPerformance:
    """Model performance metrics"""
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    sharpe_ratio: float
    max_drawdown: float
    total_trades: int
    winning_trades: int
    avg_return: float

class FeatureEngineer:
    """Automatic feature engineering from raw market data"""
    
    def __init__(self):
        self.feature_cache = {}
        
    def extract_technical_features(self, ohlcv_data: List[Dict]) -> Dict[str, List[float]]:
        """Extract technical indicators from OHLCV data"""
        if len(ohlcv_data) < 50:
            raise ValueError("Insufficient data for feature extraction")
            
        closes = [float(d['close']) for d in ohlcv_data]
        highs = [float(d['high']) for d in ohlcv_data]
        lows = [float(d['low']) for d in ohlcv_data]
        volumes = [float(d['volume']) for d in ohlcv_data]
        
        features = {}
        
        # Moving averages
        features['sma_20'] = self._simple_moving_average(closes, 20)
        features['sma_50'] = self._simple_moving_average(closes, 50)
        features['ema_12'] = self._exponential_moving_average(closes, 12)
        features['ema_26'] = self._exponential_moving_average(closes, 26)
        
        # Momentum indicators
        features['rsi'] = self._relative_strength_index(closes, 14)
        features['macd'] = self._macd(closes)
        features['stoch'] = self._stochastic_oscillator(highs, lows, closes, 14)
        
        # Volatility indicators
        features['bollinger_upper'], features['bollinger_lower'] = self._bollinger_bands(closes, 20)
        features['atr'] = self._average_true_range(highs, lows, closes, 14)
        
        # Volume indicators
        features['volume_sma'] = self._simple_moving_average(volumes, 20)
        features['volume_ratio'] = self._volume_ratio(volumes)
        
        # Price patterns
        features['price_momentum'] = self._price_momentum(closes, 10)
        features['volatility'] = self._rolling_volatility(closes, 20)
        
        return features
    
    def _simple_moving_average(self, data: List[float], period: int) -> List[float]:
        """Calculate Simple Moving Average"""
        sma = []
        for i in range(len(data)):
            if i < period - 1:
                sma.append(None)
            else:
                avg = sum(data[i-period+1:i+1]) / period
                sma.append(avg)
        return sma
    
    def _exponential_moving_average(self, data: List[float], period: int) -> List[float]:
        """Calculate Exponential Moving Average"""
        ema = []
        multiplier = 2 / (period + 1)
        
        for i, price in enumerate(data):
            if i == 0:
                ema.append(price)
            else:
                ema_value = (price * multiplier) + (ema[i-1] * (1 - multiplier))
                ema.append(ema_value)
        return ema
    
    def _relative_strength_index(self, data: List[float], period: int) -> List[float]:
        """Calculate RSI"""
        rsi = []
        gains = []
        losses = []
        
        for i in range(1, len(data)):
            change = data[i] - data[i-1]
            gains.append(max(change, 0))
            losses.append(abs(min(change, 0)))
        
        for i in range(len(gains)):
            if i < period - 1:
                rsi.append(None)
            else:
                avg_gain = sum(gains[i-period+1:i+1]) / period
                avg_loss = sum(losses[i-period+1:i+1]) / period
                
                if avg_loss == 0:
                    rsi.append(100)
                else:
                    rs = avg_gain / avg_loss
                    rsi_value = 100 - (100 / (1 + rs))
                    rsi.append(rsi_value)
        
        return [None] + rsi
    
    def _macd(self, data: List[float]) -> List[float]:
        """Calculate MACD"""
        ema_12 = self._exponential_moving_average(data, 12)
        ema_26 = self._exponential_moving_average(data, 26)
        
        macd = []
        for i in range(len(data)):
            if ema_12[i] is not None and ema_26[i] is not None:
                macd.append(ema_12[i] - ema_26[i])
            else:
                macd.append(None)
        return macd
    
    def _stochastic_oscillator(self, highs: List[float], lows: List[float], 
                              closes: List[float], period: int) -> List[float]:
        """Calculate Stochastic Oscillator"""
        stoch = []
        
        for i in range(len(closes)):
            if i < period - 1:
                stoch.append(None)
            else:
                highest_high = max(highs[i-period+1:i+1])
                lowest_low = min(lows[i-period+1:i+1])
                
                if highest_high == lowest_low:
                    stoch.append(50)
                else:
                    k_percent = ((closes[i] - lowest_low) / (highest_high - lowest_low)) * 100
                    stoch.append(k_percent)
        return stoch
    
    def _bollinger_bands(self, data: List[float], period: int) -> Tuple[List[float], List[float]]:
        """Calculate Bollinger Bands"""
        sma = self._simple_moving_average(data, period)
        upper_band = []
        lower_band = []
        
        for i in range(len(data)):
            if i < period - 1:
                upper_band.append(None)
                lower_band.append(None)
            else:
                subset = data[i-period+1:i+1]
                std_dev = statistics.stdev(subset)
                upper_band.append(sma[i] + (2 * std_dev))
                lower_band.append(sma[i] - (2 * std_dev))
        
        return upper_band, lower_band
    
    def _average_true_range(self, highs: List[float], lows: List[float], 
                           closes: List[float], period: int) -> List[float]:
        """Calculate Average True Range"""
        true_ranges = []
        
        for i in range(1, len(closes)):
            tr1 = highs[i] - lows[i]
            tr2 = abs(highs[i] - closes[i-1])
            tr3 = abs(lows[i] - closes[i-1])
            true_ranges.append(max(tr1, tr2, tr3))
        
        atr = [None]
        for i in range(len(true_ranges)):
            if i < period - 1:
                atr.append(None)
            else:
                avg_tr = sum(true_ranges[i-period+1:i+1]) / period
                atr.append(avg_tr)
        
        return atr
    
    def _volume_ratio(self, volumes: List[float]) -> List[float]:
        """Calculate volume ratio"""
        volume_sma = self._simple_moving_average(volumes, 20)
        ratios = []
        
        for i in range(len(volumes)):
            if volume_sma[i] is not None and volume_sma[i] > 0:
                ratios.append(volumes[i] / volume_sma[i])
            else:
                ratios.append(None)
        return ratios
    
    def _price_momentum(self, data: List[float], period: int) -> List[float]:
        """Calculate price momentum"""
        momentum = []
        
        for i in range(len(data)):
            if i < period:
                momentum.append(None)
            else:
                mom = (data[i] - data[i-period]) / data[i-period] * 100
                momentum.append(mom)
        return momentum
    
    def _rolling_volatility(self, data: List[float], period: int) -> List[float]:
        """Calculate rolling volatility"""
        volatility = []
        
        for i in range(len(data)):
            if i < period - 1:
                volatility.append(None)
            else:
                subset = data[i-period+1:i+1]
                returns = [(subset[j] - subset[j-1]) / subset[j-1] for j in range(1, len(subset))]
                vol = statistics.stdev(returns) * math.sqrt(252) if len(returns) > 1 else 0
                volatility.append(vol)
        return volatility

class AnomalyDetector:
    """Detect market regime changes and anomalies"""
    
    def __init__(self):
        self.baseline_metrics = {}
        self.anomaly_threshold = 2.5
    
    def detect_anomalies(self, features: Dict[str, List[float]]) -> Dict[str, bool]:
        """Detect anomalies in market data"""
        anomalies = {}
        
        for feature_name, values in features.items():
            if feature_name not in self.baseline_metrics:
                self._establish_baseline(feature_name, values)
            
            recent_values = [v for v in values[-20:] if v is not None]
            if len(recent_values) < 5:
                anomalies[feature_name] = False
                continue
            
            current_mean = statistics.mean(recent_values)
            baseline_mean = self.baseline_metrics[feature_name]['mean']
            baseline_std = self.baseline_metrics[feature_name]['std']
            
            z_score = abs(current_mean - baseline_mean) / baseline_std if baseline_std > 0 else 0
            anomalies[feature_name] = z_score > self.anomaly_threshold
        
        return anomalies
    
    def _establish_baseline(self, feature_name: str, values: List[float]):
        """Establish baseline metrics for anomaly detection"""
        clean_values = [v for v in values if v is not None]
        if len(clean_values) > 10:
            self.baseline_metrics[feature_name] = {
                'mean': statistics.mean(clean_values),
                'std': statistics.stdev(clean_values) if len(clean_values) > 1 else 1.0
            }

class EnsembleModel:
    """Ensemble model combining multiple prediction algorithms"""
    
    def __init__(self):
        self.models = {}
        self.weights = {}
        self.performance_history = {}
    
    def add_model(self, name: str, weight: float = 1.0):
        """Add a model to the ensemble"""
        self.models[name] = {
            'weight': weight,
            'predictions': [],
            'accuracy': 0.0
        }
        self.weights[name] = weight
    
    def predict_ensemble(self, features: Dict[str, List[float]], asset: str, 
                        timeframe: str) -> PredictionResult:
        """Generate ensemble prediction"""
        individual_predictions = {}
        
        # Generate predictions from each model
        for model_name in self.models.keys():
            pred = self._generate_model_prediction(model_name, features, asset, timeframe)
            individual_predictions[model_name] = pred
        
        # Combine predictions using weighted average
        weighted_confidence = 0
        weighted_direction_score = 0
        total_weight = 0
        
        for model_name, prediction in individual_predictions.items():
            weight = self.weights[model_name]
            weighted_confidence += prediction['confidence'] * weight
            direction_score = 1 if prediction['direction'] == 'BULLISH' else -1
            weighted_direction_score += direction_score * weight
            total_weight += weight
        
        final_confidence = weighted_confidence / total_weight if total_weight > 0 else 0
        final_direction = 'BULLISH' if weighted_direction_score > 0 else 'BEARISH'
        
        # Calculate target and stop loss
        current_price = features['close'][-1] if 'close' in features else 100
        price_change = 0.03 if final_direction == 'BULLISH' else -0.03
        target_price = current_price * (1 + price_change)
        stop_loss = current_price * (1 - abs(price_change) * 0.5)
        
        return PredictionResult(
            asset=asset,
            timeframe=timeframe,
            direction=final_direction,
            confidence=final_confidence,
            target_price=target_price,
            stop_loss=stop_loss,
            timestamp=datetime.now(),
            model_version="ensemble_v1.0",
            features_used=list(features.keys()),
            risk_score=self._calculate_risk_score(final_confidence, features)
        )
    
    def _generate_model_prediction(self, model_name: str, features: Dict[str, List[float]], 
                                  asset: str, timeframe: str) -> Dict:
        """Generate prediction from individual model"""
        # Simplified model prediction logic
        # In production, this would call actual ML models
        
        if model_name == "lstm":
            return self._lstm_prediction(features)
        elif model_name == "gru":
            return self._gru_prediction(features)
        elif model_name == "transformer":
            return self._transformer_prediction(features)
        else:
            return self._default_prediction(features)
    
    def _lstm_prediction(self, features: Dict[str, List[float]]) -> Dict:
        """LSTM model prediction"""
        # Simulate LSTM prediction based on momentum and trend
        momentum = features.get('price_momentum', [0])[-1] or 0
        rsi = features.get('rsi', [50])[-1] or 50
        
        confidence = min(abs(momentum) * 10 + abs(rsi - 50), 95)
        direction = 'BULLISH' if momentum > 0 and rsi < 70 else 'BEARISH'
        
        return {'confidence': confidence, 'direction': direction}
    
    def _gru_prediction(self, features: Dict[str, List[float]]) -> Dict:
        """GRU model prediction"""
        # Simulate GRU prediction based on moving averages
        sma_20 = features.get('sma_20', [100])[-1] or 100
        sma_50 = features.get('sma_50', [100])[-1] or 100
        
        trend_strength = abs(sma_20 - sma_50) / sma_50 * 100
        confidence = min(trend_strength * 20, 90)
        direction = 'BULLISH' if sma_20 > sma_50 else 'BEARISH'
        
        return {'confidence': confidence, 'direction': direction}
    
    def _transformer_prediction(self, features: Dict[str, List[float]]) -> Dict:
        """Transformer model prediction"""
        # Simulate transformer prediction based on volatility and volume
        volatility = features.get('volatility', [0.1])[-1] or 0.1
        volume_ratio = features.get('volume_ratio', [1])[-1] or 1
        
        confidence = min((volume_ratio - 1) * 50 + (1 - volatility) * 30, 85)
        direction = 'BULLISH' if volume_ratio > 1.2 and volatility < 0.3 else 'BEARISH'
        
        return {'confidence': max(confidence, 20), 'direction': direction}
    
    def _default_prediction(self, features: Dict[str, List[float]]) -> Dict:
        """Default prediction method"""
        return {'confidence': 50, 'direction': 'BULLISH'}
    
    def _calculate_risk_score(self, confidence: float, features: Dict[str, List[float]]) -> float:
        """Calculate risk score for the prediction"""
        volatility = features.get('volatility', [0.2])[-1] or 0.2
        volume_ratio = features.get('volume_ratio', [1])[-1] or 1
        
        # Higher volatility and unusual volume increase risk
        risk_score = (volatility * 100 + abs(volume_ratio - 1) * 50) * (1 - confidence / 100)
        return min(max(risk_score, 0), 100)

class MLPredictionService:
    """Main ML Prediction Service"""
    
    def __init__(self):
        self.feature_engineer = FeatureEngineer()
        self.anomaly_detector = AnomalyDetector()
        self.ensemble_model = EnsembleModel()
        self.model_performance = {}
        self.prediction_cache = {}
        self.lock = threading.Lock()
        
        # Initialize ensemble models
        self.ensemble_model.add_model("lstm", weight=0.4)
        self.ensemble_model.add_model("gru", weight=0.3)
        self.ensemble_model.add_model("transformer", weight=0.3)
        
        logger.info("ML Prediction Service initialized")
    
    def generate_prediction(self, asset: str, timeframe: str, 
                          ohlcv_data: List[Dict]) -> PredictionResult:
        """Generate ML prediction for given asset and timeframe"""
        try:
            cache_key = f"{asset}_{timeframe}_{len(ohlcv_data)}"
            
            with self.lock:
                # Check cache first
                if cache_key in self.prediction_cache:
                    cached_result = self.prediction_cache[cache_key]
                    if (datetime.now() - cached_result.timestamp).seconds < 300:  # 5 min cache
                        return cached_result
            
            # Extract features
            features = self.feature_engineer.extract_technical_features(ohlcv_data)
            
            # Add price data to features
            features['close'] = [float(d['close']) for d in ohlcv_data]
            features['volume'] = [float(d['volume']) for d in ohlcv_data]
            
            # Detect anomalies
            anomalies = self.anomaly_detector.detect_anomalies(features)
            
            # Generate ensemble prediction
            prediction = self.ensemble_model.predict_ensemble(features, asset, timeframe)
            
            # Adjust confidence based on anomalies
            anomaly_count = sum(anomalies.values())
            if anomaly_count > 3:
                prediction.confidence *= 0.8  # Reduce confidence if many anomalies
            
            # Cache result
            with self.lock:
                self.prediction_cache[cache_key] = prediction
            
            logger.info(f"Generated prediction for {asset} {timeframe}: {prediction.direction} "
                       f"({prediction.confidence:.1f}% confidence)")
            
            return prediction
            
        except Exception as e:
            logger.error(f"Error generating prediction for {asset}: {str(e)}")
            # Return default prediction on error
            return PredictionResult(
                asset=asset,
                timeframe=timeframe,
                direction="NEUTRAL",
                confidence=50.0,
                target_price=100.0,
                stop_loss=95.0,
                timestamp=datetime.now(),
                model_version="error_fallback",
                features_used=[],
                risk_score=50.0
            )
    
    def get_multi_timeframe_predictions(self, asset: str, 
                                      ohlcv_data: Dict[str, List[Dict]]) -> Dict[str, PredictionResult]:
        """Generate predictions for multiple timeframes"""
        predictions = {}
        
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {}
            
            for timeframe, data in ohlcv_data.items():
                if len(data) >= 50:  # Minimum data requirement
                    future = executor.submit(self.generate_prediction, asset, timeframe, data)
                    futures[timeframe] = future
            
            for timeframe, future in futures.items():
                try:
                    predictions[timeframe] = future.result(timeout=30)
                except Exception as e:
                    logger.error(f"Error in {timeframe} prediction: {str(e)}")
        
        return predictions
    
    def update_model_performance(self, asset: str, timeframe: str, 
                               actual_outcome: bool, prediction_id: str):
        """Update model performance metrics"""
        key = f"{asset}_{timeframe}"
        
        if key not in self.model_performance:
            self.model_performance[key] = ModelPerformance(
                accuracy=0.0, precision=0.0, recall=0.0, f1_score=0.0,
                sharpe_ratio=0.0, max_drawdown=0.0, total_trades=0,
                winning_trades=0, avg_return=0.0
            )
        
        perf = self.model_performance[key]
        perf.total_trades += 1
        
        if actual_outcome:
            perf.winning_trades += 1
        
        perf.accuracy = perf.winning_trades / perf.total_trades
        
        logger.info(f"Updated performance for {key}: {perf.accuracy:.2%} accuracy "
                   f"({perf.winning_trades}/{perf.total_trades})")
    
    def get_model_performance(self, asset: str = None, timeframe: str = None) -> Dict:
        """Get model performance metrics"""
        if asset and timeframe:
            key = f"{asset}_{timeframe}"
            return self.model_performance.get(key, None)
        
        return dict(self.model_performance)
    
    def retrain_models(self, asset: str, historical_data: List[Dict]):
        """Retrain models with new data"""
        logger.info(f"Starting model retraining for {asset}")
        
        try:
            # Extract features for training
            features = self.feature_engineer.extract_technical_features(historical_data)
            
            # Update anomaly detection baselines
            for feature_name, values in features.items():
                self.anomaly_detector._establish_baseline(feature_name, values)
            
            # Update ensemble weights based on recent performance
            self._update_ensemble_weights(asset)
            
            logger.info(f"Model retraining completed for {asset}")
            
        except Exception as e:
            logger.error(f"Error during model retraining: {str(e)}")
    
    def _update_ensemble_weights(self, asset: str):
        """Update ensemble model weights based on performance"""
        # Simplified weight update logic
        # In production, this would use more sophisticated methods
        
        total_performance = 0
        model_performances = {}
        
        for timeframe in ['1h', '4h', '1d']:
            key = f"{asset}_{timeframe}"
            if key in self.model_performance:
                perf = self.model_performance[key]
                model_performances[timeframe] = perf.accuracy
                total_performance += perf.accuracy
        
        if total_performance > 0:
            # Adjust weights based on relative performance
            for model_name in self.ensemble_model.weights.keys():
                avg_performance = total_performance / len(model_performances) if model_performances else 0.5
                self.ensemble_model.weights[model_name] = max(avg_performance, 0.1)
    
    def get_feature_importance(self, asset: str, timeframe: str) -> Dict[str, float]:
        """Get feature importance scores"""
        # Simplified feature importance calculation
        # In production, this would use actual model feature importance
        
        base_importance = {
            'price_momentum': 0.25,
            'rsi': 0.20,
            'macd': 0.15,
            'volume_ratio': 0.12,
            'volatility': 0.10,
            'sma_20': 0.08,
            'bollinger_upper': 0.05,
            'stoch': 0.05
        }
        
        return base_importance
    
    def health_check(self) -> Dict[str, Any]:
        """Service health check"""
        return {
            'status': 'healthy',
            'models_loaded': len(self.ensemble_model.models),
            'cache_size': len(self.prediction_cache),
            'performance_tracked': len(self.model_performance),
            'timestamp': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize service
    ml_service = MLPredictionService()
    
    # Sample OHLCV data
    sample_data = []
    base_price = 50000
    
    for i in range(100):
        price_change = (hash(str(i)) % 200 - 100) / 10000  # Pseudo-random price changes
        base_price *= (1 + price_change)
        
        sample_data.append({
            'timestamp': datetime.now() - timedelta(hours=100-i),
            'open': base_price * 0.999,
            'high': base_price * 1.002,
            'low': base_price * 0.998,
            'close': base_price,
            'volume': 1000000 + (hash(str(i)) % 500000)
        })
    
    # Generate prediction
    prediction = ml_service.generate_prediction("BTC", "4h", sample_data)
    
    print(f"Prediction for BTC 4h:")
    print(f"Direction: {prediction.direction}")
    print(f"Confidence: {prediction.confidence:.1f}%")
    print(f"Target: ${prediction.target_price:.2f}")
    print(f"Stop Loss: ${prediction.stop_loss:.2f}")
    print(f"Risk Score: {prediction.risk_score:.1f}")
    
    # Test multi-timeframe predictions
    multi_data = {
        "1h": sample_data[-50:],
        "4h": sample_data[-100:],
        "1d": sample_data
    }
    
    multi_predictions = ml_service.get_multi_timeframe_predictions("BTC", multi_data)
    
    print("\nMulti-timeframe predictions:")
    for tf, pred in multi_predictions.items():
        print(f"{tf}: {pred.direction} ({pred.confidence:.1f}%)")
    
    # Health check
    health = ml_service.health_check()
    print(f"\nService Health: {health}")
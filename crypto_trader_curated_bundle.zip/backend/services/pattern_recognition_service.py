"""
Advanced Pattern Recognition Service
Detects harmonic patterns, Elliott waves, candlestick patterns, and chart formations
"""

import json
import logging
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import statistics

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PatternType(Enum):
    """Types of patterns that can be detected"""
    HARMONIC = "harmonic"
    ELLIOTT_WAVE = "elliott_wave"
    CANDLESTICK = "candlestick"
    CHART_PATTERN = "chart_pattern"
    SUPPORT_RESISTANCE = "support_resistance"

class HarmonicPattern(Enum):
    """Harmonic pattern types"""
    GARTLEY = "gartley"
    BUTTERFLY = "butterfly"
    BAT = "bat"
    CRAB = "crab"
    CYPHER = "cypher"

class ElliottWave(Enum):
    """Elliott wave types"""
    IMPULSE_1 = "wave_1"
    IMPULSE_2 = "wave_2"
    IMPULSE_3 = "wave_3"
    IMPULSE_4 = "wave_4"
    IMPULSE_5 = "wave_5"
    CORRECTIVE_A = "wave_a"
    CORRECTIVE_B = "wave_b"
    CORRECTIVE_C = "wave_c"

class CandlestickPattern(Enum):
    """Candlestick pattern types"""
    DOJI = "doji"
    HAMMER = "hammer"
    SHOOTING_STAR = "shooting_star"
    ENGULFING_BULLISH = "engulfing_bullish"
    ENGULFING_BEARISH = "engulfing_bearish"
    MORNING_STAR = "morning_star"
    EVENING_STAR = "evening_star"
    HARAMI = "harami"
    PIERCING_LINE = "piercing_line"
    DARK_CLOUD = "dark_cloud"

@dataclass
class PatternResult:
    """Structure for pattern detection results"""
    pattern_type: str
    pattern_name: str
    confidence: float
    direction: str  # BULLISH, BEARISH, NEUTRAL
    timeframe: str
    start_time: datetime
    end_time: datetime
    key_levels: List[float]
    target_levels: List[float]
    stop_loss: float
    risk_reward_ratio: float
    completion_percentage: float

@dataclass
class SupportResistanceLevel:
    """Support/Resistance level structure"""
    level: float
    strength: float
    touches: int
    level_type: str  # SUPPORT, RESISTANCE
    first_touch: datetime
    last_touch: datetime
    confidence: float

class FractalAnalysis:
    """Fractal analysis for support/resistance detection"""
    
    def __init__(self, lookback_period: int = 5):
        self.lookback_period = lookback_period
    
    def find_fractals(self, highs: List[float], lows: List[float]) -> Tuple[List[int], List[int]]:
        """Find fractal highs and lows"""
        fractal_highs = []
        fractal_lows = []
        
        for i in range(self.lookback_period, len(highs) - self.lookback_period):
            # Check for fractal high
            is_fractal_high = True
            for j in range(i - self.lookback_period, i + self.lookback_period + 1):
                if j != i and highs[j] >= highs[i]:
                    is_fractal_high = False
                    break
            
            if is_fractal_high:
                fractal_highs.append(i)
            
            # Check for fractal low
            is_fractal_low = True
            for j in range(i - self.lookback_period, i + self.lookback_period + 1):
                if j != i and lows[j] <= lows[i]:
                    is_fractal_low = False
                    break
            
            if is_fractal_low:
                fractal_lows.append(i)
        
        return fractal_highs, fractal_lows
    
    def detect_support_resistance(self, ohlcv_data: List[Dict]) -> List[SupportResistanceLevel]:
        """Detect support and resistance levels using fractal analysis"""
        if len(ohlcv_data) < 50:
            return []
        
        highs = [float(d['high']) for d in ohlcv_data]
        lows = [float(d['low']) for d in ohlcv_data]
        timestamps = [d.get('timestamp', datetime.now()) for d in ohlcv_data]
        
        fractal_highs, fractal_lows = self.find_fractals(highs, lows)
        
        levels = []
        
        # Process fractal highs (resistance levels)
        resistance_clusters = self._cluster_levels([highs[i] for i in fractal_highs])
        for cluster in resistance_clusters:
            level_data = self._analyze_level_strength(cluster['level'], highs, lows, timestamps, 'RESISTANCE')
            if level_data['strength'] > 0.3:
                levels.append(SupportResistanceLevel(
                    level=cluster['level'],
                    strength=level_data['strength'],
                    touches=level_data['touches'],
                    level_type='RESISTANCE',
                    first_touch=level_data['first_touch'],
                    last_touch=level_data['last_touch'],
                    confidence=min(level_data['strength'] * 100, 95)
                ))
        
        # Process fractal lows (support levels)
        support_clusters = self._cluster_levels([lows[i] for i in fractal_lows])
        for cluster in support_clusters:
            level_data = self._analyze_level_strength(cluster['level'], highs, lows, timestamps, 'SUPPORT')
            if level_data['strength'] > 0.3:
                levels.append(SupportResistanceLevel(
                    level=cluster['level'],
                    strength=level_data['strength'],
                    touches=level_data['touches'],
                    level_type='SUPPORT',
                    first_touch=level_data['first_touch'],
                    last_touch=level_data['last_touch'],
                    confidence=min(level_data['strength'] * 100, 95)
                ))
        
        return sorted(levels, key=lambda x: x.strength, reverse=True)
    
    def _cluster_levels(self, levels: List[float], tolerance: float = 0.01) -> List[Dict]:
        """Cluster nearby levels together"""
        if not levels:
            return []
        
        sorted_levels = sorted(levels)
        clusters = []
        current_cluster = [sorted_levels[0]]
        
        for level in sorted_levels[1:]:
            if abs(level - current_cluster[-1]) / current_cluster[-1] <= tolerance:
                current_cluster.append(level)
            else:
                clusters.append({
                    'level': statistics.mean(current_cluster),
                    'count': len(current_cluster)
                })
                current_cluster = [level]
        
        # Add the last cluster
        clusters.append({
            'level': statistics.mean(current_cluster),
            'count': len(current_cluster)
        })
        
        return clusters
    
    def _analyze_level_strength(self, level: float, highs: List[float], lows: List[float], 
                               timestamps: List[datetime], level_type: str) -> Dict:
        """Analyze the strength of a support/resistance level"""
        touches = 0
        first_touch = None
        last_touch = None
        tolerance = level * 0.005  # 0.5% tolerance
        
        for i, (high, low, timestamp) in enumerate(zip(highs, lows, timestamps)):
            if level_type == 'RESISTANCE':
                if abs(high - level) <= tolerance:
                    touches += 1
                    if first_touch is None:
                        first_touch = timestamp
                    last_touch = timestamp
            else:  # SUPPORT
                if abs(low - level) <= tolerance:
                    touches += 1
                    if first_touch is None:
                        first_touch = timestamp
                    last_touch = timestamp
        
        # Calculate strength based on touches and time span
        time_span_days = (last_touch - first_touch).days if first_touch and last_touch else 1
        strength = min(touches * 0.2 + min(time_span_days / 30, 1) * 0.3, 1.0)
        
        return {
            'strength': strength,
            'touches': touches,
            'first_touch': first_touch or datetime.now(),
            'last_touch': last_touch or datetime.now()
        }

class HarmonicPatternDetector:
    """Detect harmonic patterns like Gartley, Butterfly, Bat, etc."""
    
    def __init__(self):
        # Fibonacci ratios for harmonic patterns
        self.gartley_ratios = {
            'XA_AB': (0.618, 0.618),
            'AB_BC': (0.382, 0.886),
            'BC_CD': (1.13, 1.618)
        }
        
        self.butterfly_ratios = {
            'XA_AB': (0.786, 0.786),
            'AB_BC': (0.382, 0.886),
            'BC_CD': (1.618, 2.618)
        }
        
        self.bat_ratios = {
            'XA_AB': (0.382, 0.5),
            'AB_BC': (0.382, 0.886),
            'BC_CD': (1.618, 2.618)
        }
    
    def detect_harmonic_patterns(self, ohlcv_data: List[Dict]) -> List[PatternResult]:
        """Detect harmonic patterns in price data"""
        if len(ohlcv_data) < 20:
            return []
        
        patterns = []
        highs = [float(d['high']) for d in ohlcv_data]
        lows = [float(d['low']) for d in ohlcv_data]
        timestamps = [d.get('timestamp', datetime.now()) for d in ohlcv_data]
        
        # Find potential XABCD points
        fractal_analyzer = FractalAnalysis(lookback_period=3)
        fractal_highs, fractal_lows = fractal_analyzer.find_fractals(highs, lows)
        
        # Combine and sort all fractal points
        all_fractals = []
        for i in fractal_highs:
            all_fractals.append({'index': i, 'price': highs[i], 'type': 'high'})
        for i in fractal_lows:
            all_fractals.append({'index': i, 'price': lows[i], 'type': 'low'})
        
        all_fractals.sort(key=lambda x: x['index'])
        
        # Look for XABCD patterns
        for i in range(len(all_fractals) - 4):
            xabcd_points = all_fractals[i:i+5]
            
            # Check if pattern alternates between highs and lows
            if self._is_valid_xabcd_sequence(xabcd_points):
                pattern = self._analyze_harmonic_pattern(xabcd_points, timestamps)
                if pattern:
                    patterns.append(pattern)
        
        return patterns
    
    def _is_valid_xabcd_sequence(self, points: List[Dict]) -> bool:
        """Check if XABCD points form a valid alternating sequence"""
        if len(points) != 5:
            return False
        
        # Pattern should alternate between highs and lows
        for i in range(len(points) - 1):
            if points[i]['type'] == points[i+1]['type']:
                return False
        
        return True
    
    def _analyze_harmonic_pattern(self, xabcd_points: List[Dict], timestamps: List[datetime]) -> Optional[PatternResult]:
        """Analyze XABCD points to identify specific harmonic pattern"""
        X, A, B, C, D = [p['price'] for p in xabcd_points]
        indices = [p['index'] for p in xabcd_points]
        
        # Calculate ratios
        XA = abs(A - X)
        AB = abs(B - A)
        BC = abs(C - B)
        CD = abs(D - C)
        
        if XA == 0 or AB == 0 or BC == 0:
            return None
        
        xa_ab_ratio = AB / XA
        ab_bc_ratio = BC / AB
        bc_cd_ratio = CD / BC if BC != 0 else 0
        
        # Check against known harmonic patterns
        pattern_name = None
        confidence = 0
        
        # Check Gartley pattern
        if self._ratio_matches(xa_ab_ratio, 0.618, 0.05) and \
           self._ratio_matches(ab_bc_ratio, 0.382, 0.886, 0.1) and \
           self._ratio_matches(bc_cd_ratio, 1.13, 1.618, 0.1):
            pattern_name = "Gartley"
            confidence = 0.85
        
        # Check Butterfly pattern
        elif self._ratio_matches(xa_ab_ratio, 0.786, 0.05) and \
             self._ratio_matches(ab_bc_ratio, 0.382, 0.886, 0.1) and \
             self._ratio_matches(bc_cd_ratio, 1.618, 2.618, 0.2):
            pattern_name = "Butterfly"
            confidence = 0.80
        
        # Check Bat pattern
        elif self._ratio_matches(xa_ab_ratio, 0.382, 0.5, 0.05) and \
             self._ratio_matches(ab_bc_ratio, 0.382, 0.886, 0.1) and \
             self._ratio_matches(bc_cd_ratio, 1.618, 2.618, 0.2):
            pattern_name = "Bat"
            confidence = 0.82
        
        if pattern_name:
            # Determine direction
            direction = "BULLISH" if D < C else "BEARISH"
            
            # Calculate targets and stop loss
            target_levels = self._calculate_harmonic_targets(X, A, B, C, D, direction)
            stop_loss = D * 1.02 if direction == "BULLISH" else D * 0.98
            
            return PatternResult(
                pattern_type="harmonic",
                pattern_name=pattern_name,
                confidence=confidence * 100,
                direction=direction,
                timeframe="detected",
                start_time=timestamps[indices[0]] if indices[0] < len(timestamps) else datetime.now(),
                end_time=timestamps[indices[-1]] if indices[-1] < len(timestamps) else datetime.now(),
                key_levels=[X, A, B, C, D],
                target_levels=target_levels,
                stop_loss=stop_loss,
                risk_reward_ratio=self._calculate_risk_reward(D, target_levels[0], stop_loss),
                completion_percentage=100.0
            )
        
        return None
    
    def _ratio_matches(self, ratio: float, target1: float, target2: float = None, tolerance: float = 0.05) -> bool:
        """Check if ratio matches target within tolerance"""
        if target2 is None:
            return abs(ratio - target1) / target1 <= tolerance
        else:
            return (abs(ratio - target1) / target1 <= tolerance) or \
                   (abs(ratio - target2) / target2 <= tolerance)
    
    def _calculate_harmonic_targets(self, X: float, A: float, B: float, C: float, D: float, direction: str) -> List[float]:
        """Calculate target levels for harmonic patterns"""
        targets = []
        
        if direction == "BULLISH":
            # Target 1: 38.2% retracement of CD
            targets.append(D + (C - D) * 0.382)
            # Target 2: 61.8% retracement of CD
            targets.append(D + (C - D) * 0.618)
        else:
            # Target 1: 38.2% retracement of CD
            targets.append(D - (D - C) * 0.382)
            # Target 2: 61.8% retracement of CD
            targets.append(D - (D - C) * 0.618)
        
        return targets
    
    def _calculate_risk_reward(self, entry: float, target: float, stop_loss: float) -> float:
        """Calculate risk-reward ratio"""
        risk = abs(entry - stop_loss)
        reward = abs(target - entry)
        return reward / risk if risk > 0 else 0

class ElliottWaveDetector:
    """Detect Elliott Wave patterns"""
    
    def __init__(self):
        self.wave_rules = {
            'wave_2_retracement': (0.382, 0.618),
            'wave_3_extension': (1.618, 2.618),
            'wave_4_retracement': (0.236, 0.5),
            'wave_5_extension': (0.618, 1.0)
        }
    
    def detect_elliott_waves(self, ohlcv_data: List[Dict]) -> List[PatternResult]:
        """Detect Elliott Wave patterns"""
        if len(ohlcv_data) < 30:
            return []
        
        patterns = []
        highs = [float(d['high']) for d in ohlcv_data]
        lows = [float(d['low']) for d in ohlcv_data]
        timestamps = [d.get('timestamp', datetime.now()) for d in ohlcv_data]
        
        # Find significant turning points
        fractal_analyzer = FractalAnalysis(lookback_period=5)
        fractal_highs, fractal_lows = fractal_analyzer.find_fractals(highs, lows)
        
        # Analyze for impulse waves (5-wave structure)
        impulse_patterns = self._find_impulse_waves(highs, lows, fractal_highs, fractal_lows, timestamps)
        patterns.extend(impulse_patterns)
        
        # Analyze for corrective waves (3-wave structure)
        corrective_patterns = self._find_corrective_waves(highs, lows, fractal_highs, fractal_lows, timestamps)
        patterns.extend(corrective_patterns)
        
        return patterns
    
    def _find_impulse_waves(self, highs: List[float], lows: List[float], 
                           fractal_highs: List[int], fractal_lows: List[int], 
                           timestamps: List[datetime]) -> List[PatternResult]:
        """Find 5-wave impulse patterns"""
        patterns = []
        
        # Combine and sort fractal points
        all_fractals = []
        for i in fractal_highs:
            all_fractals.append({'index': i, 'price': highs[i], 'type': 'high'})
        for i in fractal_lows:
            all_fractals.append({'index': i, 'price': lows[i], 'type': 'low'})
        
        all_fractals.sort(key=lambda x: x['index'])
        
        # Look for 5-wave patterns
        for i in range(len(all_fractals) - 5):
            wave_points = all_fractals[i:i+6]  # 6 points for 5 waves
            
            if self._is_valid_impulse_sequence(wave_points):
                pattern = self._analyze_impulse_waves(wave_points, timestamps)
                if pattern:
                    patterns.append(pattern)
        
        return patterns
    
    def _is_valid_impulse_sequence(self, points: List[Dict]) -> bool:
        """Check if points form a valid 5-wave impulse sequence"""
        if len(points) != 6:
            return False
        
        # Check alternating pattern
        for i in range(len(points) - 1):
            if points[i]['type'] == points[i+1]['type']:
                return False
        
        # Check wave relationships
        prices = [p['price'] for p in points]
        
        # For bullish impulse: 1 > 0, 2 < 1, 3 > 1, 4 < 3, 5 > 3
        if points[0]['type'] == 'low':  # Bullish impulse
            return (prices[1] > prices[0] and  # Wave 1 up
                   prices[2] < prices[1] and  # Wave 2 down
                   prices[3] > prices[1] and  # Wave 3 up (higher than wave 1)
                   prices[4] < prices[3] and  # Wave 4 down
                   prices[5] > prices[3])     # Wave 5 up
        else:  # Bearish impulse
            return (prices[1] < prices[0] and  # Wave 1 down
                   prices[2] > prices[1] and  # Wave 2 up
                   prices[3] < prices[1] and  # Wave 3 down (lower than wave 1)
                   prices[4] > prices[3] and  # Wave 4 up
                   prices[5] < prices[3])     # Wave 5 down
    
    def _analyze_impulse_waves(self, wave_points: List[Dict], timestamps: List[datetime]) -> Optional[PatternResult]:
        """Analyze 5-wave impulse pattern"""
        prices = [p['price'] for p in wave_points]
        indices = [p['index'] for p in wave_points]
        
        # Calculate wave lengths
        wave1 = abs(prices[1] - prices[0])
        wave2 = abs(prices[2] - prices[1])
        wave3 = abs(prices[3] - prices[2])
        wave4 = abs(prices[4] - prices[3])
        wave5 = abs(prices[5] - prices[4])
        
        # Check Elliott Wave rules
        confidence = 0.5
        
        # Rule 1: Wave 2 never retraces more than 100% of wave 1
        if wave2 < wave1:
            confidence += 0.1
        
        # Rule 2: Wave 3 is never the shortest wave
        if wave3 >= max(wave1, wave5):
            confidence += 0.15
        
        # Rule 3: Wave 4 never enters the price territory of wave 1
        if wave_points[0]['type'] == 'low':  # Bullish
            if prices[4] > prices[1]:
                confidence += 0.1
        else:  # Bearish
            if prices[4] < prices[1]:
                confidence += 0.1
        
        # Check Fibonacci relationships
        if 1.5 <= wave3/wave1 <= 2.7:  # Wave 3 extension
            confidence += 0.1
        
        if 0.3 <= wave2/wave1 <= 0.7:  # Wave 2 retracement
            confidence += 0.05
        
        if confidence > 0.7:
            direction = "BULLISH" if wave_points[0]['type'] == 'low' else "BEARISH"
            
            # Calculate targets
            if direction == "BULLISH":
                target_levels = [prices[5] * 1.05, prices[5] * 1.1]
                stop_loss = prices[4] * 0.98
            else:
                target_levels = [prices[5] * 0.95, prices[5] * 0.9]
                stop_loss = prices[4] * 1.02
            
            return PatternResult(
                pattern_type="elliott_wave",
                pattern_name="5-Wave Impulse",
                confidence=confidence * 100,
                direction=direction,
                timeframe="detected",
                start_time=timestamps[indices[0]] if indices[0] < len(timestamps) else datetime.now(),
                end_time=timestamps[indices[-1]] if indices[-1] < len(timestamps) else datetime.now(),
                key_levels=prices,
                target_levels=target_levels,
                stop_loss=stop_loss,
                risk_reward_ratio=self._calculate_risk_reward(prices[5], target_levels[0], stop_loss),
                completion_percentage=100.0
            )
        
        return None
    
    def _find_corrective_waves(self, highs: List[float], lows: List[float], 
                              fractal_highs: List[int], fractal_lows: List[int], 
                              timestamps: List[datetime]) -> List[PatternResult]:
        """Find 3-wave corrective patterns (ABC)"""
        patterns = []
        
        # Similar logic to impulse waves but for 3-wave patterns
        all_fractals = []
        for i in fractal_highs:
            all_fractals.append({'index': i, 'price': highs[i], 'type': 'high'})
        for i in fractal_lows:
            all_fractals.append({'index': i, 'price': lows[i], 'type': 'low'})
        
        all_fractals.sort(key=lambda x: x['index'])
        
        # Look for ABC patterns
        for i in range(len(all_fractals) - 3):
            wave_points = all_fractals[i:i+4]  # 4 points for 3 waves
            
            if self._is_valid_corrective_sequence(wave_points):
                pattern = self._analyze_corrective_waves(wave_points, timestamps)
                if pattern:
                    patterns.append(pattern)
        
        return patterns
    
    def _is_valid_corrective_sequence(self, points: List[Dict]) -> bool:
        """Check if points form a valid ABC corrective sequence"""
        if len(points) != 4:
            return False
        
        # Check alternating pattern
        for i in range(len(points) - 1):
            if points[i]['type'] == points[i+1]['type']:
                return False
        
        return True
    
    def _analyze_corrective_waves(self, wave_points: List[Dict], timestamps: List[datetime]) -> Optional[PatternResult]:
        """Analyze ABC corrective pattern"""
        prices = [p['price'] for p in wave_points]
        indices = [p['index'] for p in wave_points]
        
        # Calculate wave lengths
        wave_a = abs(prices[1] - prices[0])
        wave_b = abs(prices[2] - prices[1])
        wave_c = abs(prices[3] - prices[2])
        
        confidence = 0.6
        
        # Check common ABC relationships
        if 0.8 <= wave_c/wave_a <= 1.2:  # Wave C equals wave A
            confidence += 0.15
        elif 1.5 <= wave_c/wave_a <= 1.7:  # Wave C = 1.618 * wave A
            confidence += 0.1
        
        if 0.3 <= wave_b/wave_a <= 0.7:  # Wave B retracement
            confidence += 0.1
        
        if confidence > 0.7:
            direction = "BEARISH" if wave_points[0]['type'] == 'high' else "BULLISH"
            
            # Calculate targets (end of correction)
            if direction == "BULLISH":
                target_levels = [prices[3] * 1.03, prices[3] * 1.06]
                stop_loss = prices[3] * 0.97
            else:
                target_levels = [prices[3] * 0.97, prices[3] * 0.94]
                stop_loss = prices[3] * 1.03
            
            return PatternResult(
                pattern_type="elliott_wave",
                pattern_name="ABC Correction",
                confidence=confidence * 100,
                direction=direction,
                timeframe="detected",
                start_time=timestamps[indices[0]] if indices[0] < len(timestamps) else datetime.now(),
                end_time=timestamps[indices[-1]] if indices[-1] < len(timestamps) else datetime.now(),
                key_levels=prices,
                target_levels=target_levels,
                stop_loss=stop_loss,
                risk_reward_ratio=self._calculate_risk_reward(prices[3], target_levels[0], stop_loss),
                completion_percentage=100.0
            )
        
        return None
    
    def _calculate_risk_reward(self, entry: float, target: float, stop_loss: float) -> float:
        """Calculate risk-reward ratio"""
        risk = abs(entry - stop_loss)
        reward = abs(target - entry)
        return reward / risk if risk > 0 else 0

class CandlestickPatternDetector:
    """Detect candlestick patterns"""
    
    def __init__(self):
        self.min_body_ratio = 0.1  # Minimum body size relative to range
        self.doji_threshold = 0.05  # Maximum body size for doji
    
    def detect_candlestick_patterns(self, ohlcv_data: List[Dict]) -> List[PatternResult]:
        """Detect various candlestick patterns"""
        if len(ohlcv_data) < 3:
            return []
        
        patterns = []
        
        for i in range(2, len(ohlcv_data)):
            # Single candle patterns
            single_patterns = self._detect_single_candle_patterns(ohlcv_data[i])
            patterns.extend(single_patterns)
            
            # Two candle patterns
            if i >= 1:
                two_patterns = self._detect_two_candle_patterns(ohlcv_data[i-1:i+1])
                patterns.extend(two_patterns)
            
            # Three candle patterns
            if i >= 2:
                three_patterns = self._detect_three_candle_patterns(ohlcv_data[i-2:i+1])
                patterns.extend(three_patterns)
        
        return patterns
    
    def _detect_single_candle_patterns(self, candle: Dict) -> List[PatternResult]:
        """Detect single candlestick patterns"""
        patterns = []
        
        open_price = float(candle['open'])
        high_price = float(candle['high'])
        low_price = float(candle['low'])
        close_price = float(candle['close'])
        timestamp = candle.get('timestamp', datetime.now())
        
        body_size = abs(close_price - open_price)
        range_size = high_price - low_price
        upper_shadow = high_price - max(open_price, close_price)
        lower_shadow = min(open_price, close_price) - low_price
        
        if range_size == 0:
            return patterns
        
        # Doji pattern
        if body_size / range_size <= self.doji_threshold:
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Doji",
                confidence=80.0,
                direction="NEUTRAL",
                timeframe="1candle",
                start_time=timestamp,
                end_time=timestamp,
                key_levels=[open_price, high_price, low_price, close_price],
                target_levels=[],
                stop_loss=0,
                risk_reward_ratio=0,
                completion_percentage=100.0
            ))
        
        # Hammer pattern
        elif (lower_shadow >= 2 * body_size and 
              upper_shadow <= 0.1 * range_size and 
              body_size / range_size >= self.min_body_ratio):
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Hammer",
                confidence=75.0,
                direction="BULLISH",
                timeframe="1candle",
                start_time=timestamp,
                end_time=timestamp,
                key_levels=[open_price, high_price, low_price, close_price],
                target_levels=[close_price * 1.02],
                stop_loss=low_price * 0.99,
                risk_reward_ratio=2.0,
                completion_percentage=100.0
            ))
        
        # Shooting Star pattern
        elif (upper_shadow >= 2 * body_size and 
              lower_shadow <= 0.1 * range_size and 
              body_size / range_size >= self.min_body_ratio):
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Shooting Star",
                confidence=75.0,
                direction="BEARISH",
                timeframe="1candle",
                start_time=timestamp,
                end_time=timestamp,
                key_levels=[open_price, high_price, low_price, close_price],
                target_levels=[close_price * 0.98],
                stop_loss=high_price * 1.01,
                risk_reward_ratio=2.0,
                completion_percentage=100.0
            ))
        
        return patterns
    
    def _detect_two_candle_patterns(self, candles: List[Dict]) -> List[PatternResult]:
        """Detect two-candlestick patterns"""
        patterns = []
        
        if len(candles) != 2:
            return patterns
        
        candle1, candle2 = candles
        
        # Extract OHLC data
        o1, h1, l1, c1 = [float(candle1[k]) for k in ['open', 'high', 'low', 'close']]
        o2, h2, l2, c2 = [float(candle2[k]) for k in ['open', 'high', 'low', 'close']]
        
        timestamp = candle2.get('timestamp', datetime.now())
        
        # Bullish Engulfing
        if (c1 < o1 and  # First candle is bearish
            c2 > o2 and  # Second candle is bullish
            o2 < c1 and  # Second open below first close
            c2 > o1):    # Second close above first open
            
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Bullish Engulfing",
                confidence=85.0,
                direction="BULLISH",
                timeframe="2candle",
                start_time=candle1.get('timestamp', datetime.now()),
                end_time=timestamp,
                key_levels=[o1, h1, l1, c1, o2, h2, l2, c2],
                target_levels=[c2 * 1.03],
                stop_loss=min(l1, l2) * 0.99,
                risk_reward_ratio=2.5,
                completion_percentage=100.0
            ))
        
        # Bearish Engulfing
        elif (c1 > o1 and  # First candle is bullish
              c2 < o2 and  # Second candle is bearish
              o2 > c1 and  # Second open above first close
              c2 < o1):    # Second close below first open
            
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Bearish Engulfing",
                confidence=85.0,
                direction="BEARISH",
                timeframe="2candle",
                start_time=candle1.get('timestamp', datetime.now()),
                end_time=timestamp,
                key_levels=[o1, h1, l1, c1, o2, h2, l2, c2],
                target_levels=[c2 * 0.97],
                stop_loss=max(h1, h2) * 1.01,
                risk_reward_ratio=2.5,
                completion_percentage=100.0
            ))
        
        return patterns
    
    def _detect_three_candle_patterns(self, candles: List[Dict]) -> List[PatternResult]:
        """Detect three-candlestick patterns"""
        patterns = []
        
        if len(candles) != 3:
            return patterns
        
        candle1, candle2, candle3 = candles
        
        # Extract OHLC data
        o1, h1, l1, c1 = [float(candle1[k]) for k in ['open', 'high', 'low', 'close']]
        o2, h2, l2, c2 = [float(candle2[k]) for k in ['open', 'high', 'low', 'close']]
        o3, h3, l3, c3 = [float(candle3[k]) for k in ['open', 'high', 'low', 'close']]
        
        timestamp = candle3.get('timestamp', datetime.now())
        
        # Morning Star pattern
        if (c1 < o1 and  # First candle bearish
            abs(c2 - o2) < abs(c1 - o1) * 0.3 and  # Second candle small body
            c3 > o3 and  # Third candle bullish
            c3 > (o1 + c1) / 2):  # Third close above midpoint of first
            
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Morning Star",
                confidence=90.0,
                direction="BULLISH",
                timeframe="3candle",
                start_time=candle1.get('timestamp', datetime.now()),
                end_time=timestamp,
                key_levels=[o1, h1, l1, c1, o2, h2, l2, c2, o3, h3, l3, c3],
                target_levels=[c3 * 1.05],
                stop_loss=min(l1, l2, l3) * 0.98,
                risk_reward_ratio=3.0,
                completion_percentage=100.0
            ))
        
        # Evening Star pattern
        elif (c1 > o1 and  # First candle bullish
              abs(c2 - o2) < abs(c1 - o1) * 0.3 and  # Second candle small body
              c3 < o3 and  # Third candle bearish
              c3 < (o1 + c1) / 2):  # Third close below midpoint of first
            
            patterns.append(PatternResult(
                pattern_type="candlestick",
                pattern_name="Evening Star",
                confidence=90.0,
                direction="BEARISH",
                timeframe="3candle",
                start_time=candle1.get('timestamp', datetime.now()),
                end_time=timestamp,
                key_levels=[o1, h1, l1, c1, o2, h2, l2, c2, o3, h3, l3, c3],
                target_levels=[c3 * 0.95],
                stop_loss=max(h1, h2, h3) * 1.02,
                risk_reward_ratio=3.0,
                completion_percentage=100.0
            ))
        
        return patterns

class PatternRecognitionService:
    """Main Pattern Recognition Service"""
    
    def __init__(self):
        self.fractal_analyzer = FractalAnalysis()
        self.harmonic_detector = HarmonicPatternDetector()
        self.elliott_detector = ElliottWaveDetector()
        self.candlestick_detector = CandlestickPatternDetector()
        self.pattern_cache = {}
        
        logger.info("Pattern Recognition Service initialized")
    
    def analyze_patterns(self, asset: str, timeframe: str, ohlcv_data: List[Dict]) -> Dict[str, List[PatternResult]]:
        """Analyze all pattern types for given asset and timeframe"""
        try:
            cache_key = f"{asset}_{timeframe}_{len(ohlcv_data)}"
            
            # Check cache
            if cache_key in self.pattern_cache:
                cached_result = self.pattern_cache[cache_key]
                if (datetime.now() - cached_result['timestamp']).seconds < 600:  # 10 min cache
                    return cached_result['patterns']
            
            patterns = {
                'harmonic': [],
                'elliott_wave': [],
                'candlestick': [],
                'support_resistance': []
            }
            
            if len(ohlcv_data) < 10:
                return patterns
            
            # Detect harmonic patterns
            try:
                patterns['harmonic'] = self.harmonic_detector.detect_harmonic_patterns(ohlcv_data)
            except Exception as e:
                logger.error(f"Error detecting harmonic patterns: {str(e)}")
            
            # Detect Elliott Wave patterns
            try:
                patterns['elliott_wave'] = self.elliott_detector.detect_elliott_waves(ohlcv_data)
            except Exception as e:
                logger.error(f"Error detecting Elliott waves: {str(e)}")
            
            # Detect candlestick patterns
            try:
                patterns['candlestick'] = self.candlestick_detector.detect_candlestick_patterns(ohlcv_data[-10:])
            except Exception as e:
                logger.error(f"Error detecting candlestick patterns: {str(e)}")
            
            # Detect support/resistance levels
            try:
                sr_levels = self.fractal_analyzer.detect_support_resistance(ohlcv_data)
                patterns['support_resistance'] = self._convert_sr_to_patterns(sr_levels)
            except Exception as e:
                logger.error(f"Error detecting support/resistance: {str(e)}")
            
            # Cache results
            self.pattern_cache[cache_key] = {
                'patterns': patterns,
                'timestamp': datetime.now()
            }
            
            logger.info(f"Pattern analysis completed for {asset} {timeframe}: "
                       f"H:{len(patterns['harmonic'])}, EW:{len(patterns['elliott_wave'])}, "
                       f"CS:{len(patterns['candlestick'])}, SR:{len(patterns['support_resistance'])}")
            
            return patterns
            
        except Exception as e:
            logger.error(f"Error in pattern analysis for {asset}: {str(e)}")
            return {'harmonic': [], 'elliott_wave': [], 'candlestick': [], 'support_resistance': []}
    
    def _convert_sr_to_patterns(self, sr_levels: List[SupportResistanceLevel]) -> List[PatternResult]:
        """Convert support/resistance levels to pattern results"""
        patterns = []
        
        for level in sr_levels[:10]:  # Limit to top 10 levels
            direction = "BULLISH" if level.level_type == "SUPPORT" else "BEARISH"
            
            patterns.append(PatternResult(
                pattern_type="support_resistance",
                pattern_name=f"{level.level_type.title()} Level",
                confidence=level.confidence,
                direction=direction,
                timeframe="multiple",
                start_time=level.first_touch,
                end_time=level.last_touch,
                key_levels=[level.level],
                target_levels=[],
                stop_loss=0,
                risk_reward_ratio=0,
                completion_percentage=100.0
            ))
        
        return patterns
    
    def get_pattern_summary(self, patterns: Dict[str, List[PatternResult]]) -> Dict[str, Any]:
        """Get summary statistics of detected patterns"""
        summary = {
            'total_patterns': 0,
            'by_type': {},
            'by_direction': {'BULLISH': 0, 'BEARISH': 0, 'NEUTRAL': 0},
            'avg_confidence': 0,
            'high_confidence_patterns': 0
        }
        
        all_patterns = []
        for pattern_type, pattern_list in patterns.items():
            summary['by_type'][pattern_type] = len(pattern_list)
            all_patterns.extend(pattern_list)
        
        summary['total_patterns'] = len(all_patterns)
        
        if all_patterns:
            # Direction summary
            for pattern in all_patterns:
                summary['by_direction'][pattern.direction] += 1
            
            # Confidence statistics
            confidences = [p.confidence for p in all_patterns]
            summary['avg_confidence'] = statistics.mean(confidences)
            summary['high_confidence_patterns'] = len([c for c in confidences if c >= 80])
        
        return summary
    
    def filter_patterns_by_confidence(self, patterns: Dict[str, List[PatternResult]], 
                                    min_confidence: float = 70.0) -> Dict[str, List[PatternResult]]:
        """Filter patterns by minimum confidence threshold"""
        filtered = {}
        
        for pattern_type, pattern_list in patterns.items():
            filtered[pattern_type] = [p for p in pattern_list if p.confidence >= min_confidence]
        
        return filtered
    
    def get_conflicting_signals(self, patterns: Dict[str, List[PatternResult]]) -> Dict[str, int]:
        """Identify conflicting signals between patterns"""
        bullish_count = 0
        bearish_count = 0
        
        for pattern_list in patterns.values():
            for pattern in pattern_list:
                if pattern.confidence >= 70:  # Only consider high-confidence patterns
                    if pattern.direction == "BULLISH":
                        bullish_count += 1
                    elif pattern.direction == "BEARISH":
                        bearish_count += 1
        
        return {
            'bullish_signals': bullish_count,
            'bearish_signals': bearish_count,
            'conflict_ratio': min(bullish_count, bearish_count) / max(bullish_count, bearish_count, 1)
        }
    
    def health_check(self) -> Dict[str, Any]:
        """Service health check"""
        return {
            'status': 'healthy',
            'detectors_loaded': 4,
            'cache_size': len(self.pattern_cache),
            'timestamp': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize service
    pattern_service = PatternRecognitionService()
    
    # Sample OHLCV data
    sample_data = []
    base_price = 50000
    
    for i in range(100):
        # Create more realistic price movements
        trend = math.sin(i * 0.1) * 0.02
        noise = (hash(str(i)) % 200 - 100) / 10000
        price_change = trend + noise
        
        base_price *= (1 + price_change)
        
        sample_data.append({
            'timestamp': datetime.now() - timedelta(hours=100-i),
            'open': base_price * 0.999,
            'high': base_price * (1.001 + abs(noise)),
            'low': base_price * (0.999 - abs(noise)),
            'close': base_price,
            'volume': 1000000 + (hash(str(i)) % 500000)
        })
    
    # Analyze patterns
    patterns = pattern_service.analyze_patterns("BTC", "4h", sample_data)
    
    print("Pattern Analysis Results:")
    print("=" * 50)
    
    for pattern_type, pattern_list in patterns.items():
        print(f"\n{pattern_type.upper()} PATTERNS ({len(pattern_list)}):")
        for pattern in pattern_list[:3]:  # Show top 3 patterns
            print(f"  - {pattern.pattern_name}: {pattern.direction} "
                  f"({pattern.confidence:.1f}% confidence)")
    
    # Get summary
    summary = pattern_service.get_pattern_summary(patterns)
    print(f"\nSUMMARY:")
    print(f"Total patterns: {summary['total_patterns']}")
    print(f"Average confidence: {summary['avg_confidence']:.1f}%")
    print(f"High confidence patterns: {summary['high_confidence_patterns']}")
    print(f"Direction bias: {summary['by_direction']}")
    
    # Check for conflicts
    conflicts = pattern_service.get_conflicting_signals(patterns)
    print(f"\nSIGNAL ANALYSIS:")
    print(f"Bullish signals: {conflicts['bullish_signals']}")
    print(f"Bearish signals: {conflicts['bearish_signals']}")
    print(f"Conflict ratio: {conflicts['conflict_ratio']:.2f}")
    
    # Health check
    health = pattern_service.health_check()
    print(f"\nService Health: {health}")
"""
Market Data Service
Enhanced service for fetching and streaming market data from multiple exchanges
with caching, rate limiting, and WebSocket support
"""

import logging
import random
import asyncio
import aiohttp
import json
from typing import List, Dict, Any, Optional, Set
from datetime import datetime, timedelta
from functools import lru_cache
from dataclasses import dataclass
from collections import defaultdict
import time
from aiohttp import ClientSession
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

@dataclass
class ExchangeConfig:
    """Configuration for exchange connections"""
    name: str
    api_url: str
    ws_url: str
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    rate_limit_per_second: int = 10

class MarketDataService:
    """Enhanced service for fetching market data with real-time streaming"""

    def __init__(self, exchange_configs: List[ExchangeConfig] = None):
        self.exchanges = exchange_configs or [
            ExchangeConfig(
                name="mock",
                api_url="https://api.mockexchange.com",
                ws_url="wss://ws.mockexchange.com",
                rate_limit_per_second=10
            )
        ]
        self._cache: Dict[str, Dict[str, Any]] = {}
        self.subscriptions: Set[str] = set()
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.rate_limiter = asyncio.Semaphore(10)
        self.ws_connections: Dict[str, Any] = defaultdict(set)
        self.last_api_call: Dict[str, float] = {}
        self.session: Optional[ClientSession] = None

    async def __aenter__(self):
        """Initialize WebSocket connections"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Clean up WebSocket connections and session"""
        if self.ws_connections:
            for ws_set in self.ws_connections.values():
                for ws in ws_set:
                    if hasattr(ws, 'close'):
                        await ws.close()
        if self.session:
            await self.session.close()

    async def get_tickers(self, symbols: List[str], exchange: str = "mock") -> List[Dict[str, Any]]:
        """Get ticker data for multiple symbols from specified exchange"""
        tickers = []
        for symbol in symbols:
            try:
                ticker = await self.get_ticker(symbol, exchange)
                if ticker:
                    tickers.append(ticker)
            except Exception as e:
                logger.error(f"Error fetching ticker for {symbol}: {e}")
        return tickers

    async def get_ticker(self, symbol: str, exchange: str = "mock") -> Optional[Dict[str, Any]]:
        """Get ticker data for a single symbol from specified exchange"""
        try:
            if exchange == "mock":
                return self.generate_mock_ticker(symbol)
            # Add real exchange logic here
            return None
        except Exception as e:
            logger.error(f"Error fetching ticker for {symbol}: {e}")
            return None

    async def get_candles(
        self,
        symbol: str,
        exchange: str = "mock",
        interval: str = "1h",
        limit: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Get candlestick data for a symbol from specified exchange"""
        try:
            if exchange == "mock":
                return self.generate_mock_candles(symbol, interval, limit)
            # Add real exchange logic here
            return []
        except Exception as e:
            logger.error(f"Error fetching candles for {symbol}: {e}")
            return []

    async def get_orderbook(self, symbol: str, exchange: str = "mock", limit: int = 20) -> Dict[str, Any]:
        """Get orderbook data for a symbol from specified exchange"""
        try:
            if exchange == "mock":
                return self.generate_mock_orderbook(symbol, limit)
            # Add real exchange logic here
            return {"bids": [], "asks": []}
        except Exception as e:
            logger.error(f"Error fetching orderbook for {symbol}: {e}")
            return {"bids": [], "asks": []}

    async def get_recent_trades(self, symbol: str, exchange: str = "mock", limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent trades for a symbol from specified exchange"""
        try:
            if exchange == "mock":
                return self.generate_mock_trades(symbol, limit)
            # Add real exchange logic here
            return []
        except Exception as e:
            logger.error(f"Error fetching trades for {symbol}: {e}")
            return []

    def generate_mock_ticker(self, symbol: str) -> Dict[str, Any]:
        """Generate mock ticker data"""
        base_price = self.get_base_price_for_symbol(symbol)
        price_change = random.uniform(-2, 2) / 100
        price = base_price * (1 + price_change)
        volume = base_price * random.uniform(10, 1000)
        return {
            "symbol": symbol,
            "price": round(price, 2),
            "priceChange": round(price_change * 100, 2),
            "priceChangePercent": round(price_change, 2),
            "volume": round(volume, 2),
            "high24h": round(price * (1 + random.uniform(0.005, 0.02)), 2),
            "low24h": round(price * (1 - random.uniform(0.005, 0.02)), 2),
            "timestamp": int(datetime.now().timestamp() * 1000)
        }

    def generate_mock_candles(self, symbol: str, interval: str, limit: int) -> List[Dict[str, Any]]:
        """Generate mock candlestick data"""
        base_price = self.get_base_price_for_symbol(symbol)
        candles = []
        for i in range(limit):
            price_change = random.uniform(-1.5, 1.5) / 100
            open_price = base_price * (1 + random.uniform(-0.5, 0.5) / 100)
            close_price = base_price * (1 + price_change)
            high_price = max(open_price, close_price) * (1 + random.uniform(0.1, 0.5) / 100)
            low_price = min(open_price, close_price) * (1 - random.uniform(0.1, 0.5) / 100)
            volume = base_price * random.uniform(10, 1000)
            candle = {
                "timestamp": int(datetime.now().timestamp() * 1000) - (i * self.interval_to_seconds(interval) * 1000),
                "open": round(open_price, 2),
                "high": round(high_price, 2),
                "low": round(low_price, 2),
                "close": round(close_price, 2),
                "volume": round(volume, 2)
            }
            candles.append(candle)
        return candles

    def generate_mock_orderbook(self, symbol: str, limit: int) -> Dict[str, Any]:
        """Generate mock orderbook data"""
        base_price = self.get_base_price_for_symbol(symbol)
        bids = []
        asks = []
        for i in range(limit):
            bid_price = base_price * (1 - (i + 1) * 0.001)
            ask_price = base_price * (1 + (i + 1) * 0.001)
            quantity = random.uniform(0.1, 10) * (limit - i) / limit
            bids.append([round(bid_price, 2), round(quantity, 4)])
            asks.append([round(ask_price, 2), round(quantity, 4)])
        
        return {
            "symbol": symbol,
            "bids": bids,
            "asks": asks,
            "timestamp": int(datetime.now().timestamp() * 1000)
        }

    def generate_mock_trades(self, symbol: str, limit: int) -> List[Dict[str, Any]]:
        """Generate mock trade data"""
        base_price = self.get_base_price_for_symbol(symbol)
        trades = []
        for i in range(limit):
            price = base_price * (1 + random.uniform(-0.5, 0.5) / 100)
            quantity = random.uniform(0.01, 5)
            trade_time = datetime.now() - timedelta(seconds=i * 10)
            trade = {
                "id": f"{symbol}_{int(trade_time.timestamp())}_{i}",
                "price": round(price, 2),
                "quantity": round(quantity, 4),
                "time": int(trade_time.timestamp() * 1000),
                "isBuyerMaker": random.choice([True, False]),
                "isBestMatch": random.choice([True, False])
            }
            trades.append(trade)
        return trades

    def get_base_price_for_symbol(self, symbol: str) -> float:
        """Get base price for a symbol"""
        symbol_prices = {
            "BTCUSDT": 50000,
            "ETHUSDT": 3000,
            "BNBUSDT": 400,
            "SOLUSDT": 100,
            "ADAUSDT": 0.5,
            "XRPUSDT": 0.6,
            "DOGEUSDT": 0.1,
            "DOTUSDT": 15,
            "UNIUSDT": 10,
            "LINKUSDT": 20
        }
        return symbol_prices.get(symbol, 100)

    def interval_to_seconds(self, interval: str) -> int:
        """Convert interval string to seconds"""
        unit = interval[-1]
        value = int(interval[:-1])
        if unit == 's':
            return value
        elif unit == 'm':
            return value * 60
        elif unit == 'h':
            return value * 3600
        elif unit == 'd':
            return value * 24 * 3600
        elif unit == 'w':
            return value * 7 * 24 * 3600
        return 3600  # default to 1 hour
"""
Hybrid Signal Integration Service
Combines ML predictions, patterns, sentiment, and whale analysis into unified signals
"""

import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import statistics
import threading
from concurrent.futures import ThreadPoolExecutor
import math

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SignalStrength(Enum):
    """Signal strength classifications"""
    VERY_WEAK = "very_weak"
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"
    VERY_STRONG = "very_strong"

class SignalDirection(Enum):
    """Signal direction classifications"""
    STRONG_BEARISH = "strong_bearish"
    BEARISH = "bearish"
    NEUTRAL = "neutral"
    BULLISH = "bullish"
    STRONG_BULLISH = "strong_bullish"

class MarketRegime(Enum):
    """Market regime classifications"""
    BULL_MARKET = "bull_market"
    BEAR_MARKET = "bear_market"
    SIDEWAYS = "sideways"
    HIGH_VOLATILITY = "high_volatility"
    LOW_VOLATILITY = "low_volatility"

@dataclass
class ComponentSignal:
    """Individual component signal structure"""
    component: str
    direction: str
    strength: float  # 0-100
    confidence: float  # 0-100
    weight: float  # Current weight in ensemble
    timestamp: datetime
    details: Dict[str, Any]

@dataclass
class HybridSignal:
    """Final hybrid signal structure"""
    asset: str
    timeframe: str
    direction: str
    strength: float
    confidence: float
    timestamp: datetime
    components: List[ComponentSignal]
    risk_score: float
    position_size: float
    target_levels: List[float]
    stop_loss: float
    risk_reward_ratio: float
    market_regime: str
    signal_quality: str

class SignalWeightManager:
    """Manages dynamic weights for signal components"""
    
    def __init__(self):
        # Base weights for different components
        self.base_weights = {
            'ml_prediction': 0.30,
            'pattern_recognition': 0.25,
            'sentiment_analysis': 0.20,
            'whale_analysis': 0.15,
            'technical_indicators': 0.10
        }
        
        # Performance tracking for adaptive weights
        self.performance_history = {}
        self.weight_adjustments = {}
        
        # Market regime adjustments
        self.regime_adjustments = {
            MarketRegime.BULL_MARKET: {
                'sentiment_analysis': 1.2,
                'whale_analysis': 1.1,
                'ml_prediction': 0.9
            },
            MarketRegime.BEAR_MARKET: {
                'whale_analysis': 1.3,
                'pattern_recognition': 1.1,
                'sentiment_analysis': 0.8
            },
            MarketRegime.HIGH_VOLATILITY: {
                'pattern_recognition': 1.2,
                'technical_indicators': 1.3,
                'ml_prediction': 0.8
            },
            MarketRegime.LOW_VOLATILITY: {
                'ml_prediction': 1.2,
                'sentiment_analysis': 1.1,
                'pattern_recognition': 0.9
            }
        }
    
    def get_adaptive_weights(self, asset: str, market_regime: MarketRegime, 
                           timeframe: str) -> Dict[str, float]:
        """Get adaptive weights based on performance and market conditions"""
        weights = self.base_weights.copy()
        
        # Apply performance-based adjustments
        performance_key = f"{asset}_{timeframe}"
        if performance_key in self.performance_history:
            perf_data = self.performance_history[performance_key]
            
            for component, base_weight in weights.items():
                if component in perf_data:
                    # Adjust weight based on recent performance
                    performance_score = perf_data[component].get('accuracy', 0.5)
                    adjustment = (performance_score - 0.5) * 0.4  # Max ±20% adjustment
                    weights[component] *= (1 + adjustment)
        
        # Apply market regime adjustments
        regime_adj = self.regime_adjustments.get(market_regime, {})
        for component, multiplier in regime_adj.items():
            if component in weights:
                weights[component] *= multiplier
        
        # Normalize weights to sum to 1.0
        total_weight = sum(weights.values())
        if total_weight > 0:
            weights = {k: v / total_weight for k, v in weights.items()}
        
        return weights
    
    def update_performance(self, asset: str, timeframe: str, component: str, 
                          prediction_correct: bool, confidence: float):
        """Update performance tracking for adaptive weights"""
        key = f"{asset}_{timeframe}"
        
        if key not in self.performance_history:
            self.performance_history[key] = {}
        
        if component not in self.performance_history[key]:
            self.performance_history[key][component] = {
                'correct_predictions': 0,
                'total_predictions': 0,
                'accuracy': 0.5,
                'confidence_sum': 0
            }
        
        comp_data = self.performance_history[key][component]
        comp_data['total_predictions'] += 1
        comp_data['confidence_sum'] += confidence
        
        if prediction_correct:
            comp_data['correct_predictions'] += 1
        
        # Calculate new accuracy
        comp_data['accuracy'] = comp_data['correct_predictions'] / comp_data['total_predictions']
        
        # Keep only recent history (last 100 predictions)
        if comp_data['total_predictions'] > 100:
            # Decay old performance data
            comp_data['correct_predictions'] = int(comp_data['correct_predictions'] * 0.9)
            comp_data['total_predictions'] = int(comp_data['total_predictions'] * 0.9)
            comp_data['confidence_sum'] *= 0.9

class CorrelationFilter:
    """Filters redundant signals based on correlation"""
    
    def __init__(self):
        self.correlation_threshold = 0.7
        self.signal_history = {}
    
    def filter_correlated_signals(self, signals: List[ComponentSignal]) -> List[ComponentSignal]:
        """Remove highly correlated signals to reduce redundancy"""
        if len(signals) <= 1:
            return signals
        
        filtered_signals = []
        
        for signal in signals:
            is_redundant = False
            
            for existing_signal in filtered_signals:
                correlation = self._calculate_signal_correlation(signal, existing_signal)
                
                if correlation > self.correlation_threshold:
                    # Keep the signal with higher confidence
                    if signal.confidence > existing_signal.confidence:
                        filtered_signals.remove(existing_signal)
                        filtered_signals.append(signal)
                    is_redundant = True
                    break
            
            if not is_redundant:
                filtered_signals.append(signal)
        
        return filtered_signals
    
    def _calculate_signal_correlation(self, signal1: ComponentSignal, 
                                    signal2: ComponentSignal) -> float:
        """Calculate correlation between two signals"""
        # Simple correlation based on direction and strength similarity
        direction_similarity = self._direction_similarity(signal1.direction, signal2.direction)
        strength_similarity = 1 - abs(signal1.strength - signal2.strength) / 100
        
        # Weight by confidence
        avg_confidence = (signal1.confidence + signal2.confidence) / 200
        
        correlation = (direction_similarity * 0.6 + strength_similarity * 0.4) * avg_confidence
        return correlation
    
    def _direction_similarity(self, dir1: str, dir2: str) -> float:
        """Calculate similarity between signal directions"""
        direction_map = {
            'strong_bearish': -2,
            'bearish': -1,
            'neutral': 0,
            'bullish': 1,
            'strong_bullish': 2
        }
        
        val1 = direction_map.get(dir1.lower(), 0)
        val2 = direction_map.get(dir2.lower(), 0)
        
        max_diff = 4  # Maximum difference between strong_bearish and strong_bullish
        similarity = 1 - abs(val1 - val2) / max_diff
        
        return max(0, similarity)

class ConflictResolver:
    """Resolves conflicts between contradictory signals"""
    
    def __init__(self):
        self.conflict_threshold = 0.3  # Threshold for considering signals conflicting
    
    def resolve_signal_conflicts(self, signals: List[ComponentSignal], 
                                weights: Dict[str, float]) -> Dict[str, Any]:
        """Resolve conflicts between signals and determine final direction"""
        if not signals:
            return {'direction': 'neutral', 'confidence': 0, 'conflict_score': 0}
        
        # Calculate weighted direction score
        weighted_score = 0
        total_weight = 0
        confidence_sum = 0
        
        direction_scores = []
        
        for signal in signals:
            weight = weights.get(signal.component, 0.1)
            direction_score = self._direction_to_score(signal.direction)
            
            weighted_score += direction_score * weight * (signal.confidence / 100)
            total_weight += weight * (signal.confidence / 100)
            confidence_sum += signal.confidence * weight
            
            direction_scores.append(direction_score)
        
        # Calculate final direction and confidence
        if total_weight > 0:
            final_score = weighted_score / total_weight
            final_confidence = confidence_sum / sum(weights.get(s.component, 0.1) for s in signals)
        else:
            final_score = 0
            final_confidence = 0
        
        final_direction = self._score_to_direction(final_score)
        
        # Calculate conflict score
        conflict_score = self._calculate_conflict_score(direction_scores, weights, signals)
        
        # Adjust confidence based on conflict
        adjusted_confidence = final_confidence * (1 - conflict_score * 0.5)
        
        return {
            'direction': final_direction,
            'confidence': adjusted_confidence,
            'conflict_score': conflict_score,
            'weighted_score': final_score
        }
    
    def _direction_to_score(self, direction: str) -> float:
        """Convert direction to numerical score"""
        direction_map = {
            'strong_bearish': -2.0,
            'bearish': -1.0,
            'neutral': 0.0,
            'bullish': 1.0,
            'strong_bullish': 2.0
        }
        return direction_map.get(direction.lower(), 0.0)
    
    def _score_to_direction(self, score: float) -> str:
        """Convert numerical score to direction"""
        if score >= 1.5:
            return 'strong_bullish'
        elif score >= 0.5:
            return 'bullish'
        elif score <= -1.5:
            return 'strong_bearish'
        elif score <= -0.5:
            return 'bearish'
        else:
            return 'neutral'
    
    def _calculate_conflict_score(self, direction_scores: List[float], 
                                weights: Dict[str, float], signals: List[ComponentSignal]) -> float:
        """Calculate conflict score between signals"""
        if len(direction_scores) <= 1:
            return 0
        
        # Calculate weighted variance of direction scores
        weighted_mean = sum(score * weights.get(signals[i].component, 0.1) 
                           for i, score in enumerate(direction_scores))
        total_weight = sum(weights.get(s.component, 0.1) for s in signals)
        
        if total_weight > 0:
            weighted_mean /= total_weight
        
        weighted_variance = sum(weights.get(signals[i].component, 0.1) * 
                               (score - weighted_mean) ** 2 
                               for i, score in enumerate(direction_scores))
        
        if total_weight > 0:
            weighted_variance /= total_weight
        
        # Normalize conflict score to 0-1 range
        max_variance = 4  # Maximum possible variance for direction scores
        conflict_score = min(weighted_variance / max_variance, 1.0)
        
        return conflict_score

class RiskManager:
    """Manages risk assessment and position sizing"""
    
    def __init__(self):
        self.base_risk_per_trade = 0.02  # 2% base risk per trade
        self.max_risk_per_trade = 0.05   # 5% maximum risk per trade
        self.volatility_adjustment = True
        
        # Risk factors
        self.risk_factors = {
            'high_volatility': 1.5,
            'low_liquidity': 1.3,
            'high_correlation': 1.2,
            'news_event': 1.4,
            'market_uncertainty': 1.3
        }
    
    def calculate_risk_metrics(self, signal: Dict[str, Any], market_data: Dict[str, Any], 
                             portfolio_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate comprehensive risk metrics"""
        base_risk = self.base_risk_per_trade
        
        # Adjust for signal confidence
        confidence_adjustment = signal['confidence'] / 100
        adjusted_risk = base_risk * confidence_adjustment
        
        # Adjust for market volatility
        volatility = market_data.get('volatility', 0.2)
        volatility_adjustment = 1 + (volatility - 0.2) * 2  # Increase risk for high volatility
        adjusted_risk *= volatility_adjustment
        
        # Adjust for conflict score
        conflict_score = signal.get('conflict_score', 0)
        conflict_adjustment = 1 + conflict_score * 0.5
        adjusted_risk *= conflict_adjustment
        
        # Portfolio correlation adjustment
        correlation_risk = self._calculate_correlation_risk(portfolio_data)
        adjusted_risk *= (1 + correlation_risk)
        
        # Cap at maximum risk
        final_risk = min(adjusted_risk, self.max_risk_per_trade)
        
        # Calculate position size
        account_size = portfolio_data.get('total_value', 100000)
        entry_price = market_data.get('current_price', 100)
        stop_loss_price = self._calculate_stop_loss(entry_price, signal['direction'], volatility)
        
        risk_per_share = abs(entry_price - stop_loss_price)
        risk_amount = account_size * final_risk
        
        position_size = risk_amount / risk_per_share if risk_per_share > 0 else 0
        
        # Calculate target levels
        target_levels = self._calculate_targets(entry_price, signal['direction'], 
                                              risk_per_share, signal['confidence'])
        
        return {
            'risk_score': final_risk * 100,
            'position_size_pct': (position_size * entry_price / account_size) * 100,
            'position_size_units': position_size,
            'stop_loss': stop_loss_price,
            'target_levels': target_levels,
            'risk_reward_ratio': self._calculate_risk_reward(entry_price, target_levels[0], stop_loss_price),
            'max_loss_usd': risk_amount,
            'adjustments': {
                'confidence': confidence_adjustment,
                'volatility': volatility_adjustment,
                'conflict': conflict_adjustment,
                'correlation': 1 + correlation_risk
            }
        }
    
    def _calculate_correlation_risk(self, portfolio_data: Dict[str, Any]) -> float:
        """Calculate portfolio correlation risk"""
        # Simplified correlation risk calculation
        positions = portfolio_data.get('positions', [])
        
        if len(positions) <= 1:
            return 0
        
        # Assume higher correlation for similar assets
        crypto_positions = len([p for p in positions if p.get('asset_type') == 'crypto'])
        total_positions = len(positions)
        
        if total_positions > 0:
            crypto_ratio = crypto_positions / total_positions
            # Higher correlation risk if portfolio is concentrated in crypto
            correlation_risk = max(0, (crypto_ratio - 0.5) * 0.4)
        else:
            correlation_risk = 0
        
        return correlation_risk
    
    def _calculate_stop_loss(self, entry_price: float, direction: str, volatility: float) -> float:
        """Calculate stop loss level"""
        # Base stop loss at 2% + volatility adjustment
        base_stop_pct = 0.02 + volatility * 0.1
        
        if direction in ['bullish', 'strong_bullish']:
            return entry_price * (1 - base_stop_pct)
        elif direction in ['bearish', 'strong_bearish']:
            return entry_price * (1 + base_stop_pct)
        else:
            return entry_price * (1 - base_stop_pct)  # Default to long stop
    
    def _calculate_targets(self, entry_price: float, direction: str, 
                          risk_per_share: float, confidence: float) -> List[float]:
        """Calculate target price levels"""
        targets = []
        
        # Base risk-reward ratio adjusted by confidence
        base_rr = 1.5 + (confidence / 100) * 1.5  # 1.5 to 3.0 R:R
        
        if direction in ['bullish', 'strong_bullish']:
            targets.append(entry_price + risk_per_share * base_rr)
            targets.append(entry_price + risk_per_share * base_rr * 1.5)
        elif direction in ['bearish', 'strong_bearish']:
            targets.append(entry_price - risk_per_share * base_rr)
            targets.append(entry_price - risk_per_share * base_rr * 1.5)
        else:
            # Neutral - small targets
            targets.append(entry_price + risk_per_share * 0.5)
            targets.append(entry_price - risk_per_share * 0.5)
        
        return targets
    
    def _calculate_risk_reward(self, entry: float, target: float, stop_loss: float) -> float:
        """Calculate risk-reward ratio"""
        risk = abs(entry - stop_loss)
        reward = abs(target - entry)
        
        return reward / risk if risk > 0 else 0

class MarketRegimeDetector:
    """Detects current market regime for adaptive signal processing"""
    
    def __init__(self):
        self.regime_cache = {}
        
    def detect_market_regime(self, market_data: Dict[str, Any], 
                           sentiment_data: Dict[str, Any]) -> MarketRegime:
        """Detect current market regime"""
        # Price trend analysis
        price_change_7d = market_data.get('price_change_7d', 0)
        price_change_30d = market_data.get('price_change_30d', 0)
        
        # Volatility analysis
        volatility = market_data.get('volatility', 0.2)
        
        # Volume analysis
        volume_change = market_data.get('volume_change_7d', 0)
        
        # Sentiment analysis
        overall_sentiment = sentiment_data.get('overall_sentiment', {}).get('score', 0)
        
        # Regime detection logic
        if volatility > 0.4:
            return MarketRegime.HIGH_VOLATILITY
        elif volatility < 0.15:
            return MarketRegime.LOW_VOLATILITY
        elif price_change_30d > 20 and overall_sentiment > 30:
            return MarketRegime.BULL_MARKET
        elif price_change_30d < -20 and overall_sentiment < -30:
            return MarketRegime.BEAR_MARKET
        else:
            return MarketRegime.SIDEWAYS

class HybridSignalService:
    """Main Hybrid Signal Integration Service"""
    
    def __init__(self):
        self.weight_manager = SignalWeightManager()
        self.correlation_filter = CorrelationFilter()
        self.conflict_resolver = ConflictResolver()
        self.risk_manager = RiskManager()
        self.regime_detector = MarketRegimeDetector()
        
        self.signal_cache = {}
        self.performance_tracker = {}
        self.lock = threading.Lock()
        
        logger.info("Hybrid Signal Integration Service initialized")
    
    def generate_hybrid_signal(self, asset: str, timeframe: str,
                             ml_prediction: Dict[str, Any] = None,
                             pattern_analysis: Dict[str, Any] = None,
                             sentiment_analysis: Dict[str, Any] = None,
                             whale_analysis: Dict[str, Any] = None,
                             market_data: Dict[str, Any] = None,
                             portfolio_data: Dict[str, Any] = None) -> HybridSignal:
        """Generate comprehensive hybrid signal"""
        try:
            cache_key = f"{asset}_{timeframe}_{int(time.time() / 300)}"  # 5-min cache
            
            with self.lock:
                if cache_key in self.signal_cache:
                    return self.signal_cache[cache_key]
            
            # Use mock data if not provided
            if not ml_prediction:
                ml_prediction = self._generate_mock_ml_prediction()
            if not pattern_analysis:
                pattern_analysis = self._generate_mock_pattern_analysis()
            if not sentiment_analysis:
                sentiment_analysis = self._generate_mock_sentiment_analysis()
            if not whale_analysis:
                whale_analysis = self._generate_mock_whale_analysis()
            if not market_data:
                market_data = self._generate_mock_market_data(asset)
            if not portfolio_data:
                portfolio_data = self._generate_mock_portfolio_data()
            
            # Detect market regime
            market_regime = self.regime_detector.detect_market_regime(market_data, sentiment_analysis)
            
            # Get adaptive weights
            weights = self.weight_manager.get_adaptive_weights(asset, market_regime, timeframe)
            
            # Extract component signals
            component_signals = self._extract_component_signals(
                ml_prediction, pattern_analysis, sentiment_analysis, whale_analysis, market_data)
            
            # Filter correlated signals
            filtered_signals = self.correlation_filter.filter_correlated_signals(component_signals)
            
            # Resolve conflicts and get final direction
            resolution = self.conflict_resolver.resolve_signal_conflicts(filtered_signals, weights)
            
            # Calculate risk metrics
            risk_metrics = self.risk_manager.calculate_risk_metrics(
                resolution, market_data, portfolio_data)
            
            # Determine signal quality
            signal_quality = self._assess_signal_quality(resolution, filtered_signals, risk_metrics)
            
            # Create hybrid signal
            hybrid_signal = HybridSignal(
                asset=asset,
                timeframe=timeframe,
                direction=resolution['direction'],
                strength=self._calculate_signal_strength(resolution, filtered_signals),
                confidence=resolution['confidence'],
                timestamp=datetime.now(),
                components=filtered_signals,
                risk_score=risk_metrics['risk_score'],
                position_size=risk_metrics['position_size_pct'],
                target_levels=risk_metrics['target_levels'],
                stop_loss=risk_metrics['stop_loss'],
                risk_reward_ratio=risk_metrics['risk_reward_ratio'],
                market_regime=market_regime.value,
                signal_quality=signal_quality
            )
            
            # Cache signal
            with self.lock:
                self.signal_cache[cache_key] = hybrid_signal
            
            logger.info(f"Generated hybrid signal for {asset} {timeframe}: "
                       f"{hybrid_signal.direction} ({hybrid_signal.confidence:.1f}% confidence)")
            
            return hybrid_signal
            
        except Exception as e:
            logger.error(f"Error generating hybrid signal for {asset}: {str(e)}")
            return self._generate_fallback_signal(asset, timeframe)
    
    def _extract_component_signals(self, ml_prediction: Dict, pattern_analysis: Dict,
                                 sentiment_analysis: Dict, whale_analysis: Dict,
                                 market_data: Dict) -> List[ComponentSignal]:
        """Extract signals from each component"""
        signals = []
        
        # ML Prediction Signal
        if ml_prediction:
            ml_signal = ComponentSignal(
                component='ml_prediction',
                direction=ml_prediction.get('direction', 'neutral').lower(),
                strength=ml_prediction.get('confidence', 50),
                confidence=ml_prediction.get('confidence', 50),
                weight=0.3,
                timestamp=datetime.now(),
                details={'model_version': ml_prediction.get('model_version', 'unknown')}
            )
            signals.append(ml_signal)
        
        # Pattern Recognition Signal
        if pattern_analysis:
            # Aggregate pattern signals
            pattern_direction, pattern_confidence = self._aggregate_pattern_signals(pattern_analysis)
            
            pattern_signal = ComponentSignal(
                component='pattern_recognition',
                direction=pattern_direction,
                strength=pattern_confidence,
                confidence=pattern_confidence,
                weight=0.25,
                timestamp=datetime.now(),
                details={'patterns_detected': len(pattern_analysis.get('harmonic', []) + 
                                                pattern_analysis.get('elliott_wave', []))}
            )
            signals.append(pattern_signal)
        
        # Sentiment Analysis Signal
        if sentiment_analysis:
            sentiment_score = sentiment_analysis.get('overall_sentiment', {}).get('score', 0)
            sentiment_confidence = sentiment_analysis.get('overall_sentiment', {}).get('confidence', 50)
            
            sentiment_signal = ComponentSignal(
                component='sentiment_analysis',
                direction=self._score_to_direction(sentiment_score / 50),  # Normalize to -2 to +2
                strength=abs(sentiment_score) * 2,  # Convert to 0-100 scale
                confidence=sentiment_confidence,
                weight=0.2,
                timestamp=datetime.now(),
                details={'fear_greed_index': sentiment_analysis.get('fear_greed_index', {}).get('score', 50)}
            )
            signals.append(sentiment_signal)
        
        # Whale Analysis Signal
        if whale_analysis:
            whale_sentiment = whale_analysis.get('summary', {}).get('whale_sentiment', 'neutral')
            whale_confidence = whale_analysis.get('behavior_analysis', {}).get('confidence', 50)
            
            whale_signal = ComponentSignal(
                component='whale_analysis',
                direction=whale_sentiment,
                strength=whale_confidence,
                confidence=whale_confidence,
                weight=0.15,
                timestamp=datetime.now(),
                details={'whale_transactions': whale_analysis.get('whale_transactions', {}).get('count', 0)}
            )
            signals.append(whale_signal)
        
        # Technical Indicators Signal (derived from market data)
        if market_data:
            tech_direction, tech_strength = self._analyze_technical_indicators(market_data)
            
            tech_signal = ComponentSignal(
                component='technical_indicators',
                direction=tech_direction,
                strength=tech_strength,
                confidence=tech_strength,
                weight=0.1,
                timestamp=datetime.now(),
                details={'volatility': market_data.get('volatility', 0.2)}
            )
            signals.append(tech_signal)
        
        return signals
    
    def _aggregate_pattern_signals(self, pattern_analysis: Dict) -> Tuple[str, float]:
        """Aggregate signals from pattern analysis"""
        all_patterns = []
        
        # Collect all patterns
        for pattern_type, patterns in pattern_analysis.items():
            if isinstance(patterns, list):
                all_patterns.extend(patterns)
        
        if not all_patterns:
            return 'neutral', 50
        
        # Weight patterns by confidence
        bullish_weight = 0
        bearish_weight = 0
        total_weight = 0
        
        for pattern in all_patterns:
            confidence = getattr(pattern, 'confidence', 50)
            direction = getattr(pattern, 'direction', 'neutral').lower()
            
            if 'bullish' in direction:
                bullish_weight += confidence
            elif 'bearish' in direction:
                bearish_weight += confidence
            
            total_weight += confidence
        
        if total_weight == 0:
            return 'neutral', 50
        
        # Determine overall direction
        net_bullish = (bullish_weight - bearish_weight) / total_weight
        
        if net_bullish > 0.3:
            direction = 'bullish'
        elif net_bullish < -0.3:
            direction = 'bearish'
        else:
            direction = 'neutral'
        
        # Calculate confidence
        confidence = min(abs(net_bullish) * 100 + 30, 95)
        
        return direction, confidence
    
    def _analyze_technical_indicators(self, market_data: Dict) -> Tuple[str, float]:
        """Analyze technical indicators from market data"""
        # Simple technical analysis based on available data
        price_change_7d = market_data.get('price_change_7d', 0)
        volume_change = market_data.get('volume_change_7d', 0)
        volatility = market_data.get('volatility', 0.2)
        
        # Momentum signal
        momentum_score = 0
        if price_change_7d > 5:
            momentum_score += 1
        elif price_change_7d < -5:
            momentum_score -= 1
        
        # Volume confirmation
        if volume_change > 0.2 and price_change_7d > 0:
            momentum_score += 0.5
        elif volume_change > 0.2 and price_change_7d < 0:
            momentum_score -= 0.5
        
        # Volatility consideration
        if volatility > 0.3:
            # High volatility reduces confidence
            strength = max(abs(momentum_score) * 30, 20)
        else:
            strength = abs(momentum_score) * 40 + 20
        
        # Determine direction
        if momentum_score > 0.5:
            direction = 'bullish'
        elif momentum_score < -0.5:
            direction = 'bearish'
        else:
            direction = 'neutral'
        
        return direction, min(strength, 90)
    
    def _calculate_signal_strength(self, resolution: Dict, signals: List[ComponentSignal]) -> float:
        """Calculate overall signal strength"""
        base_strength = abs(resolution['weighted_score']) * 50  # Convert to 0-100 scale
        
        # Adjust for confidence
        confidence_factor = resolution['confidence'] / 100
        
        # Adjust for number of confirming signals
        confirming_signals = len([s for s in signals if s.direction == resolution['direction']])
        signal_factor = min(confirming_signals / len(signals), 1.0) if signals else 0
        
        # Adjust for conflict
        conflict_penalty = resolution['conflict_score'] * 0.3
        
        final_strength = base_strength * confidence_factor * (1 + signal_factor * 0.2) * (1 - conflict_penalty)
        
        return min(max(final_strength, 0), 100)
    
    def _assess_signal_quality(self, resolution: Dict, signals: List[ComponentSignal], 
                             risk_metrics: Dict) -> str:
        """Assess overall signal quality"""
        quality_score = 0
        
        # Confidence factor
        quality_score += resolution['confidence'] * 0.4
        
        # Low conflict factor
        quality_score += (1 - resolution['conflict_score']) * 30
        
        # Number of signals factor
        quality_score += min(len(signals) * 5, 20)
        
        # Risk-reward factor
        rr_ratio = risk_metrics.get('risk_reward_ratio', 1)
        quality_score += min(rr_ratio * 5, 10)
        
        # Classify quality
        if quality_score >= 80:
            return 'excellent'
        elif quality_score >= 65:
            return 'good'
        elif quality_score >= 50:
            return 'fair'
        else:
            return 'poor'
    
    def _score_to_direction(self, score: float) -> str:
        """Convert numerical score to direction"""
        if score >= 1.5:
            return 'strong_bullish'
        elif score >= 0.5:
            return 'bullish'
        elif score <= -1.5:
            return 'strong_bearish'
        elif score <= -0.5:
            return 'bearish'
        else:
            return 'neutral'
    
    def _generate_mock_ml_prediction(self) -> Dict[str, Any]:
        """Generate mock ML prediction for testing"""
        directions = ['bullish', 'bearish', 'neutral']
        direction = directions[hash(str(int(time.time() / 3600))) % 3]
        confidence = 60 + (hash(str(int(time.time() / 1800))) % 30)
        
        return {
            'direction': direction,
            'confidence': confidence,
            'target_price': 45000 + (hash(str(int(time.time() / 7200))) % 5000),
            'model_version': 'ensemble_v1.0'
        }
    
    def _generate_mock_pattern_analysis(self) -> Dict[str, Any]:
        """Generate mock pattern analysis for testing"""
        return {
            'harmonic': [
                type('Pattern', (), {
                    'pattern_name': 'Gartley',
                    'confidence': 85,
                    'direction': 'bullish'
                })()
            ],
            'elliott_wave': [
                type('Pattern', (), {
                    'pattern_name': '5-Wave Impulse',
                    'confidence': 72,
                    'direction': 'bullish'
                })()
            ]
        }
    
    def _generate_mock_sentiment_analysis(self) -> Dict[str, Any]:
        """Generate mock sentiment analysis for testing"""
        score = (hash(str(int(time.time() / 3600))) % 80) - 40
        
        return {
            'overall_sentiment': {
                'score': score,
                'confidence': 75,
                'polarity': 'bullish' if score > 0 else 'bearish'
            },
            'fear_greed_index': {
                'score': 50 + score,
                'label': 'Greed' if score > 0 else 'Fear'
            }
        }
    
    def _generate_mock_whale_analysis(self) -> Dict[str, Any]:
        """Generate mock whale analysis for testing"""
        sentiments = ['bullish', 'bearish', 'neutral']
        sentiment = sentiments[hash(str(int(time.time() / 7200))) % 3]
        
        return {
            'summary': {
                'whale_sentiment': sentiment,
                'net_exchange_flow_btc': -150 + (hash(str(int(time.time() / 3600))) % 300)
            },
            'behavior_analysis': {
                'confidence': 70 + (hash(str(int(time.time() / 1800))) % 20)
            },
            'whale_transactions': {
                'count': 15 + (hash(str(int(time.time() / 3600))) % 10)
            }
        }
    
    def _generate_mock_market_data(self, asset: str) -> Dict[str, Any]:
        """Generate mock market data for testing"""
        base_price = {'BTC': 43000, 'ETH': 2600, 'SOL': 100}.get(asset, 100)
        
        return {
            'current_price': base_price + (hash(asset + str(int(time.time() / 1800))) % 2000 - 1000),
            'price_change_7d': (hash(asset + str(int(time.time() / 86400))) % 20) - 10,
            'price_change_30d': (hash(asset + str(int(time.time() / 2592000))) % 40) - 20,
            'volume_change_7d': (hash(asset + str(int(time.time() / 86400))) % 100 - 50) / 100,
            'volatility': 0.15 + (hash(asset + str(int(time.time() / 3600))) % 30) / 100
        }
    
    def _generate_mock_portfolio_data(self) -> Dict[str, Any]:
        """Generate mock portfolio data for testing"""
        return {
            'total_value': 100000,
            'positions': [
                {'asset': 'BTC', 'value': 50000, 'asset_type': 'crypto'},
                {'asset': 'ETH', 'value': 30000, 'asset_type': 'crypto'},
                {'asset': 'STOCKS', 'value': 20000, 'asset_type': 'equity'}
            ]
        }
    
    def _generate_fallback_signal(self, asset: str, timeframe: str) -> HybridSignal:
        """Generate fallback signal on error"""
        return HybridSignal(
            asset=asset,
            timeframe=timeframe,
            direction='neutral',
            strength=50.0,
            confidence=30.0,
            timestamp=datetime.now(),
            components=[],
            risk_score=50.0,
            position_size=1.0,
            target_levels=[100.0, 105.0],
            stop_loss=95.0,
            risk_reward_ratio=1.0,
            market_regime='sideways',
            signal_quality='poor'
        )
    
    def get_signal_summary(self, asset: str, timeframe: str) -> Dict[str, Any]:
        """Get signal summary for an asset and timeframe"""
        try:
            signal = self.generate_hybrid_signal(asset, timeframe)
            
            return {
                'asset': asset,
                'timeframe': timeframe,
                'direction': signal.direction,
                'strength': signal.strength,
                'confidence': signal.confidence,
                'signal_quality': signal.signal_quality,
                'risk_score': signal.risk_score,
                'position_size': signal.position_size,
                'risk_reward_ratio': signal.risk_reward_ratio,
                'market_regime': signal.market_regime,
                'component_count': len(signal.components),
                'timestamp': signal.timestamp
            }
            
        except Exception as e:
            logger.error(f"Error generating signal summary: {str(e)}")
            return {
                'asset': asset,
                'timeframe': timeframe,
                'error': str(e),
                'timestamp': datetime.now()
            }
    
    def update_signal_performance(self, asset: str, timeframe: str, 
                                actual_outcome: bool, signal_id: str):
        """Update signal performance for adaptive learning"""
        try:
            # Update component performance
            if signal_id in self.signal_cache:
                signal = self.signal_cache[signal_id]
                
                for component in signal.components:
                    self.weight_manager.update_performance(
                        asset, timeframe, component.component, 
                        actual_outcome, component.confidence
                    )
            
            logger.info(f"Updated performance for {asset} {timeframe}: {actual_outcome}")
            
        except Exception as e:
            logger.error(f"Error updating signal performance: {str(e)}")
    
    def health_check(self) -> Dict[str, Any]:
        """Service health check"""
        return {
            'status': 'healthy',
            'components_loaded': 5,
            'cache_size': len(self.signal_cache),
            'weight_manager_ready': bool(self.weight_manager.base_weights),
            'timestamp': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize service
    hybrid_service = HybridSignalService()
    
    # Generate hybrid signal for BTC
    signal = hybrid_service.generate_hybrid_signal("BTC", "4h")
    
    print("Hybrid Signal Analysis Results:")
    print("=" * 50)
    
    print(f"\nOVERALL SIGNAL:")
    print(f"Direction: {signal.direction}")
    print(f"Strength: {signal.strength:.1f}")
    print(f"Confidence: {signal.confidence:.1f}%")
    print(f"Quality: {signal.signal_quality}")
    
    print(f"\nRISK MANAGEMENT:")
    print(f"Risk Score: {signal.risk_score:.1f}")
    print(f"Position Size: {signal.position_size:.1f}%")
    print(f"Stop Loss: ${signal.stop_loss:.2f}")
    print(f"Risk/Reward: {signal.risk_reward_ratio:.2f}")
    
    print(f"\nTARGET LEVELS:")
    for i, target in enumerate(signal.target_levels, 1):
        print(f"Target {i}: ${target:.2f}")
    
    print(f"\nCOMPONENT SIGNALS ({len(signal.components)}):")
    for component in signal.components:
        print(f"- {component.component}: {component.direction} "
              f"({component.confidence:.1f}% confidence)")
    
    print(f"\nMARKET CONTEXT:")
    print(f"Market Regime: {signal.market_regime}")
    print(f"Timestamp: {signal.timestamp}")
    
    # Get signal summary
    summary = hybrid_service.get_signal_summary("BTC", "4h")
    print(f"\nSIGNAL SUMMARY:")
    print(f"Direction: {summary['direction']}")
    print(f"Strength: {summary['strength']:.1f}")
    print(f"Quality: {summary['signal_quality']}")
    print(f"Components: {summary['component_count']}")
    
    # Health check
    health = hybrid_service.health_check()
    print(f"\nService Health: {health}")
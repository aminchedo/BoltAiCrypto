"""
Backtesting Engine
Event-driven backtesting framework for trading strategies
"""

import asyncio
import logging
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import json
import copy

# Import services
from .market_data_service import MarketDataService
from .hybrid_signal_service import HybridSignalService
from .portfolio_optimization_service import PortfolioOptimizationService

logger = logging.getLogger(__name__)

class OrderType(Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"

class OrderSide(Enum):
    BUY = "buy"
    SELL = "sell"

class OrderStatus(Enum):
    PENDING = "pending"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"

@dataclass
class Order:
    id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: float
    price: Optional[float] = None
    stop_price: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.now)
    status: OrderStatus = OrderStatus.PENDING
    filled_quantity: float = 0.0
    filled_price: float = 0.0
    commission: float = 0.0

@dataclass
class Position:
    symbol: str
    quantity: float = 0.0
    avg_price: float = 0.0
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    last_price: float = 0.0

@dataclass
class Trade:
    id: str
    symbol: str
    side: OrderSide
    quantity: float
    price: float
    timestamp: datetime
    commission: float
    pnl: float = 0.0

@dataclass
class BacktestResult:
    start_date: datetime
    end_date: datetime
    initial_capital: float
    final_capital: float
    total_return: float
    annualized_return: float
    max_drawdown: float
    sharpe_ratio: float
    sortino_ratio: float
    win_rate: float
    profit_factor: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float
    avg_trade_duration: timedelta
    positions: List[Position]
    trades: List[Trade]
    equity_curve: List[Dict[str, Any]]
    drawdown_curve: List[Dict[str, Any]]
    monthly_returns: Dict[str, float]
    performance_metrics: Dict[str, Any]

class BacktestingEngine:
    """Event-driven backtesting engine"""
    
    def __init__(self, initial_capital: float = 100000.0):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        self.cash = initial_capital
        self.positions: Dict[str, Position] = {}
        self.orders: List[Order] = []
        self.trades: List[Trade] = []
        self.equity_curve: List[Dict[str, Any]] = []
        self.drawdown_curve: List[Dict[str, Any]] = []
        
        # Services
        self.market_service = MarketDataService()
        self.signal_service = HybridSignalService()
        self.portfolio_service = PortfolioOptimizationService()
        
        # Configuration
        self.commission_rate = 0.001  # 0.1% commission
        self.slippage_rate = 0.0005   # 0.05% slippage
        self.max_position_size = 0.1  # 10% max position size
        
        # Current market data
        self.current_prices: Dict[str, float] = {}
        self.current_timestamp: datetime = datetime.now()
        
        # Performance tracking
        self.peak_equity = initial_capital
        self.current_drawdown = 0.0
        self.max_drawdown = 0.0
        
    async def run_backtest(
        self,
        symbols: List[str],
        start_date: datetime,
        end_date: datetime,
        strategy_func: Callable,
        timeframe: str = "1h",
        benchmark_symbol: Optional[str] = None
    ) -> BacktestResult:
        """Run a complete backtest"""
        logger.info(f"Starting backtest from {start_date} to {end_date}")
        
        # Reset state
        self._reset_state()
        
        # Get historical data for all symbols
        historical_data = await self._get_historical_data(symbols, start_date, end_date, timeframe)
        
        if not historical_data:
            raise ValueError("No historical data available for backtesting")
        
        # Create unified timeline
        timeline = self._create_timeline(historical_data)
        
        # Run simulation
        await self._run_simulation(timeline, strategy_func, symbols)
        
        # Calculate final results
        result = self._calculate_results(start_date, end_date, benchmark_symbol)
        
        logger.info(f"Backtest completed. Total return: {result.total_return:.2%}")
        return result
    
    async def _get_historical_data(
        self,
        symbols: List[str],
        start_date: datetime,
        end_date: datetime,
        timeframe: str
    ) -> Dict[str, pd.DataFrame]:
        """Get historical data for all symbols"""
        historical_data = {}
        
        for symbol in symbols:
            try:
                # Calculate number of periods needed
                if timeframe == "1m":
                    periods = int((end_date - start_date).total_seconds() / 60)
                elif timeframe == "5m":
                    periods = int((end_date - start_date).total_seconds() / 300)
                elif timeframe == "1h":
                    periods = int((end_date - start_date).total_seconds() / 3600)
                elif timeframe == "1d":
                    periods = (end_date - start_date).days
                else:
                    periods = 1000  # Default
                
                # Get candle data
                candles = await self.market_service.get_candles(
                    symbol=symbol,
                    interval=timeframe,
                    limit=min(periods, 1000)  # API limit
                )
                
                if candles:
                    # Convert to DataFrame
                    df = pd.DataFrame(candles)
                    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                    df.set_index('timestamp', inplace=True)
                    df = df.sort_index()
                    
                    # Filter by date range
                    df = df[(df.index >= start_date) & (df.index <= end_date)]
                    
                    historical_data[symbol] = df
                    
            except Exception as e:
                logger.error(f"Error getting historical data for {symbol}: {e}")
        
        return historical_data
    
    def _create_timeline(self, historical_data: Dict[str, pd.DataFrame]) -> List[Dict[str, Any]]:
        """Create unified timeline from all symbols"""
        all_timestamps = set()
        
        # Collect all timestamps
        for symbol, df in historical_data.items():
            all_timestamps.update(df.index.tolist())
        
        # Sort timestamps
        sorted_timestamps = sorted(all_timestamps)
        
        # Create timeline events
        timeline = []
        for timestamp in sorted_timestamps:
            event = {
                'timestamp': timestamp,
                'prices': {},
                'volumes': {},
                'ohlc': {}
            }
            
            # Add price data for each symbol at this timestamp
            for symbol, df in historical_data.items():
                if timestamp in df.index:
                    row = df.loc[timestamp]
                    event['prices'][symbol] = row['close']
                    event['volumes'][symbol] = row['volume']
                    event['ohlc'][symbol] = {
                        'open': row['open'],
                        'high': row['high'],
                        'low': row['low'],
                        'close': row['close']
                    }
            
            timeline.append(event)
        
        return timeline
    
    async def _run_simulation(
        self,
        timeline: List[Dict[str, Any]],
        strategy_func: Callable,
        symbols: List[str]
    ):
        """Run the backtesting simulation"""
        for i, event in enumerate(timeline):
            self.current_timestamp = event['timestamp']
            self.current_prices.update(event['prices'])
            
            # Process pending orders
            await self._process_orders(event)
            
            # Update positions
            self._update_positions()
            
            # Calculate equity
            current_equity = self._calculate_equity()
            
            # Update drawdown
            self._update_drawdown(current_equity)
            
            # Record equity curve
            self.equity_curve.append({
                'timestamp': self.current_timestamp,
                'equity': current_equity,
                'cash': self.cash,
                'positions_value': current_equity - self.cash
            })
            
            # Record drawdown curve
            self.drawdown_curve.append({
                'timestamp': self.current_timestamp,
                'drawdown': self.current_drawdown,
                'peak_equity': self.peak_equity
            })
            
            # Generate signals and execute strategy
            try:
                # Get signals for current timestamp
                signals = await self._get_signals_for_timestamp(symbols, i, timeline)
                
                # Execute strategy
                await strategy_func(self, signals, event)
                
            except Exception as e:
                logger.error(f"Error in strategy execution at {self.current_timestamp}: {e}")
    
    async def _get_signals_for_timestamp(
        self,
        symbols: List[str],
        current_index: int,
        timeline: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Get trading signals for current timestamp"""
        signals = {}
        
        # Get recent data for signal generation
        lookback_periods = min(100, current_index + 1)
        recent_data = timeline[max(0, current_index - lookback_periods + 1):current_index + 1]
        
        for symbol in symbols:
            try:
                # Convert recent data to candles format
                candles = []
                for event in recent_data:
                    if symbol in event['ohlc']:
                        ohlc = event['ohlc'][symbol]
                        candles.append({
                            'timestamp': int(event['timestamp'].timestamp() * 1000),
                            'open': ohlc['open'],
                            'high': ohlc['high'],
                            'low': ohlc['low'],
                            'close': ohlc['close'],
                            'volume': event['volumes'].get(symbol, 0)
                        })
                
                if len(candles) >= 20:  # Minimum data for signal generation
                    signal = await self.signal_service.get_signal_for_symbol("backtest_user", symbol)
                    if signal:
                        signals[symbol] = signal
                        
            except Exception as e:
                logger.error(f"Error generating signal for {symbol}: {e}")
        
        return signals
    
    async def _process_orders(self, event: Dict[str, Any]):
        """Process pending orders"""
        filled_orders = []
        
        for order in self.orders:
            if order.status != OrderStatus.PENDING:
                continue
            
            symbol = order.symbol
            if symbol not in event['prices']:
                continue
            
            current_price = event['prices'][symbol]
            ohlc = event['ohlc'].get(symbol, {})
            
            # Check if order should be filled
            should_fill = False
            fill_price = current_price
            
            if order.order_type == OrderType.MARKET:
                should_fill = True
                # Apply slippage
                if order.side == OrderSide.BUY:
                    fill_price = current_price * (1 + self.slippage_rate)
                else:
                    fill_price = current_price * (1 - self.slippage_rate)
            
            elif order.order_type == OrderType.LIMIT:
                if order.side == OrderSide.BUY and current_price <= order.price:
                    should_fill = True
                    fill_price = order.price
                elif order.side == OrderSide.SELL and current_price >= order.price:
                    should_fill = True
                    fill_price = order.price
            
            elif order.order_type == OrderType.STOP:
                if order.side == OrderSide.BUY and current_price >= order.stop_price:
                    should_fill = True
                    fill_price = current_price * (1 + self.slippage_rate)
                elif order.side == OrderSide.SELL and current_price <= order.stop_price:
                    should_fill = True
                    fill_price = current_price * (1 - self.slippage_rate)
            
            if should_fill:
                # Execute the order
                await self._execute_order(order, fill_price)
                filled_orders.append(order)
        
        # Remove filled orders
        self.orders = [o for o in self.orders if o not in filled_orders]
    
    async def _execute_order(self, order: Order, fill_price: float):
        """Execute an order"""
        symbol = order.symbol
        quantity = order.quantity
        side = order.side
        
        # Calculate commission
        commission = fill_price * quantity * self.commission_rate
        
        # Update cash
        if side == OrderSide.BUY:
            total_cost = fill_price * quantity + commission
            if total_cost > self.cash:
                # Insufficient funds
                order.status = OrderStatus.REJECTED
                return
            self.cash -= total_cost
        else:
            total_proceeds = fill_price * quantity - commission
            self.cash += total_proceeds
        
        # Update position
        if symbol not in self.positions:
            self.positions[symbol] = Position(symbol=symbol)
        
        position = self.positions[symbol]
        
        if side == OrderSide.BUY:
            # Calculate new average price
            total_quantity = position.quantity + quantity
            if total_quantity > 0:
                position.avg_price = (
                    (position.avg_price * position.quantity + fill_price * quantity) / total_quantity
                )
            position.quantity = total_quantity
        else:
            # Calculate realized PnL
            if position.quantity > 0:
                realized_pnl = (fill_price - position.avg_price) * min(quantity, position.quantity)
                position.realized_pnl += realized_pnl
            position.quantity -= quantity
        
        # Update order status
        order.status = OrderStatus.FILLED
        order.filled_quantity = quantity
        order.filled_price = fill_price
        order.commission = commission
        
        # Create trade record
        trade = Trade(
            id=f"trade_{len(self.trades) + 1}",
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=fill_price,
            timestamp=self.current_timestamp,
            commission=commission,
            pnl=position.realized_pnl if side == OrderSide.SELL else 0.0
        )
        self.trades.append(trade)
        
        logger.debug(f"Order executed: {side.value} {quantity} {symbol} at {fill_price}")
    
    def _update_positions(self):
        """Update position values and unrealized PnL"""
        for symbol, position in self.positions.items():
            if symbol in self.current_prices:
                position.last_price = self.current_prices[symbol]
                if position.quantity != 0:
                    position.unrealized_pnl = (position.last_price - position.avg_price) * position.quantity
    
    def _calculate_equity(self) -> float:
        """Calculate current equity"""
        positions_value = sum(
            pos.quantity * pos.last_price
            for pos in self.positions.values()
            if pos.quantity > 0
        )
        return self.cash + positions_value
    
    def _update_drawdown(self, current_equity: float):
        """Update drawdown calculations"""
        if current_equity > self.peak_equity:
            self.peak_equity = current_equity
            self.current_drawdown = 0.0
        else:
            self.current_drawdown = (self.peak_equity - current_equity) / self.peak_equity
            if self.current_drawdown > self.max_drawdown:
                self.max_drawdown = self.current_drawdown
    
    def _calculate_results(
        self,
        start_date: datetime,
        end_date: datetime,
        benchmark_symbol: Optional[str] = None
    ) -> BacktestResult:
        """Calculate final backtest results"""
        final_equity = self._calculate_equity()
        total_return = (final_equity - self.initial_capital) / self.initial_capital
        
        # Calculate time period
        time_period = (end_date - start_date).days / 365.25
        annualized_return = (1 + total_return) ** (1 / time_period) - 1 if time_period > 0 else 0
        
        # Calculate returns for Sharpe ratio
        daily_returns = self._calculate_daily_returns()
        sharpe_ratio = self._calculate_sharpe_ratio(daily_returns)
        sortino_ratio = self._calculate_sortino_ratio(daily_returns)
        
        # Trade statistics
        winning_trades = [t for t in self.trades if t.pnl > 0]
        losing_trades = [t for t in self.trades if t.pnl < 0]
        
        win_rate = len(winning_trades) / len(self.trades) if self.trades else 0
        avg_win = np.mean([t.pnl for t in winning_trades]) if winning_trades else 0
        avg_loss = np.mean([t.pnl for t in losing_trades]) if losing_trades else 0
        
        profit_factor = abs(sum(t.pnl for t in winning_trades) / sum(t.pnl for t in losing_trades)) if losing_trades else float('inf')
        
        # Monthly returns
        monthly_returns = self._calculate_monthly_returns()
        
        # Performance metrics
        performance_metrics = {
            'volatility': np.std(daily_returns) * np.sqrt(252) if daily_returns else 0,
            'skewness': self._calculate_skewness(daily_returns),
            'kurtosis': self._calculate_kurtosis(daily_returns),
            'var_95': np.percentile(daily_returns, 5) if daily_returns else 0,
            'cvar_95': np.mean([r for r in daily_returns if r <= np.percentile(daily_returns, 5)]) if daily_returns else 0
        }
        
        return BacktestResult(
            start_date=start_date,
            end_date=end_date,
            initial_capital=self.initial_capital,
            final_capital=final_equity,
            total_return=total_return,
            annualized_return=annualized_return,
            max_drawdown=self.max_drawdown,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            win_rate=win_rate,
            profit_factor=profit_factor,
            total_trades=len(self.trades),
            winning_trades=len(winning_trades),
            losing_trades=len(losing_trades),
            avg_win=avg_win,
            avg_loss=avg_loss,
            largest_win=max([t.pnl for t in self.trades]) if self.trades else 0,
            largest_loss=min([t.pnl for t in self.trades]) if self.trades else 0,
            avg_trade_duration=self._calculate_avg_trade_duration(),
            positions=list(self.positions.values()),
            trades=self.trades,
            equity_curve=self.equity_curve,
            drawdown_curve=self.drawdown_curve,
            monthly_returns=monthly_returns,
            performance_metrics=performance_metrics
        )
    
    def _calculate_daily_returns(self) -> List[float]:
        """Calculate daily returns from equity curve"""
        if len(self.equity_curve) < 2:
            return []
        
        returns = []
        prev_equity = self.equity_curve[0]['equity']
        
        for point in self.equity_curve[1:]:
            current_equity = point['equity']
            daily_return = (current_equity - prev_equity) / prev_equity if prev_equity > 0 else 0
            returns.append(daily_return)
            prev_equity = current_equity
        
        return returns
    
    def _calculate_sharpe_ratio(self, returns: List[float], risk_free_rate: float = 0.02) -> float:
        """Calculate Sharpe ratio"""
        if not returns:
            return 0
        
        excess_returns = [r - risk_free_rate / 252 for r in returns]  # Daily risk-free rate
        return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252) if np.std(excess_returns) > 0 else 0
    
    def _calculate_sortino_ratio(self, returns: List[float], risk_free_rate: float = 0.02) -> float:
        """Calculate Sortino ratio"""
        if not returns:
            return 0
        
        excess_returns = [r - risk_free_rate / 252 for r in returns]
        downside_returns = [r for r in excess_returns if r < 0]
        
        if not downside_returns:
            return float('inf')
        
        downside_deviation = np.sqrt(np.mean([r**2 for r in downside_returns]))
        return np.mean(excess_returns) / downside_deviation * np.sqrt(252) if downside_deviation > 0 else 0
    
    def _calculate_monthly_returns(self) -> Dict[str, float]:
        """Calculate monthly returns"""
        monthly_returns = {}
        
        if not self.equity_curve:
            return monthly_returns
        
        # Group by month
        monthly_data = {}
        for point in self.equity_curve:
            month_key = point['timestamp'].strftime('%Y-%m')
            if month_key not in monthly_data:
                monthly_data[month_key] = []
            monthly_data[month_key].append(point['equity'])
        
        # Calculate monthly returns
        for month, equities in monthly_data.items():
            if len(equities) > 1:
                start_equity = equities[0]
                end_equity = equities[-1]
                monthly_return = (end_equity - start_equity) / start_equity if start_equity > 0 else 0
                monthly_returns[month] = monthly_return
        
        return monthly_returns
    
    def _calculate_skewness(self, returns: List[float]) -> float:
        """Calculate skewness of returns"""
        if len(returns) < 3:
            return 0
        
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        if std_return == 0:
            return 0
        
        skewness = np.mean([((r - mean_return) / std_return) ** 3 for r in returns])
        return skewness
    
    def _calculate_kurtosis(self, returns: List[float]) -> float:
        """Calculate kurtosis of returns"""
        if len(returns) < 4:
            return 0
        
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        if std_return == 0:
            return 0
        
        kurtosis = np.mean([((r - mean_return) / std_return) ** 4 for r in returns]) - 3
        return kurtosis
    
    def _calculate_avg_trade_duration(self) -> timedelta:
        """Calculate average trade duration"""
        if len(self.trades) < 2:
            return timedelta(0)
        
        # Group trades by symbol to calculate holding periods
        symbol_trades = {}
        for trade in self.trades:
            if trade.symbol not in symbol_trades:
                symbol_trades[trade.symbol] = []
            symbol_trades[trade.symbol].append(trade)
        
        durations = []
        for symbol, trades in symbol_trades.items():
            trades.sort(key=lambda t: t.timestamp)
            
            # Calculate duration between buy and sell
            position_size = 0
            entry_time = None
            
            for trade in trades:
                if trade.side == OrderSide.BUY:
                    if position_size == 0:
                        entry_time = trade.timestamp
                    position_size += trade.quantity
                else:
                    if position_size > 0 and entry_time:
                        duration = trade.timestamp - entry_time
                        durations.append(duration)
                    position_size -= trade.quantity
                    if position_size <= 0:
                        entry_time = None
        
        return np.mean(durations) if durations else timedelta(0)
    
    def _reset_state(self):
        """Reset backtesting state"""
        self.current_capital = self.initial_capital
        self.cash = self.initial_capital
        self.positions = {}
        self.orders = []
        self.trades = []
        self.equity_curve = []
        self.drawdown_curve = []
        self.current_prices = {}
        self.peak_equity = self.initial_capital
        self.current_drawdown = 0.0
        self.max_drawdown = 0.0
    
    # Trading interface methods for strategy functions
    async def buy_market(self, symbol: str, quantity: float) -> str:
        """Place a market buy order"""
        order = Order(
            id=f"order_{len(self.orders) + 1}",
            symbol=symbol,
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            quantity=quantity
        )
        self.orders.append(order)
        return order.id
    
    async def sell_market(self, symbol: str, quantity: float) -> str:
        """Place a market sell order"""
        order = Order(
            id=f"order_{len(self.orders) + 1}",
            symbol=symbol,
            side=OrderSide.SELL,
            order_type=OrderType.MARKET,
            quantity=quantity
        )
        self.orders.append(order)
        return order.id
    
    async def buy_limit(self, symbol: str, quantity: float, price: float) -> str:
        """Place a limit buy order"""
        order = Order(
            id=f"order_{len(self.orders) + 1}",
            symbol=symbol,
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            quantity=quantity,
            price=price
        )
        self.orders.append(order)
        return order.id
    
    async def sell_limit(self, symbol: str, quantity: float, price: float) -> str:
        """Place a limit sell order"""
        order = Order(
            id=f"order_{len(self.orders) + 1}",
            symbol=symbol,
            side=OrderSide.SELL,
            order_type=OrderType.LIMIT,
            quantity=quantity,
            price=price
        )
        self.orders.append(order)
        return order.id
    
    def get_position(self, symbol: str) -> Optional[Position]:
        """Get current position for a symbol"""
        return self.positions.get(symbol)
    
    def get_cash_balance(self) -> float:
        """Get current cash balance"""
        return self.cash
    
    def get_equity(self) -> float:
        """Get current equity"""
        return self._calculate_equity()
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """Get current price for a symbol"""
        return self.current_prices.get(symbol)

# Example strategy function
async def example_strategy(engine: BacktestingEngine, signals: Dict[str, Any], event: Dict[str, Any]):
    """Example trading strategy"""
    for symbol, signal in signals.items():
        current_position = engine.get_position(symbol)
        current_price = engine.get_current_price(symbol)
        
        if not current_price:
            continue
        
        # Simple signal-based strategy
        if signal['direction'] == 'BUY' and signal['confidence'] > 70:
            # Calculate position size (2% of equity)
            equity = engine.get_equity()
            position_value = equity * 0.02
            quantity = position_value / current_price
            
            # Buy if we don't have a position
            if not current_position or current_position.quantity <= 0:
                await engine.buy_market(symbol, quantity)
        
        elif signal['direction'] == 'SELL' and signal['confidence'] > 70:
            # Sell if we have a position
            if current_position and current_position.quantity > 0:
                await engine.sell_market(symbol, current_position.quantity)
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()

@router.websocket("/ws/mobile/ping")
async def mobile_ping(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            await ws.send_json({"event": "keepalive"})
            await asyncio.sleep(10)
    except WebSocketDisconnect:
        pass

"""WebSocket manager and endpoint for market data streaming."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import redis.asyncio as aioredis


logger = logging.getLogger(__name__)

router = APIRouter()


class ConnectionManager:
    """Manage WebSocket connections and Redis subscription."""

    def __init__(self, redis_url: str = "redis://localhost:6379") -> None:
        self.redis_url = redis_url
        self.active_connections: List[WebSocket] = []
        self.redis_client: Optional[aioredis.Redis] = None
        self.pubsub: Optional[aioredis.client.PubSub] = None
        self.listener_task: Optional[asyncio.Task] = None
        self.lock = asyncio.Lock()
        self.heartbeat_interval = 30

    async def _ensure_redis(self) -> None:
        if self.redis_client is None:
            self.redis_client = aioredis.from_url(self.redis_url, decode_responses=True)
            await self.redis_client.ping()

    async def connect(self, websocket: WebSocket) -> None:
        """Accept a WebSocket connection and store it."""
        await websocket.accept()
        async with self.lock:
            if len(self.active_connections) >= 1000:
                await websocket.close(code=1001)
                logger.warning("Connection limit reached")
                return
            self.active_connections.append(websocket)
            logger.debug("Client connected. Total: %s", len(self.active_connections))

        if not self.listener_task or self.listener_task.done():
            self.listener_task = asyncio.create_task(self.start_redis_subscription())

    async def disconnect(self, websocket: WebSocket) -> None:
        """Remove a WebSocket connection."""
        async with self.lock:
            if websocket in self.active_connections:
                self.active_connections.remove(websocket)
                logger.debug(
                    "Client disconnected. Total: %s", len(self.active_connections)
                )
        if not self.active_connections and self.pubsub:
            await self.pubsub.close()
            self.pubsub = None

    async def broadcast_to_all(self, message: str) -> None:
        """Send a message to all connected clients."""
        disconnected: List[WebSocket] = []
        for ws in list(self.active_connections):
            try:
                await ws.send_text(message)
            except WebSocketDisconnect:
                disconnected.append(ws)
            except Exception as exc:  # pragma: no cover - defensive
                logger.error("Error sending message: %s", exc)
        for ws in disconnected:
            await self.disconnect(ws)

    async def start_redis_subscription(self) -> None:
        """Listen for messages on the Redis 'market_data' channel."""
        while True:
            try:
                await self._ensure_redis()
                self.pubsub = self.redis_client.pubsub()
                await self.pubsub.subscribe("market_data")
                logger.info("Subscribed to Redis channel 'market_data'")
                async for msg in self.pubsub.listen():
                    if msg.get("type") == "message":
                        await self.broadcast_to_all(msg.get("data", ""))
            except Exception as exc:  # pragma: no cover - reconnect logic
                logger.error("Redis listener error: %s", exc)
                await asyncio.sleep(5)
            finally:
                if self.pubsub:
                    await self.pubsub.close()
                    self.pubsub = None
                self.redis_client = None

    async def handle_client_message(self, websocket: WebSocket, data: str) -> None:
        """Process messages received from clients."""
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            await websocket.send_json({"error": "invalid_json"})
            return
        if payload.get("action") == "ping":
            await websocket.send_json(
                {"type": "heartbeat", "timestamp": datetime.utcnow().isoformat()}
            )

    async def send_heartbeat(self, websocket: WebSocket) -> None:
        """Send periodic heartbeat messages."""
        try:
            while True:
                await websocket.send_json(
                    {
                        "type": "heartbeat",
                        "timestamp": datetime.utcnow().isoformat(),
                        "status": "connected",
                    }
                )
                await asyncio.sleep(self.heartbeat_interval)
        except Exception:
            pass


manager = ConnectionManager()


async def authenticate(websocket: WebSocket) -> bool:
    """Basic authentication using query parameter 'token'."""
    token = websocket.query_params.get("token")
    return token is not None and token != ""


@router.websocket("/ws/data-stream")
async def websocket_data_stream(websocket: WebSocket) -> None:
    """WebSocket endpoint streaming real-time market data to clients."""
    if not await authenticate(websocket):
        await websocket.close(code=1008)
        return

    await manager.connect(websocket)
    heartbeat_task = asyncio.create_task(manager.send_heartbeat(websocket))
    try:
        while True:
            data = await websocket.receive_text()
            await manager.handle_client_message(websocket, data)
    except WebSocketDisconnect:
        pass
    finally:
        heartbeat_task.cancel()
        await manager.disconnect(websocket)

"""User position tracking via WebSocket."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
import redis.asyncio as aioredis

logger = logging.getLogger(__name__)

router = APIRouter()


class PositionManager:
    """Manage user connections and position updates."""

    def __init__(self, redis_url: str = "redis://localhost:6379") -> None:
        self.redis_url = redis_url
        self.user_connections: Dict[str, WebSocket] = {}
        self.user_positions: Dict[str, List[Dict[str, Any]]] = {}
        self.redis_client: Optional[aioredis.Redis] = None
        self.pubsubs: Dict[str, aioredis.client.PubSub] = {}
        self.rate_limits: Dict[str, Dict[str, float]] = {}
        self.heartbeat_interval = 30

    async def _ensure_redis(self) -> None:
        if self.redis_client is None:
            self.redis_client = aioredis.from_url(self.redis_url, decode_responses=True)
            await self.redis_client.ping()

    async def authenticate_user(self, user_id: str) -> bool:
        """Stub authentication - accepts any non-empty user_id."""
        return bool(user_id)

    async def subscribe_to_user_channel(self, user_id: str) -> aioredis.client.PubSub:
        await self._ensure_redis()
        pubsub = self.redis_client.pubsub()
        await pubsub.subscribe(f"position_updates_{user_id}")
        self.pubsubs[user_id] = pubsub
        return pubsub

    async def calculate_pnl(self, positions: List[Dict]) -> Dict[str, float]:
        total = 0.0
        for pos in positions:
            qty = pos.get("quantity", 0.0)
            entry = pos.get("entry_price", 0.0)
            current = pos.get("current_price", entry)
            total += (current - entry) * qty
        return {"total_pnl": total}

    async def send_heartbeat(self, user_id: str) -> None:
        while True:
            ws = self.user_connections.get(user_id)
            if ws is None:
                break
            try:
                await ws.send_json(
                    {
                        "type": "heartbeat",
                        "timestamp": datetime.utcnow().isoformat(),
                        "status": "connected",
                    }
                )
                await asyncio.sleep(self.heartbeat_interval)
            except WebSocketDisconnect:
                break
            except Exception as exc:  # pragma: no cover - heartbeat errors
                logger.error("Heartbeat error for %s: %s", user_id, exc)
                break

    async def _check_rate_limit(self, user_id: str) -> bool:
        info = self.rate_limits.setdefault(
            user_id, {"count": 0, "ts": time.monotonic()}
        )
        now = time.monotonic()
        if now - info["ts"] >= 1:
            info["ts"] = now
            info["count"] = 0
        if info["count"] >= 100:
            return False
        info["count"] += 1
        return True

    async def send_to_user(self, user_id: str, message: Dict) -> None:
        if not await self._check_rate_limit(user_id):
            return
        ws = self.user_connections.get(user_id)
        if not ws:
            return
        try:
            await ws.send_json(message)
        except WebSocketDisconnect:
            await self.disconnect_user(user_id)
        except Exception as exc:  # pragma: no cover
            logger.error("Send error for %s: %s", user_id, exc)

    async def handle_position_update(self, user_id: str, update: Dict) -> None:
        logger.info("Position update for %s: %s", user_id, update)
        positions = self.user_positions.setdefault(user_id, [])
        positions.append(update)
        pnl = await self.calculate_pnl(positions)
        await self.send_to_user(
            user_id,
            {
                "type": "position_update",
                **update,
                "aggregate_pnl": pnl["total_pnl"],
            },
        )

    async def listen_to_redis(self, user_id: str) -> None:
        while True:
            try:
                pubsub = self.pubsubs.get(
                    user_id
                ) or await self.subscribe_to_user_channel(user_id)
                async for msg in pubsub.listen():
                    if msg.get("type") == "message":
                        try:
                            data = json.loads(msg.get("data", "{}"))
                            await self.handle_position_update(user_id, data)
                        except json.JSONDecodeError:
                            logger.error("Invalid JSON for %s", user_id)
            except Exception as exc:  # pragma: no cover - reconnect
                logger.error("Redis listener error for %s: %s", user_id, exc)
                await asyncio.sleep(5)
            finally:
                if user_id in self.pubsubs:
                    await self.pubsubs[user_id].close()
                    del self.pubsubs[user_id]
                self.redis_client = None

    async def connect_user(self, websocket: WebSocket, user_id: str) -> None:
        await websocket.accept()
        self.user_connections[user_id] = websocket
        asyncio.create_task(self.listen_to_redis(user_id))
        asyncio.create_task(self.send_heartbeat(user_id))

    async def disconnect_user(self, user_id: str) -> None:
        ws = self.user_connections.pop(user_id, None)
        if ws:
            try:
                await ws.close()
            except Exception:
                pass
        if user_id in self.pubsubs:
            await self.pubsubs[user_id].close()
            del self.pubsubs[user_id]


manager = PositionManager()


@router.websocket("/ws/position-updates")
async def websocket_position_updates(
    websocket: WebSocket, user_id: str = Query(...)
) -> None:
    """WebSocket endpoint for streaming user position updates."""
    if not await manager.authenticate_user(user_id):
        await websocket.close(code=1008)
        return

    await manager.connect_user(websocket, user_id)
    try:
        while True:
            data = await websocket.receive_text()
            try:
                payload = json.loads(data)
                if payload.get("action") == "ping":
                    await manager.send_to_user(
                        user_id,
                        {
                            "type": "heartbeat",
                            "timestamp": datetime.utcnow().isoformat(),
                        },
                    )
            except json.JSONDecodeError:
                await manager.send_to_user(user_id, {"error": "invalid_json"})
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect_user(user_id)

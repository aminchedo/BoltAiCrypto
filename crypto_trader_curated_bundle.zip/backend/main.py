"""
AiSmart Trader Backend
FastAPI application for AI trading platform
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from datetime import datetime
import random

# Create FastAPI app
app = FastAPI(
    title="AI Smart Trader API",
    description="Advanced AI-powered cryptocurrency trading platform",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000", 
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock market data
MOCK_SYMBOLS = ["BTC", "ETH", "BNB", "ADA", "DOT", "SOL"]

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "AI Smart Trader API",
        "version": "1.0.0",
        "status": "online",
        "frontend_url": "http://localhost:3000",
        "docs_url": "http://localhost:8000/api/docs",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "services": {
            "database": "connected",
            "market_data": "active",
            "ai_engine": "running",
            "websocket": "ready"
        },
        "uptime": "24h 15m",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/markets")
async def get_markets():
    """Get all market data"""
    markets = []
    for symbol in MOCK_SYMBOLS:
        base_price = random.uniform(100, 50000)
        change = random.uniform(-10, 10)
        
        markets.append({
            "id": symbol.lower(),
            "symbol": symbol,
            "name": f"{symbol} Token",
            "current_price": round(base_price, 2),
            "market_cap": round(base_price * random.uniform(1000000, 100000000), 2),
            "market_cap_rank": MOCK_SYMBOLS.index(symbol) + 1,
            "price_change_percentage_24h": round(change, 2),
            "total_volume": round(random.uniform(1000000, 10000000), 2),
            "high_24h": round(base_price * 1.1, 2),
            "low_24h": round(base_price * 0.9, 2),
            "circulating_supply": round(random.uniform(1000000, 1000000000), 0),
            "last_updated": datetime.now().isoformat()
        })
    
    return {
        "success": True,
        "data": {
            "markets": markets,
            "total_market_cap": sum(m["market_cap"] for m in markets),
            "total_volume_24h": sum(m["total_volume"] for m in markets),
            "market_cap_change_percentage_24h": round(random.uniform(-5, 5), 2)
        },
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/markets/{symbol}")
async def get_market_data(symbol: str):
    """Get market data for a specific symbol"""
    symbol = symbol.upper()
    
    if symbol not in MOCK_SYMBOLS:
        raise HTTPException(status_code=404, detail=f"Symbol {symbol} not found")
    
    base_price = random.uniform(100, 50000)
    change = random.uniform(-10, 10)
    
    return {
        "success": True,
        "data": {
            "symbol": symbol,
            "name": f"{symbol} Token",
            "current_price": round(base_price, 2),
            "price_change_percentage_24h": round(change, 2),
            "volume_24h": round(random.uniform(1000000, 10000000), 2),
            "market_cap": round(base_price * random.uniform(1000000, 100000000), 2),
            "high_24h": round(base_price * 1.1, 2),
            "low_24h": round(base_price * 0.9, 2),
            "timestamp": datetime.now().isoformat()
        }
    }

@app.get("/api/signals")
async def get_trading_signals():
    """Get AI trading signals"""
    signals = []
    for symbol in MOCK_SYMBOLS[:3]:
        signal_type = random.choice(["BUY", "SELL", "HOLD"])
        confidence = random.uniform(0.6, 0.95)
        
        signals.append({
            "id": f"signal_{symbol}_{int(datetime.now().timestamp())}",
            "symbol": symbol,
            "signal_type": signal_type,
            "confidence": round(confidence, 2),
            "price_target": round(random.uniform(100, 50000), 2),
            "stop_loss": round(random.uniform(90, 45000), 2),
            "created_at": datetime.now().isoformat(),
            "expires_at": datetime.now().isoformat(),
            "ai_reasoning": f"Technical analysis indicates {signal_type} signal for {symbol}"
        })
    
    return {
        "success": True,
        "data": signals,
        "timestamp": datetime.now().isoformat()
    }

@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={
            "success": False,
            "error": "Endpoint not found",
            "message": "The requested API endpoint does not exist",
            "available_endpoints": [
                "/",
                "/health", 
                "/api/markets",
                "/api/markets/{symbol}",
                "/api/signals"
            ],
            "timestamp": datetime.now().isoformat()
        }
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "Internal server error",
            "message": "An unexpected error occurred",
            "timestamp": datetime.now().isoformat()
        }
    )

if __name__ == "__main__":
    print("🚀 Starting AI Smart Trader Backend...")
    print("📊 API Documentation: http://localhost:8000/api/docs")
    print("🌐 Frontend URL: http://localhost:3000")
    
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,  # Changed to 8000 to match frontend expectations
        reload=True,
        log_level="info"
    )

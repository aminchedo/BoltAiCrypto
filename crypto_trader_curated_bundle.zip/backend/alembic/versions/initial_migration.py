"""Initial migration

Revision ID: 001
Revises: 
Create Date: 2023-07-20 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSON


# revision identifiers, used by Alembic.
revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create users table
    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('email', sa.String(), nullable=False),
        sa.Column('hashed_password', sa.String(), nullable=False),
        sa.Column('full_name', sa.String(), nullable=True),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_superuser', sa.Boolean(), default=False),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_users_email'), 'users', ['email'], unique=True)
    op.create_index(op.f('ix_users_id'), 'users', ['id'], unique=False)
    
    # Create strategies table
    op.create_table(
        'strategies',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(), nullable=False),
        sa.Column('description', sa.String(), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('components', JSON, nullable=False),
        sa.Column('connections', JSON, nullable=False),
        sa.Column('is_active', sa.Boolean(), default=False),
        sa.Column('symbol', sa.String(), nullable=True),
        sa.Column('timeframe', sa.String(), nullable=True),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(), default=sa.func.now(), onupdate=sa.func.now()),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_strategies_id'), 'strategies', ['id'], unique=False)
    
    # Create backtest_results table
    op.create_table(
        'backtest_results',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('strategy_id', sa.Integer(), nullable=False),
        sa.Column('start_date', sa.DateTime(), nullable=False),
        sa.Column('end_date', sa.DateTime(), nullable=False),
        sa.Column('symbol', sa.String(), nullable=False),
        sa.Column('timeframe', sa.String(), nullable=False),
        sa.Column('trades', JSON, nullable=False),
        sa.Column('metrics', JSON, nullable=False),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.ForeignKeyConstraint(['strategy_id'], ['strategies.id'], ),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_backtest_results_id'), 'backtest_results', ['id'], unique=False)
    
    # Create trading_sessions table
    op.create_table(
        'trading_sessions',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('strategy_id', sa.Integer(), nullable=False),
        sa.Column('start_time', sa.DateTime(), default=sa.func.now()),
        sa.Column('end_time', sa.DateTime(), nullable=True),
        sa.Column('status', sa.String(), default='ACTIVE'),
        sa.Column('trades', JSON, default=list),
        sa.Column('metrics', JSON, default=dict),
        sa.ForeignKeyConstraint(['strategy_id'], ['strategies.id'], ),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_trading_sessions_id'), 'trading_sessions', ['id'], unique=False)
    
    # Create trades table
    op.create_table(
        'trades',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('session_id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(), nullable=False),
        sa.Column('direction', sa.String(), nullable=False),
        sa.Column('entry_price', sa.Float(), nullable=False),
        sa.Column('entry_time', sa.DateTime(), nullable=False),
        sa.Column('exit_price', sa.Float(), nullable=True),
        sa.Column('exit_time', sa.DateTime(), nullable=True),
        sa.Column('quantity', sa.Float(), nullable=False),
        sa.Column('profit', sa.Float(), nullable=True),
        sa.Column('profit_percentage', sa.Float(), nullable=True),
        sa.Column('status', sa.String(), default='OPEN'),
        sa.Column('exit_reason', sa.String(), nullable=True),
        sa.ForeignKeyConstraint(['session_id'], ['trading_sessions.id'], ),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_trades_id'), 'trades', ['id'], unique=False)
    
    # Create market data tables
    op.create_table(
        'ohlcv',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(), nullable=False),
        sa.Column('exchange', sa.String(), nullable=False),
        sa.Column('timeframe', sa.String(), nullable=False),
        sa.Column('timestamp', sa.DateTime(), nullable=False),
        sa.Column('open', sa.Float(), nullable=False),
        sa.Column('high', sa.Float(), nullable=False),
        sa.Column('low', sa.Float(), nullable=False),
        sa.Column('close', sa.Float(), nullable=False),
        sa.Column('volume', sa.Float(), nullable=False),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_ohlcv_id'), 'ohlcv', ['id'], unique=False)
    op.create_index(op.f('ix_ohlcv_symbol'), 'ohlcv', ['symbol'], unique=False)
    op.create_index(op.f('ix_ohlcv_exchange'), 'ohlcv', ['exchange'], unique=False)
    op.create_index(op.f('ix_ohlcv_timestamp'), 'ohlcv', ['timestamp'], unique=False)
    
    op.create_table(
        'orderbooks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(), nullable=False),
        sa.Column('exchange', sa.String(), nullable=False),
        sa.Column('timestamp', sa.DateTime(), nullable=False),
        sa.Column('bids', JSON, nullable=False),
        sa.Column('asks', JSON, nullable=False),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_orderbooks_id'), 'orderbooks', ['id'], unique=False)
    op.create_index(op.f('ix_orderbooks_symbol'), 'orderbooks', ['symbol'], unique=False)
    op.create_index(op.f('ix_orderbooks_exchange'), 'orderbooks', ['exchange'], unique=False)
    op.create_index(op.f('ix_orderbooks_timestamp'), 'orderbooks', ['timestamp'], unique=False)
    
    op.create_table(
        'trades',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(), nullable=False),
        sa.Column('exchange', sa.String(), nullable=False),
        sa.Column('timestamp', sa.DateTime(), nullable=False),
        sa.Column('price', sa.Float(), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('side', sa.String(), nullable=False),
        sa.Column('trade_id', sa.String(), nullable=False),
        sa.Column('created_at', sa.DateTime(), default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_trades_id'), 'trades', ['id'], unique=False)
    op.create_index(op.f('ix_trades_symbol'), 'trades', ['symbol'], unique=False)
    op.create_index(op.f('ix_trades_exchange'), 'trades', ['exchange'], unique=False)
    op.create_index(op.f('ix_trades_timestamp'), 'trades', ['timestamp'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_trades_timestamp'), table_name='trades')
    op.drop_index(op.f('ix_trades_exchange'), table_name='trades')
    op.drop_index(op.f('ix_trades_symbol'), table_name='trades')
    op.drop_index(op.f('ix_trades_id'), table_name='trades')
    op.drop_table('trades')
    
    op.drop_index(op.f('ix_orderbooks_timestamp'), table_name='orderbooks')
    op.drop_index(op.f('ix_orderbooks_exchange'), table_name='orderbooks')
    op.drop_index(op.f('ix_orderbooks_symbol'), table_name='orderbooks')
    op.drop_index(op.f('ix_orderbooks_id'), table_name='orderbooks')
    op.drop_table('orderbooks')
    
    op.drop_index(op.f('ix_ohlcv_timestamp'), table_name='ohlcv')
    op.drop_index(op.f('ix_ohlcv_exchange'), table_name='ohlcv')
    op.drop_index(op.f('ix_ohlcv_symbol'), table_name='ohlcv')
    op.drop_index(op.f('ix_ohlcv_id'), table_name='ohlcv')
    op.drop_table('ohlcv')
    
    op.drop_index(op.f('ix_trades_id'), table_name='trades')
    op.drop_table('trades')
    
    op.drop_index(op.f('ix_trading_sessions_id'), table_name='trading_sessions')
    op.drop_table('trading_sessions')
    
    op.drop_index(op.f('ix_backtest_results_id'), table_name='backtest_results')
    op.drop_table('backtest_results')
    
    op.drop_index(op.f('ix_strategies_id'), table_name='strategies')
    op.drop_table('strategies')
    
    op.drop_index(op.f('ix_users_id'), table_name='users')
    op.drop_index(op.f('ix_users_email'), table_name='users')
    op.drop_table('users')
"""
Tests for the data normalization layer.

This module contains tests for the data normalization service and exchange adapters.
"""
import pytest
from datetime import datetime
from app.services.normalization import NormalizationService
from app.services.exchange.binance import BinanceAdapter
from app.services.exchange.coinbase import CoinbaseAdapter

@pytest.fixture
def normalization_service():
    """Fixture for normalization service."""
    return NormalizationService()

@pytest.fixture
def binance_adapter():
    """Fixture for Binance adapter."""
    return BinanceAdapter()

@pytest.fixture
def coinbase_adapter():
    """Fixture for Coinbase adapter."""
    return CoinbaseAdapter()

@pytest.mark.asyncio
async def test_binance_ohlcv_normalization(binance_adapter):
    """Test OHLCV normalization for Binance."""
    # Sample Binance OHLCV data (array format)
    raw_data = [
        1499040000000,      # Open time
        "0.01634790",       # Open
        "0.80000000",       # High
        "0.01575800",       # Low
        "0.01577100",       # Close
        "148976.11427815",  # Volume
        1499644799999,      # Close time
        "2434.19055334",    # Quote asset volume
        308,                # Number of trades
        "1756.87402397",    # Taker buy base asset volume
        "28.46694368",      # Taker buy quote asset volume
        "0"                 # Ignore
    ]
    
    symbol = "BTCUSDT"
    timeframe = "1h"
    
    # Normalize data
    normalized = await binance_adapter.normalize_ohlcv(raw_data, symbol, timeframe)
    
    # Verify normalization
    assert normalized.symbol == "BTC/USDT"
    assert normalized.exchange == "binance"
    assert normalized.timeframe == "1h"
    assert normalized.open == 0.01634790
    assert normalized.high == 0.80000000
    assert normalized.low == 0.01575800
    assert normalized.close == 0.01577100
    assert normalized.volume == 148976.11427815
    assert normalized.quote_volume == 2434.19055334
    assert normalized.trades == 308
    assert normalized.raw_data == raw_data

@pytest.mark.asyncio
async def test_binance_orderbook_normalization(binance_adapter):
    """Test order book normalization for Binance."""
    # Sample Binance order book data
    raw_data = {
        "lastUpdateId": 1027024,
        "bids": [
            ["4.00000000", "431.00000000"],  # [price, quantity]
            ["3.99000000", "211.00000000"]
        ],
        "asks": [
            ["4.00000200", "12.00000000"],
            ["4.10000000", "18.00000000"]
        ]
    }
    
    symbol = "ETHBTC"
    
    # Normalize data
    normalized = await binance_adapter.normalize_orderbook(raw_data, symbol)
    
    # Verify normalization
    assert normalized.symbol == "ETH/BTC"
    assert normalized.exchange == "binance"
    assert len(normalized.bids) == 2
    assert len(normalized.asks) == 2
    assert normalized.bids[0][0] == 4.0
    assert normalized.bids[0][1] == 431.0
    assert normalized.asks[0][0] == 4.00000200
    assert normalized.asks[0][1] == 12.0
    assert normalized.bid_volume == 431.0 + 211.0
    assert normalized.ask_volume == 12.0 + 18.0
    assert normalized.spread == 4.00000200 - 4.0
    assert normalized.mid_price == (4.00000200 + 4.0) / 2
    assert normalized.raw_data == raw_data

@pytest.mark.asyncio
async def test_coinbase_ohlcv_normalization(coinbase_adapter):
    """Test OHLCV normalization for Coinbase."""
    # Sample Coinbase OHLCV data (array format)
    raw_data = [
        1499040000,      # Unix timestamp
        0.01634790,      # Low
        0.80000000,      # High
        0.01575800,      # Open
        0.01577100,      # Close
        148976.11427815  # Volume
    ]
    
    symbol = "BTC-USD"
    timeframe = "3600"  # 1 hour in seconds
    
    # Normalize data
    normalized = await coinbase_adapter.normalize_ohlcv(raw_data, symbol, timeframe)
    
    # Verify normalization
    assert normalized.symbol == "BTC/USD"
    assert normalized.exchange == "coinbase"
    assert normalized.timeframe == "1h"
    assert normalized.open == 0.01575800
    assert normalized.high == 0.80000000
    assert normalized.low == 0.01634790
    assert normalized.close == 0.01577100
    assert normalized.volume == 148976.11427815
    assert normalized.raw_data == raw_data

@pytest.mark.asyncio
async def test_coinbase_orderbook_normalization(coinbase_adapter):
    """Test order book normalization for Coinbase."""
    # Sample Coinbase order book data
    raw_data = {
        "sequence": 3,
        "bids": [
            [ "295.96", "4.39088265", 2 ],  # price, size, num-orders
            [ "295.95", "0.89088265", 1 ]
        ],
        "asks": [
            [ "295.97", "25.23542881", 12 ],
            [ "295.98", "12.52906337", 6 ]
        ]
    }
    
    symbol = "BTC-USD"
    
    # Normalize data
    normalized = await coinbase_adapter.normalize_orderbook(raw_data, symbol)
    
    # Verify normalization
    assert normalized.symbol == "BTC/USD"
    assert normalized.exchange == "coinbase"
    assert len(normalized.bids) == 2
    assert len(normalized.asks) == 2
    assert normalized.bids[0][0] == 295.96
    assert normalized.bids[0][1] == 4.39088265
    assert normalized.asks[0][0] == 295.97
    assert normalized.asks[0][1] == 25.23542881
    assert normalized.bid_volume == 4.39088265 + 0.89088265
    assert normalized.ask_volume == 25.23542881 + 12.52906337
    assert normalized.spread == 295.97 - 295.96
    assert normalized.mid_price == (295.97 + 295.96) / 2
    assert normalized.raw_data == raw_data

@pytest.mark.asyncio
async def test_normalization_service(normalization_service):
    """Test normalization service."""
    # Test getting supported exchanges
    exchanges = normalization_service.get_supported_exchanges()
    assert len(exchanges) == 2
    assert any(e.id == "binance" for e in exchanges)
    assert any(e.id == "coinbase" for e in exchanges)
    
    # Test getting adapters
    binance_adapter = normalization_service.get_adapter("binance")
    assert binance_adapter is not None
    assert binance_adapter.exchange_id == "binance"
    
    coinbase_adapter = normalization_service.get_adapter("coinbase")
    assert coinbase_adapter is not None
    assert coinbase_adapter.exchange_id == "coinbase"
    
    # Test symbol standardization
    assert normalization_service.standardize_symbol("binance", "BTCUSDT") == "BTC/USDT"
    assert normalization_service.standardize_symbol("coinbase", "BTC-USD") == "BTC/USD"
    
    # Test timeframe standardization
    assert normalization_service.standardize_timeframe("binance", "1h") == "1h"
    assert normalization_service.standardize_timeframe("coinbase", "3600") == "1h"
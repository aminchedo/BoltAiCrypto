"""
Test database connections for AiSmart Trader.
"""
import asyncio
import pytest
from datetime import datetime, timezone
import json

from app.core.db_config import (
    check_postgres_health,
    check_timescale_health,
    check_redis_health,
    RedisCache,
    TimeseriesDB
)

@pytest.mark.asyncio
async def test_postgres_connection():
    """Test PostgreSQL connection."""
    result = await check_postgres_health()
    assert result["status"] == "healthy"
    assert result["database"] == "postgres"

@pytest.mark.asyncio
async def test_timescale_connection():
    """Test TimescaleDB connection."""
    result = await check_timescale_health()
    assert result["status"] == "healthy"
    assert result["database"] == "timescaledb"

@pytest.mark.asyncio
async def test_redis_connection():
    """Test Redis connection."""
    result = await check_redis_health()
    assert result["status"] == "healthy"
    assert result["database"] == "redis"

@pytest.mark.asyncio
async def test_redis_cache_operations():
    """Test Redis cache operations."""
    # Test set and get
    key = "test:key"
    value = "test_value"
    
    await RedisCache.set(key, value, expire=60)
    result = await RedisCache.get(key)
    
    assert result == value
    
    # Test exists
    exists = await RedisCache.exists(key)
    assert exists is True
    
    # Test delete
    await RedisCache.delete(key)
    exists = await RedisCache.exists(key)
    assert exists is False
    
    # Test hash operations
    hash_key = "test:hash"
    hash_data = {
        "field1": "value1",
        "field2": "value2"
    }
    
    await RedisCache.hash_set(hash_key, hash_data)
    result = await RedisCache.hash_get(hash_key, "field1")
    assert result == "value1"
    
    all_data = await RedisCache.hash_get_all(hash_key)
    assert all_data == hash_data
    
    await RedisCache.delete(hash_key)

@pytest.mark.asyncio
async def test_timeseries_operations():
    """Test TimescaleDB operations."""
    # Test market data insertion
    now = datetime.now(timezone.utc)
    market_data = {
        "time": now,
        "symbol": "BTC/USDT",
        "exchange": "binance",
        "open": 50000.0,
        "high": 51000.0,
        "low": 49000.0,
        "close": 50500.0,
        "volume": 100.5,
        "quote_volume": 5050000.0,
        "trades": 1000,
        "timeframe": "1h"
    }
    
    result = await TimeseriesDB.insert_market_data(market_data)
    assert result is True
    
    # Test orderbook insertion
    orderbook_data = {
        "time": now,
        "symbol": "BTC/USDT",
        "exchange": "binance",
        "bids": json.dumps([[50000.0, 1.5], [49900.0, 2.0]]),
        "asks": json.dumps([[50100.0, 1.0], [50200.0, 3.0]]),
        "bid_volume": 3.5,
        "ask_volume": 4.0,
        "spread": 100.0
    }
    
    result = await TimeseriesDB.insert_orderbook(orderbook_data)
    assert result is True
    
    # Test trade insertion
    trade_data = {
        "time": now,
        "symbol": "BTC/USDT",
        "exchange": "binance",
        "trade_id": "123456789",
        "price": 50050.0,
        "amount": 0.1,
        "side": "buy",
        "is_liquidation": False
    }
    
    result = await TimeseriesDB.insert_trade(trade_data)
    assert result is True
    
    # Test OHLCV retrieval
    start_time = now.replace(hour=now.hour - 1)
    end_time = now
    
    ohlcv_data = await TimeseriesDB.get_ohlcv(
        symbol="BTC/USDT",
        exchange="binance",
        timeframe="1h",
        start_time=start_time.isoformat(),
        end_time=end_time.isoformat(),
        limit=10
    )
    
    assert len(ohlcv_data) > 0
    assert ohlcv_data[0]["symbol"] == "BTC/USDT"
    assert ohlcv_data[0]["exchange"] == "binance"

if __name__ == "__main__":
    asyncio.run(test_postgres_connection())
    asyncio.run(test_timescale_connection())
    asyncio.run(test_redis_connection())
    asyncio.run(test_redis_cache_operations())
    asyncio.run(test_timeseries_operations())
    print("All database connection tests passed!")
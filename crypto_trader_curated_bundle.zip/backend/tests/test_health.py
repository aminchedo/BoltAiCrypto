import pytest
from fastapi.testclient import TestClient

def test_health_check(client: TestClient):
    """
    Test health check endpoint.
    """
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"
    assert "version" in response.json()

@pytest.mark.asyncio
async def test_api_health_check(client: TestClient):
    """
    Test API health check endpoint.
    """
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"
    assert "database" in response.json()